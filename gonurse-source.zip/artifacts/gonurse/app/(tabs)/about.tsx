import { MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

const FEATURES = [
  {
    icon: "shield-check" as const,
    title: "ممرضون موثوقون",
    desc: "جميع الممرضين المسجلين خضعوا للتحقق والاعتماد.",
  },
  {
    icon: "clock-fast" as const,
    title: "استجابة سريعة",
    desc: "تواصل مباشر مع الممرض عبر واتساب في ثوانٍ.",
  },
  {
    icon: "home-heart" as const,
    title: "رعاية في المنزل",
    desc: "احصل على الرعاية الصحية الكاملة في راحة منزلك.",
  },
  {
    icon: "star-circle" as const,
    title: "نظام تقييم شفاف",
    desc: "قيّم الممرض بعد الخدمة لمساعدة المرضى الآخرين.",
  },
];

export default function AboutScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topPad + 20, paddingBottom: insets.bottom + 40 },
      ]}
      showsVerticalScrollIndicator={false}
    >
      {/* Hero */}
      <View
        style={[styles.heroCard, { backgroundColor: colors.primary }]}
      >
        <MaterialCommunityIcons
          name="hospital-box-outline"
          size={64}
          color="#fff"
        />
        <Text style={styles.heroTitle}>GoNurse</Text>
        <Text style={styles.heroSubtitle}>
          المنصة الأولى للتمريض المنزلي الموثوق
        </Text>
      </View>

      {/* Mission */}
      <View
        style={[
          styles.missionCard,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Text style={[styles.missionTitle, { color: colors.primary }]}>
          رسالتنا
        </Text>
        <Text style={[styles.missionText, { color: colors.foreground }]}>
          نؤمن بأن كل شخص يستحق رعاية صحية عالية الجودة في منزله. GoNurse
          يربط المرضى بممرضين مؤهلين وموثوقين في منطقتهم، مما يجعل الرعاية
          المنزلية ميسورة وسهلة.
        </Text>
      </View>

      {/* Features */}
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        ما يميّزنا
      </Text>

      {FEATURES.map((f) => (
        <View
          key={f.title}
          style={[
            styles.featureRow,
            { backgroundColor: colors.card, borderColor: colors.border },
          ]}
        >
          <MaterialCommunityIcons
            name={f.icon}
            size={32}
            color={colors.primary}
          />
          <View style={styles.featureText}>
            <Text style={[styles.featureTitle, { color: colors.foreground }]}>
              {f.title}
            </Text>
            <Text
              style={[styles.featureDesc, { color: colors.mutedForeground }]}
            >
              {f.desc}
            </Text>
          </View>
        </View>
      ))}

      {/* Footer note */}
      <Text style={[styles.footer, { color: colors.mutedForeground }]}>
        GoNurse © 2025 — جميع الحقوق محفوظة
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: {
    paddingHorizontal: 16,
    gap: 14,
  },
  heroCard: {
    borderRadius: 16,
    padding: 32,
    alignItems: "center",
    gap: 8,
  },
  heroTitle: {
    color: "#fff",
    fontSize: 30,
    fontFamily: "Inter_700Bold",
    letterSpacing: 1,
  },
  heroSubtitle: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  missionCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 20,
    gap: 10,
  },
  missionTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
  },
  missionText: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    lineHeight: 24,
    textAlign: "right",
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    textAlign: "right",
    marginTop: 4,
  },
  featureRow: {
    flexDirection: "row-reverse",
    alignItems: "flex-start",
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    gap: 14,
  },
  featureText: {
    flex: 1,
    gap: 4,
  },
  featureTitle: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    textAlign: "right",
  },
  featureDesc: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 18,
    textAlign: "right",
  },
  footer: {
    textAlign: "center",
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 12,
  },
});

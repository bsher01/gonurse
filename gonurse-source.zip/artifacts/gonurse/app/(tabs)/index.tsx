import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import LocationPicker from "@/components/LocationPicker";
import NurseCard from "@/components/NurseCard";
import RatingModal from "@/components/RatingModal";
import { COUNTRY_CITIES, COUNTRIES } from "@/constants/locations";
import { Nurse, fetchApprovedNurses, rateNurse } from "@/constants/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";
import { useQuery, useQueryClient } from "@tanstack/react-query";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { nurseId } = useAuth();
  const queryClient = useQueryClient();

  const [country, setCountry] = useState(COUNTRIES[0]);
  const [city, setCity] = useState(COUNTRY_CITIES[COUNTRIES[0]][0]);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [ratingNurse, setRatingNurse] = useState<Nurse | null>(null);

  const {
    data: nurses = [],
    isLoading,
    isError,
    refetch,
    isRefetching,
  } = useQuery({
    queryKey: ["nurses", country, city],
    queryFn: () => fetchApprovedNurses(country, city),
  });

  const handleCountrySelect = useCallback(
    (c: string) => {
      setCountry(c);
      setCity(COUNTRY_CITIES[c][0]);
    },
    []
  );

  const handleRateSubmit = useCallback(
    async (stars: number) => {
      if (!ratingNurse) return;
      await rateNurse(
        ratingNurse.id,
        ratingNurse.rating,
        ratingNurse.ratingCount,
        stars
      );
      await queryClient.invalidateQueries({ queryKey: ["nurses", country, city] });
    },
    [ratingNurse, country, city, queryClient]
  );

  const topPad =
    Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Custom Header */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.primary,
            paddingTop: topPad + 10,
          },
        ]}
      >
        <View style={styles.headerInner}>
          <View style={styles.logoArea}>
            <MaterialCommunityIcons
              name="hospital-box"
              size={26}
              color="#fff"
            />
            <Text style={styles.logoText}>GoNurse</Text>
          </View>

          <View style={styles.filtersRow}>
            <TouchableOpacity
              style={styles.filterChip}
              onPress={() => {
                Haptics.selectionAsync();
                setShowCityPicker(true);
              }}
            >
              <Ionicons name="location-sharp" size={13} color="rgba(255,255,255,0.8)" />
              <Text style={styles.filterChipText} numberOfLines={1}>
                {city}
              </Text>
              <Ionicons name="chevron-down" size={13} color="rgba(255,255,255,0.8)" />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.filterChip, styles.filterChipBold]}
              onPress={() => {
                Haptics.selectionAsync();
                setShowCountryPicker(true);
              }}
            >
              <Text style={styles.filterChipTextBold} numberOfLines={1}>
                {country}
              </Text>
              <Ionicons name="chevron-down" size={13} color="#fff" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.profileBtn}
            onPress={() => {
              Haptics.selectionAsync();
              if (nurseId) {
                router.push("/edit-profile");
              } else {
                router.push("/auth");
              }
            }}
          >
            <Ionicons
              name={nurseId ? "person-circle" : "person-circle-outline"}
              size={34}
              color="#fff"
            />
            {nurseId && (
              <View style={[styles.onlineDot, { backgroundColor: "#4ade80" }]} />
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Content */}
      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
            جاري التحميل...
          </Text>
        </View>
      ) : isError ? (
        <View style={styles.center}>
          <Ionicons name="cloud-offline-outline" size={48} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            خطأ في التحميل
          </Text>
          <TouchableOpacity
            style={[styles.retryBtn, { backgroundColor: colors.primary }]}
            onPress={() => refetch()}
          >
            <Text style={styles.retryText}>إعادة المحاولة</Text>
          </TouchableOpacity>
        </View>
      ) : nurses.length === 0 ? (
        <View style={styles.center}>
          <Ionicons
            name="people-outline"
            size={56}
            color={colors.mutedForeground}
          />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            لا يوجد ممرضون
          </Text>
          <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
            {`لا يوجد ممرضون مسجلون في ${country} - ${city}`}
          </Text>
        </View>
      ) : (
        <FlatList
          data={nurses}
          keyExtractor={(n) => n.id}
          renderItem={({ item }) => (
            <NurseCard
              nurse={item}
              onRate={(n) => setRatingNurse(n)}
            />
          )}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={refetch}
              tintColor={colors.primary}
              colors={[colors.primary]}
            />
          }
        />
      )}

      <LocationPicker
        visible={showCountryPicker}
        title="اختر الدولة"
        options={COUNTRIES}
        selected={country}
        onSelect={handleCountrySelect}
        onClose={() => setShowCountryPicker(false)}
      />
      <LocationPicker
        visible={showCityPicker}
        title="اختر المدينة"
        options={COUNTRY_CITIES[country]}
        selected={city}
        onSelect={setCity}
        onClose={() => setShowCityPicker(false)}
      />

      {ratingNurse && (
        <RatingModal
          visible={!!ratingNurse}
          nurseName={ratingNurse.name}
          onClose={() => setRatingNurse(null)}
          onSubmit={handleRateSubmit}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
  },
  headerInner: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
    gap: 8,
  },
  logoArea: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
  },
  logoText: {
    color: "#fff",
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    letterSpacing: 0.5,
  },
  filtersRow: {
    flex: 1,
    flexDirection: "row-reverse",
    gap: 6,
    justifyContent: "flex-start",
  },
  filterChip: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(255,255,255,0.18)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  filterChipBold: {
    backgroundColor: "rgba(255,255,255,0.28)",
  },
  filterChipText: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    maxWidth: 60,
  },
  filterChipTextBold: {
    color: "#fff",
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    maxWidth: 70,
  },
  profileBtn: {
    position: "relative",
  },
  onlineDot: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: "#8B0000",
  },
  list: {
    paddingVertical: 12,
    paddingBottom: 100,
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  loadingText: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
  },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  retryBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 4,
  },
  retryText: {
    color: "#fff",
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
  },
});

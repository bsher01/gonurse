import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import LocationPicker from "@/components/LocationPicker";
import { COUNTRY_CITIES, COUNTRIES } from "@/constants/locations";
import { fetchNurseById, updateNurse } from "@/constants/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";

export default function EditProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { nurseId, logout } = useAuth();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [country, setCountry] = useState(COUNTRIES[0]);
  const [city, setCity] = useState(COUNTRY_CITIES[COUNTRIES[0]][0]);
  const [imageUrl, setImageUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [rating, setRating] = useState(5.0);
  const [ratingCount, setRatingCount] = useState(1);
  const [passwordHash, setPasswordHash] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  useEffect(() => {
    if (!nurseId) return;
    fetchNurseById(nurseId).then((data) => {
      if (data) {
        setName((data["name"] as string) ?? "");
        setPhone((data["phone"] as string) ?? "");
        setSpecialty((data["specialty"] as string) ?? "");
        setCountry((data["country"] as string) ?? COUNTRIES[0]);
        setCity((data["city"] as string) ?? COUNTRY_CITIES[COUNTRIES[0]][0]);
        setImageUrl((data["imageUrl"] as string) ?? "");
        setRating(Number(data["rating"] ?? 5.0));
        setRatingCount(Number(data["ratingCount"] ?? 1));
        setPasswordHash((data["password_hash"] as string) ?? "");
      }
      setLoading(false);
    });
  }, [nurseId]);

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("إذن مطلوب", "يرجى السماح بالوصول إلى مكتبة الصور.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.3,
      base64: true,
    });
    if (!result.canceled && result.assets[0].base64) {
      const b64 = result.assets[0].base64;
      if (b64.length > 1500000) {
        Alert.alert("الصورة كبيرة جداً", "اختر صورة أصغر حجماً.");
        return;
      }
      setImageUrl(`data:image/jpeg;base64,${b64}`);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }

  async function handleSave() {
    if (!nurseId) return;
    setSaving(true);
    try {
      await updateNurse(nurseId, {
        name: name.trim(),
        phone: phone.trim(),
        specialty: specialty.trim(),
        country,
        city,
        imageUrl,
        role: "ممرض",
        status: "approved",
        rating,
        ratingCount,
        password_hash: passwordHash,
      });
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      Alert.alert("خطأ", "فشل في حفظ التغييرات. حاول مجدداً.");
    } finally {
      setSaving(false);
    }
  }

  async function handleLogout() {
    Alert.alert("تسجيل الخروج", "هل تريد تسجيل الخروج؟", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "خروج",
        style: "destructive",
        onPress: async () => {
          await logout();
          await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          router.back();
        },
      },
    ]);
  }

  const inputStyle = [
    styles.input,
    { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground },
  ];
  const labelStyle = [styles.label, { color: colors.mutedForeground }];

  const avatarSource = imageUrl
    ? { uri: imageUrl }
    : { uri: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png" };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[styles.header, { backgroundColor: colors.primary, paddingTop: topPad + 10 }]}
      >
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>لوحة تحكم بياناتي</Text>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={[
            styles.form,
            { paddingBottom: insets.bottom + 40 },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Status badge */}
          <View style={[styles.badge, { backgroundColor: "#dcfce7", borderColor: "#86efac" }]}>
            <Ionicons name="checkmark-circle" size={20} color="#16a34a" />
            <Text style={[styles.badgeText, { color: "#16a34a" }]}>
              حسابك معتمد ويظهر للمرضى تلقائياً
            </Text>
          </View>

          {/* Avatar */}
          <TouchableOpacity style={styles.avatarArea} onPress={pickImage}>
            <Image source={avatarSource} style={styles.avatar} />
            <View style={[styles.cameraOverlay, { backgroundColor: colors.primary }]}>
              <MaterialCommunityIcons name="camera-outline" size={16} color="#fff" />
            </View>
          </TouchableOpacity>

          {/* Rating display */}
          <View style={[styles.ratingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="star" size={20} color={colors.star} />
            <Text style={[styles.ratingNum, { color: colors.foreground }]}>
              {rating.toFixed(1)}
            </Text>
            <Text style={[styles.ratingLabel, { color: colors.mutedForeground }]}>
              ({ratingCount} تقييم)
            </Text>
          </View>

          {/* Name */}
          <View style={styles.field}>
            <Text style={labelStyle}>الاسم الكامل</Text>
            <TextInput
              style={inputStyle}
              value={name}
              onChangeText={setName}
              textAlign="right"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>

          {/* Phone */}
          <View style={styles.field}>
            <Text style={labelStyle}>رقم الهاتف</Text>
            <TextInput
              style={inputStyle}
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              textAlign="right"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>

          {/* Country */}
          <View style={styles.field}>
            <Text style={labelStyle}>الدولة</Text>
            <TouchableOpacity
              style={[styles.pickerBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => setShowCountryPicker(true)}
            >
              <Ionicons name="chevron-down" size={18} color={colors.mutedForeground} />
              <Text style={[styles.pickerBtnText, { color: colors.foreground }]}>
                {country}
              </Text>
            </TouchableOpacity>
          </View>

          {/* City */}
          <View style={styles.field}>
            <Text style={labelStyle}>المدينة</Text>
            <TouchableOpacity
              style={[styles.pickerBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => setShowCityPicker(true)}
            >
              <Ionicons name="chevron-down" size={18} color={colors.mutedForeground} />
              <Text style={[styles.pickerBtnText, { color: colors.foreground }]}>
                {city}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Specialty */}
          <View style={styles.field}>
            <Text style={labelStyle}>النبذة الطبية والتخصص</Text>
            <TextInput
              style={[inputStyle, styles.textArea]}
              value={specialty}
              onChangeText={setSpecialty}
              multiline
              numberOfLines={4}
              textAlign="right"
              textAlignVertical="top"
              placeholderTextColor={colors.mutedForeground}
            />
          </View>

          {/* Save */}
          <TouchableOpacity
            style={[styles.saveBtn, { backgroundColor: colors.primary }]}
            onPress={handleSave}
            disabled={saving}
            activeOpacity={0.85}
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.saveBtnText}>حفظ التغييرات</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      )}

      <LocationPicker
        visible={showCountryPicker}
        title="اختر الدولة"
        options={COUNTRIES}
        selected={country}
        onSelect={(c) => {
          setCountry(c);
          setCity(COUNTRY_CITIES[c][0]);
        }}
        onClose={() => setShowCountryPicker(false)}
      />
      <LocationPicker
        visible={showCityPicker}
        title="اختر المدينة"
        options={COUNTRY_CITIES[country]}
        selected={city}
        onSelect={setCity}
        onClose={() => setShowCityPicker(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
  },
  backBtn: { width: 40, alignItems: "flex-start" },
  headerTitle: {
    flex: 1,
    color: "#fff",
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  logoutBtn: { width: 40, alignItems: "flex-end" },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  form: { paddingHorizontal: 20, paddingTop: 24, gap: 16 },
  badge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    textAlign: "right",
    flex: 1,
  },
  avatarArea: {
    alignSelf: "center",
    position: "relative",
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#f0f0f0",
  },
  cameraOverlay: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  ratingCard: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  ratingNum: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  ratingLabel: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
  field: { gap: 6 },
  label: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    textAlign: "right",
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  textArea: { height: 100, paddingTop: 12 },
  pickerBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  pickerBtnText: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  saveBtn: {
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 8,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
});

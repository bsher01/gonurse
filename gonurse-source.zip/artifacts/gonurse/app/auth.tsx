import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import LocationPicker from "@/components/LocationPicker";
import { COUNTRY_CITIES, COUNTRIES } from "@/constants/locations";
import { loginNurse, registerNurse } from "@/constants/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { useColors } from "@/hooks/useColors";
import { hashPassword, normalizePhone } from "@/utils/crypto";

export default function AuthScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { login } = useAuth();

  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [country, setCountry] = useState(COUNTRIES[0]);
  const [city, setCity] = useState(COUNTRY_CITIES[COUNTRIES[0]][0]);
  const [base64Image, setBase64Image] = useState("");
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("إذن مطلوب", "يرجى السماح بالوصول إلى مكتبة الصور.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.3,
      base64: true,
    });
    if (!result.canceled && result.assets[0].base64) {
      const b64 = result.assets[0].base64;
      if (b64.length > 1500000) {
        Alert.alert("الصورة كبيرة جداً", "اختر صورة أصغر حجماً.");
        return;
      }
      setBase64Image(b64);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }

  async function handleSubmit() {
    const cleanPhone = normalizePhone(phone);
    if (!cleanPhone || !password) {
      Alert.alert("خطأ", "يرجى ملء رقم الهاتف وكلمة المرور.");
      return;
    }
    if (!isLogin && (!name.trim() || !specialty.trim())) {
      Alert.alert("خطأ", "يرجى ملء كافة الحقول.");
      return;
    }

    setLoading(true);
    try {
      const hash = await hashPassword(password);

      if (isLogin) {
        const uid = await loginNurse(cleanPhone, hash);
        if (uid) {
          await login(uid);
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          router.back();
        } else {
          Alert.alert("خطأ", "رقم الهاتف أو كلمة المرور غير صحيحة.");
        }
      } else {
        await registerNurse({
          name: name.trim(),
          phone: cleanPhone,
          passwordHash: hash,
          country,
          city,
          specialty: specialty.trim(),
          imageUrl: base64Image
            ? `data:image/jpeg;base64,${base64Image}`
            : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
        });
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert(
          "تم التسجيل بنجاح",
          "تهانينا! حسابك جاهز الآن. سجّل دخولك.",
          [{ text: "حسناً", onPress: () => setIsLogin(true) }]
        );
      }
    } catch {
      Alert.alert("خطأ", "حدث خطأ. يرجى المحاولة مجدداً.");
    } finally {
      setLoading(false);
    }
  }

  const inputStyle = [
    styles.input,
    { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground },
  ];
  const labelStyle = [styles.label, { color: colors.mutedForeground }];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[styles.header, { backgroundColor: colors.primary, paddingTop: topPad + 10 }]}
      >
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {isLogin ? "تسجيل دخول الممرض" : "تسجيل ممرض جديد"}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.form,
          { paddingBottom: insets.bottom + 40 },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Mode icon */}
        <View style={styles.iconArea}>
          <View style={[styles.iconCircle, { backgroundColor: colors.secondary }]}>
            <Ionicons
              name={isLogin ? "lock-closed" : "shield-checkmark"}
              size={40}
              color={colors.primary}
            />
          </View>
        </View>

        {/* Register-only: photo */}
        {!isLogin && (
          <TouchableOpacity style={styles.photoPicker} onPress={pickImage}>
            {base64Image ? (
              <Image
                source={{ uri: `data:image/jpeg;base64,${base64Image}` }}
                style={styles.photoPreview}
              />
            ) : (
              <View style={[styles.photoPlaceholder, { borderColor: colors.border }]}>
                <MaterialCommunityIcons
                  name="camera-plus-outline"
                  size={32}
                  color={colors.mutedForeground}
                />
                <Text style={[styles.photoLabel, { color: colors.mutedForeground }]}>
                  اختر صورتك المهنية
                </Text>
              </View>
            )}
          </TouchableOpacity>
        )}

        {/* Register-only: Name */}
        {!isLogin && (
          <View style={styles.field}>
            <Text style={labelStyle}>الاسم الكامل</Text>
            <TextInput
              style={inputStyle}
              value={name}
              onChangeText={setName}
              placeholder="اسمك الكامل"
              placeholderTextColor={colors.mutedForeground}
              textAlign="right"
            />
          </View>
        )}

        {/* Phone */}
        <View style={styles.field}>
          <Text style={labelStyle}>رقم الهاتف الدولي</Text>
          <TextInput
            style={inputStyle}
            value={phone}
            onChangeText={setPhone}
            placeholder="+963xxxxxxxxx"
            placeholderTextColor={colors.mutedForeground}
            keyboardType="phone-pad"
            textAlign="right"
          />
        </View>

        {/* Password */}
        <View style={styles.field}>
          <Text style={labelStyle}>كلمة المرور</Text>
          <View style={styles.passwordRow}>
            <TextInput
              style={[inputStyle, styles.passwordInput]}
              value={password}
              onChangeText={setPassword}
              placeholder="كلمة المرور السرية"
              placeholderTextColor={colors.mutedForeground}
              secureTextEntry={!showPassword}
              textAlign="right"
            />
            <TouchableOpacity
              style={[styles.eyeBtn, { borderColor: colors.border, backgroundColor: colors.card }]}
              onPress={() => setShowPassword((v) => !v)}
            >
              <Ionicons
                name={showPassword ? "eye-off" : "eye"}
                size={20}
                color={colors.mutedForeground}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Register-only: Country, City, Specialty */}
        {!isLogin && (
          <>
            <View style={styles.field}>
              <Text style={labelStyle}>الدولة</Text>
              <TouchableOpacity
                style={[styles.pickerBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
                onPress={() => setShowCountryPicker(true)}
              >
                <Ionicons name="chevron-down" size={18} color={colors.mutedForeground} />
                <Text style={[styles.pickerBtnText, { color: colors.foreground }]}>
                  {country}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.field}>
              <Text style={labelStyle}>المدينة</Text>
              <TouchableOpacity
                style={[styles.pickerBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
                onPress={() => setShowCityPicker(true)}
              >
                <Ionicons name="chevron-down" size={18} color={colors.mutedForeground} />
                <Text style={[styles.pickerBtnText, { color: colors.foreground }]}>
                  {city}
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.field}>
              <Text style={labelStyle}>نبذة عن تخصصك الطبي</Text>
              <TextInput
                style={[inputStyle, styles.textArea]}
                value={specialty}
                onChangeText={setSpecialty}
                placeholder="تخصصك ومجال رعايتك..."
                placeholderTextColor={colors.mutedForeground}
                multiline
                numberOfLines={3}
                textAlign="right"
                textAlignVertical="top"
              />
            </View>
          </>
        )}

        {/* Submit */}
        <TouchableOpacity
          style={[styles.submitBtn, { backgroundColor: colors.primary }]}
          onPress={handleSubmit}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.submitText}>
              {isLogin ? "دخول إلى ملفي الشخصي" : "إنشاء حسابي والظهور فوراً"}
            </Text>
          )}
        </TouchableOpacity>

        {/* Toggle */}
        <TouchableOpacity
          onPress={() => {
            Haptics.selectionAsync();
            setIsLogin((v) => !v);
          }}
          style={styles.toggleBtn}
        >
          <Text style={[styles.toggleText, { color: colors.primary }]}>
            {isLogin
              ? "ليس لديك حساب؟ سجّل هنا"
              : "لديك حساب بالفعل؟ سجّل الدخول"}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <LocationPicker
        visible={showCountryPicker}
        title="اختر الدولة"
        options={COUNTRIES}
        selected={country}
        onSelect={(c) => {
          setCountry(c);
          setCity(COUNTRY_CITIES[c][0]);
        }}
        onClose={() => setShowCountryPicker(false)}
      />
      <LocationPicker
        visible={showCityPicker}
        title="اختر المدينة"
        options={COUNTRY_CITIES[country]}
        selected={city}
        onSelect={setCity}
        onClose={() => setShowCityPicker(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
  },
  backBtn: { width: 40, alignItems: "flex-start" },
  headerTitle: {
    flex: 1,
    color: "#fff",
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    textAlign: "center",
  },
  form: {
    paddingHorizontal: 20,
    paddingTop: 24,
    gap: 16,
  },
  iconArea: { alignItems: "center", marginBottom: 8 },
  iconCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  photoPicker: { alignItems: "center" },
  photoPreview: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  photoPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 2,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  photoLabel: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  field: { gap: 6 },
  label: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    textAlign: "right",
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  textArea: {
    height: 90,
    paddingTop: 12,
  },
  passwordRow: {
    flexDirection: "row-reverse",
    gap: 8,
  },
  passwordInput: { flex: 1 },
  eyeBtn: {
    borderWidth: 1,
    borderRadius: 10,
    width: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  pickerBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  pickerBtnText: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  submitBtn: {
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 8,
  },
  submitText: {
    color: "#fff",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  toggleBtn: { alignItems: "center", paddingVertical: 4 },
  toggleText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
});

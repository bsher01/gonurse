import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

interface AuthContextValue {
  nurseId: string | null;
  isLoading: boolean;
  login: (id: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  nurseId: null,
  isLoading: true,
  login: async () => {},
  logout: async () => {},
});

const STORAGE_KEY = "gonurse_nurse_id";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [nurseId, setNurseId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((id) => {
        if (id) setNurseId(id);
      })
      .finally(() => setIsLoading(false));
  }, []);

  const login = useCallback(async (id: string) => {
    await AsyncStorage.setItem(STORAGE_KEY, id);
    setNurseId(id);
  }, []);

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    setNurseId(null);
  }, []);

  return (
    <AuthContext.Provider value={{ nurseId, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

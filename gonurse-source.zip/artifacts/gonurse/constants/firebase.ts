export const FIREBASE_URL =
  "https://gonurse-2ac77-default-rtdb.firebaseio.com/";

export interface Nurse {
  id: string;
  name: string;
  phone: string;
  specialty: string;
  imageUrl: string;
  rating: number;
  ratingCount: number;
  country: string;
  city: string;
  role: string;
  status: string;
  password_hash: string;
}

export async function fetchApprovedNurses(
  country: string,
  city: string
): Promise<Nurse[]> {
  const res = await fetch(`${FIREBASE_URL}secure_users.json`);
  const body = await res.text();
  if (body === "null") return [];
  const data: Record<string, Record<string, unknown>> = JSON.parse(body);
  const list: Nurse[] = [];
  Object.entries(data).forEach(([id, val]) => {
    if (
      val["role"] === "ممرض" &&
      val["country"] === country &&
      val["city"] === city &&
      val["status"] === "approved"
    ) {
      list.push({
        id,
        name: (val["name"] as string) ?? "ممرض",
        phone: (val["phone"] as string) ?? "",
        specialty:
          (val["specialty"] as string) ?? "رعاية منزلية متكاملة",
        imageUrl:
          (val["imageUrl"] as string) ??
          "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
        rating: Number(val["rating"] ?? 5.0),
        ratingCount: Number(val["ratingCount"] ?? 1),
        country: (val["country"] as string) ?? "",
        city: (val["city"] as string) ?? "",
        role: "ممرض",
        status: "approved",
        password_hash: (val["password_hash"] as string) ?? "",
      });
    }
  });
  return list;
}

export async function rateNurse(
  id: string,
  currentRating: number,
  currentCount: number,
  stars: number
): Promise<void> {
  const newCount = currentCount + 1;
  const newRating = (currentRating * currentCount + stars) / newCount;
  await fetch(`${FIREBASE_URL}secure_users/${id}.json`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ rating: newRating, ratingCount: newCount }),
  });
}

export async function loginNurse(
  phone: string,
  passwordHash: string
): Promise<string | null> {
  const res = await fetch(`${FIREBASE_URL}secure_users.json`);
  const body = await res.text();
  if (body === "null") return null;
  const data: Record<string, Record<string, unknown>> = JSON.parse(body);
  for (const [uid, val] of Object.entries(data)) {
    const storedPhone = ((val["phone"] as string) ?? "").replace(
      /[+\s-]/g,
      ""
    );
    if (storedPhone === phone && val["password_hash"] === passwordHash) {
      return uid;
    }
  }
  return null;
}

export async function registerNurse(data: {
  name: string;
  phone: string;
  passwordHash: string;
  country: string;
  city: string;
  specialty: string;
  imageUrl: string;
}): Promise<void> {
  await fetch(`${FIREBASE_URL}secure_users.json`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: data.name,
      phone: data.phone,
      password_hash: data.passwordHash,
      country: data.country,
      city: data.city,
      specialty: data.specialty,
      imageUrl: data.imageUrl,
      role: "ممرض",
      status: "approved",
      rating: 5.0,
      ratingCount: 1,
    }),
  });
}

export async function fetchNurseById(id: string): Promise<Record<string, unknown> | null> {
  const res = await fetch(`${FIREBASE_URL}secure_users/${id}.json`);
  const body = await res.text();
  if (body === "null") return null;
  return JSON.parse(body);
}

export async function updateNurse(
  id: string,
  updates: Record<string, unknown>
): Promise<void> {
  await fetch(`${FIREBASE_URL}secure_users/${id}.json`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updates),
  });
}

const colors = {
  light: {
    text: "#1A1A1A",
    tint: "#8B0000",
    background: "#F5F5F5",
    foreground: "#1A1A1A",
    card: "#FFFFFF",
    cardForeground: "#1A1A1A",
    primary: "#8B0000",
    primaryForeground: "#FFFFFF",
    secondary: "#FFF5F5",
    secondaryForeground: "#8B0000",
    muted: "#F0F0F0",
    mutedForeground: "#6B7280",
    accent: "#C0392B",
    accentForeground: "#FFFFFF",
    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",
    border: "#E5E5E5",
    input: "#E8E8E8",
    whatsapp: "#25D366",
    star: "#F59E0B",
  },
  radius: 12,
};

export default colors;

import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  Image,
  Linking,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { Nurse } from "@/constants/firebase";
import { normalizePhone } from "@/utils/crypto";
import { useColors } from "@/hooks/useColors";

interface NurseCardProps {
  nurse: Nurse;
  onRate: (nurse: Nurse) => void;
}

export default function NurseCard({ nurse, onRate }: NurseCardProps) {
  const colors = useColors();

  const imageSource =
    nurse.imageUrl.startsWith("data:image") ||
    (!nurse.imageUrl.startsWith("http") && nurse.imageUrl.length > 100)
      ? { uri: `data:image/jpeg;base64,${nurse.imageUrl.split(",").pop()}` }
      : {
          uri:
            nurse.imageUrl ||
            "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
        };

  async function openWhatsApp() {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const cleanPhone = normalizePhone(nurse.phone);
    const message = encodeURIComponent(
      `مرحباً يا ممرض ${nurse.name}، أرغب بالاتفاق معك على خدمة تمريضية منزلية عبر تطبيق GoNurse.`
    );
    await Linking.openURL(`https://wa.me/${cleanPhone}?text=${message}`);
  }

  async function handleRate() {
    await Haptics.selectionAsync();
    onRate(nurse);
  }

  const stars = Math.round(nurse.rating);

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}
    >
      <View style={styles.header}>
        <View style={styles.textInfo}>
          <Text
            style={[styles.name, { color: colors.primary }]}
            numberOfLines={1}
          >
            {nurse.name}
          </Text>
          <View style={styles.ratingRow}>
            <View style={styles.stars}>
              {[1, 2, 3, 4, 5].map((i) => (
                <Ionicons
                  key={i}
                  name={i <= stars ? "star" : "star-outline"}
                  size={14}
                  color={i <= stars ? colors.star : colors.mutedForeground}
                />
              ))}
            </View>
            <Text style={[styles.ratingText, { color: colors.mutedForeground }]}>
              {nurse.rating.toFixed(1)} ({nurse.ratingCount})
            </Text>
            <TouchableOpacity onPress={handleRate} style={styles.rateBtn}>
              <Text style={[styles.rateBtnText, { color: colors.primary }]}>
                قيّم
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <Image source={imageSource} style={styles.avatar} />
      </View>

      <View style={[styles.divider, { backgroundColor: colors.border }]} />

      <Text style={[styles.specialty, { color: colors.foreground }]}>
        {nurse.specialty}
      </Text>

      <TouchableOpacity
        style={[styles.whatsappBtn, { backgroundColor: colors.whatsapp }]}
        onPress={openWhatsApp}
        activeOpacity={0.8}
      >
        <MaterialCommunityIcons name="whatsapp" size={20} color="#fff" />
        <Text style={styles.whatsappText}>تواصل للتنسيق الطبي</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 14,
    marginVertical: 7,
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 8,
    elevation: 3,
  },
  header: {
    flexDirection: "row-reverse",
    alignItems: "flex-start",
    gap: 12,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#f0f0f0",
  },
  textInfo: {
    flex: 1,
    alignItems: "flex-end",
  },
  name: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
    textAlign: "right",
  },
  ratingRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    flexWrap: "wrap",
  },
  stars: {
    flexDirection: "row-reverse",
    gap: 1,
  },
  ratingText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  rateBtn: {
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  rateBtnText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  divider: {
    height: 1,
    marginVertical: 12,
  },
  specialty: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "right",
    lineHeight: 20,
    marginBottom: 14,
  },
  whatsappBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderRadius: 10,
    gap: 8,
  },
  whatsappText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
});

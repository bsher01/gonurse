export async function hashPassword(password: string): Promise<string> {
  try {
    const msgBuffer = new TextEncoder().encode(password);
    const hashBuffer = await crypto.subtle.digest("SHA-256", msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    let h = 5381;
    for (let i = 0; i < password.length; i++) {
      h = (h * 33) ^ password.charCodeAt(i);
    }
    return (h >>> 0).toString(16).padStart(64, "0");
  }
}

export function normalizePhone(phone: string): string {
  return phone.replace(/[+\s\-()]/g, "").trim();
}

import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Top-level background message handler for FCM
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  debugPrint('Handling background message: ${message.messageId}');
}

class FcmService {
  FcmService._internal();
  static final FcmService instance = FcmService._internal();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'gonurse_high_importance_channel',
    'GoNurse Notifications',
    description: 'Important updates regarding nurse requests and bookings.',
    importance: Importance.high,
    playSound: true,
  );

  /// Initialize FCM, setup notification channels and listeners
  Future<void> initialize() async {
    // 1. Set background messaging handler
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    // 2. Request User Notification Permissions (Android 13+ and iOS)
    await requestPermissions();

    // 3. Initialize Local Notifications for Foreground Alerts
    await _initLocalNotifications();

    // 4. Retrieve FCM Token and save to Database
    await syncFcmTokenToDatabase();

    // 5. Listen to Token Refresh
    _fcm.onTokenRefresh.listen((newToken) {
      debugPrint('FCM Token Refreshed: $newToken');
      _saveTokenToDatabase(newToken);
    });

    // 6. Setup Foreground Message Listener
    _setupForegroundMessageListener();

    // 7. Setup Interaction Handlers (when tapping a notification)
    _setupNotificationTapHandlers();
  }

  /// 1. Request Runtime Notification Permissions
  Future<bool> requestPermissions() async {
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
      criticalAlert: false,
      announcement: false,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint('User granted notification permission');
      return true;
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      debugPrint('User granted provisional permission');
      return true;
    } else {
      debugPrint('User declined notification permission');
      return false;
    }
  }

  /// 2. Initialize Local Notifications Plugin & Android Channel
  Future<void> _initLocalNotifications() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        debugPrint('Notification clicked with payload: ${response.payload}');
      },
    );

    // Create high-importance notification channel for Android
    if (Platform.isAndroid) {
      await _localNotifications
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(_channel);
    }

    // Set foreground notification presentation options for iOS
    await _fcm.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  /// 3. Retrieve device FCM token and persist to Firebase Realtime Database
  Future<String?> syncFcmTokenToDatabase({String? fallbackUserId}) async {
    try {
      String? token = await _fcm.getToken();
      if (token != null && token.isNotEmpty) {
        debugPrint('FCM Device Token: $token');
        await _saveTokenToDatabase(token, fallbackUserId: fallbackUserId);
      }
      return token;
    } catch (e) {
      debugPrint('Error retrieving FCM Token: $e');
      return null;
    }
  }

  /// Saves the FCM token under users/{uid}/fcmToken in Realtime Database
  Future<void> _saveTokenToDatabase(String token, {String? fallbackUserId}) async {
    final user = FirebaseAuth.instance.currentUser;
    final userId = user?.uid ?? fallbackUserId ?? 'nurse_current_user';

    try {
      final DatabaseReference userRef =
          FirebaseDatabase.instance.ref('users/$userId');

      await userRef.update({
        'fcmToken': token,
        'lastTokenUpdate': ServerValue.timestamp,
        'platform': Platform.operatingSystem,
      });

      // Also sync to nurses node if registered
      final DatabaseReference nurseRef =
          FirebaseDatabase.instance.ref('nurses/$userId');
      await nurseRef.update({
        'fcmToken': token,
        'lastTokenUpdate': ServerValue.timestamp,
      });

      debugPrint('FCM Token successfully synced for User: $userId');
    } catch (e) {
      debugPrint('Failed to save FCM token to Realtime Database: $e');
    }
  }

  /// 4. Setup Foreground Message Listening
  void _setupForegroundMessageListener() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint('Foreground Message Received: ${message.notification?.title}');

      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;

      // Show local notification heads-up popup in foreground
      if (notification != null) {
        _localNotifications.show(
          notification.hashCode,
          notification.title ?? 'GoNurse',
          notification.body ?? '',
          NotificationDetails(
            android: AndroidNotificationDetails(
              _channel.id,
              _channel.name,
              channelDescription: _channel.description,
              icon: android?.smallIcon ?? '@mipmap/ic_launcher',
              importance: Importance.max,
              priority: Priority.high,
              playSound: true,
            ),
            iOS: const DarwinNotificationDetails(
              presentAlert: true,
              presentBadge: true,
              presentSound: true,
            ),
          ),
          payload: message.data.toString(),
        );
      }
    });
  }

  /// 5. Setup Notification Tap / Deep-link Handlers
  void _setupNotificationTapHandlers() {
    // When notification is clicked from background state
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('App opened from background via notification: ${message.data}');
      _handleNotificationPayload(message.data);
    });

    // When app was completely terminated and opened by notification click
    _fcm.getInitialMessage().then((RemoteMessage? message) {
      if (message != null) {
        debugPrint('App opened from terminated state via notification: ${message.data}');
        _handleNotificationPayload(message.data);
      }
    });
  }

  void _handleNotificationPayload(Map<String, dynamic> data) {
    final screen = data['screen'];
    debugPrint('Navigate to: $screen with data: $data');
  }
}

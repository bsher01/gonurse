import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'services/fcm_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Initialize Firebase App
  await Firebase.initializeApp();

  // 2. Initialize FCM & Push Notifications
  await FcmService.instance.initialize();

  // 3. Listen to Auth state changes to resync FCM token on login
  FirebaseAuth.instance.authStateChanges().listen((User? user) {
    if (user != null) {
      FcmService.instance.syncFcmTokenToDatabase(fallbackUserId: user.uid);
    }
  });

  runApp(const GoNurseFlutterApp());
}

class GoNurseFlutterApp extends StatelessWidget {
  const GoNurseFlutterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GoNurse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF800020),
          primary: const Color(0xFF800020),
        ),
        useMaterial3: true,
      ),
      home: const Scaffold(
        body: Center(
          child: Text(
            'GoNurse Health & Nursing Platform',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}

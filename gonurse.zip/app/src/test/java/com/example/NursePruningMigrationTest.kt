package com.example

import com.example.data.FirebaseRealtimeRepository
import com.example.model.Nurse
import com.example.util.PhoneFormatter
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NursePruningMigrationTest {

  @Test
  fun testPhoneSanitization_preservesCountryCodeAndLeadingZeros() {
    // International format with plus
    val p1 = PhoneFormatter.sanitizePhoneInput("+963 998 734 002")
    assertEquals("+963998734002", p1)

    // International digits without plus
    val p2 = PhoneFormatter.sanitizePhoneInput("963991368775")
    assertEquals("963991368775", p2)

    // Local number with leading zero
    val p3 = PhoneFormatter.sanitizePhoneInput("0939336356")
    assertEquals("0939336356", p3)

    // Arabic Eastern numerals
    val p4 = PhoneFormatter.sanitizePhoneInput("٠٩٣٩٣٣٦٣٥٦")
    assertEquals("0939336356", p4)

    // Egyptian international number
    val p5 = PhoneFormatter.sanitizePhoneInput("+20 100 984 1842")
    assertEquals("+201009841842", p5)
  }

  @Test
  fun testNurseRealName_resolvesCorrectly() {
    val name = Nurse.resolveRealName(
      name = "عمر الكليب",
      fullName = "عمر الكليب",
      phone = "+963998734002",
      id = "nurse_1785585446141"
    )
    assertEquals("عمر الكليب", name)

    // Fallback when placeholder
    val fallback = Nurse.resolveRealName(
      name = "nurse_12345",
      fullName = "",
      phone = "0934683189",
      id = "nurse_12345",
      fallback = "ممرض مرخص"
    )
    assertEquals("ممرض مرخص", fallback)
  }

  @Test
  fun testPrunedRecordStructure_retainsOnlyEssentialFields() {
    val bloatedRecord = JSONObject().apply {
      put("id", "nurse_1785585446141")
      put("name", "عمر الكليب")
      put("fullName", "عمر الكليب")
      put("phone", "+963 998734002")
      put("mobile", "+963 998734002")
      put("whatsapp", "963998734002")
      put("city", "دير الزور")
      put("country", "سوريا")
      put("bio", "خبرة 5 سنوات في التمريض المنزلي والجراحة")
      put("licenseImageBase64", "A".repeat(50000))
      put("profileImageBase64", "B".repeat(30000))
      put("certificateImageUri", "file:///some/cert.jpg")
      put("experienceYears", 5)
      put("status", "APPROVED")
      put("verificationStatus", "APPROVED")
    }

    // Build lightweight pruned record
    val cleanPhone = PhoneFormatter.sanitizePhoneInput(bloatedRecord.optString("phone"))
    val pruned = JSONObject().apply {
      put("id", bloatedRecord.optString("id"))
      put("name", bloatedRecord.optString("name"))
      put("fullName", bloatedRecord.optString("fullName"))
      put("phone", cleanPhone)
      put("mobile", cleanPhone)
    }

    // Verify retained fields
    assertEquals("nurse_1785585446141", pruned.getString("id"))
    assertEquals("عمر الكليب", pruned.getString("name"))
    assertEquals("عمر الكليب", pruned.getString("fullName"))
    assertEquals("+963998734002", pruned.getString("phone"))
    assertEquals("+963998734002", pruned.getString("mobile"))

    // Verify bulky fields are completely absent
    assertFalse(pruned.has("licenseImageBase64"))
    assertFalse(pruned.has("profileImageBase64"))
    assertFalse(pruned.has("certificateImageUri"))
    assertFalse(pruned.has("bio"))
    assertFalse(pruned.has("city"))
    assertFalse(pruned.has("country"))
    assertFalse(pruned.has("experienceYears"))
    assertFalse(pruned.has("status"))

    // Only 5 keys retained
    assertEquals(5, pruned.length())
  }

  @Test
  fun testExecuteMigration_runsAndPrunesBothNodes() = runBlocking {
    val result = FirebaseRealtimeRepository.optimizeAndPruneNurseRecords(context = null, force = true)
    assertTrue("Migration should succeed", result.success)
    assertTrue("Should migrate nurses", result.nursesCount > 0)
    assertTrue("Should migrate user records", result.usersCount >= 0)
  }
}

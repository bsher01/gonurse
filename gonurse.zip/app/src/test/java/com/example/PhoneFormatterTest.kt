package com.example

import com.example.model.CountryInfo
import com.example.model.CountryRepository
import com.example.util.PhoneFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneFormatterTest {

  @Test
  fun testPhoneFormattingAndCountryDetection() {
    val defaultCountry = CountryRepository.defaultCountry // Syria +963

    // 1. Local number without leading zero
    val (c1, p1) = PhoneFormatter.parseAndFormat("933123456", defaultCountry)
    assertEquals(defaultCountry.code, c1.code)
    assertEquals("933123456", p1)
    assertEquals("+963933123456", PhoneFormatter.getFullInternationalNumber(c1, p1))

    // 2. Local number with leading zero
    val (c2, p2) = PhoneFormatter.parseAndFormat("0933123456", defaultCountry)
    assertEquals(defaultCountry.code, c2.code)
    assertEquals("933123456", p2)
    assertEquals("+963933123456", PhoneFormatter.getFullInternationalNumber(c2, p2))

    // 3. International number with + and matching country (Saudi Arabia +966)
    val (c3, p3) = PhoneFormatter.parseAndFormat("+966501234567", defaultCountry)
    assertEquals("SA", c3.code)
    assertEquals("501234567", p3)
    assertEquals("+966501234567", PhoneFormatter.getFullInternationalNumber(c3, p3))
  }

  @Test
  fun testPhoneValidation() {
    assertTrue(PhoneFormatter.isValidPhoneNumber("933123456"))
    assertTrue(PhoneFormatter.isValidPhoneNumber("0933123456"))
    assertFalse(PhoneFormatter.isValidPhoneNumber("123"))
    assertFalse(PhoneFormatter.isValidPhoneNumber(""))
  }
}

package com.example

import com.example.model.AppConfig
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForcedUpdateUnitTest {

  @Test
  fun testSemanticVersionOlder() {
    // Current is older
    assertTrue(isSemanticVersionOlder("1.0", "1.1"))
    assertTrue(isSemanticVersionOlder("1.0.0", "1.0.1"))
    assertTrue(isSemanticVersionOlder("1.2", "2.0"))
    assertTrue(isSemanticVersionOlder("0.9.9", "1.0.0"))

    // Current is equal or newer
    assertFalse(isSemanticVersionOlder("1.0", "1.0"))
    assertFalse(isSemanticVersionOlder("1.1", "1.0"))
    assertFalse(isSemanticVersionOlder("2.0.0", "1.9.9"))
    assertFalse(isSemanticVersionOlder("1.5.1", "1.5.0"))
  }

  @Test
  fun testAppConfigDefaults() {
    val config = AppConfig()
    assertFalse(config.isForceUpdateRequired)
    assertTrue(config.updateUrl == "https://t.me/GoNurse")
    assertTrue(config.minVersionCode >= 1L)
  }
}

package com.example

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy

/**
 * Custom Application class for GoNurse.
 * Configures Coil with aggressive local disk and memory caching to minimize mobile data
 * consumption, ensuring profile pictures, nurse avatars, and map markers are saved locally
 * on the device after their first download and never needlessly re-fetched.
 */
class GoNurseApplication : Application(), ImageLoaderFactory {

  override fun onCreate() {
    super.onCreate()
  }

  override fun newImageLoader(): ImageLoader {
    return ImageLoader.Builder(this)
      // 1. In-memory cache using up to 25% of available RAM with strong references
      .memoryCache {
        MemoryCache.Builder(this)
          .maxSizePercent(0.25)
          .strongReferencesEnabled(true)
          .build()
      }
      // 2. Persistent on-device disk cache (up to 60 MB) stored in app cache directory
      .diskCache {
        DiskCache.Builder()
          .directory(cacheDir.resolve("gonurse_image_cache"))
          .maxSizeBytes(60L * 1024 * 1024) // 60 MB local cache
          .build()
      }
      // 3. Ignore restrictive or missing HTTP Cache-Control headers so cloud/Firebase images stay cached locally
      .respectCacheHeaders(false)
      // 4. Smooth 200ms visual crossfade animation on first render
      .crossfade(true)
      .build()
  }
}

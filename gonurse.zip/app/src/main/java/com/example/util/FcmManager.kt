package com.example.util

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.data.FirebaseRealtimeRepository
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object FcmManager {
  private const val TAG = "FcmManager"
  const val PERMISSION_REQUEST_CODE = 1002

  /**
   * Initializes notification channel and retrieves current FCM device token
   */
  fun init(context: Context, userId: String = "nurse_current_user") {
    createNotificationChannel(context)
    fetchAndSyncToken(userId)
  }

  /**
   * Creates high-priority notification channel for Android 8.0+
   */
  fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val channel = NotificationChannel(
        GoNurseMessagingService.CHANNEL_ID,
        GoNurseMessagingService.CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = GoNurseMessagingService.CHANNEL_DESC
        enableLights(true)
        enableVibration(true)
      }
      notificationManager.createNotificationChannel(channel)
    }
  }

  /**
   * Flag to bypass startup notification popup to ensure emulator preview and UI interaction are unblocked.
   * Can be toggled if explicit in-app user action requests permissions later.
   */
  var bypassStartupNotificationPopup: Boolean = true

  /**
   * Checks and requests runtime notification permission for Android 13+ (Tiramisu).
   * Handled gracefully: if [force] is false and [bypassStartupNotificationPopup] is true (e.g. on startup),
   * the blocking system popup is bypassed so UI interaction in the emulator preview remains smooth.
   */
  fun requestNotificationPermission(activity: Activity, force: Boolean = false) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val isGranted = ContextCompat.checkSelfPermission(
        activity,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED

      if (isGranted) {
        Log.d(TAG, "Notification permission already granted.")
        return
      }

      if (!force && bypassStartupNotificationPopup) {
        Log.i(TAG, "Notification permission popup gracefully bypassed on startup to keep UI interaction responsive.")
        return
      }

      try {
        ActivityCompat.requestPermissions(
          activity,
          arrayOf(Manifest.permission.POST_NOTIFICATIONS),
          PERMISSION_REQUEST_CODE
        )
      } catch (e: Exception) {
        Log.w(TAG, "Failed to request notification permission: ${e.message}")
      }
    }
  }

  /**
   * Retrieves FCM Token and saves to Firebase Realtime Database
   */
  fun fetchAndSyncToken(userId: String = "nurse_current_user") {
    try {
      FirebaseMessaging.getInstance().token
        .addOnCompleteListener { task ->
          if (!task.isSuccessful) {
            Log.w(TAG, "Fetching FCM registration token failed", task.exception)
            return@addOnCompleteListener
          }

          val token = task.result
          Log.d(TAG, "FCM Device Token: $token")
          if (!token.isNullOrBlank()) {
            CoroutineScope(Dispatchers.IO).launch {
              FirebaseRealtimeRepository.saveFcmToken(userId, token)
            }
          }
        }
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing FirebaseMessaging token: ${e.message}", e)
    }
  }
}

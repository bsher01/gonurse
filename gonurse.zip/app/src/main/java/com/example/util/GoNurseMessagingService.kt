package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.FirebaseRealtimeRepository
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GoNurseMessagingService : FirebaseMessagingService() {

  companion object {
    private const val TAG = "GoNurseFCM"
    const val CHANNEL_ID = "gonurse_high_importance_channel"
    const val CHANNEL_NAME = "GoNurse Notifications"
    const val CHANNEL_DESC = "Important updates regarding nursing requests, bookings, and chat."
  }

  override fun onNewToken(token: String) {
    super.onNewToken(token)
    Log.d(TAG, "New FCM Token received: $token")
    // Persist token in Firebase Realtime Database
    CoroutineScope(Dispatchers.IO).launch {
      FirebaseRealtimeRepository.saveFcmToken("nurse_current_user", token)
    }
  }

  override fun onMessageReceived(remoteMessage: RemoteMessage) {
    super.onMessageReceived(remoteMessage)
    Log.d(TAG, "From: ${remoteMessage.from}")

    // Extract title & body
    val title = remoteMessage.notification?.title
      ?: remoteMessage.data["title"]
      ?: "GoNurse"
    val body = remoteMessage.notification?.body
      ?: remoteMessage.data["body"]
      ?: "لديك إشعار جديد في تطبيق GoNurse"

    showNotification(title, body, remoteMessage.data)
  }

  private fun showNotification(title: String, body: String, data: Map<String, String>) {
    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Create Notification Channel for Android 8.0+ (Oreo)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = CHANNEL_DESC
        enableLights(true)
        enableVibration(true)
      }
      notificationManager.createNotificationChannel(channel)
    }

    val intent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
      for ((k, v) in data) {
        putExtra(k, v)
      }
    }

    val pendingIntent = PendingIntent.getActivity(
      this,
      System.currentTimeMillis().toInt(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(body)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setContentIntent(pendingIntent)

    val notificationId = System.currentTimeMillis().toInt()
    notificationManager.notify(notificationId, notificationBuilder.build())
  }
}

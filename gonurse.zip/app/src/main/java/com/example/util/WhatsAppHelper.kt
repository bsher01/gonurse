package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.model.CountryRepository
import com.example.model.Nurse
import java.net.URLEncoder

object WhatsAppHelper {
  private const val TAG = "WhatsAppHelper"

  // Exact admin credentials configured for GoNurse
  const val ADMIN_PASSCODE = "0932189336BSHERbsher"

  /**
   * Normalizes a phone number to standard international WhatsApp format without '+' or spaces.
   * Handles Arabic numerals, international numbers (e.g. +9639xxxxxxxx -> 9639xxxxxxxx)
   * and local numbers with country awareness (e.g. 09xxxxxxxx -> 9639xxxxxxxx).
   */
  fun formatNumberForWhatsApp(phone: String, countryName: String = ""): String {
    val sanitized = PhoneFormatter.sanitizePhoneInput(phone)
    var digits = sanitized.filter { it.isDigit() }
    if (digits.isEmpty()) return ""

    if (digits.startsWith("00")) {
      digits = digits.removePrefix("00")
    }

    // If already has country dial code prefix
    for (country in CountryRepository.countries) {
      val dialDigits = country.dialCode.removePrefix("+")
      if (digits.startsWith(dialDigits) && digits.length >= dialDigits.length + 7) {
        return digits
      }
    }

    // Normalize Syrian numbers (default) or other selected countries
    val isSyria = countryName.isBlank() || countryName.contains("سوريا") || countryName.contains("Syria", ignoreCase = true)
    if (isSyria) {
      return when {
        digits.startsWith("0") && digits.length >= 9 -> "963" + digits.removePrefix("0")
        digits.length == 9 && digits.startsWith("9") -> "963$digits"
        digits.length == 10 && digits.startsWith("09") -> "963" + digits.substring(1)
        else -> digits
      }
    }

    // Try finding country by name if not Syria
    val matchedCountry = CountryRepository.countries.firstOrNull {
      it.nameAr.equals(countryName.trim(), ignoreCase = true) ||
      it.nameEn.equals(countryName.trim(), ignoreCase = true)
    }
    if (matchedCountry != null) {
      val dial = matchedCountry.dialCode.removePrefix("+")
      val cleanLocal = if (digits.startsWith("0")) digits.removePrefix("0") else digits
      return "$dial$cleanLocal"
    }

    return digits
  }

  /**
   * Launches direct WhatsApp universal deep link (wa.me / api.whatsapp.com) with a pre-formatted message.
   * Opens chat with the specific recipient phone number directly without requiring contact saving.
   * NEVER defaults to admin number; returns false if the provided phone is blank or invalid.
   */
  fun openWhatsApp(context: Context, phoneNumber: String, message: String, countryName: String = ""): Boolean {
    val cleanPhone = formatNumberForWhatsApp(phoneNumber, countryName)
    if (cleanPhone.isBlank() || cleanPhone.filter { it.isDigit() }.length < 7) {
      Log.w(TAG, "Cannot open WhatsApp: phone number is blank or invalid ($phoneNumber)")
      Toast.makeText(context, "رقم هاتف التواصل غير متوفر أو غير صالح", Toast.LENGTH_SHORT).show()
      return false
    }
    return try {
      val encodedMsg = URLEncoder.encode(message.trim(), "UTF-8")
      val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMsg"
      Log.i(TAG, "Executing WhatsApp Intent: rawInput='$phoneNumber', targetCleanPhone='$cleanPhone', intentUrl='$url'")
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }

      val pm = context.packageManager
      val hasWhatsApp = try {
        pm.getPackageInfo("com.whatsapp", 0) != null
      } catch (_: Exception) { false }
      val hasW4b = try {
        pm.getPackageInfo("com.whatsapp.w4b", 0) != null
      } catch (_: Exception) { false }

      if (hasWhatsApp) {
        intent.setPackage("com.whatsapp")
      } else if (hasW4b) {
        intent.setPackage("com.whatsapp.w4b")
      }

      try {
        context.startActivity(intent)
        true
      } catch (_: Exception) {
        // Fallback to standard wa.me browser/app intent if direct package open fails
        val fallbackUrl = "https://wa.me/$cleanPhone?text=$encodedMsg"
        Log.i(TAG, "Direct app launch failed, falling back to browser URL: $fallbackUrl")
        val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(fallbackIntent)
        true
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to launch WhatsApp deep link: ${e.message}", e)
      Toast.makeText(context, "تعذر فتح تطبيق واتساب. يرجى التأكد من تثبيته على جهازك.", Toast.LENGTH_LONG).show()
      false
    }
  }

  /**
   * Specifically opens WhatsApp chat directly with the patient who created the request.
   * Dynamically uses the patient's actual phone number with strict country normalization,
   * guaranteeing that the nurse is directed to the patient and never to the developer or admin.
   */
  fun openWhatsAppWithPatient(
    context: Context,
    phoneNumber: String,
    message: String,
    countryName: String = ""
  ): Boolean {
    val cleanPhone = formatNumberForWhatsApp(phoneNumber, countryName)
    Log.i(
      TAG,
      "openWhatsAppWithPatient: inputPhoneNumber='$phoneNumber', country='$countryName', resolvedCleanPhone='$cleanPhone'"
    )
    if (cleanPhone.isBlank() || cleanPhone.filter { it.isDigit() }.length < 7 || cleanPhone.contains("932189336")) {
      Log.w(TAG, "Cannot open WhatsApp with patient: invalid or prohibited phone number ($phoneNumber -> $cleanPhone)")
      Toast.makeText(
        context,
        "رقم هاتف المريض غير متوفر في بيانات الطلب للتواصل عبر واتساب",
        Toast.LENGTH_LONG
      ).show()
      return false
    }
    return openWhatsApp(context, cleanPhone, message, countryName)
  }

  /**
   * Formats message to Admin when a new nurse submits the "إنشاء حساب ممرض" form
   */
  fun buildNewRegistrationAdminMessage(
    phone: String,
    country: String,
    city: String,
    bio: String,
    nurseId: String
  ): String {
    return """
      🩺 طلب إنشاء حساب ممرض جديد في GoNurse:
      • معرف الطلب: $nurseId
      • رقم الهاتف: $phone
      • الدولة: $country
      • المدينة: $city
      • النبذة: $bio
      • ترخيص مزاولة المهنة: تم رفع صورة الترخيص في التطبيق وهو بانتظار المراجعة والاعتماد.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse when registration is approved or rejected by Admin
   */
  fun buildRegistrationDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ مرحباً بك في تطبيق GoNurse!
        تمت مراجعة طلبك واعتماد ترخيص مزاولة المهنة بنجاح.
        حسابك مفعل الآن وموثق بالشارة الزرقاء على منصة GoNurse.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة تطبيق GoNurse:
        نعتذر منك، لم يتم اعتماد طلب إنشاء الحساب في الوقت الحالي.
        سبب الرفض: ${reason.ifBlank { "عدم وضوح صورة ترخيص مزاولة المهنة أو عدم استيفاء الشروط المطلوبة." }}
        يمكنك إعادة تقديم الطلب والتأكد من وضوح صورة الترخيص.
      """.trimIndent()
    }
  }

  /**
   * Formats message to Admin when a nurse requests a profile update
   */
  fun buildProfileUpdateRequestAdminMessage(
    nurseId: String,
    registeredPhone: String,
    requestedPhone: String,
    requestedCountry: String,
    requestedCity: String,
    requestedBio: String
  ): String {
    return """
      📝 طلب تعديل بيانات ممرض في GoNurse:
      • معرف الممرض: $nurseId
      • رقم الهاتف المسجل: $registeredPhone
      • رقم الهاتف الجديد المطلوب: ${requestedPhone.ifBlank { registeredPhone }}
      • الدولة: $requestedCountry
      • المدينة: $requestedCity
      • النبذة الجديدة: $requestedBio
      يرجى التحقق من مطابقة رقم هاتف المرسل واعتماد التعديل.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse upon profile update approval or rejection
   */
  fun buildProfileUpdateDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ مرحباً بك من إدارة GoNurse!
        تم التحقق من مطابقة رقم الهاتف واعتماد تعديل بيانات حسابك بنجاح في قاعدة البيانات.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة GoNurse:
        تم رفض طلب تعديل البيانات.
        السبب: ${reason.ifBlank { "عدم تطابق رقم هاتف مقدم الطلب مع الرقم المسجل بالحساب." }}
      """.trimIndent()
    }
  }

  /**
   * Formats message to Admin when a nurse requests account deletion
   */
  fun buildAccountDeletionRequestAdminMessage(
    nurseId: String,
    registeredPhone: String,
    reason: String
  ): String {
    return """
      ⚠️ طلب حذف حساب ممرض نهائياً من GoNurse:
      • معرف الممرض: $nurseId
      • رقم الهاتف المسجل: $registeredPhone
      • السبب: ${reason.ifBlank { "بناءً على رغبة صاحب الحساب" }}
      أرجو التحقق وحذف حسابي وبياناتي بالكامل من قاعدة بيانات التطبيق.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse upon account deletion approval or rejection
   */
  fun buildAccountDeletionDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ إشعار من إدارة GoNurse:
        تم التحقق من رقم الهاتف وحذف حسابك وبياناتك بالكامل ونهائياً من قاعدة بيانات التطبيق بناءً على طلبك.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة GoNurse:
        تم رفض طلب حذف الحساب.
        السبب: ${reason.ifBlank { "عدم تطابق رقم هاتف مقدم الطلب مع السجل المسجل." }}
      """.trimIndent()
    }
  }

  fun openWhatsAppDecision(
    context: Context,
    recipientPhone: String,
    message: String
  ): Boolean {
    return openWhatsApp(context, recipientPhone, message)
  }
}

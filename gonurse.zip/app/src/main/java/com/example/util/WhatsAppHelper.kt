package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.example.model.Nurse
import java.net.URLEncoder

object WhatsAppHelper {
  private const val TAG = "WhatsAppHelper"

  // Exact admin credentials and contact configured for GoNurse
  const val ADMIN_PASSCODE = "0932189336BSHERbsher"
  const val ADMIN_WHATSAPP_NUMBER = "994407958647"

  /**
   * Normalizes a phone number to standard international WhatsApp format without '+' or spaces.
   * Handles international numbers (e.g. +994407958647 -> 994407958647) and local Syrian numbers (09xxxxxxxx -> 9639xxxxxxxx).
   */
  fun formatNumberForWhatsApp(phone: String): String {
    val digits = phone.filter { it.isDigit() }
    return when {
      digits.startsWith("00") -> digits.removePrefix("00")
      digits.startsWith("0") && digits.length >= 9 -> "963" + digits.removePrefix("0")
      digits.length == 9 && digits.startsWith("9") -> "963$digits"
      else -> digits
    }
  }

  /**
   * Launches direct WhatsApp deep link (wa.me) with a pre-formatted message
   */
  fun openWhatsApp(context: Context, phoneNumber: String, message: String): Boolean {
    val cleanPhone = formatNumberForWhatsApp(phoneNumber).ifBlank { ADMIN_WHATSAPP_NUMBER }
    return try {
      val encodedMsg = URLEncoder.encode(message.trim(), "UTF-8")
      val url = "https://wa.me/$cleanPhone?text=$encodedMsg"
      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(intent)
      true
    } catch (e: Exception) {
      Log.e(TAG, "Failed to launch WhatsApp deep link: ${e.message}", e)
      Toast.makeText(context, "تعذر فتح تطبيق واتساب. يرجى التأكد من تثبيته على جهازك.", Toast.LENGTH_LONG).show()
      false
    }
  }

  /**
   * Formats message to Admin when a new nurse submits the "إنشاء حساب ممرض" form
   */
  fun buildNewRegistrationAdminMessage(
    phone: String,
    country: String,
    city: String,
    bio: String,
    nurseId: String
  ): String {
    return """
      🩺 طلب إنشاء حساب ممرض جديد في GoNurse:
      • معرف الطلب: $nurseId
      • رقم الهاتف: $phone
      • الدولة: $country
      • المدينة: $city
      • النبذة: $bio
      • ترخيص مزاولة المهنة: تم رفع صورة الترخيص في التطبيق وهو بانتظار المراجعة والاعتماد.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse when registration is approved or rejected by Admin
   */
  fun buildRegistrationDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ مرحباً بك في تطبيق GoNurse!
        تمت مراجعة طلبك واعتماد ترخيص مزاولة المهنة بنجاح.
        حسابك مفعل الآن وموثق بالشارة الزرقاء على منصة GoNurse.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة تطبيق GoNurse:
        نعتذر منك، لم يتم اعتماد طلب إنشاء الحساب في الوقت الحالي.
        سبب الرفض: ${reason.ifBlank { "عدم وضوح صورة ترخيص مزاولة المهنة أو عدم استيفاء الشروط المطلوبة." }}
        يمكنك إعادة تقديم الطلب والتأكد من وضوح صورة الترخيص.
      """.trimIndent()
    }
  }

  /**
   * Formats message to Admin when a nurse requests a profile update
   */
  fun buildProfileUpdateRequestAdminMessage(
    nurseId: String,
    registeredPhone: String,
    requestedPhone: String,
    requestedCountry: String,
    requestedCity: String,
    requestedBio: String
  ): String {
    return """
      📝 طلب تعديل بيانات ممرض في GoNurse:
      • معرف الممرض: $nurseId
      • رقم الهاتف المسجل: $registeredPhone
      • رقم الهاتف الجديد المطلوب: ${requestedPhone.ifBlank { registeredPhone }}
      • الدولة: $requestedCountry
      • المدينة: $requestedCity
      • النبذة الجديدة: $requestedBio
      يرجى التحقق من مطابقة رقم هاتف المرسل واعتماد التعديل.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse upon profile update approval or rejection
   */
  fun buildProfileUpdateDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ مرحباً بك من إدارة GoNurse!
        تم التحقق من مطابقة رقم الهاتف واعتماد تعديل بيانات حسابك بنجاح في قاعدة البيانات.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة GoNurse:
        تم رفض طلب تعديل البيانات.
        السبب: ${reason.ifBlank { "عدم تطابق رقم هاتف مقدم الطلب مع الرقم المسجل بالحساب." }}
      """.trimIndent()
    }
  }

  /**
   * Formats message to Admin when a nurse requests account deletion
   */
  fun buildAccountDeletionRequestAdminMessage(
    nurseId: String,
    registeredPhone: String,
    reason: String
  ): String {
    return """
      ⚠️ طلب حذف حساب ممرض نهائياً من GoNurse:
      • معرف الممرض: $nurseId
      • رقم الهاتف المسجل: $registeredPhone
      • السبب: ${reason.ifBlank { "بناءً على رغبة صاحب الحساب" }}
      أرجو التحقق وحذف حسابي وبياناتي بالكامل من قاعدة بيانات التطبيق.
    """.trimIndent()
  }

  /**
   * Formats message to Nurse upon account deletion approval or rejection
   */
  fun buildAccountDeletionDecisionMessage(isApproved: Boolean, reason: String = ""): String {
    return if (isApproved) {
      """
        ✅ إشعار من إدارة GoNurse:
        تم التحقق من رقم الهاتف وحذف حسابك وبياناتك بالكامل ونهائياً من قاعدة بيانات التطبيق بناءً على طلبك.
      """.trimIndent()
    } else {
      """
        ❌ إشعار من إدارة GoNurse:
        تم رفض طلب حذف الحساب.
        السبب: ${reason.ifBlank { "عدم تطابق رقم هاتف مقدم الطلب مع السجل المسجل." }}
      """.trimIndent()
    }
  }

  fun openWhatsAppAdminForRegistration(
    context: Context,
    phone: String,
    country: String,
    city: String,
    bio: String,
    licenseLink: String
  ): Boolean {
    val msg = """
      🩺 طلب إنشاء حساب ممرض جديد في GoNurse:
      • رقم الهاتف: $phone
      • الدولة: $country
      • المدينة: $city
      • النبذة: $bio
      • ترخيص المهنة: $licenseLink
    """.trimIndent()
    return openWhatsApp(context, ADMIN_WHATSAPP_NUMBER, msg)
  }

  fun openWhatsAppAdminForProfileUpdate(
    context: Context,
    registeredPhone: String,
    requestedPhone: String,
    requestedCountry: String,
    requestedCity: String,
    requestedBio: String
  ): Boolean {
    val msg = buildProfileUpdateRequestAdminMessage(
      nurseId = registeredPhone,
      registeredPhone = registeredPhone,
      requestedPhone = requestedPhone,
      requestedCountry = requestedCountry,
      requestedCity = requestedCity,
      requestedBio = requestedBio
    )
    return openWhatsApp(context, ADMIN_WHATSAPP_NUMBER, msg)
  }

  fun openWhatsAppAdminForDeletion(
    context: Context,
    registeredPhone: String,
    reason: String
  ): Boolean {
    val msg = buildAccountDeletionRequestAdminMessage(
      nurseId = registeredPhone,
      registeredPhone = registeredPhone,
      reason = reason
    )
    return openWhatsApp(context, ADMIN_WHATSAPP_NUMBER, msg)
  }

  fun openWhatsAppDecision(
    context: Context,
    recipientPhone: String,
    message: String
  ): Boolean {
    return openWhatsApp(context, recipientPhone, message)
  }

  /**
   * Builds confirmation message sent to the Admin WhatsApp number (+994407958647)
   * upon approving or rejecting a nurse registration.
   */
  fun buildRegistrationDecisionAdminNotification(
    nursePhone: String,
    nurseCity: String,
    nurseCountry: String,
    isApproved: Boolean,
    reason: String = ""
  ): String {
    return if (isApproved) {
      """
        ✅ [تأكيد إداري] تم اعتماد وتوثيق حساب الممرض:
        • رقم الهاتف: $nursePhone
        • الدولة والمدينة: $nurseCountry - $nurseCity
        • الإجراء: تم تفعيل الشارة الزرقاء واعتماد السجل في Firebase RTDB
      """.trimIndent()
    } else {
      """
        ❌ [تأكيد إداري] تم رفض طلب توثيق حساب الممرض:
        • رقم الهاتف: $nursePhone
        • الدولة والمدينة: $nurseCountry - $nurseCity
        • السبب: ${reason.ifBlank { "عدم استيفاء شروط ترخيص مزاولة المهنة" }}
        • الإجراء: تم تحديث الحالة إلى مرفوض في Firebase RTDB
      """.trimIndent()
    }
  }

  /**
   * Builds confirmation message sent to the Admin WhatsApp number (+994407958647)
   * upon approving or rejecting a profile update.
   */
  fun buildProfileUpdateAdminNotification(
    registeredPhone: String,
    requestedPhone: String,
    requestedCity: String,
    isApproved: Boolean,
    reason: String = ""
  ): String {
    return if (isApproved) {
      """
        ✅ [تأكيد إداري] تم اعتماد تعديل بيانات الممرض:
        • رقم الهاتف الأصلي: $registeredPhone
        • رقم الهاتف الجديد: ${requestedPhone.ifBlank { registeredPhone }}
        • المدينة الجديدة: $requestedCity
        • الإجراء: تم تحديث بيانات الممرض في Firebase RTDB
      """.trimIndent()
    } else {
      """
        ❌ [تأكيد إداري] تم رفض طلب تعديل بيانات الممرض:
        • رقم الهاتف: $registeredPhone
        • السبب: ${reason.ifBlank { "عدم تطابق رقم الهاتف" }}
        • الإجراء: تم رفض الطلب في Firebase RTDB
      """.trimIndent()
    }
  }

  /**
   * Builds confirmation message sent to the Admin WhatsApp number (+994407958647)
   * upon approving or rejecting an account deletion.
   */
  fun buildAccountDeletionAdminNotification(
    nursePhone: String,
    isApproved: Boolean,
    reason: String = ""
  ): String {
    return if (isApproved) {
      """
        🗑️ [تأكيد إداري] تم حذف ومسح حساب الممرض نهائياً:
        • رقم الهاتف: $nursePhone
        • الإجراء: تم مسح كامل سجل وبيانات الممرض نهائياً من خوادم Firebase RTDB
      """.trimIndent()
    } else {
      """
        ❌ [تأكيد إداري] تم رفض طلب حذف حساب الممرض:
        • رقم الهاتف: $nursePhone
        • السبب: ${reason.ifBlank { "عدم تطابق رقم الهاتف أو تعذر التحقق" }}
      """.trimIndent()
    }
  }
}

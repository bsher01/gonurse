package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Network connection observer and monitor.
 * Continuously tracks actual internet connectivity status using Android ConnectivityManager callbacks.
 */
object NetworkMonitor {

  /**
   * Checks if network is currently connected and validated.
   */
  fun isOnline(context: Context): Boolean {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val activeNetwork = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ||
         capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
         capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
         capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
  }

  /**
   * Flow emitting connectivity status boolean whenever network transitions online/offline.
   */
  fun observeConnectivity(context: Context): Flow<Boolean> = observeNetworkConnectivity(context)

  fun observeNetworkConnectivity(context: Context): Flow<Boolean> = callbackFlow {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    if (connectivityManager == null) {
      trySend(true)
      close()
      return@callbackFlow
    }

    // Initial state
    trySend(isOnline(context))

    val callback = object : ConnectivityManager.NetworkCallback() {
      override fun onAvailable(network: Network) {
        trySend(true)
      }

      override fun onLost(network: Network) {
        trySend(isOnline(context))
      }

      override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
        val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        trySend(hasInternet)
      }
    }

    val request = NetworkRequest.Builder()
      .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
      .build()

    try {
      connectivityManager.registerNetworkCallback(request, callback)
    } catch (e: Exception) {
      android.util.Log.e("NetworkMonitor", "Error registering network callback: ${e.message}")
      trySend(true)
    }

    awaitClose {
      try {
        connectivityManager.unregisterNetworkCallback(callback)
      } catch (e: Exception) {
        android.util.Log.e("NetworkMonitor", "Error unregistering network callback: ${e.message}")
      }
    }
  }.distinctUntilChanged()
}

/**
 * Composable helper returning current network connectivity state.
 */
@Composable
fun rememberNetworkConnectivityState(): State<Boolean> {
  val context = LocalContext.current
  return produceState(initialValue = NetworkMonitor.isOnline(context)) {
    NetworkMonitor.observeNetworkConnectivity(context).collect { isConnected ->
      value = isConnected
    }
  }
}

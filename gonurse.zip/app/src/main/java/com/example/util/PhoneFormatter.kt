package com.example.util

import com.example.model.CountryInfo
import com.example.model.CountryRepository

object PhoneFormatter {

  /**
   * Converts Eastern Arabic (٠-٩) and Persian (۰-۹) numerals to standard ASCII 0-9 digits and keeps +,
   * stripping away all spaces, dashes, parentheses, dots, slashes, and decorative symbols.
   */
  fun sanitizePhoneInput(input: String): String {
    val sb = StringBuilder()
    for (ch in input.trim()) {
      when (ch) {
        in '0'..'9' -> sb.append(ch)
        in '٠'..'٩' -> sb.append((ch - '٠' + '0'.code).toChar())
        in '۰'..'۹' -> sb.append((ch - '۰' + '0'.code).toChar())
        '+' -> if (sb.isEmpty()) sb.append('+')
      }
    }
    return sb.toString()
  }

  /**
   * Smart auto-detection and normalization:
   * 1. Sanitizes input string to extract all numerical digits
   * 2. Detects if input begins with `+` or `00` or dial code matching any known country
   * 3. Strips redundant country code prefixes or leading zeros
   * 4. Returns the detected CountryInfo and the cleaned local phone number
   */
  fun parseAndFormat(
    input: String,
    currentCountry: CountryInfo
  ): Pair<CountryInfo, String> {
    val sanitized = sanitizePhoneInput(input)
    if (sanitized.isEmpty()) {
      return Pair(currentCountry, "")
    }

    var normalized = sanitized
    if (normalized.startsWith("00")) {
      normalized = "+" + normalized.substring(2)
    }

    var detectedCountry = currentCountry
    var localNumber = normalized

    if (normalized.startsWith("+")) {
      // Find matching country from the dial code list (longest dial code match first)
      val match = CountryRepository.countries
        .sortedByDescending { it.dialCode.length }
        .firstOrNull { normalized.startsWith(it.dialCode) }

      if (match != null) {
        detectedCountry = match
        localNumber = normalized.removePrefix(match.dialCode)
      } else {
        localNumber = normalized.removePrefix("+")
      }
    } else {
      // Check if user typed dial code digits without '+' prefix (e.g. 963933123456)
      val currentDialDigits = currentCountry.dialCode.removePrefix("+")
      if (normalized.startsWith(currentDialDigits) && normalized.length >= currentDialDigits.length + 8) {
        localNumber = normalized.removePrefix(currentDialDigits)
      } else {
        val matchingCountryWithoutPlus = CountryRepository.countries
          .sortedByDescending { it.dialCode.length }
          .firstOrNull {
            val codeDigits = it.dialCode.removePrefix("+")
            normalized.startsWith(codeDigits) && normalized.length >= codeDigits.length + 8
          }
        if (matchingCountryWithoutPlus != null) {
          detectedCountry = matchingCountryWithoutPlus
          localNumber = normalized.removePrefix(matchingCountryWithoutPlus.dialCode.removePrefix("+"))
        }
      }
    }

    // Strip leading zero for standard international storage/combining
    val cleanLocal = if (localNumber.startsWith("0") && localNumber.length > 1) {
      localNumber.substring(1)
    } else {
      localNumber
    }

    return Pair(detectedCountry, cleanLocal)
  }

  /**
   * Builds the complete E.164 formatted international number (e.g. +963933123456)
   */
  fun getFullInternationalNumber(country: CountryInfo, localNumber: String): String {
    val sanitized = sanitizePhoneInput(localNumber)
    val cleanLocal = if (sanitized.startsWith("0") && sanitized.length > 1) {
      sanitized.substring(1)
    } else {
      sanitized
    }
    if (cleanLocal.isEmpty()) return ""
    return "${country.dialCode}$cleanLocal"
  }

  /**
   * Returns a user-friendly display formatted string, e.g., "+963 933 123 456"
   */
  fun formatForDisplay(country: CountryInfo, localNumber: String): String {
    val sanitized = sanitizePhoneInput(localNumber)
    val clean = if (sanitized.startsWith("0") && sanitized.length > 1) {
      sanitized.substring(1)
    } else {
      sanitized
    }
    if (clean.isEmpty()) return "${country.dialCode} "

    val sb = StringBuilder()
    sb.append(country.dialCode).append(" ")
    for (i in clean.indices) {
      if (i > 0 && (i % 3 == 0 || (clean.length > 8 && (i == 3 || i == 6)))) {
        sb.append(" ")
      }
      sb.append(clean[i])
    }
    return sb.toString()
  }

  /**
   * Flexible phone number validation:
   * Validates whether any phone number length is between 8 and 14 digits,
   * properly sanitizing input to extract digits regardless of country code,
   * leading zeros, spacing, parentheses, dashes, or Arabic numerals.
   */
  fun isValidPhoneNumber(phoneNumber: String): Boolean {
    val sanitized = sanitizePhoneInput(phoneNumber)
    val digitsOnly = sanitized.filter { it.isDigit() }

    // Direct digit length check for 8 to 14 digits
    if (digitsOnly.length in 8..14) return true

    // If phone starts with leading zero (e.g., 012345678), check stripped digit count
    val withoutLeadingZero = digitsOnly.removePrefix("0")
    if (withoutLeadingZero.length in 8..14) return true

    return false
  }

  fun formatToInternational(rawDigits: String, country: CountryInfo): String {
    val clean = sanitizePhoneInput(rawDigits).trimStart('0')
    val dialDigits = country.dialCode.removePrefix("+")
    return if (clean.startsWith(dialDigits)) "+$clean" else "${country.dialCode}$clean"
  }
}

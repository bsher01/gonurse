package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Result data class containing compressed image bytes, Base64 representation, and dimensions.
 */
data class CompressedImageResult(
  val bytes: ByteArray,
  val base64: String,
  val width: Int,
  val height: Int
)

object ImageCompressor {

  // In-memory LRU Cache for decoded Base64 bitmaps (up to 40 entries) to avoid repeat CPU decoding
  private val decodedBitmapCache = LruCache<String, Bitmap>(40)

  /**
   * Strictly compresses and resizes profile pictures to minimize mobile data usage.
   * Target: Max dimension 320px, JPEG quality ~70%, target size under 35KB.
   * Perfect for profile avatars, nurse cards, and map markers while consuming negligible bandwidth.
   */
  suspend fun compressProfileImage(
    context: Context,
    uri: Uri,
    maxDimension: Int = 320,
    maxQuality: Int = 70,
    targetMaxBytes: Int = 35 * 1024
  ): CompressedImageResult = withContext(Dispatchers.IO) {
    try {
      var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
      val boundsOptions = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
      }
      BitmapFactory.decodeStream(inputStream, null, boundsOptions)
      inputStream?.close()

      // Calculate sample size
      var inSampleSize = 1
      val width = boundsOptions.outWidth
      val height = boundsOptions.outHeight
      if (width > maxDimension || height > maxDimension) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
          inSampleSize *= 2
        }
      }

      val decodeOptions = BitmapFactory.Options().apply {
        inSampleSize = inSampleSize
      }
      inputStream = context.contentResolver.openInputStream(uri)
      val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
      inputStream?.close()

      if (bitmap == null) {
        return@withContext CompressedImageResult(ByteArray(0), "", 0, 0)
      }

      // Proportional downscale to maxDimension
      val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
        val ratio = maxDimension.toFloat() / Math.max(bitmap.width, bitmap.height)
        val targetWidth = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetHeight = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
      } else {
        bitmap
      }

      val outputStream = ByteArrayOutputStream()
      var quality = maxQuality
      scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)

      // Strict enforcement of targetMaxBytes (~35KB)
      while (outputStream.toByteArray().size > targetMaxBytes && quality > 25) {
        outputStream.reset()
        quality -= 10
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      }

      val bytes = outputStream.toByteArray()
      val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

      // Pre-warm memory cache so preview doesn't re-decode
      val cacheKey = if (base64.length > 64) base64.take(64) else base64
      decodedBitmapCache.put(cacheKey, scaledBitmap)

      CompressedImageResult(
        bytes = bytes,
        base64 = base64,
        width = scaledBitmap.width,
        height = scaledBitmap.height
      )
    } catch (e: Exception) {
      android.util.Log.e("ImageCompressor", "Error compressing profile picture: ${e.message}", e)
      CompressedImageResult(ByteArray(0), "", 0, 0)
    }
  }

  /**
   * Compresses an image from Uri to a Base64 string.
   * Aggressively optimizes byte size to consume minimal mobile data (typically 30-70KB max)
   * while preserving clinical clarity for licenses, ID cards, and incident attachments.
   */
  suspend fun compressUriToBase64(context: Context, uri: Uri): String = uriToBase64(context, uri)

  suspend fun uriToBase64(
    context: Context,
    uri: Uri,
    maxDimension: Int = 420,
    maxQuality: Int = 68,
    targetMaxBytes: Int = 75 * 1024
  ): String = withContext(Dispatchers.IO) {
    try {
      var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
      val boundsOptions = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
      }
      BitmapFactory.decodeStream(inputStream, null, boundsOptions)
      inputStream?.close()

      // Calculate inSampleSize
      var inSampleSize = 1
      val width = boundsOptions.outWidth
      val height = boundsOptions.outHeight
      if (width > maxDimension || height > maxDimension) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
          inSampleSize *= 2
        }
      }

      val decodeOptions = BitmapFactory.Options().apply {
        inSampleSize = inSampleSize
      }
      inputStream = context.contentResolver.openInputStream(uri)
      val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
      inputStream?.close()

      if (bitmap == null) return@withContext ""

      // Scale proportionally to fit within maxDimension
      val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
        val ratio = maxDimension.toFloat() / Math.max(bitmap.width, bitmap.height)
        val targetWidth = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetHeight = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
      } else {
        bitmap
      }

      val outputStream = ByteArrayOutputStream()
      var quality = maxQuality
      scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)

      // Aggressive payload compression to enforce targetMaxBytes (default ~75KB)
      while (outputStream.toByteArray().size > targetMaxBytes && quality > 20) {
        outputStream.reset()
        quality -= 12
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      }

      val bytes = outputStream.toByteArray()
      Base64.encodeToString(bytes, Base64.NO_WRAP)
    } catch (e: Exception) {
      android.util.Log.e("ImageCompressor", "Error compressing image to Base64: ${e.message}", e)
      ""
    }
  }

  /**
   * Fast cached Base64 decoder. Checks the in-memory LRU cache before decoding,
   * avoiding main-thread GC thrashing and stutter during list scrolling.
   */
  fun getCachedOrDecodeBase64(base64Str: String): Bitmap? {
    if (base64Str.isBlank()) return null
    val cacheKey = if (base64Str.length > 64) base64Str.take(64) else base64Str
    val cached = decodedBitmapCache.get(cacheKey)
    if (cached != null) return cached

    val decoded = base64ToBitmap(base64Str)
    if (decoded != null) {
      decodedBitmapCache.put(cacheKey, decoded)
    }
    return decoded
  }

  /**
   * Decodes a Base64 string into a memory Bitmap. Returns null if invalid.
   */
  fun base64ToBitmap(base64Str: String): Bitmap? {
    return try {
      if (base64Str.isBlank()) return null
      val cleanStr = if (base64Str.contains(",")) {
        base64Str.substringAfter(",")
      } else {
        base64Str
      }
      val decodedBytes = Base64.decode(cleanStr, Base64.DEFAULT)
      BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
    } catch (e: Exception) {
      android.util.Log.e("ImageCompressor", "Error decoding Base64 to bitmap: ${e.message}")
      null
    }
  }
}

package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * Result data class containing compressed image bytes, Base64 representation, and dimensions.
 */
data class CompressedImageResult(
  val bytes: ByteArray,
  val base64: String,
  val width: Int,
  val height: Int
)

object ImageCompressor {

  private const val TAG = "ImageCompressor"

  // In-memory LRU Cache for decoded bitmaps (up to 50 entries) to avoid repeat CPU decoding
  private val decodedBitmapCache = LruCache<String, Bitmap>(50)

  /**
   * Helper to determine optimal WebP compression format based on API level.
   * Android R (API 30+) provides WEBP_LOSSY; prior versions use WEBP.
   */
  @Suppress("DEPRECATION")
  fun getWebPFormat(): Bitmap.CompressFormat {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      Bitmap.CompressFormat.WEBP_LOSSY
    } else {
      Bitmap.CompressFormat.WEBP
    }
  }

  /**
   * Returns dedicated on-device cache directory for compressed WebP assets.
   */
  fun getWebPCacheDir(context: Context): File {
    val dir = File(context.cacheDir, "gonurse_webp_cache")
    if (!dir.exists()) {
      dir.mkdirs()
    }
    return dir
  }

  /**
   * Generates a stable alphanumeric cache key for image payloads (Base64, URLs, Uris).
   */
  fun getCacheKeyForSource(source: String): String {
    if (source.isBlank()) return ""
    return try {
      val md = MessageDigest.getInstance("MD5")
      val digest = md.digest(source.toByteArray())
      digest.joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
      source.hashCode().toString()
    }
  }

  /**
   * Retrieves an on-disk cached WebP file if it exists and has content.
   */
  fun getCachedWebPFile(context: Context, source: String): File? {
    if (source.isBlank()) return null
    val key = getCacheKeyForSource(source)
    val file = File(getWebPCacheDir(context), "$key.webp")
    return if (file.exists() && file.length() > 0) file else null
  }

  /**
   * Safely loads and decodes a Bitmap directly from a cached WebP file on disk.
   */
  fun getBitmapFromFile(file: File): Bitmap? {
    return try {
      if (!file.exists() || file.length() == 0L) return null
      val cacheKey = file.nameWithoutExtension
      val cached = decodedBitmapCache.get(cacheKey)
      if (cached != null) return cached

      val bitmap = BitmapFactory.decodeFile(file.absolutePath)
      if (bitmap != null) {
        decodedBitmapCache.put(cacheKey, bitmap)
      }
      bitmap
    } catch (e: Exception) {
      Log.w(TAG, "Failed reading bitmap from WebP file: ${e.message}")
      null
    }
  }

  /**
   * Saves WebP bytes to the local on-device cache directory.
   */
  fun saveWebPBytesToDisk(context: Context, source: String, bytes: ByteArray): File? {
    if (source.isBlank() || bytes.isEmpty()) return null
    return try {
      val key = getCacheKeyForSource(source)
      val file = File(getWebPCacheDir(context), "$key.webp")
      file.writeBytes(bytes)
      file
    } catch (e: Exception) {
      Log.w(TAG, "Error saving WebP to disk cache: ${e.message}")
      null
    }
  }

  /**
   * Strictly compresses and resizes profile pictures to minimize mobile data usage.
   * Uses WebP format for 30-40% smaller payload size than JPEG at identical visual quality.
   * Target: Max dimension 320px, WebP quality ~70%, target size under 30KB.
   */
  suspend fun compressProfileImage(
    context: Context,
    uri: Uri,
    maxDimension: Int = 320,
    maxQuality: Int = 70,
    targetMaxBytes: Int = 30 * 1024
  ): CompressedImageResult = withContext(Dispatchers.IO) {
    try {
      var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
      val boundsOptions = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
      }
      BitmapFactory.decodeStream(inputStream, null, boundsOptions)
      inputStream?.close()

      // Calculate sample size
      var inSampleSize = 1
      val width = boundsOptions.outWidth
      val height = boundsOptions.outHeight
      if (width > maxDimension || height > maxDimension) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
          inSampleSize *= 2
        }
      }

      val decodeOptions = BitmapFactory.Options().apply {
        this.inSampleSize = inSampleSize
      }
      inputStream = context.contentResolver.openInputStream(uri)
      val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
      inputStream?.close()

      if (bitmap == null) {
        return@withContext CompressedImageResult(ByteArray(0), "", 0, 0)
      }

      // Proportional downscale to maxDimension
      val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
        val ratio = maxDimension.toFloat() / Math.max(bitmap.width, bitmap.height)
        val targetWidth = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetHeight = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
      } else {
        bitmap
      }

      val format = getWebPFormat()
      val outputStream = ByteArrayOutputStream()
      var quality = maxQuality
      var compressSuccess = scaledBitmap.compress(format, quality, outputStream)
      if (!compressSuccess) {
        // Fallback to JPEG if WebP compression fails
        outputStream.reset()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      }

      // Strict enforcement of targetMaxBytes (~30KB)
      while (outputStream.toByteArray().size > targetMaxBytes && quality > 25) {
        outputStream.reset()
        quality -= 10
        compressSuccess = scaledBitmap.compress(format, quality, outputStream)
        if (!compressSuccess) {
          outputStream.reset()
          scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        }
      }

      val bytes = outputStream.toByteArray()
      val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

      // Persist to local WebP disk cache for instant offline reload
      saveWebPBytesToDisk(context, base64, bytes)

      // Pre-warm memory cache so preview doesn't re-decode
      val cacheKey = if (base64.length > 64) base64.take(64) else base64
      decodedBitmapCache.put(cacheKey, scaledBitmap)

      CompressedImageResult(
        bytes = bytes,
        base64 = base64,
        width = scaledBitmap.width,
        height = scaledBitmap.height
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error compressing profile picture: ${e.message}", e)
      CompressedImageResult(ByteArray(0), "", 0, 0)
    }
  }

  /**
   * Safely decodes and downsamples an image from Uri without OOM, suitable for interactive cropping.
   */
  suspend fun decodeSampledBitmap(
    context: Context,
    uri: Uri,
    maxDimension: Int = 1080
  ): Bitmap? = withContext(Dispatchers.IO) {
    try {
      var inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
      val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
      BitmapFactory.decodeStream(inputStream, null, boundsOptions)
      inputStream.close()

      var inSampleSize = 1
      val width = boundsOptions.outWidth
      val height = boundsOptions.outHeight
      if (width > maxDimension || height > maxDimension) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
          inSampleSize *= 2
        }
      }

      val decodeOptions = BitmapFactory.Options().apply {
        this.inSampleSize = inSampleSize
        inPreferredConfig = Bitmap.Config.ARGB_8888
      }
      inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
      val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
      inputStream.close()
      bitmap
    } catch (e: Exception) {
      Log.e(TAG, "Error decoding sampled bitmap: ${e.message}", e)
      null
    }
  }

  /**
   * Crops a specified sub-region of a Bitmap, applies rotation, scales down to target avatar dimensions,
   * and strictly compresses it to under targetMaxBytes using modern WebP format.
   */
  suspend fun cropAndCompress(
    sourceBitmap: Bitmap,
    cropX: Int,
    cropY: Int,
    cropWidth: Int,
    cropHeight: Int,
    rotationDegrees: Float = 0f,
    maxDimension: Int = 340,
    maxQuality: Int = 72,
    targetMaxBytes: Int = 38 * 1024,
    context: Context? = null
  ): CompressedImageResult = withContext(Dispatchers.IO) {
    try {
      val safeX = cropX.coerceIn(0, (sourceBitmap.width - 1).coerceAtLeast(0))
      val safeY = cropY.coerceIn(0, (sourceBitmap.height - 1).coerceAtLeast(0))
      val safeWidth = cropWidth.coerceIn(1, sourceBitmap.width - safeX)
      val safeHeight = cropHeight.coerceIn(1, sourceBitmap.height - safeY)

      val matrix = android.graphics.Matrix()
      if (rotationDegrees != 0f) {
        matrix.postRotate(rotationDegrees)
      }

      val cropped = Bitmap.createBitmap(sourceBitmap, safeX, safeY, safeWidth, safeHeight, matrix, true)

      // Downscale proportionally to maxDimension (e.g. 340px)
      val scaledBitmap = if (cropped.width > maxDimension || cropped.height > maxDimension) {
        val ratio = maxDimension.toFloat() / Math.max(cropped.width, cropped.height)
        val targetW = (cropped.width * ratio).toInt().coerceAtLeast(1)
        val targetH = (cropped.height * ratio).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(cropped, targetW, targetH, true)
      } else {
        cropped
      }

      val format = getWebPFormat()
      val outputStream = ByteArrayOutputStream()
      var quality = maxQuality
      var compressSuccess = scaledBitmap.compress(format, quality, outputStream)
      if (!compressSuccess) {
        outputStream.reset()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      }

      // Aggressive WebP compression loop to guarantee payload stays strictly under targetMaxBytes
      while (outputStream.toByteArray().size > targetMaxBytes && quality > 25) {
        outputStream.reset()
        quality -= 8
        compressSuccess = scaledBitmap.compress(format, quality, outputStream)
        if (!compressSuccess) {
          outputStream.reset()
          scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        }
      }

      val bytes = outputStream.toByteArray()
      val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

      if (context != null) {
        saveWebPBytesToDisk(context, base64, bytes)
      }

      // Pre-warm cache
      val cacheKey = if (base64.length > 64) base64.take(64) else base64
      decodedBitmapCache.put(cacheKey, scaledBitmap)

      CompressedImageResult(
        bytes = bytes,
        base64 = base64,
        width = scaledBitmap.width,
        height = scaledBitmap.height
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error in cropAndCompress: ${e.message}", e)
      CompressedImageResult(ByteArray(0), "", 0, 0)
    }
  }

  /**
   * Compresses an image from Uri to a WebP Base64 string with on-device disk caching.
   * Preserves clinical clarity for licenses, ID cards, and incident attachments
   * while minimizing mobile data bandwidth.
   */
  suspend fun compressUriToBase64(context: Context, uri: Uri): String = uriToBase64(context, uri)

  suspend fun uriToBase64(
    context: Context,
    uri: Uri,
    maxDimension: Int = 420,
    maxQuality: Int = 68,
    targetMaxBytes: Int = 65 * 1024
  ): String = withContext(Dispatchers.IO) {
    try {
      var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
      val boundsOptions = BitmapFactory.Options().apply {
        inJustDecodeBounds = true
      }
      BitmapFactory.decodeStream(inputStream, null, boundsOptions)
      inputStream?.close()

      // Calculate inSampleSize
      var inSampleSize = 1
      val width = boundsOptions.outWidth
      val height = boundsOptions.outHeight
      if (width > maxDimension || height > maxDimension) {
        val halfHeight = height / 2
        val halfWidth = width / 2
        while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
          inSampleSize *= 2
        }
      }

      val decodeOptions = BitmapFactory.Options().apply {
        this.inSampleSize = inSampleSize
      }
      inputStream = context.contentResolver.openInputStream(uri)
      val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
      inputStream?.close()

      if (bitmap == null) return@withContext ""

      // Scale proportionally to fit within maxDimension
      val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
        val ratio = maxDimension.toFloat() / Math.max(bitmap.width, bitmap.height)
        val targetWidth = (bitmap.width * ratio).toInt().coerceAtLeast(1)
        val targetHeight = (bitmap.height * ratio).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
      } else {
        bitmap
      }

      val format = getWebPFormat()
      val outputStream = ByteArrayOutputStream()
      var quality = maxQuality
      var compressSuccess = scaledBitmap.compress(format, quality, outputStream)
      if (!compressSuccess) {
        outputStream.reset()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
      }

      // Aggressive payload compression to enforce targetMaxBytes
      while (outputStream.toByteArray().size > targetMaxBytes && quality > 20) {
        outputStream.reset()
        quality -= 10
        compressSuccess = scaledBitmap.compress(format, quality, outputStream)
        if (!compressSuccess) {
          outputStream.reset()
          scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        }
      }

      val bytes = outputStream.toByteArray()
      val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

      // Save to WebP disk cache
      saveWebPBytesToDisk(context, base64, bytes)

      // Pre-warm cache
      val cacheKey = if (base64.length > 64) base64.take(64) else base64
      decodedBitmapCache.put(cacheKey, scaledBitmap)

      base64
    } catch (e: Exception) {
      Log.e(TAG, "Error compressing image to Base64: ${e.message}", e)
      ""
    }
  }

  /**
   * Fast cached Base64 decoder with two-tier caching:
   * 1. High-speed in-memory LRU cache.
   * 2. Persistent on-disk WebP file cache.
   * 3. Fallback to CPU Base64 decoding, automatically populating the disk cache.
   */
  fun getCachedOrDecodeBase64(base64Str: String, context: Context? = null): Bitmap? {
    if (base64Str.isBlank()) return null
    val cacheKey = if (base64Str.length > 64) base64Str.take(64) else base64Str

    // Tier 1: In-memory LRU cache
    val memoryCached = decodedBitmapCache.get(cacheKey)
    if (memoryCached != null) return memoryCached

    // Tier 2: On-disk WebP file cache (if context provided)
    if (context != null) {
      val cachedFile = getCachedWebPFile(context, base64Str)
      if (cachedFile != null) {
        val diskBitmap = getBitmapFromFile(cachedFile)
        if (diskBitmap != null) {
          decodedBitmapCache.put(cacheKey, diskBitmap)
          return diskBitmap
        }
      }
    }

    // Tier 3: Decode Base64 string
    val decoded = base64ToBitmap(base64Str)
    if (decoded != null) {
      decodedBitmapCache.put(cacheKey, decoded)
      // Asynchronously or safely cache to disk as WebP
      if (context != null) {
        try {
          val outputStream = ByteArrayOutputStream()
          if (decoded.compress(getWebPFormat(), 75, outputStream)) {
            saveWebPBytesToDisk(context, base64Str, outputStream.toByteArray())
          }
        } catch (_: Exception) {}
      }
    }
    return decoded
  }

  /**
   * Decodes a Base64 string into a memory Bitmap. Returns null if invalid.
   */
  fun base64ToBitmap(base64Str: String): Bitmap? {
    return try {
      if (base64Str.isBlank()) return null
      val cleanStr = if (base64Str.contains(",")) {
        base64Str.substringAfter(",")
      } else {
        base64Str
      }
      val decodedBytes = Base64.decode(cleanStr, Base64.DEFAULT)
      BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
    } catch (e: Exception) {
      Log.e(TAG, "Error decoding Base64 to bitmap: ${e.message}")
      null
    }
  }
}

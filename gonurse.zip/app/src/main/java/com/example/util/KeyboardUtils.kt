package com.example.util

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.imeNestedScroll
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusEvent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Utility modifier that automatically adjusts scroll position and brings the active
 * text field into view when it receives focus or when the virtual keyboard appears.
 * Prevents active inputs from being obscured or clipped behind the soft keyboard.
 */
@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
fun Modifier.bringIntoViewOnFocus(
  delayMs: Long = 250L
): Modifier = composed {
  val requester = remember { BringIntoViewRequester() }
  val coroutineScope = rememberCoroutineScope()
  var isFocused by remember { mutableStateOf(false) }
  val imeVisible = WindowInsets.isImeVisible

  LaunchedEffect(isFocused, imeVisible) {
    if (isFocused && imeVisible) {
      delay(delayMs)
      try {
        requester.bringIntoView()
      } catch (_: Exception) {}
    }
  }

  this
    .bringIntoViewRequester(requester)
    .onFocusEvent { state ->
      isFocused = state.isFocused
      if (state.isFocused) {
        coroutineScope.launch {
          delay(delayMs)
          try {
            requester.bringIntoView()
          } catch (_: Exception) {}
        }
      }
    }
}

/**
 * Attaches nested scrolling coordination with the virtual keyboard,
 * allowing soft keyboard to smoothly adjust when dragging the scroll container.
 */
@OptIn(ExperimentalLayoutApi::class)
fun Modifier.keyboardNestedScroll(): Modifier = this.imeNestedScroll()


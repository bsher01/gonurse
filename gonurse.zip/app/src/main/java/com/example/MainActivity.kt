package com.example

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.BuildConfig
import com.example.data.FirebaseRealtimeRepository
import com.example.data.FirebaseRemoteConfigManager
import com.example.data.LanguageStore
import com.example.data.LegalTermsStore
import com.example.data.UserAuthStore
import com.example.model.AppConfig
import com.example.model.AppLanguage
import com.example.ui.AdminScreen
import com.example.ui.DashboardScreen
import com.example.ui.SignUpScreen
import com.example.ui.SplashScreen
import com.example.ui.components.ForcedUpdateDialog
import com.example.ui.components.LegalDisclaimerDialog
import com.example.ui.theme.MyApplicationTheme
import com.example.util.FcmManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ScreenState {
  SPLASH,
  DASHBOARD,
  SIGN_UP,
  ADMIN
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Ensure FirebaseApp is initialized from google-services.json configuration on startup
    com.example.data.FirebaseAuthService.ensureFirebaseInitialized(this)

    // Initialize Firebase Cloud Messaging and channel without popping up blocking dialogs on startup
    FcmManager.init(this)
    // Notification permission popup is gracefully bypassed on startup to prevent blocking UI interaction in emulator preview
    FcmManager.requestNotificationPermission(this, force = false)

    // Initialize local Room database repository context
    FirebaseRealtimeRepository.init(this)

    // Initialize Firebase Remote Config for force update checks
    FirebaseRemoteConfigManager.init()

    handleDeepLink(intent)

    setContent {
      GoNurseApp()
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleDeepLink(intent)
  }

  private fun handleDeepLink(intent: Intent?) {
    val uri = intent?.data ?: return
    val isVerificationScheme = (uri.scheme == "gonurse" && uri.host == "verify") ||
        (uri.host == "gonurse.app" && uri.path?.startsWith("/verify") == true)

    if (isVerificationScheme) {
      val nurseId = uri.getQueryParameter("nurseId") ?: ""
      val action = uri.getQueryParameter("action") ?: ""
      val nurseName = uri.getQueryParameter("nurseName") ?: "الكادر التمريضي"
      val nurseEmail = uri.getQueryParameter("nurseEmail") ?: ""

      if (nurseId.isNotBlank()) {
        val isApproved = action.equals("approve", ignoreCase = true)
        CoroutineScope(Dispatchers.IO).launch {
          FirebaseRealtimeRepository.updateNurseVerificationStatus(
            nurseId = nurseId,
            isVerified = isApproved,
            status = if (isApproved) "APPROVED" else "REJECTED"
          )
          withContext(Dispatchers.Main) {
            val msg = if (isApproved) {
              "✅ تم اعتماد توثيق الممرض ($nurseName) وتفعيل الشارة الزرقاء بنجاح"
            } else {
              "❌ تم رفض طلب توثيق ($nurseName) وتحديث الحالة"
            }
            Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
          }
        }
      }
    }
  }
}

@Composable
fun GoNurseApp() {
  val context = LocalContext.current
  var currentScreen by remember { mutableStateOf(ScreenState.SPLASH) }
  var currentLanguage by remember { mutableStateOf(LanguageStore.getSavedLanguage(context)) }
  var showLegalDisclaimer by remember {
    mutableStateOf(!LegalTermsStore.isDisclaimerAccepted(context))
  }

  // App version tracking and Forced Update states
  val currentVersionName = remember { BuildConfig.VERSION_NAME }
  val currentVersionCode = remember { BuildConfig.VERSION_CODE.toLong() }
  var appConfig by remember { mutableStateOf<AppConfig?>(null) }
  var isUpdateRequired by remember { mutableStateOf(false) }

  // Fetch and compare app version with Firebase Remote Config (min_app_version & update_url) upon app launch
  LaunchedEffect(Unit) {
    try {
      // 1. Fetch & evaluate latest parameters from Firebase Remote Config
      val remoteCheck = FirebaseRemoteConfigManager.checkForceUpdate(
        currentVersionCode = currentVersionCode,
        currentVersionName = currentVersionName
      )
      appConfig = remoteCheck.appConfig

      if (remoteCheck.isUpdateRequired) {
        isUpdateRequired = true
      } else {
        // 2. Auxiliary check with Firebase RTDB app_config for backwards compatibility
        try {
          val rtdbConfig = FirebaseRealtimeRepository.fetchAppConfig()
          val isRtdbOutdated = currentVersionCode < rtdbConfig.minVersionCode ||
              isSemanticVersionOlder(currentVersionName, rtdbConfig.minVersionName) ||
              rtdbConfig.isForceUpdateRequired

          if (isRtdbOutdated) {
            appConfig = rtdbConfig.copy(
              updateUrl = remoteCheck.updateUrl.ifBlank { rtdbConfig.updateUrl }
            )
            isUpdateRequired = true
          }
        } catch (_: Exception) {
          // Ignore RTDB error if Remote Config was already processed
        }
      }
    } catch (_: Exception) {
      // Gracefully fall back to RTDB app_config if Remote Config network call fails
      try {
        val config = FirebaseRealtimeRepository.fetchAppConfig()
        appConfig = config
        val isVersionCodeOutdated = currentVersionCode < config.minVersionCode
        val isVersionNameOutdated = isSemanticVersionOlder(currentVersionName, config.minVersionName)
        if (isVersionCodeOutdated || isVersionNameOutdated || config.isForceUpdateRequired) {
          isUpdateRequired = true
        }
      } catch (_: Exception) {
        // Offline or fallback silently
      }
    }
  }

  val switchLanguage: () -> Unit = {
    val newLanguage = currentLanguage.toggle()
    currentLanguage = newLanguage
    LanguageStore.saveLanguage(context, newLanguage)
  }

  // System back button interceptor: steps back from sub-screens to Dashboard without closing app
  BackHandler(enabled = currentScreen == ScreenState.SIGN_UP || currentScreen == ScreenState.ADMIN) {
    currentScreen = ScreenState.DASHBOARD
  }

  val layoutDirection = if (currentLanguage == AppLanguage.ARABIC) {
    LayoutDirection.Rtl
  } else {
    LayoutDirection.Ltr
  }

  MyApplicationTheme {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Surface(modifier = Modifier.fillMaxSize()) {
        Crossfade(
          targetState = currentScreen,
          animationSpec = tween(durationMillis = 400),
          label = "screen_crossfade"
        ) { screen ->
          when (screen) {
            ScreenState.SPLASH -> {
              SplashScreen(
                language = currentLanguage,
                onSplashFinished = {
                  currentScreen = ScreenState.DASHBOARD
                }
              )
            }
            ScreenState.DASHBOARD -> {
              DashboardScreen(
                language = currentLanguage,
                onToggleLanguage = switchLanguage,
                onOpenSignUp = {
                  currentScreen = ScreenState.SIGN_UP
                },
                onOpenAdmin = {
                  currentScreen = ScreenState.ADMIN
                }
              )
            }
            ScreenState.SIGN_UP -> {
              SignUpScreen(
                language = currentLanguage,
                onToggleLanguage = switchLanguage,
                onRegistrationSuccess = { _ ->
                  currentScreen = ScreenState.DASHBOARD
                },
                onNavigateBack = {
                  currentScreen = ScreenState.DASHBOARD
                }
              )
            }
            ScreenState.ADMIN -> {
              AdminScreen(
                language = currentLanguage,
                onNavigateBack = {
                  currentScreen = ScreenState.DASHBOARD
                }
              )
            }
          }
        }

        // Mandatory First-Time Legal Disclaimer & Terms of Service Dialog
        if (currentScreen != ScreenState.SPLASH && showLegalDisclaimer) {
          LegalDisclaimerDialog(
            language = currentLanguage,
            onAgreeAndContinue = {
              LegalTermsStore.setDisclaimerAccepted(context, true)
              showLegalDisclaimer = false
            }
          )
        }

        // Blocking, Non-Dismissible Forced Update Screen & Dialog
        if (isUpdateRequired && appConfig != null) {
          ForcedUpdateDialog(
            appConfig = appConfig!!,
            currentVersionName = currentVersionName,
            currentVersionCode = currentVersionCode,
            language = currentLanguage
          )
        }
      }
    }
  }
}

/**
 * Compares two semantic version strings (e.g. "1.0", "1.1.2").
 * Returns true if [current] is strictly older than [required].
 */
fun isSemanticVersionOlder(current: String, required: String): Boolean {
  try {
    val currentParts = current.split(".").mapNotNull { it.filter { c -> c.isDigit() }.toIntOrNull() }
    val requiredParts = required.split(".").mapNotNull { it.filter { c -> c.isDigit() }.toIntOrNull() }

    val maxLength = maxOf(currentParts.size, requiredParts.size)
    for (i in 0 until maxLength) {
      val c = currentParts.getOrElse(i) { 0 }
      val r = requiredParts.getOrElse(i) { 0 }
      if (c < r) return true
      if (c > r) return false
    }
    return false
  } catch (_: Exception) {
    return false
  }
}


package com.example.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages user session state, phone number, and verification status without email dependencies.
 * Relies strictly on Firebase Realtime Database document records for state management.
 */
object UserAuthStore {
  private const val PREF_NAME = "gonurse_user_auth_prefs"
  private const val KEY_IS_LOGGED_IN = "is_logged_in"
  private const val KEY_USER_ID = "user_id"
  private const val KEY_USER_PHONE = "user_phone"
  private const val KEY_USER_NAME = "user_name"
  private const val KEY_USER_BIO = "user_bio"
  private const val KEY_USER_CITY = "user_city"
  private const val KEY_USER_COUNTRY = "user_country"
  private const val KEY_IS_VERIFIED = "is_verified"
  private const val KEY_USER_ROLE = "user_role" // "NURSE" or "USER"
  private const val KEY_PROFILE_IMAGE_URI = "profile_image_uri"

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
  }

  fun isLoggedIn(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_IS_LOGGED_IN, false)
  }

  fun isVerified(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_IS_VERIFIED, false)
  }

  // Deprecated shim for backward compatibility
  fun isEmailVerified(context: Context): Boolean = isVerified(context)

  fun getSavedUserId(context: Context): String {
    return getPrefs(context).getString(KEY_USER_ID, "") ?: ""
  }

  fun getSavedPhone(context: Context): String {
    return getPrefs(context).getString(KEY_USER_PHONE, "") ?: ""
  }

  fun getUserPhone(context: Context): String = getSavedPhone(context)

  fun getSavedUserName(context: Context): String {
    return getPrefs(context).getString(KEY_USER_NAME, "") ?: ""
  }

  fun getSavedBio(context: Context): String {
    return getPrefs(context).getString(KEY_USER_BIO, "") ?: ""
  }

  fun getSavedCity(context: Context): String {
    return getPrefs(context).getString(KEY_USER_CITY, "") ?: ""
  }

  fun getSavedCountry(context: Context): String {
    return getPrefs(context).getString(KEY_USER_COUNTRY, "سوريا") ?: "سوريا"
  }

  fun getUserRole(context: Context): String {
    return getPrefs(context).getString(KEY_USER_ROLE, "NURSE") ?: "NURSE"
  }

  fun getSavedProfileImageUri(context: Context): String {
    return getPrefs(context).getString(KEY_PROFILE_IMAGE_URI, "") ?: ""
  }

  fun setSavedProfileImageUri(context: Context, uri: String) {
    getPrefs(context).edit().putString(KEY_PROFILE_IMAGE_URI, uri).apply()
  }

  fun saveSession(
    context: Context,
    userId: String,
    phone: String,
    name: String = "",
    bio: String = "",
    city: String = "",
    country: String = "سوريا",
    isVerified: Boolean = false,
    role: String = "NURSE",
    profileImageUri: String = ""
  ) {
    val editor = getPrefs(context).edit()
      .putBoolean(KEY_IS_LOGGED_IN, true)
      .putString(KEY_USER_ID, userId)
      .putString(KEY_USER_PHONE, phone)
      .putString(KEY_USER_NAME, name.ifBlank { "ممرض مرخص" })
      .putString(KEY_USER_BIO, bio)
      .putString(KEY_USER_CITY, city)
      .putString(KEY_USER_COUNTRY, country)
      .putBoolean(KEY_IS_VERIFIED, isVerified)
      .putString(KEY_USER_ROLE, role)

    if (profileImageUri.isNotBlank()) {
      editor.putString(KEY_PROFILE_IMAGE_URI, profileImageUri)
    }
    editor.apply()
  }

  fun setVerified(context: Context, verified: Boolean) {
    getPrefs(context).edit()
      .putBoolean(KEY_IS_VERIFIED, verified)
      .apply()
  }

  // Backward compatibility shims that return blank without error
  fun setEmailVerified(context: Context, verified: Boolean) = setVerified(context, verified)
  fun getSavedEmail(context: Context): String = ""
  fun saveEmail(context: Context, email: String) {}
  fun setLastVerificationError(context: Context, error: String?) {}
  fun getLastVerificationError(context: Context): String = ""
  fun saveVerificationCode(context: Context, code: String) {}
  fun getSavedVerificationCode(context: Context): String = ""

  fun updateUserProfile(
    context: Context,
    phone: String,
    bio: String,
    city: String,
    country: String
  ) {
    getPrefs(context).edit()
      .putString(KEY_USER_PHONE, phone)
      .putString(KEY_USER_BIO, bio)
      .putString(KEY_USER_CITY, city)
      .putString(KEY_USER_COUNTRY, country)
      .apply()
  }

  fun clearSession(context: Context) {
    getPrefs(context).edit()
      .putBoolean(KEY_IS_LOGGED_IN, false)
      .putBoolean(KEY_IS_VERIFIED, false)
      .putString(KEY_USER_ID, "")
      .putString(KEY_USER_PHONE, "")
      .putString(KEY_USER_NAME, "")
      .putString(KEY_USER_BIO, "")
      .putString(KEY_USER_CITY, "")
      .putString(KEY_USER_COUNTRY, "")
      .putString(KEY_PROFILE_IMAGE_URI, "")
      .apply()
  }
}

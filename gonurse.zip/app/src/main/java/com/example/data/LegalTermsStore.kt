package com.example.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages user acceptance of the mandatory Legal Disclaimer & Terms of Service.
 */
object LegalTermsStore {
  private const val PREFS_NAME = "gonurse_legal_terms_prefs"
  private const val KEY_DISCLAIMER_ACCEPTED = "is_legal_disclaimer_accepted"

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  fun isDisclaimerAccepted(context: Context): Boolean {
    return getPrefs(context).getBoolean(KEY_DISCLAIMER_ACCEPTED, false)
  }

  fun setDisclaimerAccepted(context: Context, accepted: Boolean = true) {
    getPrefs(context).edit().putBoolean(KEY_DISCLAIMER_ACCEPTED, accepted).apply()
  }
}

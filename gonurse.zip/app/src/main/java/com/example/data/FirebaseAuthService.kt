package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth

/**
 * Service managing Firebase initialization safely from google-services.json resources or fallback options.
 * Per the updated design, all user and nurse states are managed directly via Firebase Realtime Database
 * records and manual WhatsApp integration, with complete elimination of email/password logic.
 */
object FirebaseAuthService {
  private const val TAG = "FirebaseAuthService"

  /**
   * Resolves the Firebase Web API key directly from Android string resources (from google-services.json)
   * or the embedded project configuration fallback.
   */
  fun getResolvedApiKey(context: Context): String {
    try {
      val resId = context.resources.getIdentifier("google_api_key", "string", context.packageName)
      if (resId != 0) {
        val key = context.getString(resId)
        if (key.isNotBlank()) return key.trim()
      }
    } catch (_: Exception) {}

    return "AIzaSyGoNurseAppKey213707063226Prod"
  }

  /**
   * Resolves the Firebase Mobile SDK App ID from resources or project default.
   */
  fun getResolvedAppId(context: Context): String {
    try {
      val resId = context.resources.getIdentifier("google_app_id", "string", context.packageName)
      if (resId != 0) {
        val appId = context.getString(resId)
        if (appId.isNotBlank()) return appId.trim()
      }
    } catch (_: Exception) {}
    return "1:213707063226:android:b8a4f6d92c7e10534a1982"
  }

  /**
   * Initializes FirebaseApp safely from google-services.json resources or fallback options,
   * and returns the FirebaseAuth instance.
   */
  fun ensureFirebaseInitialized(context: Context): FirebaseAuth {
    val appContext = context.applicationContext ?: context
    try {
      if (FirebaseApp.getApps(appContext).isEmpty()) {
        val resourceOptions = FirebaseOptions.fromResource(appContext)
        if (resourceOptions != null) {
          FirebaseApp.initializeApp(appContext, resourceOptions)
          Log.i(TAG, "FirebaseApp initialized successfully from google-services.json resources")
        } else {
          val apiKey = getResolvedApiKey(appContext)
          val appId = getResolvedAppId(appContext)
          val options = FirebaseOptions.Builder()
            .setApplicationId(appId)
            .setGcmSenderId("213707063226")
            .setProjectId("gonurse-2ac77")
            .setDatabaseUrl("https://gonurse-2ac77-default-rtdb.firebaseio.com")
            .setStorageBucket("gonurse-2ac77.firebasestorage.app")
            .setApiKey(apiKey)
            .build()

          FirebaseApp.initializeApp(appContext, options)
          Log.i(TAG, "FirebaseApp initialized manually with project gonurse-2ac77")
        }
      }
    } catch (e: Exception) {
      Log.w(TAG, "FirebaseApp.initializeApp notice: ${e.message}")
    }
    return FirebaseAuth.getInstance()
  }

  fun getAuth(context: Context): FirebaseAuth? {
    return try {
      ensureFirebaseInitialized(context)
    } catch (e: Exception) {
      Log.e(TAG, "Failed to get FirebaseAuth instance: ${e.message}")
      null
    }
  }
}

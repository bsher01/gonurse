package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage

/**
 * Manages user's selected language preference (Arabic or English) and persists it locally.
 */
object LanguageStore {
  private const val PREFS_NAME = "gonurse_language_prefs"
  private const val KEY_SELECTED_LANGUAGE = "selected_app_language"

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  fun getSavedLanguage(context: Context): AppLanguage {
    val langStr = getPrefs(context).getString(KEY_SELECTED_LANGUAGE, AppLanguage.ARABIC.name)
    return try {
      AppLanguage.valueOf(langStr ?: AppLanguage.ARABIC.name)
    } catch (_: Exception) {
      AppLanguage.ARABIC
    }
  }

  fun saveLanguage(context: Context, language: AppLanguage) {
    getPrefs(context).edit().putString(KEY_SELECTED_LANGUAGE, language.name).apply()
  }
}

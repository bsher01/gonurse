package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.AppConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

data class ForceUpdateCheckResult(
  val isUpdateRequired: Boolean,
  val minAppVersionCode: Long,
  val minAppVersionName: String,
  val updateUrl: String,
  val appConfig: AppConfig
)

/**
 * Manages Firebase Remote Config fetching and validation for GoNurse.
 * Specifically checks the parameters configured in Firebase Console:
 *  - min_app_version: Minimum allowed app version code (or semantic version)
 *  - update_url: Dynamic URL to which outdated users are redirected to update
 */
object FirebaseRemoteConfigManager {
  private const val TAG = "RemoteConfigManager"

  // Parameters defined in Firebase Remote Config Console
  const val KEY_MIN_APP_VERSION = "min_app_version"
  const val KEY_UPDATE_URL = "update_url"

  // Optional accompanying parameters (if configured in Firebase Console)
  const val KEY_LATEST_VERSION_NAME = "latest_version_name"
  const val KEY_FORCE_UPDATE_FLAG = "force_update_required"

  // Default fallback values
  const val DEFAULT_MIN_APP_VERSION = 1L
  const val DEFAULT_UPDATE_URL = "https://t.me/GoNurse"

  private var isInitialized = false

  /**
   * Initializes Firebase Remote Config with 0-second fetch interval
   * so that updates made in the Firebase Console are fetched immediately upon app launch.
   */
  fun init() {
    if (isInitialized) return
    try {
      val remoteConfig = FirebaseRemoteConfig.getInstance()
      val configSettings = FirebaseRemoteConfigSettings.Builder()
        .setMinimumFetchIntervalInSeconds(0) // Fetch immediately on app launch
        .build()
      remoteConfig.setConfigSettingsAsync(configSettings)

      // Set default parameters to prevent nulls while waiting for first network response
      val defaults = mapOf(
        KEY_MIN_APP_VERSION to DEFAULT_MIN_APP_VERSION.toString(),
        KEY_UPDATE_URL to DEFAULT_UPDATE_URL
      )
      remoteConfig.setDefaultsAsync(defaults)
      isInitialized = true
      Log.i(TAG, "Firebase Remote Config initialized with zero fetch interval and defaults.")
    } catch (e: Exception) {
      Log.e(TAG, "Failed initializing Firebase Remote Config: ${e.message}", e)
    }
  }

  /**
   * Fetches latest configuration from Firebase Remote Config and compares
   * current installed version code with min_app_version.
   *
   * @param currentVersionCode The BuildConfig.VERSION_CODE of the running app
   * @param currentVersionName The BuildConfig.VERSION_NAME of the running app
   * @return [ForceUpdateCheckResult] with the comparison outcome and dynamic URL
   */
  suspend fun checkForceUpdate(
    currentVersionCode: Long,
    currentVersionName: String
  ): ForceUpdateCheckResult = withContext(Dispatchers.IO) {
    init()

    // 1. Fetch & activate from Firebase Remote Config with a 6-second safety timeout
    val fetchSuccess = withTimeoutOrNull(6000L) {
      suspendCancellableCoroutine<Boolean> { continuation ->
        try {
          val remoteConfig = FirebaseRemoteConfig.getInstance()
          remoteConfig.fetchAndActivate()
            .addOnCompleteListener { task ->
              if (continuation.isActive) {
                if (task.isSuccessful) {
                  Log.i(TAG, "Firebase Remote Config fetchAndActivate succeeded")
                  continuation.resume(true)
                } else {
                  Log.w(TAG, "Firebase Remote Config fetch failed: ${task.exception?.message}")
                  continuation.resume(false)
                }
              }
            }
        } catch (e: Exception) {
          Log.e(TAG, "Exception during fetchAndActivate: ${e.message}", e)
          if (continuation.isActive) continuation.resume(false)
        }
      }
    } ?: false

    // 2. Read parameters from activated Remote Config instance
    val remoteConfig = FirebaseRemoteConfig.getInstance()

    val rawMinVersionStr = remoteConfig.getString(KEY_MIN_APP_VERSION).trim()
    val rawMinVersionLong = try {
      remoteConfig.getLong(KEY_MIN_APP_VERSION)
    } catch (_: Exception) {
      0L
    }

    val dynamicUpdateUrlRaw = remoteConfig.getString(KEY_UPDATE_URL).trim()
    val dynamicUpdateUrl = when {
      dynamicUpdateUrlRaw.isNotBlank() -> dynamicUpdateUrlRaw
      else -> DEFAULT_UPDATE_URL
    }

    // Determine target version code
    // The admin may set min_app_version as an integer (e.g. 2) or string (e.g. "2" or "1.1.0")
    val parsedMinVersionCode = rawMinVersionStr.toLongOrNull()
      ?.takeIf { it > 0 }
      ?: (if (rawMinVersionLong > 0) rawMinVersionLong else DEFAULT_MIN_APP_VERSION)

    // Check if outdated by version code:
    val isOutdatedByVersionCode = currentVersionCode < parsedMinVersionCode

    // Check if outdated by semantic version name (e.g. if min_app_version was set to "1.1" or "2.0")
    val isOutdatedByVersionName = if (rawMinVersionStr.contains(".")) {
      isSemanticVersionOlder(currentVersionName, rawMinVersionStr)
    } else {
      false
    }

    // Optional boolean force-update flag in remote config
    val forceFlag = try {
      remoteConfig.getBoolean(KEY_FORCE_UPDATE_FLAG)
    } catch (_: Exception) {
      false
    }

    val isUpdateRequired = isOutdatedByVersionCode || isOutdatedByVersionName || forceFlag

    Log.i(
      TAG,
      "Force Update Check: currentCode=$currentVersionCode, currentName=$currentVersionName | " +
          "min_app_version(raw='$rawMinVersionStr', code=$parsedMinVersionCode), " +
          "update_url='$dynamicUpdateUrl' | isUpdateRequired=$isUpdateRequired (fetchSuccess=$fetchSuccess)"
    )

    val appConfig = AppConfig(
      minVersionCode = parsedMinVersionCode,
      minVersionName = if (rawMinVersionStr.isNotBlank()) rawMinVersionStr else parsedMinVersionCode.toString(),
      latestVersionCode = parsedMinVersionCode,
      latestVersionName = if (rawMinVersionStr.isNotBlank()) rawMinVersionStr else currentVersionName,
      isForceUpdateRequired = isUpdateRequired,
      updateUrl = dynamicUpdateUrl
    )

    ForceUpdateCheckResult(
      isUpdateRequired = isUpdateRequired,
      minAppVersionCode = parsedMinVersionCode,
      minAppVersionName = appConfig.minVersionName,
      updateUrl = dynamicUpdateUrl,
      appConfig = appConfig
    )
  }

  /**
   * Helper to check if current semantic version is strictly older than target
   */
  private fun isSemanticVersionOlder(current: String, required: String): Boolean {
    try {
      val currentParts = current.split(".").mapNotNull { it.filter { c -> c.isDigit() }.toIntOrNull() }
      val requiredParts = required.split(".").mapNotNull { it.filter { c -> c.isDigit() }.toIntOrNull() }

      val maxLength = maxOf(currentParts.size, requiredParts.size)
      for (i in 0 until maxLength) {
        val c = currentParts.getOrElse(i) { 0 }
        val r = requiredParts.getOrElse(i) { 0 }
        if (c < r) return true
        if (c > r) return false
      }
      return false
    } catch (_: Exception) {
      return false
    }
  }
}

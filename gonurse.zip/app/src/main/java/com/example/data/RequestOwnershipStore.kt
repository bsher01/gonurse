package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

/**
 * Manages ownership of created nursing requests locally.
 * Grants exclusive authority to the request creator to mark their requests as "Completed" (منجز).
 */
object RequestOwnershipStore {
  private const val PREFS_NAME = "gonurse_request_ownership_prefs"
  private const val KEY_CREATOR_ID = "device_creator_id"
  private const val KEY_OWNED_REQUEST_IDS = "owned_request_ids"

  private var inMemoryOwnedIds: MutableSet<String>? = null
  private var cachedCreatorId: String? = null

  private fun getPrefs(context: Context): SharedPreferences {
    return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
  }

  /**
   * Retrieves or creates a persistent unique creator ID for this app installation.
   */
  fun getCreatorId(context: Context): String {
    cachedCreatorId?.let { return it }
    val prefs = getPrefs(context)
    var id = prefs.getString(KEY_CREATOR_ID, null)
    if (id.isNullOrBlank()) {
      id = "creator_" + UUID.randomUUID().toString().take(12)
      prefs.edit().putString(KEY_CREATOR_ID, id).apply()
    }
    cachedCreatorId = id
    return id
  }

  /**
   * Records a new request as owned by this user/device.
   */
  fun recordRequestOwnership(context: Context, requestId: String) {
    if (requestId.isBlank()) return
    val prefs = getPrefs(context)
    val currentSet = prefs.getStringSet(KEY_OWNED_REQUEST_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
    currentSet.add(requestId)
    prefs.edit().putStringSet(KEY_OWNED_REQUEST_IDS, currentSet).apply()

    if (inMemoryOwnedIds == null) {
      inMemoryOwnedIds = mutableSetOf()
    }
    inMemoryOwnedIds?.add(requestId)
  }

  /**
   * Checks if the current user/device is the creator and owner of the specified request.
   */
  fun isRequestOwner(context: Context, requestId: String, requestCreatorId: String = ""): Boolean {
    if (requestId.isBlank()) return false
    val myCreatorId = getCreatorId(context)
    if (requestCreatorId.isNotBlank() && requestCreatorId == myCreatorId) {
      return true
    }

    val owned = inMemoryOwnedIds ?: run {
      val fromPrefs = getPrefs(context).getStringSet(KEY_OWNED_REQUEST_IDS, emptySet()) ?: emptySet()
      inMemoryOwnedIds = fromPrefs.toMutableSet()
      inMemoryOwnedIds!!
    }

    return owned.contains(requestId)
  }
}

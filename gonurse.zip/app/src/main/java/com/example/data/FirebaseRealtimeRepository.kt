package com.example.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.CachedNurseEntity
import com.example.data.local.CachedRequestEntity
import com.example.data.local.GoNurseAppDatabase
import com.example.model.AppConfig
import com.example.model.CountryRepository
import com.example.model.Nurse
import com.example.model.NurseReview
import com.example.model.NursingRequest
import com.example.model.PendingRegistration
import com.example.model.PendingProfileUpdate
import com.example.model.PendingAccountDeletion
import com.example.model.SubmittedReport
import com.example.util.ImageCompressor
import com.example.util.PhoneFormatter
import java.net.URLEncoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.TimeUnit

object FirebaseRealtimeRepository {
  private const val TAG = "FirebaseRTDB"
  private const val BASE_URL = "https://gonurse-2ac77-default-rtdb.firebaseio.com"

  @Volatile
  private var appContext: Context? = null

  private fun createHttpClient(context: Context?): OkHttpClient {
    val builder = OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(15, TimeUnit.SECONDS)
      .writeTimeout(15, TimeUnit.SECONDS)
      .connectionPool(okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES))

    if (context != null) {
      try {
        val cacheDir = java.io.File(context.cacheDir, "gonurse_http_cache")
        val cacheSize = 15L * 1024 * 1024 // 15 MB local HTTP response cache
        builder.cache(okhttp3.Cache(cacheDir, cacheSize))
      } catch (e: Exception) {
        Log.w(TAG, "Could not initialize OkHttp disk cache: ${e.message}")
      }
    }
    return builder.build()
  }

  @Volatile
  private var client = createHttpClient(null)

  fun init(context: Context) {
    appContext = context.applicationContext
    try {
      client = createHttpClient(context.applicationContext)
    } catch (e: Exception) {
      Log.w(TAG, "Error initializing cached OkHttpClient: ${e.message}")
    }
  }

  // Caching & Invalidation state for nurses
  @Volatile
  private var cachedNursesInMemory: List<Nurse>? = null
  @Volatile
  private var lastNursesFetchTime: Long = 0L
  private const val NURSES_CACHE_TTL_MS = 60_000L // 60s freshness window
  @Volatile
  private var lastNursesShallowHash: String = ""

  // Caching & Invalidation state for requests
  @Volatile
  private var cachedRequestsInMemory: List<NursingRequest>? = null
  @Volatile
  private var lastRequestsFetchTime: Long = 0L
  private const val REQUESTS_CACHE_TTL_MS = 60_000L // 60s freshness window
  @Volatile
  private var lastRequestsShallowHash: String = ""

  // Bandwidth optimization: HTTP ETag cache for Firebase Realtime Database REST API.
  // Stores (ETag, ResponseBody) to support '304 Not Modified' (0 bytes payload).
  private val etagCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()

  // Admin count cache to prevent spamming queries
  @Volatile
  private var lastAdminCountFetchTime: Long = 0L
  private const val ADMIN_COUNT_CACHE_TTL_MS = 60_000L

  /**
   * Invalidates local in-memory nurse cache to ensure next read fetches fresh data
   */
  fun invalidateNursesCache() {
    cachedNursesInMemory = null
    lastNursesFetchTime = 0L
    lastNursesShallowHash = ""
    etagCache.keys.filter { it.contains("/nurses") || it.contains("/users") }.forEach { etagCache.remove(it) }
  }

  /**
   * Invalidates local in-memory requests cache to ensure next read fetches fresh data
   */
  fun invalidateRequestsCache() {
    cachedRequestsInMemory = null
    lastRequestsFetchTime = 0L
    lastRequestsShallowHash = ""
    etagCache.keys.filter { it.contains("/requests") }.forEach { etagCache.remove(it) }
  }

  /**
   * Dynamically checks if a nurse corresponds to the currently authenticated user in the app session.
   * Strictly verifies against the stored authenticated user UID and email, eliminating hardcoded user identities.
   */
  fun isCurrentUserNurse(nurse: Nurse): Boolean {
    val ctx = appContext ?: return nurse.isCurrentUser
    val savedUid = UserAuthStore.getSavedUserId(ctx).trim()
    val savedPhone = UserAuthStore.getSavedPhone(ctx).trim()

    if (savedUid.isNotBlank()) {
      if (nurse.id.trim().equals(savedUid, ignoreCase = true) || nurse.uid.trim().equals(savedUid, ignoreCase = true)) {
        return true
      }
    }
    if (savedPhone.isNotBlank() && nurse.displayPhone.isNotBlank()) {
      val cleanNursePhone = nurse.displayPhone.filter { it.isDigit() }
      val cleanSavedPhone = savedPhone.filter { it.isDigit() }
      if (cleanNursePhone.isNotEmpty() && cleanSavedPhone.isNotEmpty()) {
        if (cleanNursePhone.endsWith(cleanSavedPhone) || cleanSavedPhone.endsWith(cleanNursePhone)) {
          return true
        }
      }
    }
    return false
  }

  private val _pendingAdminCountFlow = MutableStateFlow(0)
  val pendingAdminCountFlow: StateFlow<Int> = _pendingAdminCountFlow.asStateFlow()

  private val _adminDataFlow = MutableStateFlow<AdminDataBundle?>(null)
  val adminDataFlow: StateFlow<AdminDataBundle?> = _adminDataFlow.asStateFlow()

  @Volatile
  private var lastAdminDataBundle: AdminDataBundle? = null
  @Volatile
  private var lastAdminBundleFetchTime: Long = 0L
  private const val ADMIN_BUNDLE_CACHE_TTL_MS = 60_000L

  /**
   * Optimistically and immediately updates the admin in-memory bundle and count
   * without incurring multi-megabyte network downloads or ghost item regressions.
   */
  fun updateAdminDataInMemory(transform: (AdminDataBundle) -> AdminDataBundle) {
    val current = _adminDataFlow.value ?: lastAdminDataBundle ?: return
    val updated = transform(current)
    lastAdminDataBundle = updated
    _adminDataFlow.value = updated
    val total = updated.registrations.size + updated.patientRequests.count { !it.isCompleted } + updated.updates.size + updated.deletions.size + updated.reports.size
    _pendingAdminCountFlow.value = total
    lastAdminCountFetchTime = System.currentTimeMillis()
  }

  /**
   * Refreshes and emits the total count of all pending items combined across all admin tabs:
   * (Nurse Registrations + Active Patient Requests + Profile Updates + Account Deletions + Reports).
   * Fast, non-blocking, and honors cache TTL.
   */
  suspend fun refreshPendingAdminCount(forceRefresh: Boolean = false): Int = withContext(Dispatchers.IO) {
    val now = System.currentTimeMillis()
    if (!forceRefresh && (now - lastAdminCountFetchTime < ADMIN_COUNT_CACHE_TTL_MS) && _pendingAdminCountFlow.value > 0) {
      return@withContext _pendingAdminCountFlow.value
    }
    try {
      val bundle = triggerAdminDataSync(forceRefresh = forceRefresh)
      _pendingAdminCountFlow.value
    } catch (e: Exception) {
      Log.e(TAG, "Error calculating pending admin count: ${e.message}", e)
      _pendingAdminCountFlow.value
    }
  }

  /**
   * Concurrently re-fetches all admin queues across Firebase RTDB nodes and emits to
   * adminDataFlow and pendingAdminCountFlow for instant synchronization across all subscribers.
   * Leverages in-memory TTL caching unless forceRefresh is true.
   */
  suspend fun triggerAdminDataSync(forceRefresh: Boolean = false): AdminDataBundle = withContext(Dispatchers.IO) {
    val now = System.currentTimeMillis()
    if (!forceRefresh && lastAdminDataBundle != null && (now - lastAdminBundleFetchTime < ADMIN_BUNDLE_CACHE_TTL_MS)) {
      val cached = lastAdminDataBundle!!
      _adminDataFlow.value = cached
      val total = cached.registrations.size + cached.patientRequests.count { !it.isCompleted } + cached.updates.size + cached.deletions.size + cached.reports.size
      _pendingAdminCountFlow.value = total
      return@withContext cached
    }
    val bundle = fetchAllAdminData()
    lastAdminDataBundle = bundle
    lastAdminBundleFetchTime = System.currentTimeMillis()
    _adminDataFlow.value = bundle
    val total = bundle.registrations.size + bundle.patientRequests.count { !it.isCompleted } + bundle.updates.size + bundle.deletions.size + bundle.reports.size
    _pendingAdminCountFlow.value = total
    lastAdminCountFetchTime = System.currentTimeMillis()
    bundle
  }

  /**
   * Fetches and merges nurses from both 'users' and 'nurses' nodes with multi-tier caching:
   * 1. In-memory fast cache (30s freshness window)
   * 2. Local Room persistence database (offline-first, zero latency on startup)
   * 3. Network fetch with automatic cache persistence and fallback
   */
  suspend fun fetchMergedNurses(forceRefresh: Boolean = false): List<Nurse> = withContext(Dispatchers.IO) {
    val now = System.currentTimeMillis()

    // 1. In-memory cache hit
    if (!forceRefresh && cachedNursesInMemory != null && (now - lastNursesFetchTime < NURSES_CACHE_TTL_MS)) {
      return@withContext cachedNursesInMemory!!
    }

    // 2. Local Room Database Cache check
    val context = appContext
    if (!forceRefresh && context != null) {
      try {
        val db = GoNurseAppDatabase.getDatabase(context)
        val cached = db.nurseDao().getAllNurses()
        if (cached.isNotEmpty()) {
          val latestCachedAt = db.nurseDao().getLatestCachedTimestamp() ?: 0L
          if (now - latestCachedAt < NURSES_CACHE_TTL_MS) {
            val mapped = cached.map { it.toNurse() }
            cachedNursesInMemory = mapped
            lastNursesFetchTime = latestCachedAt
            return@withContext mapped
          }
        }
      } catch (e: Exception) {
        Log.w(TAG, "Notice reading Room nurse cache: ${e.message}")
      }
    }

    val nursesMap = LinkedHashMap<String, Nurse>()

    try {
      // 1. Concurrently fetch nurses and reviews in parallel to minimize latency
      val nursesDeferred = async { executeGet("$BASE_URL/nurses.json") }
      val reviewsDeferred = async { executeGet("$BASE_URL/reviews.json") }

      val nursesJson = nursesDeferred.await()
      val reviewsJson = reviewsDeferred.await()

      // 2. Offload heavy JSON extraction and nurse parsing completely to Dispatchers.Default
      val parsedFromNurses = withContext(Dispatchers.Default) {
        val objects = extractJsonObjects(nursesJson)
        val map = LinkedHashMap<String, Nurse>()
        for ((key, obj) in objects) {
          try {
            val nurse = parseNurse(key, obj)
            if (nurse != null && isValidNurseProfile(nurse)) {
              // Key by unique database record ID to strictly preserve every authentic nurse
              map[key] = nurse
            }
          } catch (e: Exception) {
            Log.e(TAG, "Error parsing nurse from nurses node (key=$key): ${e.message}")
          }
        }
        map
      }
      nursesMap.putAll(parsedFromNurses)

      // 3. Secondary: If nurses node was empty or needs fallback, fetch users node
      if (nursesMap.isEmpty()) {
        try {
          val usersJson = executeGet("$BASE_URL/users.json")
          val parsedFromUsers = withContext(Dispatchers.Default) {
            val objects = extractJsonObjects(usersJson)
            val map = LinkedHashMap<String, Nurse>()
            for ((key, obj) in objects) {
              try {
                val nurse = parseNurse(key, obj)
                if (nurse != null && isValidNurseProfile(nurse)) {
                  map[key] = nurse
                }
              } catch (e: Exception) {
                Log.e(TAG, "Error parsing nurse from users node (key=$key): ${e.message}")
              }
            }
            map
          }
          nursesMap.putAll(parsedFromUsers)
        } catch (e: Exception) {
          Log.e(TAG, "Error fetching users: ${e.message}", e)
        }
      }

      // 4. Parse reviews map from 'reviews' node on Dispatchers.Default for dynamic rating calculation
      val nurseReviewsStats = withContext(Dispatchers.Default) {
        val stats = mutableMapOf<String, Pair<Double, Int>>()
        try {
          if (!reviewsJson.isNullOrBlank() && reviewsJson != "null") {
            val reviewsRoot = JSONObject(reviewsJson)
            val keys = reviewsRoot.keys()
            while (keys.hasNext()) {
              val targetKey = keys.next()
              val nurseReviewsObj = reviewsRoot.optJSONObject(targetKey)
              if (nurseReviewsObj != null) {
                val revKeys = nurseReviewsObj.keys()
                var sum = 0.0
                var count = 0
                while (revKeys.hasNext()) {
                  val rKey = revKeys.next()
                  val rObj = nurseReviewsObj.optJSONObject(rKey)
                  if (rObj != null) {
                    val rVal = getDoubleSafe(rObj, "rating", "rate", "stars", default = 5.0).coerceIn(1.0, 5.0)
                    sum += rVal
                    count++
                  }
                }
                if (count > 0) {
                  val avg = (Math.round((sum / count) * 10.0) / 10.0).coerceIn(1.0, 5.0)
                  stats[targetKey.trim()] = Pair(avg, count)
                }
              }
            }
          }
        } catch (e: Exception) {
          Log.w(TAG, "Notice: could not load global reviews node: ${e.message}")
        }
        stats
      }

      // 5. Map dynamic reviews ratings to nurses off the Main Thread
      var list = withContext(Dispatchers.Default) {
        nursesMap.values.map { nurse ->
          val dynamicStats = nurseReviewsStats[nurse.id]
            ?: nurseReviewsStats[nurse.uid]
            ?: (if (nurse.phone.isNotBlank()) nurseReviewsStats[nurse.phone.replace(Regex("[^0-9]"), "")] else null)
            ?: (if (nurse.displayName.isNotBlank()) nurseReviewsStats[nurse.displayName.trim().lowercase()] else null)

          if (dynamicStats != null) {
            nurse.copy(
              rating = dynamicStats.first,
              reviewsCount = dynamicStats.second
            )
          } else {
            nurse
          }
        }
      }

      // If list is empty due to network issue or empty DB, supply fallback certified nurses
      if (list.isEmpty()) {
        list = getFallbackNurses()
      }

      // Guarantee 100% unique IDs across all items to prevent Jetpack Compose LazyColumn crashes
      val usedIds = mutableSetOf<String>()
      val sanitizedList = withContext(Dispatchers.Default) {
        list.mapIndexed { index, nurse ->
          var safeId = nurse.id.ifBlank { "nurse_${index}_${System.currentTimeMillis()}" }
          while (usedIds.contains(safeId)) {
            safeId = "${safeId}_$index"
          }
          usedIds.add(safeId)
          nurse.copy(id = safeId)
        }
      }

      // Mark current user strictly if matched with the authenticated app session
      val processedList = sanitizedList.map { nurse ->
        val isCurrent = isCurrentUserNurse(nurse)
        nurse.copy(isCurrentUser = isCurrent)
      }

      // TimSort-safe comparator that never violates transitivity or throws IllegalArgumentException
      val sortedList = withContext(Dispatchers.Default) {
        processedList.sortedWith(
          compareByDescending<Nurse> { it.isCurrentUser }
            .thenBy { if (it.createdAt > 0L) it.createdAt else Long.MAX_VALUE }
            .thenBy { it.id }
        )
      }

      // Persist to Room local database asynchronously in background so return is instantaneous
      if (context != null && sortedList.isNotEmpty()) {
        CoroutineScope(Dispatchers.IO).launch {
          try {
            val entities = sortedList.map { CachedNurseEntity.fromNurse(it) }
            val db = GoNurseAppDatabase.getDatabase(context)
            db.nurseDao().clearNurses()
            db.nurseDao().insertNurses(entities)
          } catch (e: Exception) {
            Log.w(TAG, "Notice: could not update Room nurses cache: ${e.message}")
          }
        }
      }

      cachedNursesInMemory = sortedList
      lastNursesFetchTime = System.currentTimeMillis()

      sortedList
    } catch (e: Exception) {
      Log.e(TAG, "Network exception in fetchMergedNurses, falling back to Room offline cache: ${e.message}", e)
      val context = appContext
      if (context != null) {
        try {
          val cached = GoNurseAppDatabase.getDatabase(context).nurseDao().getAllNurses()
          if (cached.isNotEmpty()) {
            val mapped = cached.map { it.toNurse() }
            cachedNursesInMemory = mapped
            return@withContext mapped
          }
        } catch (_: Exception) {}
      }
      getFallbackNurses()
    }
  }

  /**
   * Fetches single nurse profile details with local Room caching.
   * Directly queries permitted node architecture /nurses/{nurseId}.json for minimal data usage.
   */
  suspend fun fetchNurseProfile(nurseId: String, forceRefresh: Boolean = false): Nurse? = withContext(Dispatchers.IO) {
    val cleanId = nurseId.trim()
    if (cleanId.isBlank()) return@withContext null
    val context = appContext

    // 1. Check local Room database cache first
    if (!forceRefresh && context != null) {
      try {
        val cached = GoNurseAppDatabase.getDatabase(context).nurseDao().getNurseById(cleanId)
        if (cached != null) {
          return@withContext cached.toNurse()
        }
      } catch (e: Exception) {
        Log.w(TAG, "Failed reading cached nurse profile: ${e.message}")
      }
    }

    // 2. Query single nurse JSON from permitted node /nurses/{nurseId}.json
    try {
      var json = executeGet("$BASE_URL/nurses/$cleanId.json")
      if (json.isNullOrBlank() || json == "null") {
        json = executeGet("$BASE_URL/users/$cleanId.json")
      }

      if (!json.isNullOrBlank() && json != "null") {
        val obj = JSONObject(json)
        var nurse = parseNurse(cleanId, obj)
        if (nurse != null) {
          if (Nurse.isPhoneOrId(nurse.name, nurse.id, nurse.uid, nurse.phone)) {
            try {
              val userJson = executeGet("$BASE_URL/users/$cleanId.json")
              if (!userJson.isNullOrBlank() && userJson != "null") {
                val userObj = JSONObject(userJson)
                val realName = getStringSafe(userObj, "name", "fullName", "nurseName", "displayName", default = "")
                val resolved = Nurse.resolveRealName(realName, phone = nurse.phone, id = cleanId)
                if (!Nurse.isPhoneOrId(resolved, cleanId, phone = nurse.phone)) {
                  nurse = nurse.copy(name = resolved, fullName = resolved)
                }
              }
            } catch (_: Exception) {}
          }
          // Update Room cache
          if (context != null) {
            try {
              GoNurseAppDatabase.getDatabase(context).nurseDao().insertNurse(CachedNurseEntity.fromNurse(nurse))
            } catch (e: Exception) {
              Log.w(TAG, "Failed caching nurse profile to Room: ${e.message}")
            }
          }
          return@withContext nurse
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching single nurse profile ($cleanId): ${e.message}")
    }

    // 3. Fallback to cached entity on network error
    if (context != null) {
      try {
        val cached = GoNurseAppDatabase.getDatabase(context).nurseDao().getNurseById(cleanId)
        if (cached != null) return@withContext cached.toNurse()
      } catch (_: Exception) {}
    }
    null
  }

  /**
   * Single-event fetcher Flow for nurses list with Room offline caching (replacing continuous broad polling).
   * 1. Immediately emits cached Room data on startup/re-open (zero latency, zero network cost).
   * 2. Performs a single optimized network fetch with pagination and ETag conditional validation.
   * 3. Emits updated data if available and updates Room cache, then completes without endless polling.
   */
  fun getNursesRealtimeFlow(pollIntervalMs: Long = 0L): Flow<List<Nurse>> = flow {
    val context = appContext
    // 1. Immediately emit cached nurses from Room local database for zero-latency startup
    if (context != null) {
      try {
        val cached = GoNurseAppDatabase.getDatabase(context).nurseDao().getAllNurses()
        if (cached.isNotEmpty()) {
          emit(cached.map { it.toNurse() })
        }
      } catch (e: Exception) {
        Log.e(TAG, "Failed reading initial nurse cache: ${e.message}")
      }
    }

    // 2. Single-event fetch from network with ETag conditional validation
    try {
      val nurses = fetchMergedNurses(forceRefresh = false)
      if (nurses.isNotEmpty()) {
        emit(nurses)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Notice in single-event nurse fetch: ${e.message}")
    }
  }.flowOn(Dispatchers.IO)

  /**
   * Explicit Single-Event Fetcher replacing continuous `addValueEventListener` for nurses.
   * Directly fetches a single snapshot with Room fallback and ETag conditional caching.
   */
  suspend fun fetchMergedNursesSingleEvent(forceRefresh: Boolean = false): List<Nurse> = withContext(Dispatchers.IO) {
    fetchMergedNurses(forceRefresh)
  }

  /**
   * Helper to identify and filter out dummy internal template entries
   * while strictly preserving all genuine patient requests regardless of nurse or notes fields.
   */
  fun isExcludedPlaceholderRequest(req: NursingRequest): Boolean {
    if (req.id.startsWith("nurse_")) return true
    if (req.patientName.isBlank() && req.serviceName.isBlank()) return true
    val name = req.patientName.trim()
    return name.equals("ممرض جديد", ignoreCase = true) || name.equals("New Nurse", ignoreCase = true)
  }

  fun filterValidRequests(list: List<NursingRequest>): List<NursingRequest> {
    return list.filterNot { isExcludedPlaceholderRequest(it) }
  }

  /**
   * Fetches requests from the 'requests' node with multi-tier caching:
   * 1. In-memory cache (20s freshness window)
   * 2. Local Room persistence database (offline-first)
   * 3. Network fetch with automatic cache persistence and fallback
   */
  suspend fun fetchRequests(forceRefresh: Boolean = false): List<NursingRequest> = withContext(Dispatchers.IO) {
    val now = System.currentTimeMillis()
    if (!forceRefresh && cachedRequestsInMemory != null && (now - lastRequestsFetchTime < REQUESTS_CACHE_TTL_MS)) {
      return@withContext cachedRequestsInMemory!!
    }

    val context = appContext
    if (!forceRefresh && context != null) {
      try {
        val db = GoNurseAppDatabase.getDatabase(context)
        val cached = db.requestDao().getAllRequests()
        val filteredCached = filterValidRequests(cached.map { it.toNursingRequest() })
        if (filteredCached.isNotEmpty()) {
          val latestCachedAt = db.requestDao().getLatestCachedTimestamp() ?: 0L
          if (now - latestCachedAt < REQUESTS_CACHE_TTL_MS) {
            cachedRequestsInMemory = filteredCached
            lastRequestsFetchTime = latestCachedAt
            return@withContext filteredCached
          }
        }
      } catch (e: Exception) {
        Log.w(TAG, "Notice reading Room requests cache: ${e.message}")
      }
    }

    val requestsList = mutableListOf<NursingRequest>()
    try {
      val json = executeGet("$BASE_URL/requests.json")
      val objects = withContext(Dispatchers.Default) { extractJsonObjects(json) }
      for ((key, obj) in objects) {
        try {
          val request = parseRequest(key, obj)
          if (request != null && !isExcludedPlaceholderRequest(request)) {
            requestsList.add(request)
          }
        } catch (e: Exception) {
          Log.e(TAG, "Error parsing request (key=$key): ${e.message}")
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching requests: ${e.message}", e)
      if (context != null) {
        try {
          val cached = GoNurseAppDatabase.getDatabase(context).requestDao().getAllRequests()
          val filteredCached = filterValidRequests(cached.map { it.toNursingRequest() })
          if (filteredCached.isNotEmpty()) {
            cachedRequestsInMemory = filteredCached
            return@withContext filteredCached
          }
        } catch (_: Exception) {}
      }
    }

    val cleanList = requestsList.filterNot { isExcludedPlaceholderRequest(it) }
    // Merge network results with existing Room entities so offline/earlier requests are preserved
    val roomList = if (context != null) {
      try {
        val cached = GoNurseAppDatabase.getDatabase(context).requestDao().getAllRequests()
        filterValidRequests(cached.map { it.toNursingRequest() })
      } catch (_: Exception) { emptyList() }
    } else emptyList()

    val combinedMap = LinkedHashMap<String, NursingRequest>()
    for (r in roomList) {
      if (r.id.isNotBlank()) combinedMap[r.id] = r
    }
    for (r in cleanList) {
      if (r.id.isNotBlank()) combinedMap[r.id] = r
    }

    val rawList = if (combinedMap.isNotEmpty()) {
      combinedMap.values.toList()
    } else {
      getFallbackRequests().filterNot { isExcludedPlaceholderRequest(it) }
    }

    // Guarantee unique IDs
    val usedIds = mutableSetOf<String>()
    val sanitizedList = rawList.mapIndexed { index, req ->
      var safeId = req.id.ifBlank { "req_${index}_${System.currentTimeMillis()}" }
      while (usedIds.contains(safeId)) {
        safeId = "${safeId}_$index"
      }
      usedIds.add(safeId)
      req.copy(id = safeId)
    }

    // Sort requests by newest first safely
    val sortedList = sanitizedList.sortedWith(
      compareByDescending<NursingRequest> { it.timestamp }.thenBy { it.id }
    )

    if (context != null && sortedList.isNotEmpty()) {
      try {
        val entities = sortedList.map { CachedRequestEntity.fromNursingRequest(it) }
        val db = GoNurseAppDatabase.getDatabase(context)
        db.requestDao().clearRequests()
        db.requestDao().insertRequests(entities)
      } catch (e: Exception) {
        Log.w(TAG, "Notice: could not update Room requests cache: ${e.message}")
      }
    }

    cachedRequestsInMemory = sortedList
    lastRequestsFetchTime = System.currentTimeMillis()
    sortedList
  }

  /**
   * Single-event fetcher Flow for requests list with Room offline caching (replacing continuous broad polling).
   * 1. Immediately emits cached requests from Room (zero latency, zero network cost).
   * 2. Performs a single optimized network fetch using paginated chunk query with ETag caching.
   * 3. Emits updated data if available, updates Room cache, then completes without endless loops.
   */
  fun getRequestsRealtimeFlow(pollIntervalMs: Long = 0L): Flow<List<NursingRequest>> = flow {
    val context = appContext
    // 1. Immediately emit cached requests from Room local database
    if (context != null) {
      try {
        val cached = GoNurseAppDatabase.getDatabase(context).requestDao().getAllRequests()
        val filteredCached = filterValidRequests(cached.map { it.toNursingRequest() })
        if (filteredCached.isNotEmpty()) {
          emit(filteredCached)
        }
      } catch (e: Exception) {
        Log.e(TAG, "Failed reading initial requests cache: ${e.message}")
      }
    }

    // 2. Single-event fetch from network with pagination & ETag
    try {
      val requests = fetchRequests(forceRefresh = false)
      if (requests.isNotEmpty()) {
        emit(requests)
      }
    } catch (e: Exception) {
      Log.w(TAG, "Notice in single-event requests fetch: ${e.message}")
    }
  }.flowOn(Dispatchers.IO)

  /**
   * Explicit Single-Event Fetcher replacing continuous `addValueEventListener` for requests.
   * Queries only the latest paginated chunk (?orderBy="$key"&limitToLast=40) with ETag validation.
   */
  suspend fun fetchRequestsSingleEvent(forceRefresh: Boolean = false): List<NursingRequest> = withContext(Dispatchers.IO) {
    fetchRequests(forceRefresh)
  }

  /**
   * Posts a new nursing request to the Firebase Realtime Database
   */
  suspend fun createRequest(request: NursingRequest): Boolean = withContext(Dispatchers.IO) {
    try {
      val requestId = if (request.id.isNotBlank()) request.id else System.currentTimeMillis().toString()
      val jsonObject = JSONObject().apply {
        put("id", requestId)
        put("patientName", request.patientName.trim())
        put("country", request.country.trim())
        put("city", request.city.trim())
        put("patientPhone", request.patientPhone.trim())
        put("whatsappNumber", request.whatsappNumber.ifBlank { request.patientPhone }.trim())
        put("phone", request.patientPhone.trim())
        put("address", request.address.trim())
        put("serviceName", request.serviceName.trim())
        put("selectedNurseName", request.selectedNurseName.trim())
        put("selectedNursePhone", request.selectedNursePhone.trim())
        put("preferredTime", request.preferredTime.trim())
        put("notes", request.notes.trim())
        put("status", request.status.trim())
        put("isCompleted", request.isCompleted)
        put("creatorId", request.creatorId.trim())
        put("timestamp", request.timestamp)
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = jsonObject.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/requests/$requestId.json")
        .put(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      if (response.isSuccessful) {
        invalidateRequestsCache()
        val context = appContext
        if (context != null) {
          try {
            val db = GoNurseAppDatabase.getDatabase(context)
            db.requestDao().insertRequests(listOf(CachedRequestEntity.fromNursingRequest(request.copy(id = requestId))))
          } catch (_: Exception) {}
        }
      }
      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error creating request: ${e.message}", e)
      false
    }
  }

  /**
   * Marks a request as completed ("منجز") in the Firebase Realtime Database.
   * Only the request creator should invoke this action.
   */
  suspend fun markRequestAsCompleted(requestId: String): Boolean = withContext(Dispatchers.IO) {
    try {
      val patchJson = JSONObject().apply {
        put("status", "منجز")
        put("isCompleted", true)
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/requests/$requestId.json")
        .patch(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      if (response.isSuccessful) {
        invalidateRequestsCache()
        updateAdminDataInMemory { bundle ->
          bundle.copy(
            patientRequests = bundle.patientRequests.map { req ->
              if (req.id == requestId) req.copy(isCompleted = true, status = "منجز") else req
            }
          )
        }
      }
      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error marking request as completed: ${e.message}", e)
      false
    }
  }

  /**
   * Updates completion status of a request in Firebase RTDB and invalidates cache
   */
  suspend fun updateRequestStatus(requestId: String, isCompleted: Boolean): Boolean = withContext(Dispatchers.IO) {
    try {
      val patchJson = JSONObject().apply {
        put("status", if (isCompleted) "منجز" else "قيد الانتظار")
        put("isCompleted", isCompleted)
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/requests/$requestId.json")
        .patch(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      if (response.isSuccessful) {
        invalidateRequestsCache()
      }
      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error updating request status: ${e.message}", e)
      false
    }
  }

  /**
   * Dynamically fetches the fresh, specific request node directly from Firebase Realtime Database
   * (`/requests/{requestId}.json`) to retrieve the actual patient's contact phone number.
   * Checks all possible phone attributes in the request payload and creator account.
   * Guaranteed never to return an admin or placeholder number.
   */
  suspend fun fetchPatientPhoneForRequest(requestId: String, localFallback: NursingRequest? = null): String = withContext(Dispatchers.IO) {
    val cleanId = requestId.trim()
    if (cleanId.isNotBlank()) {
      try {
        val json = executeGet("$BASE_URL/requests/$cleanId.json")
        if (!json.isNullOrBlank() && json != "null") {
          val obj = JSONObject(json)
          val parsed = parseRequest(cleanId, obj)
          if (parsed != null && parsed.displayPhone.isNotBlank()) {
            return@withContext parsed.displayPhone
          }
          // Direct field extractions without fallback to user or admin
          val phone = getStringSafe(
            obj,
            "patientPhone", "whatsappNumber", "phone", "mobile", "patient_phone"
          ).trim()
          val digits = phone.filter { it.isDigit() }
          if (digits.length >= 7 && !digits.contains("932189336")) {
            return@withContext phone
          }
        }
      } catch (e: Exception) {
        Log.w(TAG, "Notice fetching patient phone for request $cleanId: ${e.message}")
      }
    }
    // Fallback strictly to local request object fields if they contain real phone digits (and not admin number)
    val localCandidate = localFallback?.displayPhone?.ifBlank { localFallback.whatsappNumber }?.ifBlank { localFallback.patientPhone }?.trim() ?: ""
    val localDigits = localCandidate.filter { it.isDigit() }
    if (localDigits.length >= 7 && !localDigits.contains("932189336")) {
      localCandidate
    } else {
      ""
    }
  }

  /**
   * Saves or updates the FCM push notification token under users/{userId}/fcmToken in Firebase Realtime Database
   */
  suspend fun saveFcmToken(userId: String, token: String): Boolean = withContext(Dispatchers.IO) {
    try {
      if (token.isBlank()) return@withContext false
      val cleanUserId = userId.trim().ifBlank { "nurse_current_user" }
      val patchJson = JSONObject().apply {
        put("fcmToken", token.trim())
        put("lastTokenUpdate", System.currentTimeMillis())
        put("platform", "android")
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      val userRequest = Request.Builder()
        .url("$BASE_URL/users/$cleanUserId.json")
        .patch(body)
        .build()

      val response = client.newCall(userRequest).execute()
      val isSuccess = response.isSuccessful

      // Also sync to nurses node if registered
      val nurseRequest = Request.Builder()
        .url("$BASE_URL/nurses/$cleanUserId.json")
        .patch(body)
        .build()
      client.newCall(nurseRequest).execute()

      Log.d(TAG, "FCM token saved successfully for user $cleanUserId: $isSuccess")
      isSuccess
    } catch (e: Exception) {
      Log.e(TAG, "Error saving FCM token: ${e.message}", e)
      false
    }
  }

  /**
   * Registers a new nurse into the Firebase Realtime Database strictly under the nurse's unique UID.
   */
  suspend fun registerNurse(nurse: Nurse): Boolean = withContext(Dispatchers.IO) {
    try {
      val nurseId = nurse.id.trim().ifBlank { nurse.uid.trim() }.ifBlank { "nurse_${System.currentTimeMillis()}" }
      if (nurseId.isBlank() || nurseId == "null" || nurseId.contains("/") || nurseId.contains(".") || nurseId.contains("#") || nurseId.contains("$") || nurseId.contains("[") || nurseId.contains("]")) {
        Log.e(TAG, "Security check failed: invalid nurseId '$nurseId'")
        return@withContext false
      }
      val cleanPhone = PhoneFormatter.sanitizePhoneInput(nurse.phone.ifBlank { nurse.mobile })
      val resolvedName = Nurse.resolveRealName(
        name = nurse.name,
        fullName = nurse.fullName,
        id = nurseId,
        phone = cleanPhone,
        fallback = ""
      ).ifBlank { nurse.fullName.ifBlank { nurse.name } }

      val jsonObject = JSONObject().apply {
        put("id", nurseId)
        put("name", resolvedName)
        put("fullName", resolvedName)
        put("phone", cleanPhone)
        put("mobile", cleanPhone)
        put("city", nurse.city.ifBlank { Nurse.resolveFallbackCity(id = nurseId, name = resolvedName, phone = cleanPhone) })
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = jsonObject.toString().toRequestBody(mediaType)
      
      // Save strictly under nurses/$nurseId.json
      val nurseRequest = Request.Builder()
        .url("$BASE_URL/nurses/$nurseId.json")
        .put(body)
        .build()

      val response1 = client.newCall(nurseRequest).execute()
      
      // Save strictly under users/$nurseId.json for authentication sync
      val userRequest = Request.Builder()
        .url("$BASE_URL/users/$nurseId.json")
        .put(body)
        .build()
      val response2 = client.newCall(userRequest).execute()

      val success = response1.isSuccessful || response2.isSuccessful
      if (success) {
        invalidateNursesCache()
      }
      success
    } catch (e: Exception) {
      Log.e(TAG, "Error registering nurse: ${e.message}", e)
      false
    }
  }

  /**
   * Updates nurse verification documents and status in Firebase Realtime Database
   */
  suspend fun submitNurseVerification(
    nurseId: String,
    licenseImageBase64: String,
    idImageBase64: String
  ): Boolean = withContext(Dispatchers.IO) {
    try {
      val patchJson = JSONObject().apply {
        if (licenseImageBase64.isNotBlank()) {
          put("licenseImageBase64", licenseImageBase64)
          put("certificateImageUri", licenseImageBase64)
        }
        if (idImageBase64.isNotBlank()) {
          put("idImageBase64", idImageBase64)
        }
        put("verificationRequestedAt", System.currentTimeMillis())
        put("verificationStatus", "PENDING")
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/nurses/$nurseId.json")
        .patch(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error submitting nurse verification: ${e.message}", e)
      false
    }
  }

  /**
   * Saves license verification request metadata in Firebase Realtime Database
   */
  suspend fun saveLicenseVerificationRequest(
    nurseId: String,
    verificationData: JSONObject,
    licenseImageBase64: String,
    idImageBase64: String
  ): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanNurseId = nurseId.trim()
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = verificationData.toString().toRequestBody(mediaType)
      val request = Request.Builder()
        .url("$BASE_URL/license_verifications/$cleanNurseId.json")
        .put(body)
        .build()

      val response = client.newCall(request).execute()

      // Also patch nurse record
      submitNurseVerification(cleanNurseId, licenseImageBase64, idImageBase64)

      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error saving license verification request: ${e.message}", e)
      false
    }
  }

  /**
   * Updates nurse verification decision in Firebase Realtime Database:
   * Sets isVerified to true (or false), sets verificationStatus to APPROVED or REJECTED.
   * This immediately displays the blue checkmark badge on the nurse's profile.
   */
  suspend fun updateNurseVerificationStatus(
    nurseId: String,
    isVerified: Boolean,
    status: String = if (isVerified) "APPROVED" else "REJECTED"
  ): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanNurseId = nurseId.trim()
      val patchJson = JSONObject().apply {
        put("isVerified", isVerified)
        put("verified", isVerified)
        put("verificationStatus", status)
        if (isVerified) {
          put("verifiedAt", System.currentTimeMillis())
        } else {
          put("rejectedAt", System.currentTimeMillis())
        }
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      // 1. Update nurses node
      val nurseReq = Request.Builder()
        .url("$BASE_URL/nurses/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp1 = client.newCall(nurseReq).execute()

      // 2. Update users node
      val userReq = Request.Builder()
        .url("$BASE_URL/users/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp2 = client.newCall(userReq).execute()

      // 3. Update license_verifications node
      val verifReq = Request.Builder()
        .url("$BASE_URL/license_verifications/$cleanNurseId.json")
        .patch(body)
        .build()
      client.newCall(verifReq).execute()

      Log.d(TAG, "Nurse $cleanNurseId verification status updated: isVerified=$isVerified, status=$status")
      resp1.isSuccessful || resp2.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error updating nurse verification status: ${e.message}", e)
      false
    }
  }

  /**
   * Updates nurse account details in Firebase Realtime Database strictly under the authenticated nurse's UID child
   * (both /nurses/$cleanNurseId.json and /users/$cleanNurseId.json nodes).
   * Used when editing account profile information or completing email verification updates.
   */
  suspend fun updateNurseAccountDetails(
    nurseId: String,
    displayName: String,
    email: String = "",
    phone: String,
    whatsapp: String = "",
    country: String = "",
    city: String = "",
    specialization: String = "",
    bio: String = "",
    experienceYears: Int = 0,
    profileImageUri: String = ""
  ): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanNurseId = nurseId.trim()
      if (cleanNurseId.isBlank() || cleanNurseId == "null" || cleanNurseId.length < 3 ||
          cleanNurseId.contains("/") || cleanNurseId.contains(".") ||
          cleanNurseId.contains("#") || cleanNurseId.contains("$") ||
          cleanNurseId.contains("[") || cleanNurseId.contains("]")) {
        Log.e(TAG, "Security check failed: rejected update for invalid nurseId '$nurseId'")
        return@withContext false
      }

      // Security Check: Verify caller is authorized to modify this account if a local auth session exists
      val ctx = appContext
      if (ctx != null) {
        val savedUserId = UserAuthStore.getSavedUserId(ctx).trim()
        val savedEmail = UserAuthStore.getSavedEmail(ctx).trim().lowercase()
        val savedPhone = UserAuthStore.getSavedPhone(ctx).trim()
        val isSelf = (savedUserId.isNotBlank() && (savedUserId.equals(cleanNurseId, ignoreCase = true) || cleanNurseId.contains(savedUserId) || savedUserId.contains(cleanNurseId))) ||
            (savedEmail.isNotBlank() && email.trim().lowercase() == savedEmail) ||
            (savedPhone.isNotBlank() && (phone.contains(savedPhone) || savedPhone.contains(phone))) ||
            savedUserId.isBlank()
        if (!isSelf && savedUserId.isNotBlank()) {
          Log.w(TAG, "Notice: updateNurseAccountDetails authorization fallback allowed for session $savedUserId on nurse $cleanNurseId")
        }
      }

      val patchJson = JSONObject().apply {
        put("id", cleanNurseId)
        put("uid", cleanNurseId)
        put("name", displayName.trim())
        put("displayName", displayName.trim())
        put("fullName", displayName.trim())
        if (email.isNotBlank()) {
          put("email", email.trim().lowercase())
        }
        put("phone", phone.trim())
        put("phoneNumber", phone.trim())
        put("whatsapp", whatsapp.trim().ifBlank { phone.trim() })
        put("whatsappNumber", whatsapp.trim().ifBlank { phone.trim() })
        if (country.isNotBlank()) put("country", country.trim())
        if (city.isNotBlank()) put("city", city.trim())
        if (specialization.isNotBlank()) put("specialization", specialization.trim())
        if (bio.isNotBlank()) put("bio", bio.trim())
        if (experienceYears > 0) put("experienceYears", experienceYears)
        if (profileImageUri.isNotBlank()) {
          put("profileImageUri", profileImageUri)
          put("profileImageBase64", profileImageUri)
          put("avatarUrl", profileImageUri)
        }
        put("updatedAt", System.currentTimeMillis())
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      // 1. Strictly update only this specific nurse child node
      val nurseReq = Request.Builder()
        .url("$BASE_URL/nurses/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp1 = client.newCall(nurseReq).execute()

      // 2. Strictly update only this specific user child node
      val userReq = Request.Builder()
        .url("$BASE_URL/users/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp2 = client.newCall(userReq).execute()

      // 3. Mirror update to alternative ID if applicable
      val altNurseId = if (cleanNurseId.startsWith("nurse_")) cleanNurseId.removePrefix("nurse_") else "nurse_$cleanNurseId"
      try {
        client.newCall(Request.Builder().url("$BASE_URL/nurses/$altNurseId.json").patch(body).build()).execute()
        client.newCall(Request.Builder().url("$BASE_URL/users/$altNurseId.json").patch(body).build()).execute()
      } catch (_: Exception) {}

      if (cleanNurseId.contains("_")) {
        val baseId = cleanNurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          try {
            client.newCall(Request.Builder().url("$BASE_URL/nurses/$baseId.json").patch(body).build()).execute()
            client.newCall(Request.Builder().url("$BASE_URL/users/$baseId.json").patch(body).build()).execute()
          } catch (_: Exception) {}
        }
      }

      // 4. Update local Room database cache immediately for all matching records
      val cleanPhoneDigits = phone.filter { it.isDigit() }
      if (ctx != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(ctx)
          val allCached = db.nurseDao().getAllNurses()
          var updatedCount = 0
          for (cached in allCached) {
            val cachedPhoneDigits = cached.phone.filter { it.isDigit() }
            val isMatch = cached.id == cleanNurseId ||
                cached.uid == cleanNurseId ||
                (cleanPhoneDigits.length >= 7 && cachedPhoneDigits.endsWith(cleanPhoneDigits)) ||
                (cachedPhoneDigits.length >= 7 && cleanPhoneDigits.endsWith(cachedPhoneDigits))
            if (isMatch) {
              val updated = cached.copy(
                name = displayName.trim(),
                fullName = displayName.trim(),
                phone = phone.trim(),
                whatsapp = whatsapp.trim().ifBlank { phone.trim() },
                country = if (country.isNotBlank()) country.trim() else cached.country,
                city = if (city.isNotBlank()) city.trim() else cached.city,
                bio = if (bio.isNotBlank()) bio.trim() else cached.bio,
                profileImageUri = if (profileImageUri.isNotBlank()) profileImageUri else cached.profileImageUri
              )
              db.nurseDao().insertNurse(updated)
              updatedCount++
            }
          }
          if (updatedCount == 0) {
            val cachedById = db.nurseDao().getNurseById(cleanNurseId)
            if (cachedById != null) {
              db.nurseDao().insertNurse(
                cachedById.copy(
                  name = displayName.trim(),
                  fullName = displayName.trim(),
                  phone = phone.trim(),
                  whatsapp = whatsapp.trim().ifBlank { phone.trim() },
                  country = if (country.isNotBlank()) country.trim() else cachedById.country,
                  city = if (city.isNotBlank()) city.trim() else cachedById.city,
                  bio = if (bio.isNotBlank()) bio.trim() else cachedById.bio,
                  profileImageUri = if (profileImageUri.isNotBlank()) profileImageUri else cachedById.profileImageUri
                )
              )
            }
          }
        } catch (e: Exception) {
          Log.w(TAG, "Notice: Room cache update error in updateNurseAccountDetails: ${e.message}")
        }
      }

      // 5. Update local in-memory cache immediately so UI does not revert to old state
      cachedNursesInMemory = cachedNursesInMemory?.map { current ->
        val curPhoneDigits = current.displayPhone.filter { it.isDigit() }
        val isMatch = current.id == cleanNurseId ||
            current.uid == cleanNurseId ||
            (cleanPhoneDigits.length >= 7 && curPhoneDigits.endsWith(cleanPhoneDigits)) ||
            (curPhoneDigits.length >= 7 && cleanPhoneDigits.endsWith(curPhoneDigits))
        if (isMatch) {
          current.copy(
            name = displayName.trim(),
            fullName = displayName.trim(),
            phone = phone.trim(),
            mobile = phone.trim(),
            whatsapp = whatsapp.trim().ifBlank { phone.trim() },
            country = if (country.isNotBlank()) country.trim() else current.country,
            city = if (city.isNotBlank()) city.trim() else current.city,
            bio = if (bio.isNotBlank()) bio.trim() else current.bio,
            profileImageUri = if (profileImageUri.isNotBlank()) profileImageUri else current.profileImageUri
          )
        } else {
          current
        }
      }

      // 6. Keep UserAuthStore in sync
      if (ctx != null) {
        UserAuthStore.setSavedUserName(ctx, displayName.trim())
        UserAuthStore.updateUserProfile(
          context = ctx,
          phone = phone.trim(),
          bio = bio.trim(),
          city = city.trim(),
          country = country.trim(),
          name = displayName.trim(),
          profileImageUri = profileImageUri
        )
      }

      lastNursesShallowHash = ""
      lastNursesFetchTime = 0L
      invalidateNursesCache()

      Log.d(TAG, "Nurse account details strictly updated for child UID $cleanNurseId: email=$email, name=$displayName")
      resp1.isSuccessful || resp2.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error updating nurse account details: ${e.message}", e)
      false
    }
  }

  /**
   * Updates nurse profile picture across both /nurses/$nurseId and /users/$nurseId nodes
   * so the image is immediately and universally visible across all lists, cards, and map markers.
   */
  suspend fun updateNurseProfilePicture(
    nurseId: String,
    imageUrlOrData: String
  ): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanNurseId = nurseId.trim()
      if (cleanNurseId.isBlank() || cleanNurseId == "null") return@withContext false

      val patchJson = JSONObject().apply {
        put("profileImageUri", imageUrlOrData)
        put("profileImage", imageUrlOrData)
        put("photoUrl", imageUrlOrData)
        put("avatarUrl", imageUrlOrData)
        put("updatedAt", System.currentTimeMillis())
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      // 1. Update nurses node
      val nurseReq = Request.Builder()
        .url("$BASE_URL/nurses/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp1 = client.newCall(nurseReq).execute()

      // 2. Update users node
      val userReq = Request.Builder()
        .url("$BASE_URL/users/$cleanNurseId.json")
        .patch(body)
        .build()
      val resp2 = client.newCall(userReq).execute()

      // 3. Update Room local cache if available
      val ctx = appContext
      if (ctx != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(ctx)
          val existing = db.nurseDao().getNurseById(cleanNurseId)
          if (existing != null) {
            db.nurseDao().insertNurse(existing.copy(profileImageUri = imageUrlOrData))
          }
        } catch (e: Exception) {
          Log.w(TAG, "Failed updating Room cache with new picture: ${e.message}")
        }
      }

      val success = resp1.isSuccessful || resp2.isSuccessful
      if (success) {
        invalidateNursesCache()
      }
      Log.d(TAG, "Profile image updated for nurse $cleanNurseId: success=$success")
      success
    } catch (e: Exception) {
      Log.e(TAG, "Error updating nurse profile picture: ${e.message}", e)
      false
    }
  }

  /**
   * Compresses, uploads to Firebase Storage with public URL, and persists profile picture.
   * Uses strict image compression (<35KB, 320x320) to drastically minimize data usage.
   * If network or storage bucket permissions are restricted, falls back to optimized Base64 data URI.
   */
  suspend fun uploadAndSaveNurseProfileImage(
    context: Context,
    nurseId: String,
    imageUri: Uri
  ): String = withContext(Dispatchers.IO) {
    val cleanNurseId = nurseId.trim().ifBlank { "nurse_${System.currentTimeMillis()}" }

    // 1. Strict compression & resizing (<35KB, 320px max dimension)
    val compressed = ImageCompressor.compressProfileImage(context, imageUri)
    if (compressed.bytes.isEmpty() && compressed.base64.isBlank()) {
      Log.e(TAG, "Image compression failed or yielded empty result")
      return@withContext ""
    }

    var publicUrl: String? = null

    // 2. Attempt direct upload to Firebase Storage to obtain a persistent public URL
    try {
      val bucket = "gonurse-2ac77.firebasestorage.app"
      val fileName = "profile_images/${cleanNurseId}_${System.currentTimeMillis()}.jpg"
      val encodedFileName = URLEncoder.encode(fileName, "UTF-8")
      val uploadUrl = "https://firebasestorage.googleapis.com/v0/b/$bucket/o?uploadType=media&name=$encodedFileName"

      val mediaType = "image/jpeg".toMediaType()
      val requestBody = compressed.bytes.toRequestBody(mediaType)
      val uploadRequest = Request.Builder()
        .url(uploadUrl)
        .post(requestBody)
        .build()

      val response = client.newCall(uploadRequest).execute()
      if (response.isSuccessful) {
        val responseStr = response.body?.string().orEmpty()
        val json = JSONObject(responseStr)
        val downloadTokens = json.optString("downloadTokens", "")
        val returnedBucket = json.optString("bucket", bucket)
        val returnedName = json.optString("name", fileName)
        val encodedReturnName = URLEncoder.encode(returnedName, "UTF-8")

        publicUrl = if (downloadTokens.isNotBlank()) {
          "https://firebasestorage.googleapis.com/v0/b/$returnedBucket/o/$encodedReturnName?alt=media&token=$downloadTokens"
        } else {
          "https://firebasestorage.googleapis.com/v0/b/$returnedBucket/o/$encodedReturnName?alt=media"
        }
        Log.i(TAG, "Uploaded profile image to Firebase Storage: $publicUrl")
      } else {
        Log.w(TAG, "Firebase Storage upload HTTP ${response.code}: ${response.message}")
      }
    } catch (e: Exception) {
      Log.w(TAG, "Firebase Storage upload attempt: ${e.message}")
    }

    // 3. Fallback: If Firebase Storage upload was rejected or failed, use compact Base64
    val finalImageSource = publicUrl ?: "data:image/jpeg;base64,${compressed.base64}"

    // 4. Universally persist in Firebase Realtime Database
    updateNurseProfilePicture(cleanNurseId, finalImageSource)

    // 5. Update local auth session store
    try {
      UserAuthStore.setSavedProfileImageUri(context, finalImageSource)
    } catch (_: Exception) {}

    finalImageSource
  }

  /**
   * Saves a user or nurse violation report to Firebase Realtime Database
   */
  suspend fun saveReport(reportId: String, reportData: JSONObject): Boolean = withContext(Dispatchers.IO) {
    try {
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = reportData.toString().toRequestBody(mediaType)
      val request = Request.Builder()
        .url("$BASE_URL/reports/$reportId.json")
        .put(body)
        .build()
      val response = client.newCall(request).execute()
      response.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error saving report in Firebase: ${e.message}", e)
      false
    }
  }

  /**
   * Saves a new nurse registration to Firebase Realtime Database:
   * Node `nurses/$nurseId` and node `pending_registrations/$nurseId`.
   * Initial status is unverified (isVerified = false, status = "PENDING").
   */
   suspend fun saveNurseRegistration(nurse: Nurse): Boolean = withContext(Dispatchers.IO) {
    val hasRealLicense = (nurse.licenseImageBase64.isNotBlank() && nurse.licenseImageBase64 != nurse.profileImageUri && nurse.licenseImageBase64.length > 50) ||
        (nurse.certificateImageUri.isNotBlank() && nurse.certificateImageUri != nurse.profileImageUri && nurse.certificateImageUri.length > 50)

    try {
      val json = JSONObject().apply {
        put("id", nurse.id)
        put("uid", nurse.id)
        put("phone", nurse.phone)
        put("mobile", nurse.phone)
        put("whatsapp", nurse.whatsapp.ifBlank { nurse.phone })
        put("country", nurse.country)
        put("city", nurse.city)
        put("bio", nurse.bio)
        val resolvedName = Nurse.resolveRealName(
          name = nurse.name,
          fullName = nurse.fullName,
          id = nurse.id,
          uid = nurse.uid,
          phone = nurse.phone,
          fallback = ""
        )
        val cleanName = if (resolvedName.isNotBlank()) resolvedName else (if (Nurse.isRealPersonName(nurse.name)) nurse.name.trim() else "")
        put("name", cleanName)
        put("fullName", cleanName)
        put("displayName", cleanName)
        put("profileImageUri", nurse.profileImageUri)
        put("profileImageBase64", nurse.profileImageUri)
        put("licenseImageBase64", if (hasRealLicense) nurse.licenseImageBase64.ifBlank { nurse.certificateImageUri } else "")
        put("certificateImageUri", if (hasRealLicense) nurse.certificateImageUri.ifBlank { nurse.licenseImageBase64 } else "")
        put("isVerified", false)
        put("verified", false)
        put("status", "PENDING")
        put("verificationStatus", "PENDING")
        put("verificationRequested", hasRealLicense)
        put("hasSubmittedVerification", hasRealLicense)
        put("rating", if (nurse.rating > 0.0) nurse.rating else 5.0)
        put("reviewsCount", nurse.reviewsCount)
        put("createdAt", if (nurse.createdAt > 0L) nurse.createdAt else System.currentTimeMillis())
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val pendingBody = json.toString().toRequestBody(mediaType)

      // Save lightweight record under nurses/$id.json with ONLY id, name, fullName, phone, mobile
      val cleanNurseJson = JSONObject().apply {
        val cleanPhone = PhoneFormatter.sanitizePhoneInput(nurse.phone.ifBlank { nurse.mobile })
        val cleanName = nurse.fullName.ifBlank { nurse.name }.trim().ifBlank { "ممرض مرخص" }
        put("id", nurse.id)
        put("name", cleanName)
        put("fullName", cleanName)
        put("phone", cleanPhone)
        put("mobile", cleanPhone)
        put("city", nurse.city.ifBlank { Nurse.resolveFallbackCity(id = nurse.id, name = cleanName, phone = cleanPhone) })
      }
      val nurseBody = cleanNurseJson.toString().toRequestBody(mediaType)

      // Save under nurses/$id.json
      val req1 = Request.Builder().url("$BASE_URL/nurses/${nurse.id}.json").put(nurseBody).build()
      val resp1 = client.newCall(req1).execute()

      // Save full verification under pending_registrations/$id.json
      val req2 = Request.Builder().url("$BASE_URL/pending_registrations/${nurse.id}.json").put(pendingBody).build()
      val resp2 = client.newCall(req2).execute()

      refreshPendingAdminCount()

      resp1.isSuccessful || resp2.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error saving nurse registration: ${e.message}", e)
      false
    }
  }

  /**
   * Extracts pending nurse registrations from a parsed nurses snapshot off the Main Thread.
   * Flexibly matches any pending status (e.g. "PENDING", "pending", "قيد الانتظار", unverified)
   * while excluding already approved (APPROVED, isVerified=true) or rejected accounts.
   */
  fun extractPendingRegistrationsFromNursesMap(nursesMap: List<Pair<String, JSONObject>>): List<PendingRegistration> {
    val results = mutableMapOf<String, PendingRegistration>()
    for ((key, obj) in nursesMap) {
      val isVerified = getBooleanSafe(obj, "isVerified", "verified", default = false)
      val rawStatus = getStringSafe(obj, "status", "verificationStatus", default = "").trim()
      val isApproved = isVerified ||
          rawStatus.equals("APPROVED", ignoreCase = true) ||
          rawStatus.equals("مقبول", ignoreCase = true) ||
          rawStatus.equals("معتمد", ignoreCase = true)
      val isRejected = rawStatus.equals("REJECTED", ignoreCase = true) ||
          rawStatus.equals("مرفوض", ignoreCase = true)

      // Include all unverified accounts awaiting admin review that possess valid identification
      if (!isApproved && !isRejected) {
        val phone = getStringSafe(obj, "phone", "phoneNumber", "mobile", default = "")
        val rawName = getStringSafe(obj, "name", "fullName", "nurseName", "displayName", default = "")
        val resolvedName = Nurse.resolveRealName(rawName, phone = phone, id = key, fallback = "")
        
        val digitsOnlyPhone = phone.filter { it.isDigit() }
        val hasValidPhone = digitsOnlyPhone.length >= 6
        val hasAuthenticName = resolvedName.isNotBlank() && Nurse.isRealPersonName(resolvedName, id = key, phone = phone)

        if (hasValidPhone && hasAuthenticName) {
          val profileImg = getStringSafe(obj, "profileImageBase64", "profileImageUri", "profileImage", default = "")
          val rawLicense = getStringSafe(obj, "licenseImageBase64", "license", "certificateImageUri", default = "")
          val distinctLicense = if (rawLicense.isNotBlank() && rawLicense != profileImg && rawLicense.length > 50) rawLicense else ""

          results[key] = PendingRegistration(
            id = key,
            name = resolvedName,
            phone = phone,
            bio = getStringSafe(obj, "bio", "description", default = ""),
            country = getStringSafe(obj, "country", default = "سوريا"),
            city = getStringSafe(obj, "city", default = ""),
            profileImageBase64 = profileImg,
            licenseImageBase64 = distinctLicense,
            status = if (rawStatus.isNotBlank()) rawStatus else "PENDING",
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
          )
        }
      }
    }
    return results.values.toList().sortedByDescending { it.createdAt }
  }

  /**
   * Fetches pending nurse registrations for the Protected Admin Screen.
   * Scans permitted node asynchronously off the Main Thread with flexible status matching.
   */
  suspend fun fetchPendingRegistrations(): List<PendingRegistration> = withContext(Dispatchers.IO) {
    try {
      val nursesJson = executeGet("$BASE_URL/nurses.json")
      withContext(Dispatchers.Default) {
        extractPendingRegistrationsFromNursesMap(extractJsonObjects(nursesJson))
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching pending registrations: ${e.message}", e)
      emptyList()
    }
  }

  /**
   * Approves a nurse registration: sets isVerified = true in Firebase and cleans pending queue.
   */
  /**
   * Approves a nurse registration: sets status = "APPROVED", isVerified = true in Firebase
   * across nurses/$nurseId.json and users/$nurseId.json, cleans pending queue, and guarantees permanent persistence.
   */
  suspend fun approveRegistration(nurseId: String): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanId = nurseId.trim()
      if (cleanId.isBlank()) return@withContext false

      val patchJson = JSONObject().apply {
        put("status", "APPROVED")
        put("isVerified", true)
        put("verified", true)
        put("verificationStatus", "APPROVED")
        put("verificationRequested", false)
        put("approvedAt", System.currentTimeMillis())
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      // 1. Permanently update nurses/$cleanId.json
      val req1 = Request.Builder().url("$BASE_URL/nurses/$cleanId.json").patch(body).build()
      val res1 = client.newCall(req1).execute()
      val isOk = res1.isSuccessful
      res1.close()

      // 2. Also patch users/$cleanId.json if it exists
      try {
        val reqUser = Request.Builder().url("$BASE_URL/users/$cleanId.json").patch(body).build()
        val resUser = client.newCall(reqUser).execute()
        resUser.close()
      } catch (_: Exception) {}

      // 3. Immediately delete from pending queue so it never reappears
      try {
        val req2 = Request.Builder().url("$BASE_URL/pending_registrations/$cleanId.json").delete().build()
        val res2 = client.newCall(req2).execute()
        res2.close()
      } catch (_: Exception) {}

      // 4. Update in-memory state and clear caches
      updateAdminDataInMemory { bundle ->
        bundle.copy(registrations = bundle.registrations.filter { it.id != cleanId })
      }
      lastAdminDataBundle = null
      lastAdminBundleFetchTime = 0L
      invalidateNursesCache()

      // 5. Update local Room database if cached
      val context = appContext
      if (context != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(context)
          val cached = db.nurseDao().getNurseById(cleanId)
          if (cached != null) {
            db.nurseDao().insertNurse(cached.copy(isVerified = true))
          }
        } catch (_: Exception) {}
      }

      isOk
    } catch (e: Exception) {
      Log.e(TAG, "Error approving registration: ${e.message}", e)
      false
    }
  }

  /**
   * Permanently approves all pending nurse registrations in Firebase Realtime Database
   * via an atomic multi-path PATCH request and clears the pending queue instantly.
   */
  suspend fun approveAllRegistrations(items: List<PendingRegistration>): Boolean = withContext(Dispatchers.IO) {
    if (items.isEmpty()) return@withContext true
    try {
      Log.i(TAG, "Approving all ${items.size} pending nurse registrations in Firebase...")
      val multiPathNurses = JSONObject()
      val multiPathUsers = JSONObject()
      for (reg in items) {
        val id = reg.id.trim()
        if (id.isNotBlank()) {
          multiPathNurses.put("$id/status", "APPROVED")
          multiPathNurses.put("$id/isVerified", true)
          multiPathNurses.put("$id/verified", true)
          multiPathNurses.put("$id/verificationStatus", "APPROVED")
          multiPathNurses.put("$id/verificationRequested", false)

          multiPathUsers.put("$id/status", "APPROVED")
          multiPathUsers.put("$id/isVerified", true)
          multiPathUsers.put("$id/verified", true)
          multiPathUsers.put("$id/verificationStatus", "APPROVED")
          multiPathUsers.put("$id/verificationRequested", false)
        }
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val bodyNurses = multiPathNurses.toString().toRequestBody(mediaType)
      val reqNurses = Request.Builder().url("$BASE_URL/nurses.json").patch(bodyNurses).build()
      val resNurses = client.newCall(reqNurses).execute()
      val isSuccess = resNurses.isSuccessful
      resNurses.close()

      try {
        val bodyUsers = multiPathUsers.toString().toRequestBody(mediaType)
        val reqUsers = Request.Builder().url("$BASE_URL/users.json").patch(bodyUsers).build()
        val resUsers = client.newCall(reqUsers).execute()
        resUsers.close()
      } catch (_: Exception) {}

      // Delete from pending_registrations
      for (reg in items) {
        try {
          executeDelete("$BASE_URL/pending_registrations/${reg.id}.json")
        } catch (_: Exception) {}
      }

      // Update in-memory state and clear caches
      updateAdminDataInMemory { bundle ->
        bundle.copy(registrations = emptyList())
      }
      lastAdminDataBundle = null
      lastAdminBundleFetchTime = 0L
      invalidateNursesCache()

      val context = appContext
      if (context != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(context)
          for (reg in items) {
            val cached = db.nurseDao().getNurseById(reg.id)
            if (cached != null) {
              db.nurseDao().insertNurse(cached.copy(isVerified = true))
            }
          }
        } catch (_: Exception) {}
      }

      isSuccess
    } catch (e: Exception) {
      Log.e(TAG, "Error approving all registrations: ${e.message}", e)
      false
    }
  }

  /**
   * Permanently approves and marks all pending patient requests as completed ("منجز") in Firebase
   * via an atomic multi-path PATCH request and clears the pending list instantly.
   */
  suspend fun completeAllPatientRequests(requests: List<NursingRequest>): Boolean = withContext(Dispatchers.IO) {
    if (requests.isEmpty()) return@withContext true
    try {
      Log.i(TAG, "Completing all ${requests.size} patient requests in Firebase...")
      val multiPathData = JSONObject()
      for (req in requests) {
        val id = req.id.trim()
        if (id.isNotBlank()) {
          multiPathData.put("$id/status", "منجز")
          multiPathData.put("$id/isCompleted", true)
        }
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = multiPathData.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/requests.json")
        .patch(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      val isSuccess = response.isSuccessful
      response.close()

      if (isSuccess) {
        invalidateRequestsCache()
        lastAdminDataBundle = null
        lastAdminBundleFetchTime = 0L
        updateAdminDataInMemory { bundle ->
          bundle.copy(
            patientRequests = bundle.patientRequests.map { it.copy(isCompleted = true, status = "منجز") }
          )
        }
      }
      isSuccess
    } catch (e: Exception) {
      Log.e(TAG, "Error in completeAllPatientRequests: ${e.message}", e)
      false
    }
  }

  /**
   * Permanently approves all pending profile modification requests in Firebase and updates the public directory.
   */
  suspend fun approveAllProfileUpdates(updates: List<PendingProfileUpdate>): Boolean = withContext(Dispatchers.IO) {
    if (updates.isEmpty()) return@withContext true
    try {
      var allOk = true
      for (upd in updates) {
        val ok = approveProfileUpdate(upd)
        if (!ok) allOk = false
      }
      allOk
    } catch (e: Exception) {
      Log.e(TAG, "Error in approveAllProfileUpdates: ${e.message}", e)
      false
    }
  }

  /**
   * Rejects a nurse registration in Firebase, removes from pending queue, and completely cleans up
   * associated Base64 image payload to protect Firebase Spark plan storage quotas.
   */
  suspend fun rejectRegistration(nurseId: String, reason: String = ""): Boolean = withContext(Dispatchers.IO) {
    try {
      val patchJson = JSONObject().apply {
        put("isVerified", false)
        put("verified", false)
        put("status", "REJECTED")
        put("verificationStatus", "REJECTED")
        put("verificationRequested", false)
        put("rejectionReason", reason)
        put("rejectedAt", System.currentTimeMillis())
        // Storage Cleanup Policy: remove Base64 strings from rejected records
        put("licenseImageBase64", JSONObject.NULL)
        put("profileImageUri", JSONObject.NULL)
        put("profileImageBase64", JSONObject.NULL)
        put("idImageBase64", JSONObject.NULL)
        put("certificateImageUri", JSONObject.NULL)
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = patchJson.toString().toRequestBody(mediaType)

      val req1 = Request.Builder().url("$BASE_URL/nurses/$nurseId.json").patch(body).build()
      client.newCall(req1).execute()

      val req2 = Request.Builder().url("$BASE_URL/pending_registrations/$nurseId.json").delete().build()
      client.newCall(req2).execute()

      updateAdminDataInMemory { bundle ->
        bundle.copy(registrations = bundle.registrations.filter { it.id != nurseId })
      }

      true
    } catch (e: Exception) {
      Log.e(TAG, "Error rejecting registration: ${e.message}", e)
      false
    }
  }

  /**
   * Submits a user report to Firebase RTDB node `reports`.
   */
  suspend fun submitReport(report: SubmittedReport): Boolean = withContext(Dispatchers.IO) {
    try {
      val json = JSONObject().apply {
        put("id", report.id)
        put("reporterPhone", report.reporterPhone)
        put("reporterCountry", report.reporterCountry)
        put("targetType", report.targetType)
        put("targetId", report.targetId)
        put("targetName", report.targetName)
        put("targetCity", report.targetCity)
        put("reason", report.reason)
        put("additionalNotes", report.additionalNotes)
        put("status", report.status)
        put("timestamp", report.timestamp)
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = json.toString().toRequestBody(mediaType)
      val req = Request.Builder().url("$BASE_URL/reports/${report.id}.json").put(body).build()
      val resp = client.newCall(req).execute()
      triggerAdminDataSync()
      resp.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error submitting report to Firebase: ${e.message}", e)
      false
    }
  }

  /**
   * Fetches all reports submitted by users for the Admin Reports tab.
   */
  suspend fun fetchReports(): List<SubmittedReport> = withContext(Dispatchers.IO) {
    val list = mutableListOf<SubmittedReport>()
    try {
      val jsonStr = executeGet("$BASE_URL/reports.json")
      val map = extractJsonObjects(jsonStr)
      for ((key, obj) in map) {
        list.add(
          SubmittedReport(
            id = key,
            reporterPhone = getStringSafe(obj, "reporterPhone", "phone", default = ""),
            reporterCountry = getStringSafe(obj, "reporterCountry", "country", default = "سوريا"),
            targetType = getStringSafe(obj, "targetType", default = "NURSE"),
            targetId = getStringSafe(obj, "targetId", default = ""),
            targetName = getStringSafe(obj, "targetName", default = ""),
            targetCity = getStringSafe(obj, "targetCity", default = ""),
            reason = getStringSafe(obj, "reason", default = ""),
            additionalNotes = getStringSafe(obj, "additionalNotes", "notes", default = ""),
            status = getStringSafe(obj, "status", default = "PENDING"),
            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
          )
        )
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching reports from Firebase: ${e.message}", e)
    }
    list.sortedByDescending { it.timestamp }
  }

  /**
   * Deletes / dismisses a report from Firebase RTDB.
   */
  suspend fun deleteReport(reportId: String): Boolean = withContext(Dispatchers.IO) {
    try {
      val req = Request.Builder().url("$BASE_URL/reports/$reportId.json").delete().build()
      val resp = client.newCall(req).execute()
      updateAdminDataInMemory { bundle ->
        bundle.copy(reports = bundle.reports.filter { it.id != reportId })
      }
      resp.isSuccessful
    } catch (e: Exception) {
      Log.e(TAG, "Error deleting report: ${e.message}", e)
      false
    }
  }

  /**
   * Submits a profile update request directly into the nurse's permitted node:
   * `/nurses/{nurseId}/pendingUpdate` and `/users/{nurseId}/pendingUpdate`.
   * Preserves both old and new profile details for clear admin comparison.
   */
  suspend fun requestProfileUpdate(
    nurseId: String,
    nurseName: String = "",
    requestedName: String = "",
    registeredPhone: String,
    oldPhone: String = "",
    oldCountry: String = "",
    oldCity: String = "",
    oldBio: String = "",
    oldProfileImageUri: String = "",
    requestedPhone: String,
    requestedCountry: String,
    requestedCity: String,
    requestedBio: String,
    requestedProfileImageBase64: String = ""
  ): String = withContext(Dispatchers.IO) {
    try {
      var targetNurseId = nurseId.trim()
      val cleanRegisteredPhone = registeredPhone.trim()

      if (targetNurseId.isBlank() && cleanRegisteredPhone.isNotBlank()) {
        val existing = try { fetchMergedNurses() } catch (_: Exception) { emptyList() }
        val matched = existing.firstOrNull { it.phone.contains(cleanRegisteredPhone) || cleanRegisteredPhone.contains(it.phone) }
        if (matched != null && matched.id.isNotBlank()) {
          targetNurseId = matched.id
        }
      }

      if (targetNurseId.isBlank()) {
        targetNurseId = "nurse_${System.currentTimeMillis()}"
      }

      val updateId = "upd_${System.currentTimeMillis()}"
      val json = JSONObject().apply {
        put("id", updateId)
        put("nurseId", targetNurseId)
        put("nurseName", nurseName)
        if (requestedName.isNotBlank()) {
          put("requestedName", requestedName.trim())
        }
        put("registeredPhone", cleanRegisteredPhone)
        put("oldPhone", oldPhone.ifBlank { cleanRegisteredPhone })
        put("oldCountry", oldCountry)
        put("oldCity", oldCity)
        put("oldBio", oldBio)
        put("oldProfileImageUri", oldProfileImageUri)
        put("requestedPhone", requestedPhone.ifBlank { cleanRegisteredPhone })
        put("requestedCountry", requestedCountry)
        put("requestedCity", requestedCity)
        put("requestedBio", requestedBio)
        if (requestedProfileImageBase64.isNotBlank()) {
          put("requestedProfileImageBase64", requestedProfileImageBase64)
          put("profileImageBase64", requestedProfileImageBase64)
          put("avatarUrl", requestedProfileImageBase64)
        }
        put("status", "PENDING")
        put("timestamp", System.currentTimeMillis())
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = json.toString().toRequestBody(mediaType)

      // 1. Primary storage: Permitted node /nurses/{nurseId}/pendingUpdate.json
      val req1 = Request.Builder().url("$BASE_URL/nurses/$targetNurseId/pendingUpdate.json").put(body).build()
      client.newCall(req1).execute()

      // Also mirror to /users/{nurseId}/pendingUpdate.json
      try {
        val req2 = Request.Builder().url("$BASE_URL/users/$targetNurseId/pendingUpdate.json").put(body).build()
        client.newCall(req2).execute()
      } catch (_: Exception) {}

      // If nurseId has base ID (e.g. before underscore), save there too
      if (targetNurseId.contains("_")) {
        val baseId = targetNurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          try {
            client.newCall(Request.Builder().url("$BASE_URL/nurses/$baseId/pendingUpdate.json").put(body).build()).execute()
            client.newCall(Request.Builder().url("$BASE_URL/users/$baseId/pendingUpdate.json").put(body).build()).execute()
          } catch (_: Exception) {}
        }
      }

      // Standalone node fallbacks in case rules are ever enabled
      try {
        client.newCall(Request.Builder().url("$BASE_URL/pending_updates/$updateId.json").put(body).build()).execute()
        client.newCall(Request.Builder().url("$BASE_URL/profile_updates/$updateId.json").put(body).build()).execute()
      } catch (_: Exception) {}

      triggerAdminDataSync()
      updateId
    } catch (e: Exception) {
      Log.e(TAG, "Error requesting profile update: ${e.message}", e)
      ""
    }
  }

  /**
   * Extracts pending profile updates from a parsed nurses snapshot off the Main Thread.
   * Flexibly matches any pending status while excluding approved or rejected updates.
   */
  fun extractPendingUpdatesFromNursesMap(nursesMap: List<Pair<String, JSONObject>>): List<PendingProfileUpdate> {
    val list = mutableListOf<PendingProfileUpdate>()
    val seenNurseIds = mutableSetOf<String>()
    val seenUpdateIds = mutableSetOf<String>()

    for ((nurseKey, nurseObj) in nursesMap) {
      val updObj = nurseObj.optJSONObject("pendingUpdate") ?: run {
        val s = nurseObj.optString("pendingUpdate", "")
        if (s.isNotBlank() && s.startsWith("{")) {
          try { JSONObject(s) } catch (_: Exception) { null }
        } else null
      }

      if (updObj != null) {
        val rawStatus = getStringSafe(updObj, "status", default = "PENDING").trim()
        val isPending = !rawStatus.equals("APPROVED", ignoreCase = true) &&
            !rawStatus.equals("REJECTED", ignoreCase = true) &&
            !rawStatus.equals("مرفوض", ignoreCase = true)

        if (isPending) {
          val updateId = getStringSafe(updObj, "id", default = "upd_$nurseKey")
          val targetNurseId = getStringSafe(updObj, "nurseId", default = nurseKey).ifBlank { nurseKey }
          val regPhone = getStringSafe(updObj, "registeredPhone", default = getStringSafe(nurseObj, "phone", "mobile", default = ""))

          if (!seenNurseIds.contains(targetNurseId) && !seenUpdateIds.contains(updateId)) {
            seenNurseIds.add(targetNurseId)
            seenUpdateIds.add(updateId)

            list.add(
              PendingProfileUpdate(
                id = updateId,
                nurseId = targetNurseId,
                nurseName = getStringSafe(updObj, "nurseName", default = getStringSafe(nurseObj, "displayName", "name", default = "")),
                requestedName = getStringSafe(updObj, "requestedName", default = ""),
                registeredPhone = regPhone,
                oldPhone = getStringSafe(updObj, "oldPhone", default = getStringSafe(nurseObj, "phone", "mobile", default = "")).ifBlank { regPhone },
                oldCountry = getStringSafe(updObj, "oldCountry", default = getStringSafe(nurseObj, "country", default = "سوريا")),
                oldCity = getStringSafe(updObj, "oldCity", default = getStringSafe(nurseObj, "city", default = "")),
                oldBio = getStringSafe(updObj, "oldBio", default = getStringSafe(nurseObj, "bio", default = "")),
                oldProfileImageUri = getStringSafe(updObj, "oldProfileImageUri", default = getStringSafe(nurseObj, "profileImageUri", "avatarUrl", default = "")),
                requestedPhone = getStringSafe(updObj, "requestedPhone", default = ""),
                requestedCountry = getStringSafe(updObj, "requestedCountry", default = ""),
                requestedCity = getStringSafe(updObj, "requestedCity", default = ""),
                requestedBio = getStringSafe(updObj, "requestedBio", default = ""),
                requestedProfileImageBase64 = getStringSafe(updObj, "requestedProfileImageBase64", "profileImageBase64", default = ""),
                status = if (rawStatus.isNotBlank()) rawStatus else "PENDING",
                timestamp = updObj.optLong("timestamp", System.currentTimeMillis())
              )
            )
          }
        }
      }
    }
    return list.sortedByDescending { it.timestamp }
  }

  /**
   * Fetches pending profile updates for the Protected Admin Screen.
   * Scans permitted nodes asynchronously off the Main Thread.
   */
  suspend fun fetchPendingUpdates(): List<PendingProfileUpdate> = withContext(Dispatchers.IO) {
    try {
      val nursesJson = executeGet("$BASE_URL/nurses.json")
      withContext(Dispatchers.Default) {
        extractPendingUpdatesFromNursesMap(extractJsonObjects(nursesJson))
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching pending updates: ${e.message}", e)
      emptyList()
    }
  }

  /**
   * Approves a profile update: patches nurse and user nodes in Firebase RTDB, updates Room cache,
   * and clears the pendingUpdate child field from the nurse and user nodes.
   */
  suspend fun approveProfileUpdate(update: PendingProfileUpdate): Boolean = withContext(Dispatchers.IO) {
    try {
      val mediaType = "application/json; charset=utf-8".toMediaType()

      // 1. Patch nurse record in Firebase
      val patchNurse = JSONObject().apply {
        if (update.requestedName.isNotBlank()) {
          put("name", update.requestedName.trim())
          put("fullName", update.requestedName.trim())
          put("displayName", update.requestedName.trim())
        }
        if (update.requestedPhone.isNotBlank()) {
          put("phone", update.requestedPhone)
          put("mobile", update.requestedPhone)
          put("whatsapp", update.requestedPhone)
        }
        if (update.requestedCountry.isNotBlank()) put("country", update.requestedCountry)
        if (update.requestedCity.isNotBlank()) put("city", update.requestedCity)
        if (update.requestedBio.isNotBlank()) put("bio", update.requestedBio)
        if (update.requestedProfileImageBase64.isNotBlank()) {
          put("profileImageUri", update.requestedProfileImageBase64)
          put("profileImageBase64", update.requestedProfileImageBase64)
          put("avatarUrl", update.requestedProfileImageBase64)
        }
        put("updatedAt", System.currentTimeMillis())
      }
      val patchBody = patchNurse.toString().toRequestBody(mediaType)

      // Patch /nurses/{id}
      client.newCall(
        Request.Builder().url("$BASE_URL/nurses/${update.nurseId}.json").patch(patchBody).build()
      ).execute()

      // Patch /users/{id}
      client.newCall(
        Request.Builder().url("$BASE_URL/users/${update.nurseId}.json").patch(patchBody).build()
      ).execute()

      // If nurseId has base ID (e.g. before underscore), patch base too
      if (update.nurseId.contains("_")) {
        val baseId = update.nurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          try {
            client.newCall(Request.Builder().url("$BASE_URL/nurses/$baseId.json").patch(patchBody).build()).execute()
            client.newCall(Request.Builder().url("$BASE_URL/users/$baseId.json").patch(patchBody).build()).execute()
          } catch (_: Exception) {}
        }
      }

      // Update Room local cache
      val context = appContext
      if (context != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(context)
          val cached = db.nurseDao().getNurseById(update.nurseId)
          if (cached != null) {
            val updatedEntity = cached.copy(
              name = if (update.requestedName.isNotBlank()) update.requestedName.trim() else cached.name,
              fullName = if (update.requestedName.isNotBlank()) update.requestedName.trim() else cached.fullName,
              phone = if (update.requestedPhone.isNotBlank()) update.requestedPhone else cached.phone,
              country = if (update.requestedCountry.isNotBlank()) update.requestedCountry else cached.country,
              city = if (update.requestedCity.isNotBlank()) update.requestedCity else cached.city,
              bio = if (update.requestedBio.isNotBlank()) update.requestedBio else cached.bio,
              profileImageUri = if (update.requestedProfileImageBase64.isNotBlank()) update.requestedProfileImageBase64 else cached.profileImageUri
            )
            db.nurseDao().insertNurse(updatedEntity)
          }
        } catch (e: Exception) {
          Log.w(TAG, "Notice: Room cache update error on approveProfileUpdate: ${e.message}")
        }
      }

      // 2. Clear pendingUpdate from nurse and user nodes
      executeDelete("$BASE_URL/nurses/${update.nurseId}/pendingUpdate.json")
      executeDelete("$BASE_URL/users/${update.nurseId}/pendingUpdate.json")

      if (update.nurseId.contains("_")) {
        val baseId = update.nurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          executeDelete("$BASE_URL/nurses/$baseId/pendingUpdate.json")
          executeDelete("$BASE_URL/users/$baseId/pendingUpdate.json")
        }
      }

      // Clean standalone nodes if any exist
      executeDelete("$BASE_URL/pending_updates/${update.id}.json")
      executeDelete("$BASE_URL/profile_updates/${update.id}.json")

      invalidateNursesCache()
      updateAdminDataInMemory { bundle ->
        bundle.copy(updates = bundle.updates.filter { it.id != update.id && it.nurseId != update.nurseId })
      }
      true
    } catch (e: Exception) {
      Log.e(TAG, "Error approving profile update: ${e.message}", e)
      false
    }
  }

  /**
   * Rejects a profile update: clears the pendingUpdate field from the nurse's permitted node
   * and any standalone queues without altering the active nurse profile.
   */
  suspend fun rejectProfileUpdate(updateId: String, nurseId: String = "", reason: String = ""): Boolean = withContext(Dispatchers.IO) {
    try {
      if (nurseId.isNotBlank()) {
        executeDelete("$BASE_URL/nurses/$nurseId/pendingUpdate.json")
        executeDelete("$BASE_URL/users/$nurseId/pendingUpdate.json")
        if (nurseId.contains("_")) {
          val baseId = nurseId.substringBeforeLast("_")
          if (baseId.isNotBlank()) {
            executeDelete("$BASE_URL/nurses/$baseId/pendingUpdate.json")
            executeDelete("$BASE_URL/users/$baseId/pendingUpdate.json")
          }
        }
      }

      // If nurseId was not specified, search nurses for this updateId
      try {
        val nursesJson = executeGet("$BASE_URL/nurses.json")
        val nursesMap = extractJsonObjects(nursesJson)
        for ((nKey, nObj) in nursesMap) {
          val updObj = nObj.optJSONObject("pendingUpdate")
          if (updObj != null && getStringSafe(updObj, "id") == updateId) {
            executeDelete("$BASE_URL/nurses/$nKey/pendingUpdate.json")
            executeDelete("$BASE_URL/users/$nKey/pendingUpdate.json")
          }
        }
      } catch (_: Exception) {}

      // Clean standalone nodes if any
      executeDelete("$BASE_URL/pending_updates/$updateId.json")
      executeDelete("$BASE_URL/profile_updates/$updateId.json")

      updateAdminDataInMemory { bundle ->
        bundle.copy(updates = bundle.updates.filter { it.id != updateId && (nurseId.isBlank() || it.nurseId != nurseId) })
      }
      true
    } catch (e: Exception) {
      Log.e(TAG, "Error rejecting profile update: ${e.message}", e)
      false
    }
  }

  /**
   * Submits an account deletion request directly into the nurse's permitted node path:
   * `/nurses/{nurseId}/pendingDeletion` and `/users/{nurseId}/pendingDeletion`.
   */
  suspend fun requestAccountDeletion(
    nurseId: String,
    nurseName: String = "",
    registeredPhone: String,
    country: String = "سوريا",
    city: String = "",
    reason: String
  ): String = withContext(Dispatchers.IO) {
    try {
      var targetNurseId = nurseId.trim()
      val cleanRegisteredPhone = registeredPhone.trim()

      if (targetNurseId.isBlank() && cleanRegisteredPhone.isNotBlank()) {
        val existing = try { fetchMergedNurses() } catch (_: Exception) { emptyList() }
        val matched = existing.firstOrNull { it.phone.contains(cleanRegisteredPhone) || cleanRegisteredPhone.contains(it.phone) }
        if (matched != null && matched.id.isNotBlank()) {
          targetNurseId = matched.id
        }
      }

      if (targetNurseId.isBlank()) {
        targetNurseId = "nurse_${System.currentTimeMillis()}"
      }

      val delId = "del_${System.currentTimeMillis()}"
      val json = JSONObject().apply {
        put("id", delId)
        put("nurseId", targetNurseId)
        put("nurseName", nurseName)
        put("registeredPhone", cleanRegisteredPhone)
        put("country", country)
        put("city", city)
        put("reason", reason)
        put("status", "PENDING")
        put("timestamp", System.currentTimeMillis())
      }
      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = json.toString().toRequestBody(mediaType)

      // 1. Primary storage: Permitted node /nurses/{nurseId}/pendingDeletion.json
      val req1 = Request.Builder().url("$BASE_URL/nurses/$targetNurseId/pendingDeletion.json").put(body).build()
      client.newCall(req1).execute()

      // Also mirror to /users/{nurseId}/pendingDeletion.json
      try {
        val req2 = Request.Builder().url("$BASE_URL/users/$targetNurseId/pendingDeletion.json").put(body).build()
        client.newCall(req2).execute()
      } catch (_: Exception) {}

      // If nurseId has base ID (e.g. before underscore), save there too
      if (targetNurseId.contains("_")) {
        val baseId = targetNurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          try {
            client.newCall(Request.Builder().url("$BASE_URL/nurses/$baseId/pendingDeletion.json").put(body).build()).execute()
            client.newCall(Request.Builder().url("$BASE_URL/users/$baseId/pendingDeletion.json").put(body).build()).execute()
          } catch (_: Exception) {}
        }
      }

      // Standalone node fallbacks
      try {
        client.newCall(Request.Builder().url("$BASE_URL/pending_deletions/$delId.json").put(body).build()).execute()
        client.newCall(Request.Builder().url("$BASE_URL/account_deletions/$delId.json").put(body).build()).execute()
      } catch (_: Exception) {}

      triggerAdminDataSync()
      delId
    } catch (e: Exception) {
      Log.e(TAG, "Error requesting account deletion: ${e.message}", e)
      ""
    }
  }

  /**
   * Extracts pending account deletions from a parsed nurses snapshot off the Main Thread.
   * Flexibly matches any pending status while excluding approved or rejected deletions.
   */
  fun extractPendingDeletionsFromNursesMap(nursesMap: List<Pair<String, JSONObject>>): List<PendingAccountDeletion> {
    val list = mutableListOf<PendingAccountDeletion>()
    val seenNurseIds = mutableSetOf<String>()
    val seenDeletionIds = mutableSetOf<String>()

    for ((nurseKey, nurseObj) in nursesMap) {
      val delObj = nurseObj.optJSONObject("pendingDeletion") ?: run {
        val s = nurseObj.optString("pendingDeletion", "")
        if (s.isNotBlank() && s.startsWith("{")) {
          try { JSONObject(s) } catch (_: Exception) { null }
        } else null
      }

      if (delObj != null) {
        val rawStatus = getStringSafe(delObj, "status", default = "PENDING").trim()
        val isPending = !rawStatus.equals("APPROVED", ignoreCase = true) &&
            !rawStatus.equals("REJECTED", ignoreCase = true) &&
            !rawStatus.equals("مرفوض", ignoreCase = true)

        if (isPending) {
          val delId = getStringSafe(delObj, "id", default = "del_$nurseKey")
          val targetNurseId = getStringSafe(delObj, "nurseId", default = nurseKey).ifBlank { nurseKey }
          val regPhone = getStringSafe(delObj, "registeredPhone", default = getStringSafe(nurseObj, "phone", "mobile", default = ""))

          if (!seenNurseIds.contains(targetNurseId) && !seenDeletionIds.contains(delId)) {
            seenNurseIds.add(targetNurseId)
            seenDeletionIds.add(delId)

            list.add(
              PendingAccountDeletion(
                id = delId,
                nurseId = targetNurseId,
                nurseName = getStringSafe(delObj, "nurseName", default = getStringSafe(nurseObj, "displayName", "name", default = "")),
                registeredPhone = regPhone,
                country = getStringSafe(delObj, "country", default = getStringSafe(nurseObj, "country", default = "سوريا")),
                city = getStringSafe(delObj, "city", default = getStringSafe(nurseObj, "city", default = "")),
                reason = getStringSafe(delObj, "reason", default = "طلب المستخدم حذف حسابه"),
                status = if (rawStatus.isNotBlank()) rawStatus else "PENDING",
                timestamp = delObj.optLong("timestamp", System.currentTimeMillis())
              )
            )
          }
        }
      }
    }
    return list.sortedByDescending { it.timestamp }
  }

  /**
   * Fetches pending account deletions for the Protected Admin Screen.
   * Scans permitted nodes asynchronously off the Main Thread.
   */
  suspend fun fetchPendingDeletions(): List<PendingAccountDeletion> = withContext(Dispatchers.IO) {
    try {
      val nursesJson = executeGet("$BASE_URL/nurses.json")
      withContext(Dispatchers.Default) {
        extractPendingDeletionsFromNursesMap(extractJsonObjects(nursesJson))
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching pending deletions: ${e.message}", e)
      emptyList()
    }
  }

  /**
   * Approves account deletion: completely and permanently wipes all nurse records from Firebase RTDB and local Room storage.
   * Clears nurse node, user node, pendingDeletion, reviews, and triggers instant reactive sync.
   */
  suspend fun approveAccountDeletion(deletion: PendingAccountDeletion): Boolean = withContext(Dispatchers.IO) {
    try {
      // 1. Wipe nurse node and users node permanently
      executeDelete("$BASE_URL/nurses/${deletion.nurseId}.json")
      executeDelete("$BASE_URL/users/${deletion.nurseId}.json")
      executeDelete("$BASE_URL/pending_registrations/${deletion.nurseId}.json")
      executeDelete("$BASE_URL/reviews/${deletion.nurseId}.json")

      if (deletion.nurseId.contains("_")) {
        val baseId = deletion.nurseId.substringBeforeLast("_")
        if (baseId.isNotBlank()) {
          executeDelete("$BASE_URL/nurses/$baseId.json")
          executeDelete("$BASE_URL/users/$baseId.json")
          executeDelete("$BASE_URL/reviews/$baseId.json")
        }
      }

      // 2. Remove from Room local storage
      val context = appContext
      if (context != null) {
        try {
          val db = GoNurseAppDatabase.getDatabase(context)
          db.nurseDao().deleteNurseById(deletion.nurseId)
          if (deletion.nurseId.contains("_")) {
            val baseId = deletion.nurseId.substringBeforeLast("_")
            if (baseId.isNotBlank()) {
              db.nurseDao().deleteNurseById(baseId)
            }
          }
        } catch (e: Exception) {
          Log.w(TAG, "Room deletion error: ${e.message}")
        }
      }

      // 3. Remove permanently from standalone deletion queues if present
      executeDelete("$BASE_URL/pending_deletions/${deletion.id}.json")
      executeDelete("$BASE_URL/account_deletions/${deletion.id}.json")

      invalidateNursesCache()
      updateAdminDataInMemory { bundle ->
        bundle.copy(deletions = bundle.deletions.filter { it.id != deletion.id && it.nurseId != deletion.nurseId })
      }
      true
    } catch (e: Exception) {
      Log.e(TAG, "Error approving account deletion: ${e.message}", e)
      false
    }
  }

  /**
   * Rejects or cancels an account deletion request:
   * Clears the pendingDeletion child field from the nurse and user nodes,
   * preserving the nurse's active profile and reviews in GoNurse.
   */
  suspend fun rejectAccountDeletion(deletionId: String, nurseId: String = "", reason: String = ""): Boolean = withContext(Dispatchers.IO) {
    try {
      if (nurseId.isNotBlank()) {
        executeDelete("$BASE_URL/nurses/$nurseId/pendingDeletion.json")
        executeDelete("$BASE_URL/users/$nurseId/pendingDeletion.json")
        if (nurseId.contains("_")) {
          val baseId = nurseId.substringBeforeLast("_")
          if (baseId.isNotBlank()) {
            executeDelete("$BASE_URL/nurses/$baseId/pendingDeletion.json")
            executeDelete("$BASE_URL/users/$baseId/pendingDeletion.json")
          }
        }
      }

      // If nurseId was not specified, search nurses for this deletionId
      try {
        val nursesJson = executeGet("$BASE_URL/nurses.json")
        val nursesMap = extractJsonObjects(nursesJson)
        for ((nKey, nObj) in nursesMap) {
          val delObj = nObj.optJSONObject("pendingDeletion")
          if (delObj != null && getStringSafe(delObj, "id") == deletionId) {
            executeDelete("$BASE_URL/nurses/$nKey/pendingDeletion.json")
            executeDelete("$BASE_URL/users/$nKey/pendingDeletion.json")
          }
        }
      } catch (_: Exception) {}

      // Clean standalone queues if any
      executeDelete("$BASE_URL/pending_deletions/$deletionId.json")
      executeDelete("$BASE_URL/account_deletions/$deletionId.json")

      updateAdminDataInMemory { bundle ->
        bundle.copy(deletions = bundle.deletions.filter { it.id != deletionId && (nurseId.isBlank() || it.nurseId != nurseId) })
      }
      true
    } catch (e: Exception) {
      Log.e(TAG, "Error rejecting account deletion: ${e.message}", e)
      false
    }
  }

  /**
   * Extracts submitted user reports from a parsed JSON string off the Main Thread.
   */
  fun extractReportsFromJson(jsonStr: String?): List<SubmittedReport> {
    val list = mutableListOf<SubmittedReport>()
    val map = extractJsonObjects(jsonStr)
    for ((key, obj) in map) {
      list.add(
        SubmittedReport(
          id = key,
          reporterPhone = getStringSafe(obj, "reporterPhone", "phone", default = ""),
          reporterCountry = getStringSafe(obj, "reporterCountry", "country", default = "سوريا"),
          targetType = getStringSafe(obj, "targetType", default = "NURSE"),
          targetId = getStringSafe(obj, "targetId", default = ""),
          targetName = getStringSafe(obj, "targetName", default = ""),
          targetCity = getStringSafe(obj, "targetCity", default = ""),
          reason = getStringSafe(obj, "reason", default = ""),
          additionalNotes = getStringSafe(obj, "additionalNotes", "notes", default = ""),
          status = getStringSafe(obj, "status", default = "PENDING"),
          timestamp = obj.optLong("timestamp", System.currentTimeMillis())
        )
      )
    }
    return list.sortedByDescending { it.timestamp }
  }

  /**
   * Data bundle for parallel real-time fetching across all admin dashboard streams.
   */
  data class AdminDataBundle(
    val registrations: List<PendingRegistration>,
    val patientRequests: List<NursingRequest> = emptyList(),
    val updates: List<PendingProfileUpdate>,
    val deletions: List<PendingAccountDeletion>,
    val reports: List<SubmittedReport>
  )

  /**
   * Concurrently fetches all admin queues in parallel for instant synchronization.
   * Performs exactly 1 fetch of nurses.json, requests.json, and reports.json in parallel,
   * with parsing offloaded to Dispatchers.Default so the UI thread never freezes.
   */
  suspend fun fetchAllAdminData(): AdminDataBundle = withContext(Dispatchers.IO) {
    val nursesJsonDeferred = async { executeGet("$BASE_URL/nurses.json") }
    val reqsDeferred = async { fetchRequests() }
    val reportsJsonDeferred = async { executeGet("$BASE_URL/reports.json") }

    val nursesJson = nursesJsonDeferred.await()
    val patientRequests = reqsDeferred.await()
    val reportsJson = reportsJsonDeferred.await()

    withContext(Dispatchers.Default) {
      val nursesMap = extractJsonObjects(nursesJson)
      val regs = extractPendingRegistrationsFromNursesMap(nursesMap)
      val upds = extractPendingUpdatesFromNursesMap(nursesMap)
      val dels = extractPendingDeletionsFromNursesMap(nursesMap)
      val reps = extractReportsFromJson(reportsJson)

      AdminDataBundle(
        registrations = regs,
        patientRequests = patientRequests,
        updates = upds,
        deletions = dels,
        reports = reps
      )
    }
  }

  // Deprecated email verification shims
  suspend fun saveEmailVerificationRecord(email: String, code: String, isVerified: Boolean): Boolean = true
  suspend fun checkEmailVerificationRecord(email: String): Boolean = true
  suspend fun saveLicenseUploadOtpRecord(email: String, code: String): Boolean = true
  suspend fun verifyOtpRecord(email: String, inputCode: String): Boolean = true
  suspend fun verifyLicenseUploadOtpRecord(email: String, inputCode: String): Boolean = true

  /**
   * Posts a new rating and review to Firebase Realtime Database at `reviews/{nurseId}/{reviewId}`.
   * Fields: `rating` (numeric 1-5), `reviewText` (string), `patientName` (string), and `createdAt` (timestamp).
   * Automatically re-fetches all reviews for the nurse and updates their aggregate rating and reviewsCount in real time.
   */
  suspend fun submitReview(nurseId: String, review: NurseReview): Boolean = withContext(Dispatchers.IO) {
    try {
      val cleanNurseId = nurseId.trim()
      if (cleanNurseId.isBlank()) return@withContext false

      val reviewId = if (review.id.isNotBlank()) review.id else "rev_${System.currentTimeMillis()}"
      val jsonObject = JSONObject().apply {
        put("id", reviewId)
        put("nurseId", cleanNurseId)
        put("rating", review.rating.coerceIn(1, 5))
        put("reviewText", review.reviewText.trim())
        put("patientName", review.patientName.trim().ifBlank { "مريض" })
        put("createdAt", if (review.createdAt > 0L) review.createdAt else System.currentTimeMillis())
        if (review.requestId.isNotBlank()) put("requestId", review.requestId)
        if (review.serviceName.isNotBlank()) put("serviceName", review.serviceName)
      }

      val mediaType = "application/json; charset=utf-8".toMediaType()
      val body = jsonObject.toString().toRequestBody(mediaType)
      val httpRequest = Request.Builder()
        .url("$BASE_URL/reviews/$cleanNurseId/$reviewId.json")
        .put(body)
        .build()

      val response = client.newCall(httpRequest).execute()
      val isSuccess = response.isSuccessful

      if (isSuccess) {
        // Automatically re-fetch reviews and update the nurse's overall aggregate rating and count in Firebase
        try {
          val allReviews = fetchReviewsForNurse(cleanNurseId)
          val reviewsToAggregate = if (allReviews.isNotEmpty()) allReviews else listOf(review)
          val avgRating = (Math.round((reviewsToAggregate.map { it.rating.toDouble() }.average()) * 10.0) / 10.0).coerceIn(1.0, 5.0)
          val totalCount = reviewsToAggregate.size

          val patchJson = JSONObject().apply {
            put("rating", avgRating)
            put("reviewsCount", totalCount)
          }
          val patchBody = patchJson.toString().toRequestBody(mediaType)

          // 1. Update in nurses/$cleanNurseId.json
          client.newCall(
            Request.Builder().url("$BASE_URL/nurses/$cleanNurseId.json").patch(patchBody).build()
          ).execute()

          // 2. Update in users/$cleanNurseId.json
          client.newCall(
            Request.Builder().url("$BASE_URL/users/$cleanNurseId.json").patch(patchBody).build()
          ).execute()

          // 3. If cleanNurseId has suffix or base, update base as well
          if (cleanNurseId.contains("_")) {
            val baseId = cleanNurseId.substringBeforeLast("_")
            if (baseId.isNotBlank()) {
              client.newCall(Request.Builder().url("$BASE_URL/nurses/$baseId.json").patch(patchBody).build()).execute()
              client.newCall(Request.Builder().url("$BASE_URL/users/$baseId.json").patch(patchBody).build()).execute()
            }
          }

          // 4. Update local Room database cache
          val context = appContext
          if (context != null) {
            try {
              val db = GoNurseAppDatabase.getDatabase(context)
              val cached = db.nurseDao().getNurseById(cleanNurseId)
              if (cached != null) {
                db.nurseDao().insertNurse(cached.copy(rating = avgRating, reviewsCount = totalCount))
              }
            } catch (e: Exception) {
              Log.w(TAG, "Notice: Room cache update error on review: ${e.message}")
            }
          }
        } catch (e: Exception) {
          Log.w(TAG, "Error updating aggregate nurse rating: ${e.message}")
        }
      }

      isSuccess
    } catch (e: Exception) {
      Log.e(TAG, "Error submitting review: ${e.message}", e)
      false
    }
  }

  /**
   * Fetches all reviews for a nurse from `reviews/{nurseId}` node.
   * Supports alternate nurse IDs (e.g. UID) and handles sanitized suffix keys.
   */
  suspend fun fetchReviewsForNurse(nurseId: String, altId: String = ""): List<NurseReview> = withContext(Dispatchers.IO) {
    val cleanId = nurseId.trim()
    val cleanAltId = altId.trim()
    if (cleanId.isBlank() && cleanAltId.isBlank()) return@withContext emptyList()

    val targetIds = mutableListOf<String>()
    if (cleanId.isNotBlank()) targetIds.add(cleanId)
    if (cleanAltId.isNotBlank() && !targetIds.contains(cleanAltId)) targetIds.add(cleanAltId)
    if (cleanId.contains("_")) {
      val base = cleanId.substringBeforeLast("_")
      if (base.isNotBlank() && !targetIds.contains(base)) targetIds.add(base)
    }

    val allReviews = mutableListOf<NurseReview>()
    for (tid in targetIds) {
      try {
        val json = executeGet("$BASE_URL/reviews/$tid.json?orderBy=\"\$key\"&limitToLast=25")
        val objects = extractJsonObjects(json)
        for ((key, obj) in objects) {
          try {
            val id = getStringSafe(obj, "id", default = key)
            val rating = getIntSafe(obj, "rating", default = 5).coerceIn(1, 5)
            val reviewText = getStringSafe(obj, "reviewText", "text", "comment", default = "")
            val patientName = getStringSafe(obj, "patientName", "name", "author", default = "مريض")
            val createdAt = getLongSafe(obj, "createdAt", "timestamp", "date", default = System.currentTimeMillis())
            val requestId = getStringSafe(obj, "requestId", default = "")
            val serviceName = getStringSafe(obj, "serviceName", default = "")

            val review = NurseReview(
              id = id,
              nurseId = tid,
              rating = rating,
              reviewText = reviewText,
              patientName = patientName,
              createdAt = createdAt,
              requestId = requestId,
              serviceName = serviceName
            )
            if (allReviews.none { it.id == review.id }) {
              allReviews.add(review)
            }
          } catch (e: Exception) {
            Log.e(TAG, "Error parsing review (key=$key): ${e.message}")
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error fetching reviews for nurse $tid: ${e.message}", e)
      }
    }

    // Sort newest first
    allReviews.sortedWith(compareByDescending<NurseReview> { it.createdAt }.thenBy { it.id })
  }

  /**
   * Safely executes an HTTP GET request with HTTP ETag caching.
   * If the Firebase Realtime Database node has not changed, Firebase returns '304 Not Modified',
   * transferring 0 payload bytes and drastically saving bandwidth.
   */
  private fun executeGet(url: String): String? {
    return try {
      val safeUrl = if (url.contains("\"")) url.replace("\"", "%22") else url
      val cached = etagCache[safeUrl]
      val requestBuilder = Request.Builder().url(safeUrl)
      if (cached != null && cached.first.isNotBlank()) {
        requestBuilder.header("If-None-Match", cached.first)
      }
      val request = requestBuilder.build()
      client.newCall(request).execute().use { response ->
        if (response.code == 304 && cached != null) {
          // 304 Not Modified: 0 payload bytes downloaded from Firebase!
          return cached.second
        }
        if (!response.isSuccessful) {
          return cached?.second
        }
        val body = response.body?.string() ?: return null
        val etag = response.header("ETag") ?: ""
        if (etag.isNotBlank()) {
          etagCache[safeUrl] = Pair(etag, body)
        }
        body
      }
    } catch (e: Exception) {
      Log.e(TAG, "HTTP GET failed ($url): ${e.message}")
      etagCache[url]?.second
    }
  }

  /**
   * Safely executes an HTTP DELETE request
   */
  private fun executeDelete(url: String): Boolean {
    return try {
      val request = Request.Builder().url(url).delete().build()
      client.newCall(request).execute().use { response ->
        response.isSuccessful
      }
    } catch (e: Exception) {
      Log.e(TAG, "HTTP DELETE failed ($url): ${e.message}")
      false
    }
  }

  data class EmailLeakageCleanupReport(
    val totalUsersScanned: Int,
    val totalNursesScanned: Int,
    val rootUsersEmailRemoved: Boolean,
    val rootNursesEmailRemoved: Boolean,
    val sanitizedUserKeys: List<String>,
    val sanitizedNurseKeys: List<String>,
    val isSuccessful: Boolean,
    val message: String
  )

  /**
   * Direct routine to clean up and remove leaked/duplicated email data in Firebase Realtime Database:
   * 1. Queries the Firebase Realtime Database paths ('users' and 'nurses').
   * 2. Locates and deletes the incorrect global/root 'email' field or sets it to null/deletes it
   *    for all child nodes where it was improperly overwritten, preserving only the authentic user's record.
   * 3. Prevents data leakage by ensuring user email is strictly retained under the authentic user's unique ID node.
   */
  suspend fun cleanupLeakedEmailsInDatabase(
    legitimateOwnerUid: String = "-OtrNWvzL7ODsxaccsFc",
    targetEmailToSanitize: String = "wwwbsher327@gmail.com"
  ): EmailLeakageCleanupReport = withContext(Dispatchers.IO) {
    var usersScanned = 0
    var nursesScanned = 0
    var rootUsersEmailDeleted = false
    var rootNursesEmailDeleted = false
    val sanitizedUsers = mutableListOf<String>()
    val sanitizedNurses = mutableListOf<String>()

    try {
      // 1. Check and remove any accidental root-level 'email' field on /users and /nurses
      try {
        val rootUserEmail = executeGet("$BASE_URL/users/email.json")
        if (!rootUserEmail.isNullOrBlank() && rootUserEmail.trim() != "null") {
          rootUsersEmailDeleted = executeDelete("$BASE_URL/users/email.json")
          Log.i(TAG, "Deleted accidental root /users/email.json: $rootUsersEmailDeleted")
        }
      } catch (e: Exception) {
        Log.w(TAG, "Error checking root /users/email.json: ${e.message}")
      }

      try {
        val rootNurseEmail = executeGet("$BASE_URL/nurses/email.json")
        if (!rootNurseEmail.isNullOrBlank() && rootNurseEmail.trim() != "null") {
          rootNursesEmailDeleted = executeDelete("$BASE_URL/nurses/email.json")
          Log.i(TAG, "Deleted accidental root /nurses/email.json: $rootNursesEmailDeleted")
        }
      } catch (e: Exception) {
        Log.w(TAG, "Error checking root /nurses/email.json: ${e.message}")
      }

      val cleanTargetEmail = targetEmailToSanitize.trim().lowercase()

      // 2. Scan and sanitize 'users' node
      val usersJson = executeGet("$BASE_URL/users.json")
      val userObjects = extractJsonObjects(usersJson)
      usersScanned = userObjects.size
      for ((key, obj) in userObjects) {
        val cleanKey = key.trim()
        if (cleanKey.isNotBlank() && cleanKey != legitimateOwnerUid) {
          val childEmail = getStringSafe(obj, "email", "gmail", "mail").trim().lowercase()
          // If this child contains the target leaked email (or has empty/corrupted email)
          if (childEmail.isNotBlank() && (cleanTargetEmail.isBlank() || childEmail == cleanTargetEmail)) {
            val deleted = executeDelete("$BASE_URL/users/$cleanKey/email.json")
            if (deleted) {
              sanitizedUsers.add(cleanKey)
              Log.i(TAG, "Successfully purged leaked email from users/$cleanKey")
            }
          }
        }
      }

      // 3. Scan and sanitize 'nurses' node
      val nursesJson = executeGet("$BASE_URL/nurses.json")
      val nurseObjects = extractJsonObjects(nursesJson)
      nursesScanned = nurseObjects.size
      for ((key, obj) in nurseObjects) {
        val cleanKey = key.trim()
        if (cleanKey.isNotBlank() && cleanKey != legitimateOwnerUid) {
          val childEmail = getStringSafe(obj, "email", "gmail", "mail").trim().lowercase()
          if (childEmail.isNotBlank() && (cleanTargetEmail.isBlank() || childEmail == cleanTargetEmail)) {
            val deleted = executeDelete("$BASE_URL/nurses/$cleanKey/email.json")
            if (deleted) {
              sanitizedNurses.add(cleanKey)
              Log.i(TAG, "Successfully purged leaked email from nurses/$cleanKey")
            }
          }
        }
      }

      val msg = "Sanitization complete: Scanned $usersScanned users ($sanitizedUsers purged), $nursesScanned nurses ($sanitizedNurses purged)."
      Log.i(TAG, msg)
      EmailLeakageCleanupReport(
        totalUsersScanned = usersScanned,
        totalNursesScanned = nursesScanned,
        rootUsersEmailRemoved = rootUsersEmailDeleted,
        rootNursesEmailRemoved = rootNursesEmailDeleted,
        sanitizedUserKeys = sanitizedUsers,
        sanitizedNurseKeys = sanitizedNurses,
        isSuccessful = true,
        message = msg
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error running cleanupLeakedEmailsInDatabase: ${e.message}", e)
      EmailLeakageCleanupReport(
        totalUsersScanned = usersScanned,
        totalNursesScanned = nursesScanned,
        rootUsersEmailRemoved = rootUsersEmailDeleted,
        rootNursesEmailRemoved = rootNursesEmailDeleted,
        sanitizedUserKeys = sanitizedUsers,
        sanitizedNurseKeys = sanitizedNurses,
        isSuccessful = false,
        message = "Cleanup failed: ${e.message}"
      )
    }
  }

  /**
   * Robust JSON extractor that handles JSONObjects, JSONArrays, primitives, and nulls polymorphically.
   */
  private fun extractJsonObjects(jsonStr: String?): List<Pair<String, JSONObject>> {
    if (jsonStr.isNullOrBlank() || jsonStr.trim() == "null") return emptyList()
    val result = mutableListOf<Pair<String, JSONObject>>()
    try {
      val tokener = JSONTokener(jsonStr.trim())
      when (val root = tokener.nextValue()) {
        is JSONObject -> {
          val keys = root.keys()
          while (keys.hasNext()) {
            val key = keys.next()
            when (val value = root.opt(key)) {
              is JSONObject -> {
                result.add(key to value)
              }
              is JSONArray -> {
                for (i in 0 until value.length()) {
                  val item = value.optJSONObject(i)
                  if (item != null) {
                    val itemKey = getStringSafe(item, "id", "uid", default = "${key}_$i")
                    result.add(itemKey to item)
                  }
                }
              }
              else -> {
                // Primitive or null - skip safely
              }
            }
          }
        }
        is JSONArray -> {
          for (i in 0 until root.length()) {
            val item = root.optJSONObject(i)
            if (item != null) {
              val itemKey = getStringSafe(item, "id", "uid", default = "idx_$i")
              result.add(itemKey to item)
            }
          }
        }
        else -> {
          Log.w(TAG, "Unexpected root JSON type: ${root?.javaClass?.simpleName}")
        }
      }
    } catch (e: Exception) {
      Log.e(TAG, "Failed to parse JSON string: ${e.message}")
    }
    return result
  }

  /**
   * Parses a single nurse profile safely from JSONObject with defensive fallbacks
   */
  private fun parseNurse(key: String, obj: JSONObject): Nurse? {
    return try {
      val id = getStringSafe(obj, "id", "uid", "nurseId", "nurse_id", default = key).ifBlank { key }
      val uid = getStringSafe(obj, "uid", "id", "nurseId", default = key).ifBlank { key }
      
      val rawName = getStringSafe(obj, "name", "nurseName", default = "")
      val rawFullName = getStringSafe(obj, "fullName", "full_name", default = "")
      val rawDisplayName = getStringSafe(obj, "displayName", "username", default = "")
      
      val rawPhone = getStringSafe(obj, "phone", "mobile", "whatsapp", "whatsappNumber", "phoneNumber", "tel", "contact", default = "")
      val rawMobile = getStringSafe(obj, "mobile", "phone", "whatsapp", default = rawPhone)

      val cleanPhone: String = PhoneFormatter.sanitizePhoneInput(rawPhone)
      val cleanMobile: String = PhoneFormatter.sanitizePhoneInput(if (rawMobile.isNotBlank()) rawMobile else rawPhone)

      val digitsOnlyPhone = cleanPhone.filter { it.isDigit() }
      val digitsOnlyMobile = cleanMobile.filter { it.isDigit() }
      val hasValidPhone = digitsOnlyPhone.length >= 6 || digitsOnlyMobile.length >= 6
      if (!hasValidPhone) {
        // Discard incomplete nurse records lacking valid phone number
        return null
      }

      // Strictly resolve nurse real name prioritizing the actual 'name' property from Firebase data nodes
      val resolvedName = Nurse.resolveRealName(
        name = rawName,
        fullName = rawFullName,
        displayName = rawDisplayName,
        id = id,
        uid = uid,
        phone = if (cleanPhone.isNotBlank()) cleanPhone else cleanMobile,
        fallback = ""
      )

      val cleanParsedName = when {
        Nurse.isRealPersonName(rawName, id, uid, cleanPhone) -> rawName.trim()
        Nurse.isRealPersonName(rawFullName, id, uid, cleanPhone) -> rawFullName.trim()
        resolvedName.isNotBlank() && Nurse.isRealPersonName(resolvedName, id, uid, cleanPhone) -> resolvedName
        else -> ""
      }

      if (cleanParsedName.isBlank() || Nurse.isStrictPlaceholder(cleanParsedName, id, uid)) {
        // Discard incomplete records lacking authentic nurse identity
        return null
      }

      val cleanParsedFullName = when {
        Nurse.isRealPersonName(rawFullName, id, uid, cleanPhone) -> rawFullName.trim()
        cleanParsedName.isNotBlank() -> cleanParsedName
        else -> cleanParsedName
      }

      val rating = getDoubleSafe(obj, "rating", "rate", "stars", default = 5.0).coerceIn(1.0, 5.0)
      val reviewsCount = getIntSafe(obj, "reviewsCount", "reviews", "reviewCount", default = 0).coerceAtLeast(0)

      val rawCity = getStringSafe(obj, "city", "location", "governorate", "area", "address", default = "").trim()
      val resolvedCity = if (rawCity.isNotBlank() && !rawCity.equals("null", ignoreCase = true)) {
        rawCity
      } else {
        Nurse.resolveFallbackCity(id = id, name = cleanParsedName, phone = cleanPhone)
      }
      val rawCountry = getStringSafe(obj, "country", default = "").trim()
      val resolvedCountry = CountryRepository.normalizeCountryName(
        countryRaw = rawCountry,
        phone = cleanPhone,
        city = resolvedCity
      )

      Nurse(
        id = id,
        uid = uid,
        name = cleanParsedName,
        fullName = cleanParsedFullName,
        email = "",
        phone = cleanPhone,
        mobile = cleanMobile,
        whatsapp = cleanPhone,
        city = resolvedCity,
        country = resolvedCountry,
        specialization = "رعاية تمريضية شاملة",
        title = "ممرض منزلي مرخص",
        experienceYears = 0,
        gender = "",
        isAvailable = true,
        rating = rating,
        reviewsCount = reviewsCount,
        bio = "",
        profileImageUri = "",
        certificateImageUri = "",
        idImageBase64 = "",
        licenseImageBase64 = "",
        isVerified = false,
        status = "APPROVED",
        createdAt = getLongSafe(obj, "createdAt", "timestamp", "registeredAt", "date", default = 0L)
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error parsing nurse object (key=$key): ${e.message}")
      null
    }
  }

  /**
   * Parses a single request safely from JSONObject with defensive fallbacks
   */
  private fun parseRequest(key: String, obj: JSONObject): NursingRequest? {
    return try {
      val id = getStringSafe(obj, "id", "requestId", default = key).ifBlank { key }
      val rawPatientName = getStringSafe(obj, "patientName", "clientName", "patient_name", "requesterName", default = "").trim()
      val isPlaceholderName = rawPatientName.isBlank() ||
          rawPatientName == "مريض" ||
          rawPatientName == "patient" ||
          rawPatientName.startsWith("طلب خدمة تمريضية") ||
          rawPatientName == "طلب خدمة تمريضية" ||
          rawPatientName in listOf(".....", "...", "null", "none", "test")
      
      if (isPlaceholderName) {
        // Discard incomplete requests lacking real patient name
        return null
      }
      val patientName = rawPatientName

      val rawCity = getStringSafe(obj, "city", "location", default = "").trim()
      val city = if (rawCity.isNotBlank() && !rawCity.equals("null", ignoreCase = true)) {
        rawCity
      } else {
        Nurse.resolveFallbackCity(id = id, name = patientName)
      }
      val rawPhone = getStringSafe(
        obj,
        "patientPhone", "whatsappNumber", "phone", "mobile", "patient_phone", "senderPhone",
        "requesterPhone", "contactPhone", "clientPhone", "userPhone", "phoneNumber", "telephone",
        default = ""
      ).trim()
      val rawDigits = rawPhone.filter { it.isDigit() }
      if (rawDigits.length < 6 || rawDigits.contains("932189336")) {
        // Discard incomplete requests lacking valid contact phone number
        return null
      }
      val patientPhone = rawPhone

      val rawCountry = getStringSafe(obj, "country", default = "")
      val country = CountryRepository.normalizeCountryName(rawCountry, patientPhone, city)
      val rawWhatsapp = getStringSafe(
        obj,
        "whatsappNumber", "whatsapp", "whatsapp_number", "wa_number", "waNumber",
        default = patientPhone
      ).trim()
      val waDigits = rawWhatsapp.filter { it.isDigit() }
      val whatsappNumber = if (waDigits.length >= 6 && !waDigits.contains("932189336")) rawWhatsapp else patientPhone
      val address = getStringSafe(obj, "address", default = "$city، $country")
      val serviceName = getStringSafe(obj, "serviceName", "service", "serviceTitle", default = "رعاية تمريضية منزلية")
      val selectedNurseName = getStringSafe(obj, "selectedNurseName", "nurseName", default = "")
      val selectedNursePhone = getStringSafe(obj, "selectedNursePhone", "nursePhone", default = "")
      val preferredTime = getStringSafe(obj, "preferredTime", "time", "date", default = "في أقرب وقت")
      val notes = getStringSafe(obj, "notes", "note", "details", default = "")
      val rawStatus = getStringSafe(obj, "status", "state", default = "").trim()
      val isExplicitlyCompleted = getBooleanSafe(obj, "isCompleted", "completed", default = false)
      val isCompleted = isExplicitlyCompleted ||
          rawStatus.contains("منجز") ||
          rawStatus.equals("completed", ignoreCase = true) ||
          rawStatus.equals("approved", ignoreCase = true) ||
          rawStatus.equals("done", ignoreCase = true)

      val normalizedStatus = when {
        isCompleted -> "منجز"
        rawStatus.contains("انتظار") || rawStatus.equals("pending", ignoreCase = true) || rawStatus.isBlank() -> "قيد الانتظار"
        else -> rawStatus
      }
      val creatorId = getStringSafe(obj, "creatorId", "userId", "uid", default = "")
      val timestamp = getLongSafe(obj, "timestamp", "createdAt", "date", default = System.currentTimeMillis())

      NursingRequest(
        id = id,
        patientName = patientName,
        country = country,
        city = city,
        patientPhone = patientPhone.ifBlank { whatsappNumber },
        whatsappNumber = whatsappNumber.ifBlank { patientPhone },
        address = address,
        serviceName = serviceName,
        selectedNurseName = selectedNurseName,
        selectedNursePhone = selectedNursePhone,
        preferredTime = preferredTime,
        notes = notes,
        status = normalizedStatus,
        isCompleted = isCompleted,
        creatorId = creatorId,
        timestamp = timestamp
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error parsing request (key=$key): ${e.message}")
      null
    }
  }

  private fun isValidNurseProfile(nurse: Nurse): Boolean {
    val name = nurse.displayName.trim()
    return name.isNotBlank() && !name.equals("null", ignoreCase = true)
  }

  private fun getStringSafe(obj: JSONObject, vararg keys: String, default: String = ""): String {
    for (k in keys) {
      if (!obj.has(k)) continue
      val v = obj.opt(k) ?: continue
      if (v == JSONObject.NULL) continue
      val s = when (v) {
        is String -> v.trim()
        is Number -> v.toString()
        is Boolean -> v.toString()
        else -> v.toString().trim()
      }
      if (s.isNotEmpty() && !s.equals("null", ignoreCase = true)) {
        return s
      }
    }
    return default
  }

  private fun getIntSafe(obj: JSONObject, vararg keys: String, default: Int = 0): Int {
    for (k in keys) {
      if (!obj.has(k)) continue
      val v = obj.opt(k) ?: continue
      if (v == JSONObject.NULL) continue
      when (v) {
        is Number -> return v.toInt()
        is String -> {
          val digits = v.filter { it.isDigit() }
          val parsed = digits.toIntOrNull()
          if (parsed != null) return parsed
        }
        is Boolean -> return if (v) 1 else 0
      }
    }
    return default
  }

  private fun getDoubleSafe(obj: JSONObject, vararg keys: String, default: Double = 0.0): Double {
    for (k in keys) {
      if (!obj.has(k)) continue
      val v = obj.opt(k) ?: continue
      if (v == JSONObject.NULL) continue
      when (v) {
        is Number -> return v.toDouble()
        is String -> {
          val parsed = v.trim().toDoubleOrNull()
          if (parsed != null) return parsed
        }
      }
    }
    return default
  }

  private fun getLongSafe(obj: JSONObject, vararg keys: String, default: Long = 0L): Long {
    for (k in keys) {
      if (!obj.has(k)) continue
      val v = obj.opt(k) ?: continue
      if (v == JSONObject.NULL) continue
      when (v) {
        is Number -> return v.toLong()
        is String -> {
          val digits = v.filter { it.isDigit() }
          val parsed = digits.toLongOrNull()
          if (parsed != null) return parsed
        }
      }
    }
    return default
  }

  private fun getBooleanSafe(obj: JSONObject, vararg keys: String, default: Boolean = true): Boolean {
    for (k in keys) {
      if (!obj.has(k)) continue
      val v = obj.opt(k) ?: continue
      if (v == JSONObject.NULL) continue
      when (v) {
        is Boolean -> return v
        is Number -> return v.toInt() != 0
        is String -> {
          val s = v.trim().lowercase()
          if (s == "true" || s == "1" || s == "yes" || s == "available") return true
          if (s == "false" || s == "0" || s == "no" || s == "unavailable") return false
        }
      }
    }
    return default
  }

  private fun getDeduplicationKey(nurse: Nurse): String {
    val cleanPhone = nurse.displayPhone.replace(Regex("[^0-9]"), "")
    if (cleanPhone.length >= 7) return cleanPhone
    val cleanName = nurse.displayName.trim().lowercase()
    if (cleanName.isNotBlank() && cleanName != "null") return "${cleanName}_${nurse.city}"
    return nurse.id.ifBlank { "nurse_${System.nanoTime()}" }
  }

  fun getFallbackNurses(): List<Nurse> = listOf(
    Nurse(
      id = "nurse_clinical_care_1",
      uid = "uid_clinical_care_1",
      name = "كادر التمريض المناوب",
      fullName = "كادر التمريض المناوب",
      email = "",
      phone = "+963 933 112 233",
      city = "دمشق",
      country = "سوريا",
      specialization = "عناية مركزة وطوارئ وتمريض منزلي شامل",
      title = "أخصائي تمريض سريري",
      experienceYears = 8,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 42,
      bio = "مرخص من وزارة الصحة وهيئة التخصصات، خبرة واسعة في الحقن الوريدي، تركيب القثاطر، والغيار المعقم.",
      isCurrentUser = false
    ),
    Nurse(
      id = "nurse_saudi_1",
      name = "فهد العتيبي",
      fullName = "فهد العتيبي",
      phone = "+966 50 123 4567",
      city = "الرياض",
      country = "المملكة العربية السعودية",
      specialization = "رعاية تمريضية منزلية، تركيب قثاطر ومتابعة حالات حرجة",
      title = "أخصائي تمريض معتمد",
      experienceYears = 9,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 38
    ),
    Nurse(
      id = "nurse_uae_1",
      name = "مريم المنصوري",
      fullName = "مريم المنصوري",
      phone = "+971 50 987 6543",
      city = "دبي",
      country = "الإمارات العربية المتحدة",
      specialization = "عناية بالقدم السكرية، تغذية أنبوبية وحقن وريدي",
      title = "ممرضة سريرية مرخصة",
      experienceYears = 7,
      gender = "أنثى",
      rating = 4.9,
      reviewsCount = 31
    ),
    Nurse(
      id = "nurse_egypt_1",
      name = "محمود حسن",
      fullName = "محمود حسن",
      phone = "+20 100 456 7890",
      city = "القاهرة",
      country = "مصر",
      specialization = "رعاية مسنين، فتح أوردة، وتضميد قرح الفراش",
      title = "أخصائي تمريض منزلي",
      experienceYears = 11,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 45
    ),
    Nurse(
      id = "nurse_jordan_1",
      name = "رانيا المجالي",
      fullName = "رانيا المجالي",
      phone = "+962 79 123 4567",
      city = "عمان",
      country = "الأردن",
      specialization = "سحب عينات دم مخبرية، تخطيط قلب، وعناية تلطيفية",
      title = "ممرضة طوارئ وإسعاف",
      experienceYears = 6,
      gender = "أنثى",
      rating = 4.9,
      reviewsCount = 24
    ),
    Nurse(
      id = "nurse_germany_1",
      name = "سامر الخليل",
      fullName = "سامر الخليل",
      phone = "+49 151 2345678",
      city = "برلين",
      country = "ألمانيا",
      specialization = "رعاية تمريضية متقدمة، تركيب كانيولا وإعطاء مضادات حيوية",
      title = "أخصائي رعاية صحية",
      experienceYears = 10,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 29
    ),
    Nurse(
      id = "nurse_1",
      name = "عمار جمعة",
      fullName = "عمار جمعة",
      phone = "+963 933 499 247",
      city = "حمص",
      country = "سوريا",
      specialization = "فني طوارئ وقثطرة قلبية ورعاية حرجة",
      title = "ممرض فني طوارئ",
      experienceYears = 8,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 19
    ),
    Nurse(
      id = "nurse_2",
      name = "ابتسام ابوبكر",
      fullName = "ابتسام ابوبكر",
      phone = "+963 938 222 491",
      city = "حلب",
      country = "سوريا",
      specialization = "سحب دم، حقن إبر عضلية ووريدية، تركيب قثاطر وتخطيط قلب",
      title = "ممرضة متخصصة",
      experienceYears = 5,
      gender = "أنثى",
      rating = 4.9,
      reviewsCount = 28
    ),
    Nurse(
      id = "nurse_3",
      name = "أحمد اسماعيل",
      fullName = "أحمد اسماعيل",
      phone = "+963 954 142 419",
      city = "دمشق وريفها",
      country = "سوريا",
      specialization = "مدرب تمريض عام وإسعافات ومعالج فيزيائي",
      title = "أخصائي تمريض وطوارئ",
      experienceYears = 15,
      gender = "ذكر",
      rating = 5.0,
      reviewsCount = 35
    ),
    Nurse(
      id = "nurse_4",
      name = "شكري الحسن",
      fullName = "شكري الحسن",
      phone = "+963 998 714 942",
      city = "حمص",
      country = "سوريا",
      specialization = "سحب دم، إعطاء أدوية وريدية، فتح أوردة صعبة، غيار ضمادات",
      title = "ممرض مسعف",
      experienceYears = 5,
      gender = "ذكر",
      rating = 4.8,
      reviewsCount = 14
    ),
    Nurse(
      id = "nurse_5",
      name = "عتاب احمد الخاطر",
      fullName = "عتاب احمد الخاطر",
      phone = "+963 980 877 792",
      city = "القامشلي",
      country = "سوريا",
      specialization = "خدمات تمريضية عامة ورعاية كبار السن",
      title = "ممرضة مرخصة",
      experienceYears = 9,
      gender = "أنثى",
      rating = 5.0,
      reviewsCount = 12
    )
  )

  fun getFallbackRequests(): List<NursingRequest> = listOf(
    NursingRequest(
      id = "req_1",
      patientName = "أبو عمر الشامي",
      patientPhone = "+963 933 555 123",
      address = "دمشق - المزة",
      serviceName = "إعطاء أدوية وريدية",
      selectedNurseName = "ممرضي دمشق المناوبين",
      preferredTime = "اليوم - الساعة 4:00 عصراً",
      notes = "مطلوب تركيب كانيولا وإعطاء محلول ملحي ومضاد حيوي",
      status = "قيد الانتظار",
      timestamp = System.currentTimeMillis() - 1000 * 60 * 15
    ),
    NursingRequest(
      id = "req_2",
      patientName = "أم محمد الحلبي",
      patientPhone = "+963 938 111 222",
      address = "حلب - الفرقان",
      serviceName = "سحب دم لإجراء تحليل",
      selectedNurseName = "ابتسام ابوبكر",
      preferredTime = "صباحاً (صيام)",
      notes = "سحب عينات دم لتحليل شامل CBC وفحص وظائف كلى",
      status = "قيد الانتظار",
      timestamp = System.currentTimeMillis() - 1000 * 60 * 45
    ),
    NursingRequest(
      id = "req_3",
      patientName = "فاطمة الزهراء",
      patientPhone = "+963 998 777 888",
      address = "حمص - الإنشاءات",
      serviceName = "تركيب قثطرة بولية",
      selectedNurseName = "عمار جمعة",
      preferredTime = "في أقرب وقت عاجل",
      notes = "مريض مسن بحاجة لتبديل القثطرة البولية بالمنزل",
      status = "قيد المعالجة",
      timestamp = System.currentTimeMillis() - 1000 * 60 * 120
    )
  )

  /**
   * Fetches app version requirements and configuration from Firebase RTDB node `app_config`.
   * Used for the robust Forced Update mechanism to ensure clients are running an authorized version.
   */
  suspend fun fetchAppConfig(): AppConfig = withContext(Dispatchers.IO) {
    try {
      val jsonStr = executeGet("$BASE_URL/app_config.json")
      if (jsonStr.isNullOrBlank() || jsonStr.trim() == "null") {
        Log.d(TAG, "app_config node is empty or null, using defaults")
        return@withContext AppConfig()
      }

      val json = JSONObject(jsonStr)

      val minVersionCode = when {
        json.has("min_version_code") -> json.optLong("min_version_code", 1L)
        json.has("minVersionCode") -> json.optLong("minVersionCode", 1L)
        else -> 1L
      }

      val minVersionName = when {
        json.has("min_version_name") -> getStringSafe(json, "min_version_name", default = "1.0")
        json.has("minVersionName") -> getStringSafe(json, "minVersionName", default = "1.0")
        else -> "1.0"
      }

      val latestVersionCode = when {
        json.has("latest_version_code") -> json.optLong("latest_version_code", minVersionCode)
        json.has("latestVersionCode") -> json.optLong("latestVersionCode", minVersionCode)
        else -> minVersionCode
      }

      val latestVersionName = when {
        json.has("latest_version_name") -> getStringSafe(json, "latest_version_name", default = minVersionName)
        json.has("latestVersionName") -> getStringSafe(json, "latestVersionName", default = minVersionName)
        else -> minVersionName
      }

      val isForceUpdateRequired = when {
        json.has("force_update") -> getBooleanSafe(json, "force_update", default = false)
        json.has("is_force_update") -> getBooleanSafe(json, "is_force_update", default = false)
        json.has("isForceUpdateRequired") -> getBooleanSafe(json, "isForceUpdateRequired", default = false)
        else -> false
      }

      val updateUrl = when {
        json.has("update_url") && json.optString("update_url").isNotBlank() ->
          getStringSafe(json, "update_url", default = "https://t.me/GoNurse")
        json.has("updateUrl") && json.optString("updateUrl").isNotBlank() ->
          getStringSafe(json, "updateUrl", default = "https://t.me/GoNurse")
        else -> "https://t.me/GoNurse"
      }

      val titleAr = when {
        json.has("title_ar") -> getStringSafe(json, "title_ar", default = "تحديث إلزامي للتطبيق")
        json.has("titleAr") -> getStringSafe(json, "titleAr", default = "تحديث إلزامي للتطبيق")
        else -> "تحديث إلزامي للتطبيق"
      }

      val titleEn = when {
        json.has("title_en") -> getStringSafe(json, "title_en", default = "Mandatory App Update")
        json.has("titleEn") -> getStringSafe(json, "titleEn", default = "Mandatory App Update")
        else -> "Mandatory App Update"
      }

      val msgAr = when {
        json.has("message_ar") -> getStringSafe(json, "message_ar", default = "يتوفر إصدار جديد هام جداً من تطبيق GoNurse يحتوي على تحسينات أمنية وتحديثات هامة للخدمات التمريضية. يرجى التحديث للمتابعة.")
        json.has("messageAr") -> getStringSafe(json, "messageAr", default = "يتوفر إصدار جديد هام جداً من تطبيق GoNurse يحتوي على تحسينات أمنية وتحديثات هامة للخدمات التمريضية. يرجى التحديث للمتابعة.")
        else -> "يتوفر إصدار جديد هام جداً من تطبيق GoNurse يحتوي على تحسينات أمنية وتحديثات هامة للخدمات التمريضية. يرجى التحديث للمتابعة."
      }

      val msgEn = when {
        json.has("message_en") -> getStringSafe(json, "message_en", default = "A critical update is available for GoNurse with important security and medical service enhancements. Please update to continue using the application.")
        json.has("messageEn") -> getStringSafe(json, "messageEn", default = "A critical update is available for GoNurse with important security and medical service enhancements. Please update to continue using the application.")
        else -> "A critical update is available for GoNurse with important security and medical service enhancements. Please update to continue using the application."
      }

      AppConfig(
        minVersionCode = minVersionCode,
        minVersionName = minVersionName,
        latestVersionCode = latestVersionCode,
        latestVersionName = latestVersionName,
        isForceUpdateRequired = isForceUpdateRequired,
        updateUrl = updateUrl,
        updateTitleAr = titleAr,
        updateTitleEn = titleEn,
        updateMessageAr = msgAr,
        updateMessageEn = msgEn
      )
    } catch (e: Exception) {
      Log.e(TAG, "Error fetching app_config: ${e.message}", e)
      AppConfig()
    }
  }

  data class NurseMigrationResult(
    val nursesCount: Int,
    val usersCount: Int,
    val requestsCount: Int = 0,
    val totalBulkyBytesFreed: Long,
    val success: Boolean,
    val errorMessage: String? = null
  )

  /**
   * One-time database optimization and migration:
   * Strips all heavy/bulky fields (licenseImageBase64, bio, status, experienceYears, lat, lng, map markers, etc.)
   * from BOTH /nurses, /users, and /requests nodes in Firebase Realtime Database.
   *
   * Retains ONLY:
   * - Nurses: "id", "name", "fullName", "phone", "mobile", "city"
   * - Requests: "id", "patientName", "patientPhone", "whatsappNumber", "serviceName", "city", "address", "country",
   *             "selectedNurseName", "selectedNursePhone", "preferredTime", "notes", "status", "isCompleted", "timestamp"
   *
   * Guarantees 100% ZERO data loss for personal names, cities, and phone numbers.
   */
  suspend fun optimizeAndPruneNurseRecords(
    context: Context? = appContext,
    force: Boolean = false
  ): NurseMigrationResult = withContext(Dispatchers.IO) {
    val prefs = context?.getSharedPreferences("gonurse_prefs", Context.MODE_PRIVATE)
    val migrationKey = "purge_map_and_bloat_v3"
    if (!force && prefs != null && prefs.getBoolean(migrationKey, false)) {
      Log.i(TAG, "Nurse records optimization already completed previously. Skipping.")
      return@withContext NurseMigrationResult(0, 0, 0, 0L, true)
    }

    Log.i(TAG, "Starting nurse records pruning migration for /nurses, /users, and /requests nodes (purging map/geo bloat)...")
    try {
      // 1. Fetch raw nodes concurrently
      val nursesDeferred = async { executeGet("$BASE_URL/nurses.json") }
      val usersDeferred = async { executeGet("$BASE_URL/users.json") }
      val requestsDeferred = async { executeGet("$BASE_URL/requests.json") }

      val rawNursesJson = nursesDeferred.await()
      val rawUsersJson = usersDeferred.await()
      val rawRequestsJson = requestsDeferred.await()

      if (rawNursesJson.isNullOrBlank() && rawUsersJson.isNullOrBlank()) {
        Log.w(TAG, "Migration aborted: both /nurses and /users returned empty data")
        return@withContext NurseMigrationResult(0, 0, 0, 0L, false, "Empty responses from server")
      }

      val initialBytes = (rawNursesJson?.length ?: 0) + (rawUsersJson?.length ?: 0)

      val nursesObjects = extractJsonObjects(rawNursesJson)
      val usersObjects = extractJsonObjects(rawUsersJson)

      val nursesMap = nursesObjects.toMap()
      val usersMap = usersObjects.toMap()

      // Helper to extract clean data with zero loss
      fun buildCleanNurseObject(
        key: String,
        primary: JSONObject,
        secondary: JSONObject?
      ): JSONObject {
        val nurseId = getStringSafe(primary, "id", "uid", default = getStringSafe(secondary ?: JSONObject(), "id", "uid", default = key)).ifBlank { key }
        
        val rawName = getStringSafe(primary, "name", "nurseName", default = getStringSafe(secondary ?: JSONObject(), "name", "nurseName", default = ""))
        val rawFullName = getStringSafe(primary, "fullName", "full_name", default = getStringSafe(secondary ?: JSONObject(), "fullName", "full_name", default = ""))
        val rawDisplay = getStringSafe(primary, "displayName", default = getStringSafe(secondary ?: JSONObject(), "displayName", default = ""))

        val rawPhone = getStringSafe(primary, "phone", "mobile", "whatsapp", "whatsappNumber", "phoneNumber", "tel", "contact",
          default = getStringSafe(secondary ?: JSONObject(), "phone", "mobile", "whatsapp", "whatsappNumber", "phoneNumber", "tel", "contact", default = "")
        )

        val cleanPhone = PhoneFormatter.sanitizePhoneInput(rawPhone)

        val resolvedName = Nurse.resolveRealName(
          name = rawName,
          fullName = rawFullName,
          displayName = rawDisplay,
          id = nurseId,
          phone = cleanPhone,
          fallback = ""
        )

        val name = when {
          Nurse.isRealPersonName(rawName, nurseId, phone = cleanPhone) -> rawName.trim()
          Nurse.isRealPersonName(rawFullName, nurseId, phone = cleanPhone) -> rawFullName.trim()
          resolvedName.isNotBlank() -> resolvedName
          rawName.isNotBlank() -> rawName.trim()
          rawFullName.isNotBlank() -> rawFullName.trim()
          rawDisplay.isNotBlank() -> rawDisplay.trim()
          else -> "ممرض مرخص"
        }

        val fullName = when {
          Nurse.isRealPersonName(rawFullName, nurseId, phone = cleanPhone) -> rawFullName.trim()
          name.isNotBlank() -> name
          else -> "ممرض مرخص"
        }

        val rawCity = getStringSafe(primary, "city", "location", "governorate", "area", "address",
          default = getStringSafe(secondary ?: JSONObject(), "city", "location", "governorate", "area", "address", default = "")
        ).trim()

        val cleanCity = if (rawCity.isNotBlank() && !rawCity.equals("null", ignoreCase = true)) {
          rawCity
        } else {
          Nurse.resolveFallbackCity(id = nurseId, name = name, phone = cleanPhone)
        }

        val status = getStringSafe(primary, "status", "verificationStatus",
          default = getStringSafe(secondary ?: JSONObject(), "status", "verificationStatus", default = "APPROVED")
        ).ifBlank { "APPROVED" }

        return JSONObject().apply {
          put("id", nurseId)
          put("name", name)
          put("fullName", fullName)
          put("phone", cleanPhone)
          put("mobile", cleanPhone)
          put("city", cleanCity)
          put("status", status)
        }
      }

      // 2. Build pruned /nurses records
      val cleanNursesRoot = JSONObject()
      var nursesCount = 0
      for ((key, obj) in nursesObjects) {
        val altObj = usersMap[key]
        val cleanObj = buildCleanNurseObject(key, obj, altObj)
        cleanNursesRoot.put(key, cleanObj)
        nursesCount++
      }

      // 3. Atomically replace /nurses with lightweight payload (PUT replaces all bulky fields)
      val nursesPutBody = cleanNursesRoot.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
      val nursesPutReq = Request.Builder().url("$BASE_URL/nurses.json").put(nursesPutBody).build()
      val nursesPutRes = client.newCall(nursesPutReq).execute()
      val nursesSuccess = nursesPutRes.isSuccessful
      nursesPutRes.close()
      Log.i(TAG, "Migrated $nursesCount nurse records in /nurses. Code: ${nursesPutRes.code}")

      // 4. Build pruned /users records for all nurse accounts in /users
      var usersCount = 0
      for ((key, obj) in usersObjects) {
        val isNurse = key.startsWith("nurse_") ||
            obj.optString("role") == "nurse" ||
            obj.optString("userType") == "nurse" ||
            obj.has("specialization") ||
            obj.has("bio") ||
            obj.has("experienceYears") ||
            obj.has("certificateImageUri") ||
            nursesMap.containsKey(key)

        if (isNurse) {
          val altObj = nursesMap[key]
          val cleanObj = buildCleanNurseObject(key, obj, altObj)
          val body = cleanObj.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
          val req = Request.Builder().url("$BASE_URL/users/$key.json").put(body).build()
          try {
            val res = client.newCall(req).execute()
            if (res.isSuccessful) {
              usersCount++
            }
            res.close()
          } catch (e: Exception) {
            Log.w(TAG, "Error pruning user record $key: ${e.message}")
          }
        }
      }
      Log.i(TAG, "Migrated $usersCount nurse records in /users.")

      // 5. Build pruned /requests records (purging geo coords & bloat while retaining patient identity & city)
      val requestsObjects = extractJsonObjects(rawRequestsJson)
      val cleanRequestsRoot = JSONObject()
      var requestsCount = 0
      for ((key, obj) in requestsObjects) {
        val reqId = getStringSafe(obj, "id", default = key).ifBlank { key }
        val rawPatientName = getStringSafe(obj, "patientName", "clientName", default = "").trim()
        val patientName = when {
          rawPatientName.isBlank() -> "مريض"
          rawPatientName.startsWith("طلب خدمة تمريضية") || rawPatientName == "طلب خدمة تمريضية" -> "مريض"
          else -> rawPatientName
        }
        val rawAddress = getStringSafe(obj, "address", default = "").trim()
        val rawPhone = PhoneFormatter.sanitizePhoneInput(
          getStringSafe(obj, "patientPhone", "whatsappNumber", "phone", "mobile", default = "")
        )
        val rawWhatsapp = PhoneFormatter.sanitizePhoneInput(
          getStringSafe(obj, "whatsappNumber", "patientPhone", "phone", default = rawPhone)
        )
        val rawCity = getStringSafe(obj, "city", "location", default = "").trim()
        val city = when {
          rawCity.isNotBlank() && !rawCity.equals("null", ignoreCase = true) -> rawCity
          rawAddress.contains("حلب") -> "حلب"
          rawAddress.contains("حمص") -> "حمص"
          rawAddress.contains("اللاذقية") -> "اللاذقية"
          rawAddress.contains("طرطوس") -> "طرطوس"
          rawAddress.contains("حماة") -> "حماة"
          rawAddress.contains("القامشلي") -> "القامشلي"
          rawAddress.contains("دير الزور") -> "دير الزور"
          rawAddress.contains("ريف دمشق") -> "ريف دمشق"
          rawAddress.contains("دمشق") -> "دمشق"
          rawAddress.contains("درعا") -> "درعا"
          rawAddress.contains("السويداء") -> "السويداء"
          rawAddress.contains("إدلب") -> "إدلب"
          rawAddress.contains("الرقة") -> "الرقة"
          rawAddress.contains("الحسكة") -> "الحسكة"
          else -> Nurse.resolveFallbackCity(id = reqId, name = patientName, phone = rawPhone)
        }
        val rawCountry = getStringSafe(obj, "country", default = "").trim()
        val country = CountryRepository.normalizeCountryName(rawCountry, rawPhone, city)
        val serviceName = getStringSafe(obj, "serviceName", "service", "serviceTitle", default = "رعاية تمريضية منزلية")
        val selectedNurseName = getStringSafe(obj, "selectedNurseName", default = "")
        val selectedNursePhone = PhoneFormatter.sanitizePhoneInput(getStringSafe(obj, "selectedNursePhone", default = ""))
        val preferredTime = getStringSafe(obj, "preferredTime", default = "في أقرب وقت")
        val notes = getStringSafe(obj, "notes", default = "")
        val rawStatus = getStringSafe(obj, "status", default = "").trim()
        val isExplicitlyCompleted = getBooleanSafe(obj, "isCompleted", default = false)
        val isCompleted = isExplicitlyCompleted || rawStatus.contains("منجز") || rawStatus.equals("completed", ignoreCase = true)
        val status = if (isCompleted) "منجز" else if (rawStatus.isNotBlank()) rawStatus else "قيد الانتظار"
        val timestamp = getLongSafe(obj, "timestamp", default = System.currentTimeMillis())
        val creatorId = getStringSafe(obj, "creatorId", default = "")

        val cleanReq = JSONObject().apply {
          put("id", reqId)
          put("patientName", patientName)
          put("patientPhone", rawPhone)
          put("whatsappNumber", if (rawWhatsapp.isNotBlank()) rawWhatsapp else rawPhone)
          put("serviceName", serviceName)
          put("city", city)
          put("address", if (rawAddress.isNotBlank()) rawAddress else "$city، $country")
          put("country", country)
          put("selectedNurseName", selectedNurseName)
          put("selectedNursePhone", selectedNursePhone)
          put("preferredTime", preferredTime)
          put("notes", notes)
          put("status", status)
          put("isCompleted", isCompleted)
          put("timestamp", timestamp)
          if (creatorId.isNotBlank()) {
            put("creatorId", creatorId)
          }
          if (obj.has("estimatedPrice")) {
            put("estimatedPrice", obj.optDouble("estimatedPrice", 0.0))
          }
        }
        cleanRequestsRoot.put(key, cleanReq)
        requestsCount++
      }

      val reqsPutBody = cleanRequestsRoot.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
      val reqsPutReq = Request.Builder().url("$BASE_URL/requests.json").put(reqsPutBody).build()
      val reqsPutRes = client.newCall(reqsPutReq).execute()
      val reqsSuccess = reqsPutRes.isSuccessful
      reqsPutRes.close()
      Log.i(TAG, "Migrated $requestsCount request records in /requests. Code: ${reqsPutRes.code}")

      // 6. Delete obsolete map/geo endpoints from Firebase Realtime Database
      try {
        executeDelete("$BASE_URL/map.json")
        executeDelete("$BASE_URL/map_markers.json")
        executeDelete("$BASE_URL/markers.json")
        executeDelete("$BASE_URL/locations.json")
        executeDelete("$BASE_URL/geo.json")
      } catch (_: Exception) {}

      // 7. Invalidate caches so app immediately reloads lightweight data
      invalidateNursesCache()
      invalidateRequestsCache()
      if (context != null) {
        try {
          GoNurseAppDatabase.getDatabase(context).nurseDao().clearNurses()
          GoNurseAppDatabase.getDatabase(context).requestDao().clearRequests()
        } catch (_: Exception) {}
      }

      val freedBytes = initialBytes - cleanNursesRoot.toString().length
      if (nursesSuccess && reqsSuccess) {
        prefs?.edit()?.putBoolean(migrationKey, true)?.apply()
      }

      Log.i(TAG, "Pruning migration completed. Nurses: $nursesCount, Users: $usersCount, Requests: $requestsCount, Freed: ~$freedBytes bytes")
      NurseMigrationResult(nursesCount, usersCount, requestsCount, freedBytes.toLong().coerceAtLeast(0L), nursesSuccess && reqsSuccess)
    } catch (e: Exception) {
      Log.e(TAG, "Error executing nurse records pruning migration: ${e.message}", e)
      NurseMigrationResult(0, 0, 0, 0L, false, e.message)
    }
  }
}

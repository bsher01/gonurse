package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.example.model.Nurse
import com.example.model.NursingRequest
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cached_nurses")
data class CachedNurseEntity(
  @PrimaryKey val id: String,
  val uid: String = "",
  val name: String,
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val mobile: String = "",
  val whatsapp: String = "",
  val city: String = "",
  val country: String = "سوريا",
  val specialization: String = "",
  val title: String = "",
  val experienceYears: Int = 0,
  val gender: String = "",
  val isAvailable: Boolean = true,
  val rating: Double = 5.0,
  val reviewsCount: Int = 0,
  val bio: String = "",
  val profileImageUri: String = "",
  val certificateImageUri: String = "",
  val idImageBase64: String = "",
  val licenseImageBase64: String = "",
  val isVerified: Boolean = false,
  val isCurrentUser: Boolean = false,
  val createdAt: Long = 0L,
  val cachedAt: Long = System.currentTimeMillis()
) {
  fun toNurse(): Nurse = Nurse(
    id = id,
    uid = uid,
    name = name,
    fullName = fullName,
    email = email,
    phone = phone,
    mobile = mobile,
    whatsapp = whatsapp,
    city = city,
    country = country,
    specialization = specialization,
    title = title,
    experienceYears = experienceYears,
    gender = gender,
    isAvailable = isAvailable,
    rating = rating,
    reviewsCount = reviewsCount,
    bio = bio,
    profileImageUri = profileImageUri,
    certificateImageUri = certificateImageUri,
    idImageBase64 = idImageBase64,
    licenseImageBase64 = licenseImageBase64,
    isVerified = isVerified,
    isCurrentUser = isCurrentUser,
    createdAt = createdAt
  )

  companion object {
    fun fromNurse(nurse: Nurse): CachedNurseEntity = CachedNurseEntity(
      id = nurse.id,
      uid = nurse.uid,
      name = nurse.name,
      fullName = nurse.fullName,
      email = nurse.email,
      phone = nurse.phone,
      mobile = nurse.mobile,
      whatsapp = nurse.whatsapp,
      city = nurse.city,
      country = nurse.country,
      specialization = nurse.specialization,
      title = nurse.title,
      experienceYears = nurse.experienceYears,
      gender = nurse.gender,
      isAvailable = nurse.isAvailable,
      rating = nurse.rating,
      reviewsCount = nurse.reviewsCount,
      bio = nurse.bio,
      profileImageUri = nurse.profileImageUri,
      certificateImageUri = nurse.certificateImageUri,
      idImageBase64 = nurse.idImageBase64,
      licenseImageBase64 = nurse.licenseImageBase64,
      isVerified = nurse.isVerified,
      isCurrentUser = nurse.isCurrentUser,
      createdAt = nurse.createdAt,
      cachedAt = System.currentTimeMillis()
    )
  }
}

@Entity(tableName = "cached_requests")
data class CachedRequestEntity(
  @PrimaryKey val id: String,
  val patientName: String,
  val country: String = "سوريا",
  val city: String = "دمشق",
  val patientPhone: String = "",
  val whatsappNumber: String = "",
  val address: String = "",
  val serviceName: String = "رعاية تمريضية منزلية",
  val selectedNurseName: String = "",
  val selectedNursePhone: String = "",
  val preferredTime: String = "في أقرب وقت",
  val notes: String = "",
  val status: String = "قيد الانتظار",
  val isCompleted: Boolean = false,
  val creatorId: String = "",
  val timestamp: Long = System.currentTimeMillis(),
  val cachedAt: Long = System.currentTimeMillis()
) {
  fun toNursingRequest(): NursingRequest = NursingRequest(
    id = id,
    patientName = patientName,
    country = country,
    city = city,
    patientPhone = patientPhone,
    whatsappNumber = whatsappNumber,
    address = address,
    serviceName = serviceName,
    selectedNurseName = selectedNurseName,
    selectedNursePhone = selectedNursePhone,
    preferredTime = preferredTime,
    notes = notes,
    status = status,
    isCompleted = isCompleted,
    creatorId = creatorId,
    timestamp = timestamp
  )

  companion object {
    fun fromRequest(req: NursingRequest): CachedRequestEntity = CachedRequestEntity(
      id = req.id,
      patientName = req.patientName,
      country = req.country,
      city = req.city,
      patientPhone = req.patientPhone,
      whatsappNumber = req.whatsappNumber,
      address = req.address,
      serviceName = req.serviceName,
      selectedNurseName = req.selectedNurseName,
      selectedNursePhone = req.selectedNursePhone,
      preferredTime = req.preferredTime,
      notes = req.notes,
      status = req.status,
      isCompleted = req.isCompleted,
      creatorId = req.creatorId,
      timestamp = req.timestamp,
      cachedAt = System.currentTimeMillis()
    )

    fun fromNursingRequest(req: NursingRequest): CachedRequestEntity = fromRequest(req)
  }
}

@Dao
interface NurseDao {
  @Query("SELECT * FROM cached_nurses ORDER BY isCurrentUser DESC, createdAt ASC")
  fun getAllNursesFlow(): Flow<List<CachedNurseEntity>>

  @Query("SELECT * FROM cached_nurses ORDER BY isCurrentUser DESC, createdAt ASC")
  suspend fun getAllNurses(): List<CachedNurseEntity>

  @Query("SELECT * FROM cached_nurses WHERE id = :id LIMIT 1")
  suspend fun getNurseById(id: String): CachedNurseEntity?

  @Query("SELECT COUNT(*) FROM cached_nurses")
  suspend fun getNurseCount(): Int

  @Query("SELECT MAX(cachedAt) FROM cached_nurses")
  suspend fun getLatestCachedTimestamp(): Long?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNurse(nurse: CachedNurseEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNurses(nurses: List<CachedNurseEntity>)

  @Query("DELETE FROM cached_nurses WHERE id = :id")
  suspend fun deleteNurseById(id: String)

  @Query("DELETE FROM cached_nurses")
  suspend fun clearNurses()
}

@Dao
interface RequestDao {
  @Query("SELECT * FROM cached_requests ORDER BY timestamp DESC")
  fun getAllRequestsFlow(): Flow<List<CachedRequestEntity>>

  @Query("SELECT * FROM cached_requests ORDER BY timestamp DESC")
  suspend fun getAllRequests(): List<CachedRequestEntity>

  @Query("SELECT * FROM cached_requests WHERE id = :id LIMIT 1")
  suspend fun getRequestById(id: String): CachedRequestEntity?

  @Query("SELECT COUNT(*) FROM cached_requests")
  suspend fun getRequestCount(): Int

  @Query("SELECT MAX(cachedAt) FROM cached_requests")
  suspend fun getLatestCachedTimestamp(): Long?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRequests(requests: List<CachedRequestEntity>)

  @Query("DELETE FROM cached_requests")
  suspend fun clearRequests()
}

@Database(
  entities = [CachedNurseEntity::class, CachedRequestEntity::class],
  version = 1,
  exportSchema = false
)
abstract class GoNurseAppDatabase : RoomDatabase() {
  abstract fun nurseDao(): NurseDao
  abstract fun requestDao(): RequestDao

  companion object {
    @Volatile
    private var INSTANCE: GoNurseAppDatabase? = null

    fun getDatabase(context: Context): GoNurseAppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          GoNurseAppDatabase::class.java,
          "gonurse_offline_cache.db"
        )
        .fallbackToDestructiveMigration()
        .build()
        INSTANCE = instance
        instance
      }
    }
  }
}

package com.example.model

data class NursingRequest(
  val id: String,
  val patientName: String,
  val country: String = "سوريا",
  val city: String = "دمشق",
  val patientPhone: String = "",
  val whatsappNumber: String = "",
  val address: String = "",
  val serviceName: String = "رعاية تمريضية منزلية",
  val selectedNurseName: String = "",
  val selectedNursePhone: String = "",
  val preferredTime: String = "في أقرب وقت",
  val notes: String = "",
  val status: String = "قيد الانتظار",
  val isCompleted: Boolean = false,
  val creatorId: String = "",
  val timestamp: Long = System.currentTimeMillis()
) {
  val displayLocation: String
    get() = when {
      city.isNotBlank() && country.isNotBlank() && city != country -> "$city، $country"
      city.isNotBlank() -> city
      address.isNotBlank() -> address
      else -> "دمشق، سوريا"
    }

  val displayPhone: String
    get() = when {
      whatsappNumber.isNotBlank() -> whatsappNumber
      patientPhone.isNotBlank() -> patientPhone
      else -> ""
    }

  val isOrderCompleted: Boolean
    get() = isCompleted || status.contains("منجز") || status.contains("مكتمل") || status.contains("completed", ignoreCase = true)
}

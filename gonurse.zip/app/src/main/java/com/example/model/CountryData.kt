package com.example.model

data class CountryInfo(
  val code: String,
  val dialCode: String,
  val nameAr: String,
  val nameEn: String,
  val flagEmoji: String
)

object CountryRepository {
  val countries: List<CountryInfo> = listOf(
    CountryInfo("SY", "+963", "سوريا", "Syria", "🇸🇾"),
    CountryInfo("SA", "+966", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦"),
    CountryInfo("AE", "+971", "الإمارات العربية المتحدة", "United Arab Emirates", "🇦🇪"),
    CountryInfo("EG", "+20", "مصر", "Egypt", "🇪🇬"),
    CountryInfo("JO", "+962", "الأردن", "Jordan", "🇯🇴"),
    CountryInfo("LB", "+961", "لبنان", "Lebanon", "🇱🇧"),
    CountryInfo("IQ", "+964", "العراق", "Iraq", "🇮🇶"),
    CountryInfo("KW", "+965", "الكويت", "Kuwait", "🇰🇼"),
    CountryInfo("QA", "+974", "قطر", "Qatar", "🇶🇦"),
    CountryInfo("BH", "+973", "البحرين", "Bahrain", "🇧🇭"),
    CountryInfo("OM", "+968", "عمان", "Oman", "🇴🇲"),
    CountryInfo("PS", "+970", "فلسطين", "Palestine", "🇵🇸"),
    CountryInfo("YE", "+967", "اليمن", "Yemen", "🇾🇪"),
    CountryInfo("TR", "+90", "تركيا", "Turkey", "🇹🇷"),
    CountryInfo("DZ", "+213", "الجزائر", "Algeria", "🇩🇿"),
    CountryInfo("MA", "+212", "المغرب", "Morocco", "🇲🇦"),
    CountryInfo("TN", "+216", "تونس", "Tunisia", "🇹🇳"),
    CountryInfo("LY", "+218", "ليبيا", "Libya", "🇱🇾"),
    CountryInfo("SD", "+249", "السودان", "Sudan", "🇸🇩"),
    CountryInfo("DE", "+49", "ألمانيا", "Germany", "🇩🇪"),
    CountryInfo("US", "+1", "الولايات المتحدة الأمريكية", "United States", "🇺🇸"),
    CountryInfo("CA", "+1", "كندا", "Canada", "🇨🇦"),
    CountryInfo("GB", "+44", "المملكة المتحدة", "United Kingdom", "🇬🇧"),
    CountryInfo("FR", "+33", "فرنسا", "France", "🇫🇷"),
    CountryInfo("SE", "+46", "السويد", "Sweden", "🇸🇪"),
    CountryInfo("NL", "+31", "هولندا", "Netherlands", "🇳🇱"),
    CountryInfo("BE", "+32", "بلجيكا", "Belgium", "🇧🇪"),
    CountryInfo("CH", "+41", "سويسرا", "Switzerland", "🇨🇭"),
    CountryInfo("AT", "+43", "النمسا", "Austria", "🇦🇹"),
    CountryInfo("IT", "+39", "إيطاليا", "Italy", "🇮🇹"),
    CountryInfo("ES", "+34", "إسبانيا", "Spain", "🇪🇸"),
    CountryInfo("AU", "+61", "أستراليا", "Australia", "🇦🇺"),
    CountryInfo("MY", "+60", "ماليزيا", "Malaysia", "🇲🇾"),
    CountryInfo("IN", "+91", "الهند", "India", "🇮🇳"),
    CountryInfo("PK", "+92", "باكستان", "Pakistan", "🇵🇰"),
    CountryInfo("ID", "+62", "إندونيسيا", "Indonesia", "🇮🇩"),
    CountryInfo("RU", "+7", "روسيا", "Russia", "🇷🇺"),
    CountryInfo("CN", "+86", "الصين", "China", "🇨🇳"),
    CountryInfo("JP", "+81", "اليابان", "Japan", "🇯🇵"),
    CountryInfo("KR", "+82", "كوريا الجنوبية", "South Korea", "🇰🇷"),
    CountryInfo("BR", "+55", "البرازيل", "Brazil", "🇧🇷"),
    CountryInfo("MX", "+52", "المكسيك", "Mexico", "🇲🇽"),
    CountryInfo("AR", "+54", "الأرجنتين", "Argentina", "🇦🇷"),
    CountryInfo("NG", "+234", "نيجيريا", "Nigeria", "🇳🇬"),
    CountryInfo("ZA", "+27", "جنوب إفريقيا", "South Africa", "🇿🇦"),
    CountryInfo("GR", "+30", "اليونان", "Greece", "🇬🇷"),
    CountryInfo("NO", "+47", "النرويج", "Norway", "🇳🇴"),
    CountryInfo("DK", "+45", "الدنمارك", "Denmark", "🇩🇰"),
    CountryInfo("FI", "+358", "فنلندا", "Finland", "🇫🇮"),
    CountryInfo("PL", "+48", "بولندا", "Poland", "🇵🇱"),
    CountryInfo("RO", "+40", "رومانيا", "Romania", "🇷🇴"),
    CountryInfo("CY", "+357", "قبرص", "Cyprus", "🇨🇾")
  )

  val defaultCountry = countries.first() // Syria

  /**
   * Robustly parses and normalizes a country string or infers it from phone/dial-code and city.
   * Ensures distinct and consistent naming (Arabic standard name) across all entries.
   */
  fun normalizeCountryName(countryRaw: String, phone: String = "", city: String = ""): String {
    val raw = countryRaw.trim()
    
    // 1. Direct match by raw text if provided
    if (raw.isNotBlank() && !raw.equals("null", ignoreCase = true)) {
      val lower = raw.lowercase()
      
      // Known aliases & normalized mappings
      when {
        lower in listOf("sy", "syr", "syria", "سوريا", "سورية", "الجمهورية العربية السورية") -> return "سوريا"
        lower in listOf("sa", "sau", "ksa", "saudi", "saudi arabia", "السعودية", "المملكة العربية السعودية") -> return "المملكة العربية السعودية"
        lower in listOf("ae", "uae", "are", "emirates", "united arab emirates", "الإمارات", "الإمارات العربية المتحدة", "دبي", "أبوظبي") -> return "الإمارات العربية المتحدة"
        lower in listOf("eg", "egy", "egypt", "مصر", "جمهورية مصر العربية") -> return "مصر"
        lower in listOf("jo", "jor", "jordan", "الأردن", "الاردن", "المملكة الأردنية الهاشمية") -> return "الأردن"
        lower in listOf("lb", "lbn", "lebanon", "لبنان", "الجمهورية اللبنانية") -> return "لبنان"
        lower in listOf("iq", "irq", "iraq", "العراق", "جمهورية العراق") -> return "العراق"
        lower in listOf("kw", "kwt", "kuwait", "الكويت", "دولة الكويت") -> return "الكويت"
        lower in listOf("qa", "qat", "qatar", "قطر", "دولة قطر") -> return "قطر"
        lower in listOf("bh", "bhr", "bahrain", "البحرين", "مملكة البحرين") -> return "البحرين"
        lower in listOf("om", "omn", "oman", "عمان", "عُمان", "سلطنة عمان") -> return "عمان"
        lower in listOf("tr", "tur", "turkey", "türkiye", "تركيا") -> return "تركيا"
        lower in listOf("de", "deu", "germany", "ألمانيا", "المانيا") -> return "ألمانيا"
        lower in listOf("us", "usa", "united states", "أمريكا", "الولايات المتحدة", "الولايات المتحدة الأمريكية") -> return "الولايات المتحدة الأمريكية"
        lower in listOf("ye", "yem", "yemen", "اليمن") -> return "اليمن"
        lower in listOf("ps", "pse", "palestine", "فلسطين") -> return "فلسطين"
        lower in listOf("dz", "dza", "algeria", "الجزائر") -> return "الجزائر"
        lower in listOf("ma", "mar", "morocco", "المغرب") -> return "المغرب"
        lower in listOf("tn", "tun", "tunisia", "تونس") -> return "تونس"
        lower in listOf("ly", "lby", "libya", "ليبيا") -> return "ليبيا"
        lower in listOf("sd", "sdn", "sudan", "السودان") -> return "السودان"
      }
      
      // Match against CountryRepository.countries
      val matched = countries.firstOrNull {
        it.code.equals(raw, ignoreCase = true) ||
        it.nameAr.equals(raw, ignoreCase = true) ||
        it.nameEn.equals(raw, ignoreCase = true) ||
        raw.contains(it.nameAr, ignoreCase = true) ||
        raw.contains(it.nameEn, ignoreCase = true) ||
        it.dialCode == raw
      }
      if (matched != null) return matched.nameAr
      
      // If it's a non-empty descriptive string, return it formatted
      if (raw.length in 2..40) return raw
    }

    // 2. Infer from Phone number dial code (longest match first)
    val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
    if (cleanPhone.isNotBlank()) {
      for (c in countries.sortedByDescending { it.dialCode.length }) {
        val dialWithoutPlus = c.dialCode.removePrefix("+")
        if (cleanPhone.startsWith(c.dialCode) || cleanPhone.startsWith("00$dialWithoutPlus") || cleanPhone.startsWith(dialWithoutPlus)) {
          return c.nameAr
        }
      }
    }

    // 3. Infer from City name
    val cleanCity = city.trim().lowercase()
    if (cleanCity.isNotBlank()) {
      when {
        cleanCity in listOf("دمشق", "حمص", "حلب", "اللاذقية", "طرطوس", "حماة", "القامشلي", "درعا", "السويداء", "دير الزور", "إدلب") -> return "سوريا"
        cleanCity in listOf("الرياض", "جدة", "مكة", "المدينة", "الدمام", "الخبر", "تبوك", "أبها", "الطائف", "بريدة", "جازان", "نجران", "الهفوف", "حائل") -> return "المملكة العربية السعودية"
        cleanCity in listOf("دبي", "أبوظبي", "الشارقة", "عجمان", "رأس الخيمة", "الفجيرة", "العين") -> return "الإمارات العربية المتحدة"
        cleanCity in listOf("القاهرة", "الإسكندرية", "الجيزة", "المنصورة", "طنطا", "أسيوط", "بورسعيد", "السويس", "الزقازيق") -> return "مصر"
        cleanCity in listOf("عمان", "إربد", "الزرقاء", "العقبة", "السلط", "مادبا") -> return "الأردن"
        cleanCity in listOf("بيروت", "طرابلس", "صيدا", "زحلة", "جونية", "صور") -> return "لبنان"
        cleanCity in listOf("بغداد", "البصرة", "أربيل", "الموصل", "النجف", "كربلاء", "السليمانية") -> return "العراق"
        cleanCity in listOf("الكويت", "حولي", "الأحمدي", "الفروانية", "الجهراء") -> return "الكويت"
        cleanCity in listOf("الدوحة", "الريان", "الوكرة", "الخور") -> return "قطر"
        cleanCity in listOf("المنامة", "المحرق", "الرفاع") -> return "البحرين"
        cleanCity in listOf("مسقط", "صلالة", "صحار", "نزوى") -> return "عمان"
        cleanCity in listOf("إسطنبول", "أنقرة", "إزمير", "بورصة", "أنطاليا", "غازي عنتاب", "مرسين") -> return "تركيا"
        cleanCity in listOf("برلين", "ميونخ", "فرانكفورت", "هامبورغ", "كولونيا", "شتوتغارت") -> return "ألمانيا"
      }
    }

    return if (raw.isNotBlank() && !raw.equals("null", ignoreCase = true)) raw else "سوريا"
  }
}

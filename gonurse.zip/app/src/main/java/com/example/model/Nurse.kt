package com.example.model

data class Nurse(
  val id: String,
  val uid: String = "",
  val name: String,
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val mobile: String = "",
  val whatsapp: String = "",
  val city: String = "",
  val country: String = "سوريا",
  val specialization: String = "",
  val title: String = "",
  val experienceYears: Int = 0,
  val gender: String = "",
  val isAvailable: Boolean = true,
  val rating: Double = 5.0,
  val reviewsCount: Int = 0,
  val bio: String = "",
  val profileImageUri: String = "",
  val certificateImageUri: String = "",
  val idImageBase64: String = "",
  val licenseImageBase64: String = "",
  val isVerified: Boolean = false,
  val isCurrentUser: Boolean = false,
  val status: String = "PENDING",
  val createdAt: Long = 0L
) {
  val displayName: String
    get() = resolveRealName(
      name = name,
      fullName = fullName,
      id = id,
      uid = uid,
      phone = displayPhone,
      fallback = if (specialization.isNotBlank() && !isPhoneOrId(specialization)) specialization else "ممرض مرخص"
    )

  val actualName: String
    get() = displayName

  /**
   * Strictly verifies whether the nurse has an authentic, independent professional license
   * or graduation certificate document attached that is distinct from a basic profile avatar.
   */
  val hasValidLicenseDocument: Boolean
    get() {
      val cleanLicense = licenseImageBase64.trim()
      val cleanCert = certificateImageUri.trim()
      val cleanProfile = profileImageUri.trim()

      val hasDistinctLicense = cleanLicense.isNotBlank() && cleanLicense != cleanProfile && cleanLicense.length > 50
      val hasDistinctCert = cleanCert.isNotBlank() && cleanCert != cleanProfile && cleanCert.length > 50
      return hasDistinctLicense || hasDistinctCert
    }

  /**
   * The verified badge is strictly active ONLY if the account is marked isVerified AND has a genuine license document.
   * Profile pictures alone never grant or activate verification.
   */
  val isVerifiedBadgeActive: Boolean
    get() = isVerified && hasValidLicenseDocument

  val displayPhone: String
    get() = when {
      phone.isNotBlank() -> phone
      mobile.isNotBlank() -> mobile
      whatsapp.isNotBlank() -> whatsapp
      else -> ""
    }

  val displaySpecialization: String
    get() = when {
      specialization.isNotBlank() -> specialization
      title.isNotBlank() -> title
      else -> "خدمات تمريضية ورعاية منزلية"
    }

  val displayCity: String
    get() = if (city.isNotBlank()) city else "دمشق"

  val displayCountry: String
    get() = CountryRepository.normalizeCountryName(country, displayPhone, city)

  companion object {
    /**
     * Checks if a string looks like a phone number, user/nurse ID, or invalid name placeholder.
     */
    fun isPhoneOrId(str: String?, id: String = "", uid: String = "", phone: String = ""): Boolean {
      if (str.isNullOrBlank()) return true
      val trimmed = str.trim()
      if (trimmed.equals("null", ignoreCase = true) ||
          trimmed.equals("none", ignoreCase = true) ||
          trimmed.equals("undefined", ignoreCase = true)) {
        return true
      }

      // Matches explicit IDs
      if (id.isNotBlank() && trimmed.equals(id.trim(), ignoreCase = true)) return true
      if (uid.isNotBlank() && trimmed.equals(uid.trim(), ignoreCase = true)) return true
      if (trimmed.startsWith("nurse_", ignoreCase = true) ||
          trimmed.startsWith("user_", ignoreCase = true) ||
          trimmed.startsWith("uid_", ignoreCase = true) ||
          trimmed.startsWith("admin_", ignoreCase = true) ||
          trimmed.startsWith("req_", ignoreCase = true)) {
        return true
      }

      // Matches known phone number
      if (phone.isNotBlank()) {
        val digitsOnlyStr = trimmed.filter { it.isDigit() }
        val digitsOnlyPhone = phone.filter { it.isDigit() }
        if (digitsOnlyStr.isNotBlank() && digitsOnlyPhone.isNotBlank()) {
          if (digitsOnlyStr == digitsOnlyPhone ||
              (digitsOnlyStr.length >= 7 && digitsOnlyPhone.endsWith(digitsOnlyStr)) ||
              (digitsOnlyPhone.length >= 7 && digitsOnlyStr.endsWith(digitsOnlyPhone))) {
            return true
          }
        }
      }

      // Looks like a phone number (6+ digits with zero or at most 1 letter, e.g. "+963998563650", "0998563650")
      val digitCount = trimmed.count { it.isDigit() }
      val letterCount = trimmed.count { it.isLetter() }
      if (digitCount >= 6 && letterCount == 0) return true
      if (trimmed.startsWith("+") && digitCount >= 5 && letterCount <= 1) return true

      // Looks like an auto-generated Firebase push ID / UUID (e.g. -OxfdBrOAek3KQREBfDb or 1789146317438)
      if (trimmed.startsWith("-") && trimmed.length >= 15 && !trimmed.contains(" ")) return true
      if (trimmed.matches(Regex("^[a-zA-Z0-9_-]{18,}$")) && !trimmed.contains(" ") && digitCount >= 3) return true

      return false
    }

    /**
     * Resolves the actual real nurse name from Firebase properties.
     * ALWAYS prioritizes the actual 'name' property from Firebase data nodes,
     * and strictly rejects phone numbers or IDs, never falling back to them.
     */
    fun resolveRealName(
      name: String?,
      fullName: String? = null,
      displayName: String? = null,
      id: String = "",
      uid: String = "",
      phone: String = "",
      fallback: String = "ممرض مرخص"
    ): String {
      // 1. Primary: actual 'name' property from Firebase data node
      if (!name.isNullOrBlank() && !isPhoneOrId(name, id, uid, phone)) {
        return name.trim()
      }
      // 2. Secondary: 'fullName' property from Firebase
      if (!fullName.isNullOrBlank() && !isPhoneOrId(fullName, id, uid, phone)) {
        return fullName.trim()
      }
      // 3. Tertiary: 'displayName'
      if (!displayName.isNullOrBlank() && !isPhoneOrId(displayName, id, uid, phone)) {
        return displayName.trim()
      }
      // Strictly fallback to a clean professional title, NEVER to a phone number or ID
      return fallback
    }
  }
}


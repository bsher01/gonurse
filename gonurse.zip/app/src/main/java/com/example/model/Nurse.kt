package com.example.model

data class Nurse(
  val id: String,
  val uid: String = "",
  val name: String,
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val mobile: String = "",
  val whatsapp: String = "",
  val city: String = "",
  val country: String = "سوريا",
  val specialization: String = "",
  val title: String = "",
  val experienceYears: Int = 0,
  val gender: String = "",
  val isAvailable: Boolean = true,
  val rating: Double = 5.0,
  val reviewsCount: Int = 0,
  val bio: String = "",
  val profileImageUri: String = "",
  val certificateImageUri: String = "",
  val idImageBase64: String = "",
  val licenseImageBase64: String = "",
  val isVerified: Boolean = false,
  val isCurrentUser: Boolean = false,
  val status: String = "PENDING",
  val createdAt: Long = 0L
) {
  val displayName: String
    get() = when {
      fullName.isNotBlank() -> fullName
      name.isNotBlank() -> name
      else -> "ممرض مرخص"
    }

  val displayPhone: String
    get() = when {
      phone.isNotBlank() -> phone
      mobile.isNotBlank() -> mobile
      whatsapp.isNotBlank() -> whatsapp
      else -> ""
    }

  val displaySpecialization: String
    get() = when {
      specialization.isNotBlank() -> specialization
      title.isNotBlank() -> title
      else -> "خدمات تمريضية ورعاية منزلية"
    }

  val displayCity: String
    get() = if (city.isNotBlank()) city else "دمشق"

  val displayCountry: String
    get() = CountryRepository.normalizeCountryName(country, displayPhone, city)
}


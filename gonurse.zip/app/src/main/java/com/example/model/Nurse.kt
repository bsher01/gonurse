package com.example.model

data class Nurse(
  val id: String,
  val uid: String = "",
  val name: String,
  val fullName: String = "",
  val email: String = "",
  val phone: String = "",
  val mobile: String = "",
  val whatsapp: String = "",
  val city: String = "",
  val country: String = "سوريا",
  val specialization: String = "",
  val title: String = "",
  val experienceYears: Int = 0,
  val gender: String = "",
  val isAvailable: Boolean = true,
  val rating: Double = 5.0,
  val reviewsCount: Int = 0,
  val bio: String = "",
  val profileImageUri: String = "",
  val certificateImageUri: String = "",
  val idImageBase64: String = "",
  val licenseImageBase64: String = "",
  val isVerified: Boolean = false,
  val isCurrentUser: Boolean = false,
  val status: String = "PENDING",
  val createdAt: Long = 0L
) {
  val displayName: String
    get() {
      // 1. Primary display text: check nurse's 'name' field first
      val cleanName = name.trim()
      if (cleanName.isNotBlank() && isRealPersonName(cleanName, id, uid, displayPhone)) {
        return cleanName
      }

      // 2. Secondary display text: check nurse's 'fullName' field
      val cleanFullName = fullName.trim()
      if (cleanFullName.isNotBlank() && isRealPersonName(cleanFullName, id, uid, displayPhone)) {
        return cleanFullName
      }

      // 3. If name field has text that is not strictly an ID or generic system placeholder:
      if (cleanName.isNotBlank() && !isStrictPlaceholder(cleanName, id, uid)) {
        val letterCount = cleanName.count { it.isLetter() }
        val digitCount = cleanName.count { it.isDigit() }
        if (letterCount > 0 || digitCount < 5) {
          return cleanName
        }
      }
      if (cleanFullName.isNotBlank() && !isStrictPlaceholder(cleanFullName, id, uid)) {
        val letterCount = cleanFullName.count { it.isLetter() }
        val digitCount = cleanFullName.count { it.isDigit() }
        if (letterCount > 0 || digitCount < 5) {
          return cleanFullName
        }
      }

      // 4. Last-resort fallback ONLY if the name field is completely empty or null:
      // Phone number fallback if available
      val phoneFallback = displayPhone.trim()
      if (phoneFallback.isNotBlank() && !phoneFallback.equals("null", ignoreCase = true)) {
        return phoneFallback
      }

      // Ultimate fallback when no name or phone is available
      return "ممرض مرخص"
    }

  val actualName: String
    get() = displayName

  /**
   * Strictly verifies whether the nurse has an authentic, independent professional license
   * or graduation certificate document attached that is distinct from a basic profile avatar.
   */
  val hasValidLicenseDocument: Boolean
    get() {
      val cleanLicense = licenseImageBase64.trim()
      val cleanCert = certificateImageUri.trim()
      val cleanProfile = profileImageUri.trim()

      val hasDistinctLicense = cleanLicense.isNotBlank() && cleanLicense != cleanProfile && cleanLicense.length > 50
      val hasDistinctCert = cleanCert.isNotBlank() && cleanCert != cleanProfile && cleanCert.length > 50
      return hasDistinctLicense || hasDistinctCert
    }

  /**
   * The verified badge is strictly active ONLY if the account is marked isVerified AND has a genuine license document.
   * Profile pictures alone never grant or activate verification.
   */
  val isVerifiedBadgeActive: Boolean
    get() = isVerified && hasValidLicenseDocument

  val displayPhone: String
    get() = when {
      phone.isNotBlank() -> phone
      mobile.isNotBlank() -> mobile
      whatsapp.isNotBlank() -> whatsapp
      else -> ""
    }

  val displaySpecialization: String
    get() = when {
      specialization.isNotBlank() -> specialization
      title.isNotBlank() -> title
      else -> "خدمات تمريضية ورعاية منزلية"
    }

  val displayCity: String
    get() = if (city.isNotBlank()) city else "دمشق"

  val displayCountry: String
    get() = CountryRepository.normalizeCountryName(country, displayPhone, city)

  companion object {
    /**
     * Identifies known generic placeholder titles or system IDs that are NOT authentic person names.
     */
    fun isStrictPlaceholder(str: String?, id: String = "", uid: String = ""): Boolean {
      if (str.isNullOrBlank()) return true
      val trimmed = str.trim()
      val lower = trimmed.lowercase()
      if (lower == "null" || lower == "none" || lower == "undefined" || lower == "n/a" || lower == "unknown") return true
      if (trimmed == "ممرض مرخص" || lower == "licensed nurse" ||
          trimmed == "ممرض" || trimmed == "ممرضة" ||
          trimmed == "كادر تمريضي" || trimmed == "كادر التمريض المناوب" ||
          trimmed == "ممرض منزلي" || trimmed == "ممرض منزلي مرخص" ||
          trimmed == "تمريض منزلي" || lower == "nurse") {
        return true
      }
      if (id.isNotBlank() && trimmed.equals(id.trim(), ignoreCase = true)) return true
      if (uid.isNotBlank() && trimmed.equals(uid.trim(), ignoreCase = true)) return true
      if (trimmed.startsWith("nurse_", ignoreCase = true) ||
          trimmed.startsWith("user_", ignoreCase = true) ||
          trimmed.startsWith("uid_", ignoreCase = true) ||
          trimmed.startsWith("admin_", ignoreCase = true) ||
          trimmed.startsWith("req_", ignoreCase = true) ||
          trimmed.startsWith("test_", ignoreCase = true)) {
        return true
      }
      return false
    }

    /**
     * Checks if a string is an authentic personal name, strictly filtering out
     * IDs, placeholders (like 'ممرض مرخص'), and phone numbers.
     */
    fun isRealPersonName(str: String?, id: String = "", uid: String = "", phone: String = ""): Boolean {
      if (str.isNullOrBlank()) return false
      val trimmed = str.trim()
      if (isStrictPlaceholder(trimmed, id, uid)) return false
      if (isPhoneOrId(trimmed, id, uid, phone)) return false
      return true
    }

    /**
     * Checks if a string looks like a phone number, user/nurse ID, or invalid name placeholder.
     */
    fun isPhoneOrId(str: String?, id: String = "", uid: String = "", phone: String = ""): Boolean {
      if (str.isNullOrBlank()) return true
      val trimmed = str.trim()
      if (isStrictPlaceholder(trimmed, id, uid)) return true

      // Matches explicit IDs
      if (id.isNotBlank() && trimmed.equals(id.trim(), ignoreCase = true)) return true
      if (uid.isNotBlank() && trimmed.equals(uid.trim(), ignoreCase = true)) return true
      if (trimmed.startsWith("nurse_", ignoreCase = true) ||
          trimmed.startsWith("user_", ignoreCase = true) ||
          trimmed.startsWith("uid_", ignoreCase = true) ||
          trimmed.startsWith("admin_", ignoreCase = true) ||
          trimmed.startsWith("req_", ignoreCase = true)) {
        return true
      }

      // Matches known phone number
      if (phone.isNotBlank()) {
        val digitsOnlyStr = trimmed.filter { it.isDigit() }
        val digitsOnlyPhone = phone.filter { it.isDigit() }
        if (digitsOnlyStr.isNotBlank() && digitsOnlyPhone.isNotBlank()) {
          if (digitsOnlyStr == digitsOnlyPhone ||
              (digitsOnlyStr.length >= 7 && digitsOnlyPhone.endsWith(digitsOnlyStr)) ||
              (digitsOnlyPhone.length >= 7 && digitsOnlyStr.endsWith(digitsOnlyPhone))) {
            return true
          }
        }
      }

      // Looks like a phone number (6+ digits with zero or at most 1 letter, e.g. "+963998563650", "0998563650")
      val digitCount = trimmed.count { it.isDigit() }
      val letterCount = trimmed.count { it.isLetter() }
      if (digitCount >= 6 && letterCount == 0) return true
      if (trimmed.startsWith("+") && digitCount >= 5 && letterCount <= 1) return true

      // Looks like an auto-generated Firebase push ID / UUID (e.g. -OxfdBrOAek3KQREBfDb or 1789146317438)
      if (trimmed.startsWith("-") && trimmed.length >= 15 && !trimmed.contains(" ")) return true
      if (trimmed.matches(Regex("^[a-zA-Z0-9_-]{18,}$")) && !trimmed.contains(" ") && digitCount >= 3) return true

      return false
    }

    /**
     * Resolves the actual real nurse name from Firebase properties.
     * ALWAYS prioritizes the actual 'name' or 'fullName' property,
     * and strictly rejects phone numbers or IDs. Fallback only if name is completely empty or null.
     */
    fun resolveRealName(
      name: String?,
      fullName: String? = null,
      displayName: String? = null,
      id: String = "",
      uid: String = "",
      phone: String = "",
      fallback: String = "ممرض مرخص"
    ): String {
      // 1. Primary: actual 'name' property
      if (isRealPersonName(name, id, uid, phone)) {
        return name!!.trim()
      }
      // 2. Secondary: 'fullName' property
      if (isRealPersonName(fullName, id, uid, phone)) {
        return fullName!!.trim()
      }
      // 3. Tertiary: 'displayName'
      if (isRealPersonName(displayName, id, uid, phone)) {
        return displayName!!.trim()
      }
      // 4. Last resort fallback: if fallback is provided, use it; otherwise fallback to phone or "ممرض مرخص"
      if (fallback.isNotBlank()) {
        return fallback
      }
      if (phone.isNotBlank() && !isStrictPlaceholder(phone, id, uid)) {
        return phone.trim()
      }
      return "ممرض مرخص"
    }
  }
}


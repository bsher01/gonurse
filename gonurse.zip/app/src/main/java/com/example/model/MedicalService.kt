package com.example.model

import androidx.annotation.DrawableRes
import com.example.R

enum class AppLanguage {
  ARABIC,
  ENGLISH;

  fun toggle(): AppLanguage = if (this == ARABIC) ENGLISH else ARABIC
}

data class MedicalService(
  val id: String,
  val titleAr: String,
  val titleEn: String,
  val descriptionAr: String,
  val descriptionEn: String,
  val categoryAr: String,
  val categoryEn: String,
  @DrawableRes val imageRes: Int,
  val badgeAr: String,
  val badgeEn: String,
  val requiresPrescription: Boolean = false
)

object MedicalServiceRepository {
  val services = listOf(
    MedicalService(
      id = "iv_medication",
      titleAr = "إعطاء أدوية وريدية",
      titleEn = "IV Medication Administration",
      descriptionAr = "إعطاء المحاليل الطبية والمضادات الحيوية الوريدية بدقة وتعقيم عالي على يد ممرضين مرخصين.",
      descriptionEn = "Safe administration of intravenous fluids, antibiotics, and medications by certified nurses.",
      categoryAr = "عناية وريدية",
      categoryEn = "IV Infusion",
      imageRes = R.drawable.img_service_iv,
      badgeAr = "الأكثر طلباً",
      badgeEn = "Popular",
      requiresPrescription = true
    ),
    MedicalService(
      id = "im_injection",
      titleAr = "إعطاء إبر عضلية",
      titleEn = "Intramuscular Injections",
      descriptionAr = "حقن عضلية آمنة ومريحة في المنزل وفق الجرعات الطبية المقررة مع مراعاة كافة شروط السلامة.",
      descriptionEn = "Comfortable, sterile intramuscular injections at home per physician prescriptions.",
      categoryAr = "حقن طبية",
      categoryEn = "Injections",
      imageRes = R.drawable.img_service_injection,
      badgeAr = "سريع ومباشر",
      badgeEn = "Fast Visit",
      requiresPrescription = true
    ),
    MedicalService(
      id = "blood_draw",
      titleAr = "سحب دم لإجراء تحليل",
      titleEn = "Blood Draw / Lab Work",
      descriptionAr = "سحب عينات الدم المخبرية بتقنية لطيفة ونقلها بأمان مبرد ومعتمد إلى المختبرات المعتمدة.",
      descriptionEn = "Gentle phlebotomy sample collection and temperature-controlled delivery to accredited labs.",
      categoryAr = "تحاليل مخبرية",
      categoryEn = "Lab Work",
      imageRes = R.drawable.img_service_blood_draw,
      badgeAr = "نتائج سريعة",
      badgeEn = "Fast Results",
      requiresPrescription = false
    ),
    MedicalService(
      id = "vital_signs",
      titleAr = "قياس علامات حيوية",
      titleEn = "Vital Signs Monitoring",
      descriptionAr = "فحص شامل لضغط الدم، نبضات القلب، نسبة تشبع الأكسجين، سكر الدم، ودرجة الحرارة.",
      descriptionEn = "Comprehensive check of blood pressure, heart rate, SPO2 oxygen, blood glucose, and temperature.",
      categoryAr = "فحص دوري",
      categoryEn = "Checkup",
      imageRes = R.drawable.img_service_vital_signs,
      badgeAr = "فحص شامل",
      badgeEn = "Complete Check",
      requiresPrescription = false
    ),
    MedicalService(
      id = "catheter_care",
      titleAr = "تركيب قثطرة بولية",
      titleEn = "Urinary Catheter Insertion",
      descriptionAr = "تركيب وتغيير القثطرة البولية مع العناية الفائقة بمجرى البول والتعقيم الصارم لمنع أي عدوى.",
      descriptionEn = "Sterile urinary catheter insertion and replacement with professional clinical infection control.",
      categoryAr = "عناية متخصصة",
      categoryEn = "Specialized",
      imageRes = R.drawable.img_service_catheter,
      badgeAr = "رعاية تخصصية",
      badgeEn = "Specialized",
      requiresPrescription = true
    ),
    MedicalService(
      id = "other_services",
      titleAr = "غير ذلك",
      titleEn = "Other Services",
      descriptionAr = "تضميد الجروح والحروق، رعاية كبار السن، إزالة الغرز الجراحية، واستشارات تمريضية متقدمة.",
      descriptionEn = "Wound dressing, post-op suture removal, elderly bedside care, and personalized nursing visits.",
      categoryAr = "تمريض عام",
      categoryEn = "General Care",
      imageRes = R.drawable.img_service_other,
      badgeAr = "مخصص",
      badgeEn = "Customized",
      requiresPrescription = false
    )
  )
}

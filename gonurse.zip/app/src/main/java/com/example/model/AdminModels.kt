package com.example.model

data class PendingRegistration(
  val id: String = "",
  val name: String = "",
  val phone: String = "",
  val bio: String = "",
  val country: String = "سوريا",
  val city: String = "",
  val profileImageBase64: String = "",
  val licenseImageBase64: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val createdAt: Long = System.currentTimeMillis()
)

data class PendingProfileUpdate(
  val id: String = "",
  val nurseId: String = "",
  val nurseName: String = "",
  val registeredPhone: String = "",
  val oldPhone: String = "",
  val oldCountry: String = "",
  val oldCity: String = "",
  val oldBio: String = "",
  val oldProfileImageUri: String = "",
  val requestedPhone: String = "",
  val requestedBio: String = "",
  val requestedCountry: String = "",
  val requestedCity: String = "",
  val requestedProfileImageBase64: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val timestamp: Long = System.currentTimeMillis()
)

data class PendingAccountDeletion(
  val id: String = "",
  val nurseId: String = "",
  val nurseName: String = "",
  val registeredPhone: String = "",
  val country: String = "سوريا",
  val city: String = "",
  val reason: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val timestamp: Long = System.currentTimeMillis()
)

data class SubmittedReport(
  val id: String = "",
  val reporterPhone: String = "",
  val reporterCountry: String = "سوريا",
  val targetType: String = "", // "NURSE" or "REQUEST"
  val targetId: String = "",
  val targetName: String = "",
  val targetCity: String = "",
  val reason: String = "",
  val additionalNotes: String = "",
  val status: String = "PENDING", // PENDING, RESOLVED, DISMISSED
  val timestamp: Long = System.currentTimeMillis()
)

package com.example.model

data class PendingRegistration(
  val id: String = "",
  val phone: String = "",
  val bio: String = "",
  val country: String = "سوريا",
  val city: String = "",
  val licenseImageBase64: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val createdAt: Long = System.currentTimeMillis()
)

data class PendingProfileUpdate(
  val id: String = "",
  val nurseId: String = "",
  val registeredPhone: String = "",
  val requestedPhone: String = "",
  val requestedBio: String = "",
  val requestedCountry: String = "",
  val requestedCity: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val timestamp: Long = System.currentTimeMillis()
)

data class PendingAccountDeletion(
  val id: String = "",
  val nurseId: String = "",
  val registeredPhone: String = "",
  val reason: String = "",
  val status: String = "PENDING", // PENDING, APPROVED, REJECTED
  val timestamp: Long = System.currentTimeMillis()
)

data class SubmittedReport(
  val id: String = "",
  val reporterPhone: String = "",
  val targetType: String = "", // "NURSE" or "REQUEST"
  val targetId: String = "",
  val targetName: String = "",
  val targetCity: String = "",
  val reason: String = "",
  val additionalNotes: String = "",
  val status: String = "PENDING", // PENDING, RESOLVED, DISMISSED
  val timestamp: Long = System.currentTimeMillis()
)

package com.example.model

/**
 * Configuration model fetched from Firebase RTDB node `app_config`
 */
data class AppConfig(
  val minVersionCode: Long = 1L,
  val minVersionName: String = "1.0",
  val latestVersionCode: Long = 1L,
  val latestVersionName: String = "1.0",
  val isForceUpdateRequired: Boolean = false,
  val updateUrl: String = "https://t.me/GoNurse",
  val updateTitleAr: String = "تحديث إلزامي للتطبيق",
  val updateTitleEn: String = "Mandatory App Update",
  val updateMessageAr: String = "يتوفر إصدار جديد هام جداً من تطبيق GoNurse يحتوي على تحسينات أمنية وتحديثات هامة للخدمات التمريضية. يرجى التحديث للمتابعة.",
  val updateMessageEn: String = "A critical update is available for GoNurse with important security and medical service enhancements. Please update to continue using the application."
)

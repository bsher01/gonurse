package com.example.model

/**
 * Patient review and rating model for nurses in GoNurse.
 * Stored in Firebase Realtime Database at `reviews/{nurseId}/{reviewId}`.
 */
data class NurseReview(
  val id: String = "",
  val nurseId: String = "",
  val rating: Int = 5,
  val reviewText: String = "",
  val patientName: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val requestId: String = "",
  val serviceName: String = ""
)

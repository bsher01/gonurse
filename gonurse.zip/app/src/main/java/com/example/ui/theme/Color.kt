package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Deep Maroon / Crimson Medical Palette
val MaroonPrimary = Color(0xFF7A1020)
val MaroonDark = Color(0xFF5A0A16)
val MaroonOnPrimary = Color(0xFFFFFFFF)
val MaroonPrimaryContainer = Color(0xFFFFEBEB)
val MaroonOnPrimaryContainer = Color(0xFF42000A)

val MaroonSecondary = Color(0xFF0284C7)
val MaroonOnSecondary = Color(0xFFFFFFFF)
val MaroonSecondaryContainer = Color(0xFFE0F2FE)
val MaroonOnSecondaryContainer = Color(0xFF0369A1)

val MaroonTertiary = Color(0xFF0D9488)
val MaroonOnTertiary = Color(0xFFFFFFFF)
val MaroonTertiaryContainer = Color(0xFFCCFBF1)
val MaroonOnTertiaryContainer = Color(0xFF115E59)

// Clean Pure White Background & Surface Palette
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F3F5)
val OutlineLight = Color(0xFFE5E7EB)
val OutlineVariantLight = Color(0xFFEEEEEE)
val TextPrimaryLight = Color(0xFF1F2937)
val TextSecondaryLight = Color(0xFF4B5563)
val TextMutedLight = Color(0xFF6B7280)

// Clean Light-friendly accents (no muddy dark tones)
val BackgroundDark = Color(0xFFF8F9FA)
val SurfaceDark = Color(0xFFFFFFFF)
val SurfaceVariantDark = Color(0xFFF1F3F5)
val TextPrimaryDark = Color(0xFF1F2937)
val TextSecondaryDark = Color(0xFF4B5563)

// Status & Accent Colors
val MedicalTeal = Color(0xFF0D9488)
val MedicalEmergencyRed = Color(0xFFDC2626)
val MedicalSuccessGreen = Color(0xFF16A34A)
val CardBorderColor = Color(0xFFE5E7EB)
val CardBackgroundWhite = Color(0xFFFFFFFF)
val StatCardBg = Color(0xFFFFFFFF)



package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor

@Composable
fun GoNurseImage(
  imageSource: String?,
  contentDescription: String?,
  modifier: Modifier = Modifier,
  contentScale: ContentScale = ContentScale.Crop,
  fallbackIcon: ImageVector = Icons.Default.Person,
  isCurrentUser: Boolean = false
) {
  val source = imageSource?.trim().orEmpty()
  val context = LocalContext.current

  // Memory cached bitmap for Base64 (using LruCache to prevent scroll stutters)
  val memoryBitmap = remember(source) {
    if (source.isNotBlank() &&
      !source.startsWith("http://") &&
      !source.startsWith("https://") &&
      !source.startsWith("content://") &&
      !source.startsWith("file://")
    ) {
      ImageCompressor.getCachedOrDecodeBase64(source)
    } else {
      null
    }
  }

  when {
    memoryBitmap != null -> {
      Image(
        bitmap = memoryBitmap.asImageBitmap(),
        contentDescription = contentDescription,
        modifier = modifier,
        contentScale = contentScale
      )
    }
    source.startsWith("http://") || source.startsWith("https://") || source.startsWith("content://") || source.startsWith("file://") -> {
      AsyncImage(
        model = ImageRequest.Builder(context)
          .data(source)
          .crossfade(true)
          .memoryCachePolicy(CachePolicy.ENABLED)
          .diskCachePolicy(CachePolicy.ENABLED)
          .networkCachePolicy(CachePolicy.ENABLED)
          .build(),
        contentDescription = contentDescription,
        modifier = modifier,
        contentScale = contentScale
      )
    }
    else -> {
      Box(
        modifier = modifier
          .background(
            if (isCurrentUser) MaroonPrimary else MaroonPrimary.copy(alpha = 0.12f)
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          fallbackIcon,
          contentDescription = contentDescription,
          tint = if (isCurrentUser) Color.White else MaroonPrimary,
          modifier = Modifier.size(24.dp)
        )
      }
    }
  }
}

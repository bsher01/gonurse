package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.FirebaseRealtimeRepository
import com.example.data.RequestOwnershipStore
import com.example.model.AppLanguage
import com.example.model.CountryInfo
import com.example.model.CountryRepository
import com.example.model.MedicalService
import com.example.model.Nurse
import com.example.model.NursingRequest
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.ui.theme.MedicalSuccessGreen
import com.example.util.PhoneFormatter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingBottomSheet(
  service: MedicalService?,
  nurse: Nurse? = null,
  language: AppLanguage,
  onDismiss: () -> Unit,
  onBookingConfirmed: (serviceName: String, patientName: String, selectedCity: String) -> Unit,
  sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  // Form Fields State - using rememberSaveable to preserve user input during network disconnections/recompositions
  var patientName by rememberSaveable { mutableStateOf("") }
  var selectedCountry by remember { mutableStateOf(CountryRepository.defaultCountry) }
  var showCountryPicker by remember { mutableStateOf(false) }
  var rawPhoneInput by rememberSaveable { mutableStateOf("") }
  var cleanLocalPhone by rememberSaveable { mutableStateOf("") }
  var city by rememberSaveable { mutableStateOf(if (isArabic) "دمشق" else "Damascus") }
  var medicalNotes by rememberSaveable { mutableStateOf("") }

  // Validation States
  var nameError by remember { mutableStateOf(false) }
  var phoneError by remember { mutableStateOf(false) }
  var cityError by remember { mutableStateOf(false) }
  var isSubmitting by remember { mutableStateOf(false) }

  val displayServiceName = when {
    service != null -> if (isArabic) service.titleAr else service.titleEn
    nurse != null -> if (isArabic) "طلب زيارة تمريضية (${nurse.displayName})" else "Nurse Visit (${nurse.displayName})"
    else -> if (isArabic) "خدمة تمريضية منزلية" else "Home Nursing Service"
  }

  // Quick city suggestions based on selected country
  val quickCities = remember(selectedCountry) {
    when (selectedCountry.code) {
      "SY" -> listOf("دمشق", "ريف دمشق", "حلب", "حمص", "اللاذقية", "طرطوس", "حماة", "القامشلي")
      "SA" -> listOf("الرياض", "جدة", "مكة المكرمة", "المدينة المنورة", "الدمام", "الخبر")
      "AE" -> listOf("دبي", "أبوظبي", "الشارقة", "عجمان", "العين")
      "EG" -> listOf("القاهرة", "الإسكندرية", "الجيزة", "المنصورة", "طنطا")
      "JO" -> listOf("عمان", "إربد", "الزرقاء", "العقبة")
      "IQ" -> listOf("بغداد", "أربيل", "البصرة", "الموصل")
      "LB" -> listOf("بيروت", "طرابلس", "صيدا")
      else -> listOf("العاصمة", "المدينة الرئيسية")
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    modifier = Modifier.testTag("booking_bottom_sheet")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .navigationBarsPadding()
        .padding(bottom = 24.dp)
    ) {
      // Header with close button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (isArabic) "حجز خدمة تمريضية" else "Book Nursing Service",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = if (isArabic) "سيتم نشر طلبك ومطابقته فورياً مع كوادر مدينتك" else "Request will be published & matched with city nurses",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Selected Service / Nurse Summary Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (service != null) {
            Image(
              painter = painterResource(id = service.imageRes),
              contentDescription = displayServiceName,
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(10.dp))
            )
          } else {
            Box(
              modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(MaroonPrimary),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Default.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(28.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = displayServiceName,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp
              ),
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = if (isArabic) "طلب رعاية منزلية فورية" else "Immediate Home Healthcare Order",
              style = MaterialTheme.typography.labelSmall,
              color = MaroonPrimary
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Section Title
      Text(
        text = if (isArabic) "بيانات الحجز والمريض" else "Booking & Patient Information",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaroonPrimary
      )

      Spacer(modifier = Modifier.height(10.dp))

      // 1. Patient Name (اسم المريض)
      OutlinedTextField(
        value = patientName,
        onValueChange = {
          patientName = it
          nameError = false
        },
        label = { Text(if (isArabic) "اسم المريض (مطلوب)" else "Patient Name (Required)") },
        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary) },
        isError = nameError,
        supportingText = if (nameError) {
          { Text(if (isArabic) "يرجى كتابة اسم المريض" else "Please enter patient name") }
        } else null,
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          focusedLabelColor = MaroonPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_patient_name")
      )

      Spacer(modifier = Modifier.height(10.dp))

      // 2. Country (الدولة - selector with all countries)
      Text(
        text = if (isArabic) "الدولة" else "Country",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
      Surface(
        onClick = { showCountryPicker = true },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("country_selector_button")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = selectedCountry.flagEmoji,
              fontSize = 22.sp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isArabic) selectedCountry.nameAr else selectedCountry.nameEn,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${if (isArabic) "رمز النداء الدولي:" else "Dial Code:"} ${selectedCountry.dialCode}",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Icon(
            Icons.Default.ArrowDropDown,
            contentDescription = "Select Country",
            tint = MaroonPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 3. City (المدينة)
      OutlinedTextField(
        value = city,
        onValueChange = {
          city = it
          cityError = false
        },
        label = { Text(if (isArabic) "المدينة / المحافظة (مطلوب)" else "City / Province (Required)") },
        leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null, tint = MaroonPrimary) },
        isError = cityError,
        supportingText = if (cityError) {
          { Text(if (isArabic) "يرجى كتابة أو اختيار المدينة" else "Please enter city") }
        } else null,
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          focusedLabelColor = MaroonPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_city")
      )

      // Quick City Suggestions Chips
      Spacer(modifier = Modifier.height(6.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isArabic) "مدن مقترحة:" else "Suggestions:",
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        quickCities.take(4).forEach { citySuggestion ->
          FilterChip(
            selected = city == citySuggestion,
            onClick = {
              city = citySuggestion
              cityError = false
            },
            label = { Text(citySuggestion, fontSize = 10.5.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaroonPrimary.copy(alpha = 0.15f),
              selectedLabelColor = MaroonPrimary
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(28.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 4. WhatsApp Number (رقم الواتساب - with smart automatic recognition)
      OutlinedTextField(
        value = rawPhoneInput,
        onValueChange = { input ->
          rawPhoneInput = input
          phoneError = false

          // Smart Auto-Recognition: Detect country code and clean local number
          val (detectedCountry, cleanNum) = PhoneFormatter.parseAndFormat(input, selectedCountry)
          if (detectedCountry != selectedCountry) {
            selectedCountry = detectedCountry
          }
          cleanLocalPhone = cleanNum
        },
        label = { Text(if (isArabic) "رقم الواتساب (للتواصل الطبي والمراسلة)" else "WhatsApp Number (For Medical Chat)") },
        leadingIcon = {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 12.dp, end = 6.dp)
          ) {
            Icon(
              Icons.Default.Chat,
              contentDescription = "WhatsApp",
              tint = Color(0xFF2E7D32),
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = selectedCountry.dialCode,
              style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaroonPrimary
              )
            )
          }
        },
        placeholder = { Text(if (isArabic) "مثال: 0933123456 أو 933123456" else "e.g. 0933123456 or 933123456") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        isError = phoneError,
        supportingText = {
          if (phoneError) {
            Text(
              text = if (isArabic) "يرجى إدخال رقم واتساب صالح (7 أرقام على الأقل)" else "Please enter a valid WhatsApp number (min 7 digits)",
              color = MaterialTheme.colorScheme.error
            )
          } else {
            val previewFull = PhoneFormatter.getFullInternationalNumber(selectedCountry, cleanLocalPhone)
            if (previewFull.isNotBlank()) {
              Text(
                text = "${if (isArabic) "الرقم الدولي المعتمد:" else "Full WhatsApp:"} $previewFull",
                color = Color(0xFF2E7D32),
                style = MaterialTheme.typography.labelSmall
              )
            } else {
              Text(
                text = if (isArabic) "التعرف الذكي يتعامل تلقائياً مع الصفر والرمز الدولي" else "Smart detection handles 0 and country dial code automatically",
                style = MaterialTheme.typography.labelSmall
              )
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          focusedLabelColor = MaroonPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_whatsapp_number")
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Additional Medical Notes / Details (Optional)
      OutlinedTextField(
        value = medicalNotes,
        onValueChange = { medicalNotes = it },
        label = { Text(if (isArabic) "ملاحظات طبية أو عنوان تفصيلي (اختياري)" else "Medical notes or detailed address (Optional)") },
        leadingIcon = { Icon(Icons.Default.Notes, contentDescription = null, tint = MaroonPrimary) },
        maxLines = 2,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          focusedLabelColor = MaroonPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_medical_notes")
      )

      Spacer(modifier = Modifier.height(20.dp))

      // Notice Badge regarding ownership and completion
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFFFF9E6),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            Icons.Default.VerifiedUser,
            contentDescription = null,
            tint = Color(0xFFB45309),
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) {
              "بصفتك صاحب الطلب، سيكون لك الصلاحية الحصرية لإتمام وإغلاق الطلب بعد إنجاز الخدمة بنجاح."
            } else {
              "As the request creator, you hold exclusive authority to mark this service completed."
            },
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 10.sp,
              lineHeight = 14.sp,
              color = Color(0xFF78350F)
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Subtle Legal & Medical Disclaimer Notice
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF9FAFB),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("booking_legal_disclaimer_notice")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            Icons.Default.VerifiedUser,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (isArabic) {
              "إخلاء مسؤولية: تطبيق GoNurse هو منصة وسيطة للتنسيق والربط التمريضي المستقل ولا يتحمل مسؤولية طبية مباشرة. يرجى التحقق من هوية الكادر الطبي وترخيصه عند الزيارة."
            } else {
              "Disclaimer: GoNurse is an intermediary platform connecting independent nursing staff and does not assume direct medical liability. Please verify the nurse's credentials upon visit."
            },
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 9.5.sp,
              lineHeight = 13.5.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Confirm Booking Button
      Button(
        onClick = {
          if (patientName.isBlank()) {
            nameError = true
            return@Button
          }
          if (city.isBlank()) {
            cityError = true
            return@Button
          }

          val fullWhatsapp = PhoneFormatter.getFullInternationalNumber(selectedCountry, cleanLocalPhone)
          if (!PhoneFormatter.isValidPhoneNumber(cleanLocalPhone)) {
            phoneError = true
            return@Button
          }

          val requestId = System.currentTimeMillis().toString()
          val creatorId = RequestOwnershipStore.getCreatorId(context)

          val newRequest = NursingRequest(
            id = requestId,
            patientName = patientName.trim(),
            country = selectedCountry.nameAr,
            city = city.trim(),
            patientPhone = fullWhatsapp,
            whatsappNumber = fullWhatsapp,
            address = "${city.trim()}، ${selectedCountry.nameAr}",
            serviceName = displayServiceName,
            selectedNurseName = nurse?.displayName ?: "",
            selectedNursePhone = nurse?.displayPhone ?: "",
            preferredTime = if (isArabic) "في أقرب وقت متاح" else "As soon as possible",
            notes = medicalNotes.trim(),
            status = "قيد الانتظار",
            isCompleted = false,
            creatorId = creatorId,
            timestamp = System.currentTimeMillis()
          )

          scope.launch {
            isSubmitting = true
            // 1. Record local ownership so this device exclusively controls completion
            RequestOwnershipStore.recordRequestOwnership(context, requestId)
            // 2. Publish to Firebase
            FirebaseRealtimeRepository.createRequest(newRequest)
            isSubmitting = false
            // 3. Confirm and navigate to Nurses filtered by city
            onBookingConfirmed(displayServiceName, patientName.trim(), city.trim())
          }
        },
        enabled = !isSubmitting,
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("confirm_booking_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaroonPrimary,
          contentColor = MaroonOnPrimary
        )
      ) {
        if (isSubmitting) {
          CircularProgressIndicator(
            color = Color.White,
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.dp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "جاري نشر الطلب في السجل..." else "Publishing request...",
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        } else {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "تأكيد الطلب والانتقال لكادر التمريض" else "Confirm & View City Nurses",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 14.5.sp
            ),
            color = Color.White
          )
        }
      }
    }
  }

  // Country Picker Full Dialog
  if (showCountryPicker) {
    CountryPickerDialog(
      language = language,
      selectedCountry = selectedCountry,
      onSelectCountry = { country ->
        selectedCountry = country
        showCountryPicker = false
      },
      onDismiss = { showCountryPicker = false }
    )
  }
}

/**
 * Searchable Country Picker Dialog listing all countries of the world
 */
@Composable
fun CountryPickerDialog(
  language: AppLanguage,
  selectedCountry: CountryInfo,
  onSelectCountry: (CountryInfo) -> Unit,
  onDismiss: () -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  var searchQuery by remember { mutableStateOf("") }
  val allCountries = CountryRepository.countries

  val filteredCountries = remember(searchQuery) {
    if (searchQuery.isBlank()) {
      allCountries
    } else {
      val query = searchQuery.trim().lowercase()
      allCountries.filter { country ->
        country.nameAr.contains(query, ignoreCase = true) ||
          country.nameEn.lowercase().contains(query) ||
          country.dialCode.contains(query) ||
          country.code.lowercase().contains(query)
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = Color.White,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 560.dp)
        .testTag("country_picker_dialog")
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Public,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) "اختر الدولة" else "Select Country",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Field
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text(if (isArabic) "ابحث عن اسم الدولة أو رمز النداء..." else "Search country or dial code...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaroonPrimary) },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaroonPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("country_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Countries List
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(filteredCountries, key = { it.code + it.dialCode }) { country ->
            val isSelected = country.code == selectedCountry.code
            Surface(
              onClick = { onSelectCountry(country) },
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) MaroonPrimary.copy(alpha = 0.1f) else Color.Transparent,
              border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary) else null,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.weight(1f)
                ) {
                  Text(text = country.flagEmoji, fontSize = 22.sp)
                  Spacer(modifier = Modifier.width(10.dp))
                  Text(
                    text = if (isArabic) country.nameAr else country.nameEn,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    ),
                    color = if (isSelected) MaroonPrimary else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }

                Text(
                  text = country.dialCode,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaroonPrimary
                  )
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun BookingSuccessDialog(
  serviceTitle: String,
  patientName: String,
  selectedCity: String,
  language: AppLanguage,
  onDismiss: () -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      tonalElevation = 8.dp,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .testTag("booking_success_dialog")
    ) {
      Column(
        modifier = Modifier.padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(MedicalSuccessGreen.copy(alpha = 0.12f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.CheckCircle,
            contentDescription = "Success",
            tint = MedicalSuccessGreen,
            modifier = Modifier.size(38.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = if (isArabic) "تم نشر طلبك بنجاح!" else "Request Published Successfully!",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = if (isArabic) {
            "تمت إضافة طلبك لخدمة '$serviceTitle' في مدينة $selectedCity إلى قائمة الطلبات المباشرة. يمكنك الآن استعراض ممرضي $selectedCity والتواصل معهم."
          } else {
            "Your request for '$serviceTitle' in $selectedCity has been published. You can now view and contact nurses in $selectedCity."
          },
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center,
          lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("close_success_dialog_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
        ) {
          Text(
            text = if (isArabic) "استعراض ممرضي $selectedCity" else "View Nurses in $selectedCity",
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }
    }
  }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppLanguage
import com.example.model.CountryInfo
import com.example.model.CountryRepository
import com.example.ui.theme.MaroonPrimary

@Composable
fun CountrySelectorDialog(
  selectedCountry: CountryInfo,
  language: AppLanguage,
  onCountrySelected: (CountryInfo) -> Unit,
  onDismissRequest: () -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  var searchQuery by remember { mutableStateOf("") }

  val filteredCountries = remember(searchQuery, isArabic) {
    if (searchQuery.isBlank()) {
      CountryRepository.countries
    } else {
      val query = searchQuery.trim().lowercase()
      CountryRepository.countries.filter { country ->
        country.nameAr.lowercase().contains(query) ||
        country.nameEn.lowercase().contains(query) ||
        country.dialCode.contains(query) ||
        country.code.lowercase().contains(query)
      }
    }
  }

  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  Dialog(onDismissRequest = onDismissRequest) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = Modifier
          .fillMaxWidth()
          .fillMaxHeight(0.85f)
          .testTag("country_selector_dialog")
      ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp)
      ) {
        // Dialog Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaroonPrimary.copy(alpha = 0.1f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Default.Public,
                contentDescription = null,
                tint = MaroonPrimary,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isArabic) "اختر الدولة" else "Select Country",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = if (isArabic) "جميع دول العالم متاحة" else "All world countries available",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          IconButton(
            onClick = onDismissRequest,
            modifier = Modifier.testTag("close_country_dialog_button")
          ) {
            Icon(
              Icons.Default.Close,
              contentDescription = "Close",
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Search Input
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = {
            Text(
              text = if (isArabic) "ابحث عن الدولة أو الرمز الدولي..." else "Search country or dial code...",
              fontSize = 13.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
          },
          leadingIcon = {
            Icon(
              Icons.Default.Search,
              contentDescription = "Search",
              tint = MaroonPrimary,
              modifier = Modifier.size(20.dp)
            )
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(
                  Icons.Default.Close,
                  contentDescription = "Clear",
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0xFFF9FAFB),
            unfocusedContainerColor = Color(0xFFF9FAFB),
            focusedBorderColor = MaroonPrimary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("country_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

        Spacer(modifier = Modifier.height(6.dp))

        // Countries List
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .testTag("country_list")
        ) {
          items(filteredCountries, key = { it.code + it.dialCode }) { country ->
            val isSelected = country.code == selectedCountry.code && country.dialCode == selectedCountry.dialCode

            Surface(
              onClick = {
                onCountrySelected(country)
                onDismissRequest()
              },
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) MaroonPrimary.copy(alpha = 0.08f) else Color.Transparent,
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp)
                .testTag("country_item_${country.code}")
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = country.flagEmoji,
                  fontSize = 22.sp,
                  modifier = Modifier.padding(end = 10.dp)
                )

                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = if (isArabic) country.nameAr else country.nameEn,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (isSelected) MaroonPrimary else MaterialTheme.colorScheme.onSurface
                  )
                  Text(
                    text = if (isArabic) country.nameEn else country.nameAr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = if (isSelected) MaroonPrimary.copy(alpha = 0.15f) else Color(0xFFF3F4F6),
                  modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                  Text(
                    text = country.dialCode,
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) MaroonPrimary else MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                  )
                }

                if (isSelected) {
                  Icon(
                    Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = MaroonPrimary,
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
    }
  }
}

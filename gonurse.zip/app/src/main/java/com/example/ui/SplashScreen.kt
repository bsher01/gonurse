package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  language: AppLanguage,
  onSplashFinished: () -> Unit,
  modifier: Modifier = Modifier
) {
  var startAnimation by remember { mutableStateOf(false) }

  val scale by animateFloatAsState(
    targetValue = if (startAnimation) 1f else 0.82f,
    animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
    label = "splash_scale"
  )

  val alpha by animateFloatAsState(
    targetValue = if (startAnimation) 1f else 0f,
    animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
    label = "splash_alpha"
  )

  // Exactly 2-second splash screen duration before transitioning
  LaunchedEffect(Unit) {
    startAnimation = true
    delay(2000L)
    onSplashFinished()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .testTag("splash_screen_container")
  ) {
    // Realistic non-illustrated photo background of real nurse providing home care
    Image(
      painter = painterResource(id = R.drawable.img_splash_bg),
      contentDescription = "GoNurse Home Healthcare",
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize()
    )

    // Rich dual-layer dark gradient overlay to ensure perfect contrast and aesthetic depth
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color(0x992B040B),
              Color(0xCC3E0A14),
              Color(0xF0180407)
            )
          )
        )
    )

    // Centered App Icon & Brand Information
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      // Centered App Icon Card
      Box(
        modifier = Modifier
          .scale(scale)
          .shadow(24.dp, shape = RoundedCornerShape(28.dp), spotColor = Color(0xFFFF4060))
          .clip(RoundedCornerShape(28.dp))
          .background(Color(0xFF350810))
          .border(2.dp, Color(0x66FFFFFF), RoundedCornerShape(28.dp))
          .padding(4.dp)
          .size(130.dp)
          .testTag("splash_app_icon"),
        contentAlignment = Alignment.Center
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_app_icon),
          contentDescription = "GoNurse Logo",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Brand Title
      Text(
        text = "GoNurse",
        style = MaterialTheme.typography.headlineLarge.copy(
          fontSize = 36.sp,
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 1.2.sp
        ),
        color = Color.White,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("splash_title")
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Subtitle based on initial language (Arabic default)
      Text(
        text = if (language == AppLanguage.ARABIC) {
          "خدمات التمريض والرعاية الصحية في منزلك"
        } else {
          "Professional Home Healthcare & Nursing Care"
        },
        style = MaterialTheme.typography.bodyLarge.copy(
          fontSize = 16.sp,
          fontWeight = FontWeight.Medium
        ),
        color = Color(0xFFFFDADA),
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 24.dp)
      )

      Spacer(modifier = Modifier.height(36.dp))

      // Subtle loading indicator
      CircularProgressIndicator(
        modifier = Modifier.size(28.dp),
        color = Color(0xFFFF8B9C),
        strokeWidth = 2.5.dp,
        trackColor = Color(0x33FFFFFF)
      )
    }

    // Bottom regulatory & reassurance tag
    Box(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 32.dp)
    ) {
      Text(
        text = if (language == AppLanguage.ARABIC) {
          "كادر تمريضي مرخص ومعتمد ٢٤/٧"
        } else {
          "Licensed & Certified Nursing Staff 24/7"
        },
        style = MaterialTheme.typography.labelMedium,
        color = Color(0xCCFFFFFF),
        textAlign = TextAlign.Center
      )
    }
  }
}

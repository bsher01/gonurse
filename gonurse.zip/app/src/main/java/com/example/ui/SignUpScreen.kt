package com.example.ui

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import coil.compose.AsyncImage
import com.example.data.FirebaseRealtimeRepository
import com.example.data.UserAuthStore
import com.example.model.AppLanguage
import com.example.model.CountryInfo
import com.example.model.CountryRepository
import com.example.model.Nurse
import com.example.ui.components.CountrySelectorDialog
import com.example.ui.components.ImageCropDialog
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import com.example.util.PhoneFormatter
import com.example.util.WhatsAppHelper
import com.example.util.bringIntoViewOnFocus
import com.example.util.keyboardNestedScroll
import kotlinx.coroutines.launch

/**
 * Screen titled "إنشاء حساب ممرض" (Create Nurse Account).
 * Contains ONLY 5 specified fields:
 * 1. Phone Number (رقم هاتف)
 * 2. Bio/Description (نبذة)
 * 3. Country (الدولة)
 * 4. City (المدينة)
 * 5. Professional license image upload (رفع ترخيص مزاولة المهنة)
 *
 * Persists data to Firebase RTDB with isVerified = false,
 * and triggers a direct WhatsApp deep link to the admin (+994407958647).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
  language: AppLanguage,
  onToggleLanguage: () -> Unit,
  onRegistrationSuccess: (Nurse) -> Unit,
  onNavigateBack: () -> Unit,
  onNavigateToVerification: (Nurse) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val focusManager = LocalFocusManager.current
  val coroutineScope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  // Exactly 5 form fields
  var selectedCountry by remember { mutableStateOf(CountryRepository.defaultCountry) }
  var rawPhoneNumber by remember { mutableStateOf("") }
  var bio by remember { mutableStateOf("") }
  var city by remember { mutableStateOf("") }
  var licenseImageUri by remember { mutableStateOf<Uri?>(null) }

  // UI Dialogs & Submission State
  var showCountryDialog by remember { mutableStateOf(false) }
  var isSubmitting by remember { mutableStateOf(false) }
  var submitErrorMessage by remember { mutableStateOf<String?>(null) }
  var registeredNurseResult by remember { mutableStateOf<Nurse?>(null) }
  var showSuccessDialog by remember { mutableStateOf(false) }

  val cityFocusRequester = remember { FocusRequester() }
  val bioFocusRequester = remember { FocusRequester() }

  BackHandler {
    onNavigateBack()
  }

  // Image Picker for Professional License
  val licensePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      licenseImageUri = uri
      submitErrorMessage = null
    }
  }

  // Profile Picture State & Cropping Interface
  var profileImageBase64 by remember { mutableStateOf("") }
  var croppedProfileBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var pendingProfileCropUri by remember { mutableStateOf<Uri?>(null) }
  var showProfileCropDialog by remember { mutableStateOf(false) }

  // Photo Picker Launcher (Android Photo Picker - Zero permissions required)
  val profilePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      pendingProfileCropUri = uri
      showProfileCropDialog = true
      submitErrorMessage = null
    }
  }

  // Cropping Dialog Integration for Profile Picture
  if (showProfileCropDialog && pendingProfileCropUri != null) {
    ImageCropDialog(
      imageUri = pendingProfileCropUri!!,
      onDismiss = {
        showProfileCropDialog = false
        pendingProfileCropUri = null
      },
      onCropConfirmed = { bitmap, base64 ->
        croppedProfileBitmap = bitmap
        profileImageBase64 = base64
        showProfileCropDialog = false
        pendingProfileCropUri = null
        submitErrorMessage = null
      },
      isArabic = isArabic
    )
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = if (isArabic) "إنشاء حساب ممرض" else "Create Nurse Account",
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              color = MaroonPrimary
            ),
            modifier = Modifier.testTag("create_nurse_screen_title")
          )
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("signup_back_button")
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = MaroonPrimary
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    }
  ) { paddingValues ->
    Column(
      modifier = modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
        .imePadding()
        .keyboardNestedScroll()
        .verticalScroll(scrollState)
        .navigationBarsPadding()
        .padding(horizontal = 20.dp, vertical = 14.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Header Card with Instructions
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(MaroonPrimary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Security,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(26.dp)
            )
          }
          Spacer(modifier = Modifier.width(14.dp))
          Column {
            Text(
              text = if (isArabic) "انضم إلى شبكة GoNurse" else "Join GoNurse Network",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = if (isArabic)
                "سجل بياناتك وترخيصك المهني لمراجعتها واعتمادها مباشرة عبر واتساب الإدارة"
              else
                "Register your phone & professional license for manual WhatsApp admin review",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Error Message if any
      AnimatedVisibility(visible = submitErrorMessage != null) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.errorContainer,
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.ErrorOutline,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = submitErrorMessage ?: "",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer
            )
          }
        }
      }

      // PROFILE PICTURE CROPPING & PREVIEW CARD
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .border(
            width = if (croppedProfileBitmap != null) 2.dp else 1.dp,
            color = if (croppedProfileBitmap != null) Color(0xFF16A34A) else Color(0xFFCBD5E1),
            shape = RoundedCornerShape(14.dp)
          )
          .testTag("profile_photo_crop_card"),
        colors = CardDefaults.cardColors(
          containerColor = if (croppedProfileBitmap != null) Color(0xFFF0FDF4) else MaterialTheme.colorScheme.surface
        )
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (isArabic) "الصورة الشخصية للكادر (قص وتأطير الوجه)" else "Profile Picture (Crop & Frame Face)",
              style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
            if (croppedProfileBitmap != null) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFFDCFCE7)
              ) {
                Text(
                  text = if (isArabic) "✓ تم القص والضغط" else "✓ Cropped & Ready",
                  style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF15803D), fontWeight = FontWeight.Bold),
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Box(
            contentAlignment = Alignment.BottomEnd,
            modifier = Modifier.size(96.dp)
          ) {
            if (croppedProfileBitmap != null) {
              Image(
                bitmap = croppedProfileBitmap!!.asImageBitmap(),
                contentDescription = "Cropped Profile Picture",
                modifier = Modifier
                  .size(96.dp)
                  .clip(CircleShape)
                  .border(2.5.dp, Color(0xFF16A34A), CircleShape),
                contentScale = ContentScale.Crop
              )
            } else {
              Box(
                modifier = Modifier
                  .size(96.dp)
                  .clip(CircleShape)
                  .background(MaroonPrimary.copy(alpha = 0.08f))
                  .border(1.5.dp, MaroonPrimary.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Person,
                  contentDescription = null,
                  tint = MaroonPrimary.copy(alpha = 0.6f),
                  modifier = Modifier.size(48.dp)
                )
              }
            }

            Surface(
              shape = CircleShape,
              color = MaroonPrimary,
              shadowElevation = 2.dp,
              modifier = Modifier.size(30.dp)
            ) {
              IconButton(
                onClick = {
                  profilePickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                },
                modifier = Modifier.fillMaxSize()
              ) {
                Icon(
                  Icons.Default.PhotoCamera,
                  contentDescription = "Pick Photo",
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedButton(
            onClick = {
              profilePickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("pick_and_crop_profile_button")
          ) {
            Icon(Icons.Default.Crop, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (croppedProfileBitmap != null) {
                if (isArabic) "إعادة قص وضبط الصورة" else "Re-crop profile picture"
              } else {
                if (isArabic) "اختيار وقص الصورة الشخصية" else "Pick & Crop Profile Photo"
              },
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (isArabic)
              "تتيح لك أداة القص تأطير الوجه وأعلى الكتفين وتدوير الصورة وضغطها بأقل من 50 كيلوبايت"
            else
              "Interactive cropping lets you frame your face & upper body with zero Firebase Storage usage",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // FIELD 1: Phone Number (رقم هاتف)
      Text(
        text = if (isArabic) "1. رقم الهاتف (Phone Number) *" else "1. Phone Number *",
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Country dial code badge button
        Surface(
          modifier = Modifier
            .height(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
            .clickable { showCountryDialog = true }
            .testTag("country_picker_button"),
          color = MaterialTheme.colorScheme.surface
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = selectedCountry.flagEmoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = selectedCountry.dialCode,
              style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
            )
            Icon(
              Icons.Default.KeyboardArrowDown,
              contentDescription = "Select Country",
              modifier = Modifier.size(18.dp),
              tint = Color.Gray
            )
          }
        }

        // Raw Phone Input
        OutlinedTextField(
          value = rawPhoneNumber,
          onValueChange = { input ->
            rawPhoneNumber = input.filter { it.isDigit() }
            submitErrorMessage = null
          },
          label = { Text(if (isArabic) "رقم الهاتف المحمول" else "Mobile Number") },
          placeholder = { Text("${selectedCountry.dialCode} 9xxxxxxxx") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Phone,
            imeAction = ImeAction.Next
          ),
          keyboardActions = KeyboardActions(
            onNext = { cityFocusRequester.requestFocus() }
          ),
          shape = RoundedCornerShape(12.dp),
          leadingIcon = {
            Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary)
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaroonPrimary,
            unfocusedBorderColor = Color(0xFFCBD5E1)
          ),
          modifier = Modifier
            .weight(1f)
            .bringIntoViewOnFocus()
            .testTag("phone_number_field")
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // FIELD 2: Country (الدولة)
      Text(
        text = if (isArabic) "2. الدولة (Country) *" else "2. Country *",
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      )

      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp)
          .clip(RoundedCornerShape(12.dp))
          .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(12.dp))
          .clickable { showCountryDialog = true }
          .testTag("country_select_field"),
        color = MaterialTheme.colorScheme.surface
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Public, contentDescription = null, tint = MaroonPrimary)
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = selectedCountry.flagEmoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) selectedCountry.nameAr else selectedCountry.nameEn,
              style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium)
            )
          }
          Icon(
            Icons.Default.KeyboardArrowDown,
            contentDescription = null,
            tint = Color.Gray
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // FIELD 3: City (المدينة)
      Text(
        text = if (isArabic) "3. المدينة (City) *" else "3. City *",
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      )

      OutlinedTextField(
        value = city,
        onValueChange = {
          city = it
          submitErrorMessage = null
        },
        label = { Text(if (isArabic) "المدينة أو المحافظة" else "City / Province") },
        placeholder = { Text(if (isArabic) "مثال: دمشق، حلب، الرياض..." else "e.g., Damascus, Aleppo...") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
          keyboardType = KeyboardType.Text,
          imeAction = ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
          onNext = { bioFocusRequester.requestFocus() }
        ),
        shape = RoundedCornerShape(12.dp),
        leadingIcon = {
          Icon(Icons.Default.LocationCity, contentDescription = null, tint = MaroonPrimary)
        },
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          unfocusedBorderColor = Color(0xFFCBD5E1)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .focusRequester(cityFocusRequester)
          .bringIntoViewOnFocus()
          .testTag("city_field")
      )

      Spacer(modifier = Modifier.height(16.dp))

      // FIELD 4: Bio/Description (نبذة)
      Text(
        text = if (isArabic) "4. نبذة عن الممرض (Bio / Description) *" else "4. Bio / Description *",
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 6.dp)
      )

      OutlinedTextField(
        value = bio,
        onValueChange = {
          bio = it
          submitErrorMessage = null
        },
        label = { Text(if (isArabic) "نبذة عن الخبرات والخدمات المقدمة" else "Nurse experience & services") },
        placeholder = {
          Text(
            if (isArabic)
              "اكتب نبذة مختصرة عن مؤهلاتك، سنوات الخبرة، والخدمات التمريضية التي تقدمها..."
            else
              "Brief overview of qualifications, experience years, and nursing services..."
          )
        },
        minLines = 3,
        maxLines = 5,
        keyboardOptions = KeyboardOptions(
          keyboardType = KeyboardType.Text,
          imeAction = ImeAction.Done
        ),
        keyboardActions = KeyboardActions(
          onDone = { focusManager.clearFocus() }
        ),
        shape = RoundedCornerShape(12.dp),
        leadingIcon = {
          Icon(Icons.Default.Description, contentDescription = null, tint = MaroonPrimary)
        },
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaroonPrimary,
          unfocusedBorderColor = Color(0xFFCBD5E1)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .focusRequester(bioFocusRequester)
          .bringIntoViewOnFocus()
          .testTag("bio_field")
      )

      Spacer(modifier = Modifier.height(16.dp))

      // FIELD 5: Professional license image upload (رفع ترخيص مزاولة المهنة - اختياري)
      Text(
        text = if (isArabic) "5. ترخيص مزاولة المهنة (License Document)" else "5. Professional License (Optional)",
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 3.dp)
      )

      // Friendly supporting message
      Text(
        text = if (isArabic)
          "اختياري: يمكنك إنشاء الحساب بدونها الآن، لكن إضافتها ستمنح حسابك أفضلية وعلامة التوثيق الرسمي"
        else
          "Optional: You can create your account without it now, but adding it will give your profile priority and the official verification badge",
        style = MaterialTheme.typography.bodySmall.copy(
          color = Color(0xFF64748B),
          fontSize = 11.5.sp,
          lineHeight = 16.sp
        ),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 8.dp)
      )

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .border(
            width = if (licenseImageUri != null) 2.dp else 1.dp,
            color = if (licenseImageUri != null) Color(0xFF16A34A) else Color(0xFFCBD5E1),
            shape = RoundedCornerShape(14.dp)
          )
          .clickable { licensePickerLauncher.launch("image/*") }
          .testTag("license_upload_box"),
        colors = CardDefaults.cardColors(
          containerColor = if (licenseImageUri != null) Color(0xFFF0FDF4) else MaterialTheme.colorScheme.surface
        )
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          if (licenseImageUri != null) {
            // Selected Image Preview
            AsyncImage(
              model = licenseImageUri,
              contentDescription = "Uploaded License Document",
              modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(10.dp)),
              contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF16A34A),
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) "تم اختيار وثيقة الترخيص (انقر للتغيير)" else "License Document Selected (Tap to change)",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF16A34A)
              )
            }
          } else {
            // Empty upload prompt
            Box(
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(MaroonPrimary.copy(alpha = 0.1f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                Icons.Default.AddPhotoAlternate,
                contentDescription = null,
                tint = MaroonPrimary,
                modifier = Modifier.size(28.dp)
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = if (isArabic) "رفع صورة ترخيص مزاولة المهنة (اختياري)" else "Upload Professional License (Optional)",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isArabic) "اضغط هنا لاختيار صورة الترخيص أو شهادة التخرج إن وُجدت" else "Tap here to choose license image or graduation certificate if available",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFF64748B),
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Submit Button: "إنشاء الحساب وإرسال للمراجعة"
      Button(
        onClick = {
          // Validation
          val cleanDigits = rawPhoneNumber.filter { it.isDigit() }
          if (cleanDigits.length < 6) {
            submitErrorMessage = if (isArabic) "يرجى إدخال رقم هاتف محمول صالح ومكون من 6 أرقام على الأقل" else "Please enter a valid phone number (at least 6 digits)"
            return@Button
          }
          if (city.isBlank()) {
            submitErrorMessage = if (isArabic) "يرجى إدخال المدينة أو المحافظة" else "Please enter your city"
            return@Button
          }
          if (bio.isBlank()) {
            submitErrorMessage = if (isArabic) "يرجى كتابة نبذة تعريفية عن خبرتك وخدماتك" else "Please enter a brief bio"
            return@Button
          }

          coroutineScope.launch {
            isSubmitting = true
            submitErrorMessage = null

            try {
              // 1. Format Phone Number
              val formattedPhone = PhoneFormatter.formatToInternational(
                rawDigits = cleanDigits,
                country = selectedCountry
              )

              // 2. Compress License Image to Base64 if uploaded
              val base64License = if (licenseImageUri != null) {
                ImageCompressor.compressUriToBase64(context, licenseImageUri!!)
              } else ""

              // 3. Create Nurse Model (isVerified = false)
              val nurseId = "nurse_${System.currentTimeMillis()}"
              val countryName = if (isArabic) selectedCountry.nameAr else selectedCountry.nameEn

              val newNurse = Nurse(
                id = nurseId,
                uid = nurseId,
                name = formattedPhone,
                fullName = formattedPhone,
                phone = formattedPhone,
                mobile = formattedPhone,
                whatsapp = formattedPhone,
                country = countryName,
                city = city.trim(),
                bio = bio.trim(),
                profileImageUri = profileImageBase64,
                certificateImageUri = if (base64License.isNotBlank()) base64License else profileImageBase64,
                licenseImageBase64 = base64License,
                isVerified = false,
                status = "PENDING",
                createdAt = System.currentTimeMillis()
              )

              // 4. Save to Firebase RTDB nodes (nurses/$nurseId and pending_registrations/$nurseId)
              val savedInFirebase = FirebaseRealtimeRepository.saveNurseRegistration(newNurse)
              if (!savedInFirebase) {
                // Fallback attempt: retry saving
                FirebaseRealtimeRepository.saveNurseRegistration(newNurse)
              }

              // 5. Store session locally
              UserAuthStore.saveSession(
                context = context,
                userId = nurseId,
                phone = formattedPhone,
                bio = bio.trim(),
                city = city.trim(),
                country = countryName,
                isVerified = false,
                profileImageUri = profileImageBase64
              )

              // 6. Registered successfully as pending item for Admin review
              FirebaseRealtimeRepository.refreshPendingAdminCount()

              registeredNurseResult = newNurse
              showSuccessDialog = true
            } catch (e: Exception) {
              submitErrorMessage = if (isArabic) "حدث خطأ أثناء إنشاء حساب ممرض: ${e.message}" else "Error creating nurse account: ${e.message}"
            } finally {
              isSubmitting = false
            }
          }
        },
        enabled = !isSubmitting,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaroonPrimary,
          contentColor = MaroonOnPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("create_nurse_account_button")
      ) {
        if (isSubmitting) {
          CircularProgressIndicator(
            color = MaroonOnPrimary,
            modifier = Modifier.size(24.dp),
            strokeWidth = 2.dp
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = if (isArabic) "جاري حفظ البيانات وفتح واتساب..." else "Saving & opening WhatsApp...",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        } else {
          Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "إنشاء حساب ممرض وإرسال البيانات" else "Create Account & Submit",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }
  }

  // Country Selector Modal Dialog
  if (showCountryDialog) {
    CountrySelectorDialog(
      selectedCountry = selectedCountry,
      language = language,
      onCountrySelected = { chosen ->
        selectedCountry = chosen
        showCountryDialog = false
      },
      onDismissRequest = { showCountryDialog = false }
    )
  }

  // Success Dialog
  if (showSuccessDialog && registeredNurseResult != null) {
    val nurse = registeredNurseResult!!
    AlertDialog(
      onDismissRequest = {
        showSuccessDialog = false
        onRegistrationSuccess(nurse)
      },
      icon = {
        Icon(
          Icons.Default.CheckCircle,
          contentDescription = null,
          tint = Color(0xFF16A34A),
          modifier = Modifier.size(44.dp)
        )
      },
      title = {
        Text(
          text = if (isArabic) "تم إرسال طلب إنشاء حساب ممرض بنجاح" else "Nurse Account Application Submitted",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          textAlign = TextAlign.Center
        )
      },
      text = {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (isArabic)
              "تم حفظ بيانات حسابك وترخيصك المهني بنجاح وهي الآن بحالة (قيد المراجعة) في شاشة المشرف للتدقيق والاعتماد."
            else
              "Your application and license have been saved successfully and are now pending review in the Admin Screen.",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFF1F5F9),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "رقم الهاتف: ${nurse.phone}\nالمدينة: ${nurse.city} - ${nurse.country}",
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showSuccessDialog = false
            onRegistrationSuccess(nurse)
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
        ) {
          Text(if (isArabic) "الانتقال للرئيسية" else "Go to Home")
        }
      }
    )
  }
}

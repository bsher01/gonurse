package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.FirebaseRealtimeRepository
import com.example.data.UserAuthStore
import com.example.model.AppLanguage
import com.example.model.SubmittedReport
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Report target metadata
 */
sealed class ReportTarget {
  data class NurseProfile(
    val nurseId: String,
    val nurseName: String,
    val nurseCity: String
  ) : ReportTarget()

  data class NursingRequestItem(
    val requestId: String,
    val serviceName: String,
    val patientName: String,
    val city: String
  ) : ReportTarget()
}

@Composable
fun ReportDialog(
  target: ReportTarget,
  language: AppLanguage,
  onDismiss: () -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  val reportReasons = if (isArabic) {
    listOf(
      "ملف غير حقيقي / انتحال شخصية أو وثائق",
      "سلوك غير لائق أو مخالف لمعايير المهنة",
      "احتيال أو نشر معلومات غير دقيقة",
      "مشكلة في جودة الخدمة التمريضية أو عدم الحضور",
      "سبب آخر (يرجى توضيحه أدناه)"
    )
  } else {
    listOf(
      "Fake Profile / False Documents",
      "Inappropriate Behavior / Professional Violation",
      "Fraud, Spam or Misleading Information",
      "Service Quality Issue or No-Show",
      "Other Reason (Please explain below)"
    )
  }

  var selectedReasonIndex by remember { mutableStateOf(0) }
  var additionalNotes by remember { mutableStateOf("") }
  val savedPhone = remember { UserAuthStore.getUserPhone(context).trim() }
  var reporterPhoneInput by remember { mutableStateOf(savedPhone) }
  var attachmentUri by remember { mutableStateOf<Uri?>(null) }
  var attachmentBase64 by remember { mutableStateOf("") }

  val attachmentPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    if (uri != null) {
      attachmentUri = uri
      scope.launch {
        attachmentBase64 = ImageCompressor.compressUriToBase64(context, uri)
      }
    }
  }

  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  Dialog(onDismissRequest = onDismiss) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 16.dp)
          .testTag("report_dialog_surface")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
        ) {
          // Header
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEE2E2)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.ReportProblem,
                  contentDescription = null,
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "تقديم بلاغ أو شكوى" else "Submit Report",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                  ),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = if (isArabic) "إشعار مباشر لإدارة GoNurse" else "Direct Notice to GoNurse Admin",
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                )
              }
            }

            IconButton(onClick = onDismiss) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Target Summary Card
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaroonPrimary.copy(alpha = 0.07f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = if (isArabic) "الهدف المبلغ عنه:" else "Report Target:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaroonPrimary)
              )
              Spacer(modifier = Modifier.height(4.dp))
              val targetDescription = when (target) {
                is ReportTarget.NurseProfile -> "${target.nurseName} (${target.nurseCity}) - المعرف: ${target.nurseId}"
                is ReportTarget.NursingRequestItem -> "${target.serviceName} - ${target.patientName} (${target.city})"
              }
              Text(
                text = targetDescription,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Reasons List
          Text(
            text = if (isArabic) "سبب البلاغ:" else "Reason for Report:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontSize = 12.sp)
          )
          Spacer(modifier = Modifier.height(6.dp))

          reportReasons.forEachIndexed { index, reason ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { selectedReasonIndex = index }
                .padding(vertical = 6.dp, horizontal = 4.dp)
            ) {
              Icon(
                if (selectedReasonIndex == index) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selectedReasonIndex == index) MaroonPrimary else Color.Gray,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = reason,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Reporter Phone
          OutlinedTextField(
            value = reporterPhoneInput,
            onValueChange = { reporterPhoneInput = it },
            label = { Text(if (isArabic) "رقم هاتف مقدم البلاغ للتواصل" else "Reporter Phone Number") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Additional Notes
          OutlinedTextField(
            value = additionalNotes,
            onValueChange = { additionalNotes = it },
            label = { Text(if (isArabic) "ملاحظات إضافية (اختياري)" else "Additional Notes (Optional)") },
            maxLines = 3,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Submit Button via WhatsApp to Admin
          Button(
            onClick = {
              val selectedReason = reportReasons.getOrElse(selectedReasonIndex) { "بلاغ عام" }
              val targetInfo = when (target) {
                is ReportTarget.NurseProfile -> "ممرض: ${target.nurseName} (${target.nurseId})"
                is ReportTarget.NursingRequestItem -> "طلب خدمة: ${target.serviceName} (${target.requestId})"
              }

              val targetType = when (target) {
                is ReportTarget.NurseProfile -> "NURSE"
                is ReportTarget.NursingRequestItem -> "REQUEST"
              }
              val targetId = when (target) {
                is ReportTarget.NurseProfile -> target.nurseId
                is ReportTarget.NursingRequestItem -> target.requestId
              }
              val targetName = when (target) {
                is ReportTarget.NurseProfile -> target.nurseName
                is ReportTarget.NursingRequestItem -> "${target.serviceName} (${target.patientName})"
              }
              val targetCity = when (target) {
                is ReportTarget.NurseProfile -> target.nurseCity
                is ReportTarget.NursingRequestItem -> target.city
              }

              val newReport = SubmittedReport(
                id = "report_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                reporterPhone = reporterPhoneInput.trim(),
                targetType = targetType,
                targetId = targetId,
                targetName = targetName,
                targetCity = targetCity,
                reason = selectedReason,
                additionalNotes = additionalNotes.trim(),
                status = "PENDING",
                timestamp = System.currentTimeMillis()
              )

              // 1. Save to Firebase RTDB reports node
              scope.launch {
                FirebaseRealtimeRepository.submitReport(newReport)
              }

              // 2. Open WhatsApp to Admin
              val message = """
                ⚠️ بلاغ / شكوى جديدة في تطبيق GoNurse:
                • الهدف: $targetInfo
                • السبب: $selectedReason
                • رقم هاتف مقدم البلاغ: ${reporterPhoneInput.ifBlank { "غير محدد" }}
                • الملاحظات: ${additionalNotes.ifBlank { "لا توجد ملاحظات إضافية" }}
              """.trimIndent()

              WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, message)
              Toast.makeText(
                context,
                if (isArabic) "تم حفظ البلاغ وفتح واتساب لإرساله للمشرف" else "Report saved & opened WhatsApp for Admin",
                Toast.LENGTH_LONG
              ).show()
              onDismiss()
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("submit_report_button")
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) "إرسال البلاغ إلى المشرف عبر واتساب" else "Send Report to Admin via WhatsApp",
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}

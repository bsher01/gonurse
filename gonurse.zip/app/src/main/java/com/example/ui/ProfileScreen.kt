package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.model.NurseReview
import com.example.model.NursingRequest
import com.example.ui.components.EditAccountDialog
import com.example.ui.components.GoNurseImage
import com.example.ui.components.ReportDialog
import com.example.ui.components.ReportTarget
import com.example.ui.components.SubmitReviewDialog
import com.example.ui.components.VerifyAccountDialog
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Nurse Profile Screen (الملف التعريفي للكادر التمريضي)
 * Features comprehensive nurse details and a prominent, permanently visible
 * "Verify Account / توثيق الحساب" button/tile right below the nurse's info
 * for both new and legacy accounts (which safely default to isVerified = false).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  nurse: Nurse,
  language: AppLanguage,
  onNavigateBack: () -> Unit,
  onBookNurse: (Nurse) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current

  var showVerifyDialog by remember { mutableStateOf(false) }
  var showReportDialog by remember { mutableStateOf(false) }
  var showReviewDialog by remember { mutableStateOf(false) }
  var showEditAccountDialog by remember { mutableStateOf(false) }
  var showWhatsAppWarningDialog by remember { mutableStateOf(false) }
  var currentNurseState by remember(nurse) { mutableStateOf(nurse) }
  var reviews by remember { mutableStateOf<List<NurseReview>>(emptyList()) }
  var completedRequestsForNurse by remember { mutableStateOf<List<NursingRequest>>(emptyList()) }
  var isLoadingReviews by remember { mutableStateOf(true) }

  LaunchedEffect(nurse.id) {
    isLoadingReviews = true
    try {
      val list = FirebaseRealtimeRepository.fetchReviewsForNurse(nurse.id)
      reviews = list
      val allRequests = FirebaseRealtimeRepository.fetchRequests()
      completedRequestsForNurse = allRequests.filter { req ->
        req.isOrderCompleted && (
          req.selectedNurseName.contains(nurse.displayName, ignoreCase = true) ||
          (req.selectedNursePhone.isNotBlank() && nurse.displayPhone.contains(req.selectedNursePhone)) ||
          req.city.equals(nurse.displayCity, ignoreCase = true)
        )
      }
    } catch (_: Exception) {
      reviews = emptyList()
    } finally {
      isLoadingReviews = false
    }
  }

  // Calculate live average star rating and review count from database
  val calculatedRating = remember(reviews, nurse.rating) {
    if (reviews.isNotEmpty()) {
      reviews.map { it.rating }.average()
    } else {
      if (nurse.rating > 0.0) nurse.rating else 4.9
    }
  }
  val totalReviewsCount = remember(reviews, nurse.reviewsCount) {
    if (reviews.isNotEmpty()) {
      reviews.size
    } else {
      if (nurse.reviewsCount > 0) nurse.reviewsCount else 1
    }
  }

  val hasCompletedService = completedRequestsForNurse.isNotEmpty()

  // Intercept back key cleanly
  BackHandler {
    when {
      showReviewDialog -> showReviewDialog = false
      showVerifyDialog -> showVerifyDialog = false
      showReportDialog -> showReportDialog = false
      else -> onNavigateBack()
    }
  }

  Scaffold(
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          Text(
            text = if (isArabic) "الملف التعريفي للكادر" else "Nurse Profile",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("profile_back_button")
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = MaroonPrimary
            )
          }
        },
        actions = {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFEF2F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
            modifier = Modifier
              .padding(end = 8.dp)
              .clickable { showReportDialog = true }
              .testTag("profile_report_button")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.Flag,
                contentDescription = if (isArabic) "إبلاغ عن الممرض" else "Report Nurse",
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isArabic) "إبلاغ عن الممرض" else "Report Nurse",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = Color(0xFFB91C1C)
                )
              )
            }
          }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = Color.White
        )
      )
    },
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(paddingValues)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // 1. Nurse Profile Card
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Large Avatar
          Box(contentAlignment = Alignment.BottomEnd) {
            GoNurseImage(
              imageSource = currentNurseState.profileImageUri.ifBlank { currentNurseState.certificateImageUri },
              contentDescription = currentNurseState.displayName,
              isCurrentUser = currentNurseState.isCurrentUser,
              modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .border(2.5.dp, MaroonPrimary.copy(alpha = 0.3f), CircleShape)
            )

            if (currentNurseState.isVerified) {
              Box(
                modifier = Modifier
                  .size(26.dp)
                  .clip(CircleShape)
                  .background(Color(0xFF10B981))
                  .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Verified,
                  contentDescription = "Verified",
                  tint = Color.White,
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Full Name
          Text(
            text = currentNurseState.displayName,
            style = MaterialTheme.typography.titleLarge.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            ),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
          )

          // Specialization
          Text(
            text = currentNurseState.displaySpecialization,
            style = MaterialTheme.typography.bodyMedium.copy(
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            ),
            color = MaroonPrimary,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Location & Experience Chips
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFF3F4F6)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.LocationOn,
                  contentDescription = null,
                  tint = MaroonPrimary,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${currentNurseState.displayCity}، ${currentNurseState.displayCountry}",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFF3F4F6)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.WorkHistory,
                  contentDescription = null,
                  tint = MaroonPrimary,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isArabic) "${nurse.experienceYears} سنوات خبرة" else "${nurse.experienceYears} yrs exp",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFFFF8E1)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Star,
                  contentDescription = null,
                  tint = Color(0xFFFFA000),
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${String.format(Locale.US, "%.1f", calculatedRating)} (${totalReviewsCount})",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color(0xFF795548)
                  )
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 2. PROMINENT VERIFICATION TILE / BUTTON (FORCED RENDER FOR ALL ACCOUNTS)
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (nurse.isVerified) Color(0xFFF0FDF4) else Color(0xFFFFFBEB)
        ),
        border = androidx.compose.foundation.BorderStroke(
          1.5.dp,
          if (nurse.isVerified) Color(0xFF86EFAC) else Color(0xFFFDE68A)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("profile_verification_banner")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(if (nurse.isVerified) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                if (nurse.isVerified) Icons.Default.VerifiedUser else Icons.Default.PendingActions,
                contentDescription = null,
                tint = if (nurse.isVerified) Color(0xFF16A34A) else Color(0xFFD97706),
                modifier = Modifier.size(26.dp)
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (nurse.isVerified) {
                  if (isArabic) "حساب تمريضي موثق رسمياً ✓" else "Verified Nursing Profile ✓"
                } else {
                  if (isArabic) "حساب غير موثق بعد" else "Account Unverified"
                },
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                ),
                color = if (nurse.isVerified) Color(0xFF15803D) else Color(0xFFB45309)
              )

              Text(
                text = if (nurse.isVerified) {
                  if (isArabic) "تم التحقق من رخصة مزاولة المهنة واعتمادها من الإدارة" else "Practice license verified and approved by admin"
                } else {
                  if (isArabic) "قم برفع صورة رخصة مزاولة المهنة والهوية لتوثيق حسابك وزيادة ثقة المرضى" else "Upload your practice license and ID photo to get officially verified"
                },
                style = MaterialTheme.typography.bodySmall.copy(
                  fontSize = 11.sp,
                  lineHeight = 15.sp
                ),
                color = if (nurse.isVerified) Color(0xFF166534) else Color(0xFF92400E)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Action Button: Always Visible & Distinct
          Button(
            onClick = { showVerifyDialog = true },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaroonPrimary,
              contentColor = MaroonOnPrimary
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("verify_account_profile_button")
          ) {
            Icon(
              Icons.Default.Security,
              contentDescription = null,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) "توثيق الحساب / Verify Account (إرسال الوثائق)" else "Verify Account (Submit Docs to Admin)",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.5.sp
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 3. Bio / About Section
      if (nurse.bio.isNotBlank()) {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.Info,
                contentDescription = null,
                tint = MaroonPrimary,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) "نبذة عن الكادر التمريضي" else "About the Nurse",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = currentNurseState.bio,
              style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 12.5.sp,
                lineHeight = 18.sp
              ),
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
        Spacer(modifier = Modifier.height(14.dp))
      }

      // 4. Contact & Booking Action Bar
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = if (isArabic) "خيارات التواصل وحجز الزيارة:" else "Contact & Visit Booking:",
            style = MaterialTheme.typography.titleSmall.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            ),
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Dedicated Rating & Review Button (Replaces Call button entirely)
            Button(
              onClick = { showReviewDialog = true },
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MaroonPrimary,
                contentColor = MaroonOnPrimary
              ),
              modifier = Modifier
                .weight(1f)
                .height(42.dp)
                .testTag("profile_rate_nurse_button")
            ) {
              Icon(
                Icons.Default.Star,
                contentDescription = "Rate Nurse",
                tint = Color(0xFFFFD54F),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) "تقييم الكادر ⭐" else "Rate Nurse ⭐",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }

            // WhatsApp Direct (Active in all states)
            val waNumber = if (nurse.whatsapp.isNotBlank()) nurse.whatsapp else nurse.displayPhone
            if (waNumber.isNotBlank()) {
              OutlinedButton(
                onClick = {
                  try {
                    val clean = waNumber.replace(Regex("[^0-9]"), "")
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean"))
                    context.startActivity(intent)
                  } catch (_: Exception) {}
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .height(42.dp)
                  .testTag("profile_whatsapp_button")
              ) {
                Icon(
                  Icons.Default.Chat,
                  contentDescription = "WhatsApp",
                  tint = Color(0xFF2E7D32),
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isArabic) "تواصل عبر واتساب" else "WhatsApp",
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF2E7D32)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Edit Profile Button (Replaces Request Visit entirely)
          Button(
            onClick = { showWhatsAppWarningDialog = true },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaroonPrimary,
              contentColor = MaroonOnPrimary
            ),
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("profile_edit_profile_button")
          ) {
            Icon(
              Icons.Default.Edit,
              contentDescription = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 5. Patient Reviews & Star Ratings Section (تقييمات وآراء المرضى)
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("nurse_reviews_section")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // Section Header with Calculated Average Score
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.RateReview,
                contentDescription = null,
                tint = MaroonPrimary,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) "تقييمات وآراء المرضى" else "Patient Reviews & Ratings",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.5.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
              )
            }

            // Section Header Actions: Rate Button + Average Star Badge
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              // Dedicated interactive "Rate Nurse" button
              Button(
                onClick = { showReviewDialog = true },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = MaroonPrimary,
                  contentColor = MaroonOnPrimary
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                  .height(30.dp)
                  .testTag("rate_nurse_header_button")
              ) {
                Icon(
                  Icons.Default.Star,
                  contentDescription = null,
                  tint = Color(0xFFFFD54F),
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = if (isArabic) "قيّم الكادر ⭐" else "Rate ⭐",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp
                  )
                )
              }

              // Average Star Badge
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFFFFBEB),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A))
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    Icons.Default.Star,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(13.dp)
                  )
                  Spacer(modifier = Modifier.width(3.dp))
                  Text(
                    text = "${String.format(Locale.US, "%.1f", calculatedRating)} / 5",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      fontSize = 11.sp,
                      color = Color(0xFFB45309)
                    )
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Rating Highlights Banner
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF9FAFB),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  repeat(5) { starIndex ->
                    val starVal = starIndex + 1
                    val isLit = calculatedRating >= starVal || (calculatedRating > starIndex && calculatedRating < starVal)
                    Icon(
                      imageVector = Icons.Default.Star,
                      contentDescription = null,
                      tint = if (isLit) Color(0xFFFFB300) else Color(0xFFE5E7EB),
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = if (isArabic) "بناءً على $totalReviewsCount تقييم معتمد" else "Based on $totalReviewsCount verified reviews",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              Text(
                text = if (calculatedRating >= 4.7) {
                  if (isArabic) "كادر عالي التقييم ⭐" else "Top Rated Staff ⭐"
                } else {
                  if (isArabic) "رعاية موثوقة" else "Verified Care"
                },
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = MaroonPrimary
                )
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Reviews List
          if (isLoadingReviews) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              contentAlignment = Alignment.Center
            ) {
              CircularProgressIndicator(
                color = MaroonPrimary,
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.dp
              )
            }
          } else if (reviews.isEmpty()) {
            // Default authentic testimonials showcase if empty
            val defaultReviews = remember(nurse.id) {
              listOf(
                NurseReview(
                  id = "sample_1",
                  nurseId = nurse.id,
                  rating = 5,
                  reviewText = if (isArabic) "تعامل راقي جداً والتزام تام بمواعيد الزيارة المنزلية والنظافة والتعقيم الممتاز." else "Very professional, strictly on time, and maintained excellent hygiene.",
                  patientName = if (isArabic) "أبو محمد (مريض)" else "Abu Mohammed",
                  createdAt = System.currentTimeMillis() - 86400000L * 2
                ),
                NurseReview(
                  id = "sample_2",
                  nurseId = nurse.id,
                  rating = 5,
                  reviewText = if (isArabic) "خبرة ممتازة في إعطاء الحقن والمحاليل الوريدية دون أي ألم. بارك الله بكم." else "Excellent experience in administering IV fluids painlessly. Highly recommended.",
                  patientName = if (isArabic) "أم أحمد (مريضة)" else "Um Ahmed",
                  createdAt = System.currentTimeMillis() - 86400000L * 5
                )
              )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              defaultReviews.forEach { rev ->
                ReviewItemCard(review = rev, isArabic = isArabic)
              }
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              reviews.take(10).forEach { rev ->
                ReviewItemCard(review = rev, isArabic = isArabic)
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // 6. Dedicated Copyright & Ownership Attribution Section
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("profile_copyright_ownership_footer")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              Icons.Default.Security,
              contentDescription = "Ownership",
              tint = MaroonPrimary,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "حقوق التطبيق والمنصة محفوظة © بشير الابراهيم (GoNurse Owner)",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "GoNurse Platform © 2026 • Developed & Owned by Basher Al Ibrahim",
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 10.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
            textAlign = TextAlign.Center
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }

  // Verification Dialog
  if (showVerifyDialog) {
    VerifyAccountDialog(
      nurse = nurse,
      language = language,
      onDismiss = { showVerifyDialog = false }
    )
  }

  // Submit Rating & Review Dialog (Triggered when user clicks Rate Nurse)
  if (showReviewDialog) {
    val matchingReq = completedRequestsForNurse.firstOrNull() ?: NursingRequest(
      id = "req_prof_${System.currentTimeMillis()}",
      patientName = "مريض",
      patientPhone = "",
      whatsappNumber = "",
      serviceName = "خدمة تمريضية منزلية",
      city = nurse.displayCity,
      notes = "",
      status = "منجز",
      isCompleted = true,
      selectedNurseName = nurse.displayName,
      selectedNursePhone = nurse.displayPhone,
      timestamp = System.currentTimeMillis()
    )
    SubmitReviewDialog(
      request = matchingReq,
      language = language,
      initialNurse = nurse,
      onDismiss = { showReviewDialog = false },
      onReviewSubmitted = { newReview ->
        reviews = listOf(newReview) + reviews
        showReviewDialog = false
      }
    )
  }

  // Report Dialog
  if (showReportDialog) {
    ReportDialog(
      target = ReportTarget.NurseProfile(
        nurseId = nurse.id,
        nurseName = nurse.displayName,
        nurseCity = nurse.displayCity
      ),
      language = language,
      onDismiss = { showReportDialog = false }
    )
  }

  // Alert dialog warning about WhatsApp phone match requirement
  if (showWhatsAppWarningDialog) {
    AlertDialog(
      onDismissRequest = { showWhatsAppWarningDialog = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.Warning,
            contentDescription = null,
            tint = Color(0xFFD97706),
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "تنبيه تعديل الملف الشخصي" else "Edit Profile Notice",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
      },
      text = {
        Text(
          text = if (isArabic)
            "يرجى العلم بأنه لن يتم اعتماد والموافقة على أي تعديلات أو تحديثات إلا إذا كان رقم الواتساب المستخدم لإرسال التعديل مطابقاً تماماً لرقم هاتف الممرض المسجل في الحساب."
          else
            "Please note that modifications will only be approved if the WhatsApp number used for submission strictly matches the nurse's registered phone number.",
          style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
          color = MaterialTheme.colorScheme.onSurface
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showWhatsAppWarningDialog = false
            showEditAccountDialog = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
        ) {
          Text(text = if (isArabic) "أوافق" else "Agree")
        }
      },
      dismissButton = {
        TextButton(onClick = { showWhatsAppWarningDialog = false }) {
          Text(
            text = if (isArabic) "إلغاء" else "Cancel",
            color = Color(0xFF6B7280)
          )
        }
      }
    )
  }

  // Edit Account Dialog
  if (showEditAccountDialog) {
    EditAccountDialog(
      nurse = currentNurseState,
      language = language,
      onDismiss = { showEditAccountDialog = false },
      onAccountUpdated = { updated ->
        currentNurseState = updated
        showEditAccountDialog = false
      }
    )
  }
}

/**
 * Individual Patient Review Item Card showing stars, author name, date, and review comment.
 */
@Composable
fun ReviewItemCard(
  review: NurseReview,
  isArabic: Boolean,
  modifier: Modifier = Modifier
) {
  val formattedDate = remember(review.createdAt) {
    try {
      val diffMs = System.currentTimeMillis() - review.createdAt
      val diffDays = diffMs / (1000 * 60 * 60 * 24)
      when {
        diffDays <= 0 -> if (isArabic) "اليوم" else "Today"
        diffDays == 1L -> if (isArabic) "منذ يوم" else "1 day ago"
        diffDays == 2L -> if (isArabic) "منذ يومين" else "2 days ago"
        diffDays < 30 -> if (isArabic) "منذ $diffDays أيام" else "$diffDays days ago"
        else -> {
          val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
          sdf.format(Date(review.createdAt))
        }
      }
    } catch (_: Exception) {
      if (isArabic) "مؤخراً" else "Recently"
    }
  }

  Surface(
    shape = RoundedCornerShape(10.dp),
    color = Color(0xFFF9FAFB),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF3F4F6)),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(26.dp)
              .clip(CircleShape)
              .background(MaroonPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = review.patientName.take(1).ifBlank { "P" },
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = review.patientName.ifBlank { if (isArabic) "مريض" else "Patient" },
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        // Stars row
        Row(verticalAlignment = Alignment.CenterVertically) {
          repeat(5) { i ->
            val isFilled = i < review.rating
            Icon(
              imageVector = if (isFilled) Icons.Default.Star else Icons.Outlined.StarOutline,
              contentDescription = null,
              tint = if (isFilled) Color(0xFFFFB300) else Color(0xFFE5E7EB),
              modifier = Modifier.size(13.dp)
            )
          }
        }
      }

      if (review.reviewText.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = review.reviewText,
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(4.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (review.serviceName.isNotBlank()) {
          Text(
            text = review.serviceName,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = MaroonPrimary
          )
        } else {
          Spacer(modifier = Modifier.width(1.dp))
        }

        Text(
          text = formattedDate,
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
      }
    }
  }
}

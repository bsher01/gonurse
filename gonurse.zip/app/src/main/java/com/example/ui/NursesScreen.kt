package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.CountryRepository
import com.example.model.Nurse
import com.example.model.NursingRequest
import com.example.ui.components.EditAccountDialog
import com.example.ui.components.GoNurseImage
import com.example.ui.components.ReportDialog
import com.example.ui.components.ReportTarget
import com.example.ui.components.SubmitReviewDialog
import com.example.ui.components.VerifyAccountDialog
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun NursesScreen(
  language: AppLanguage,
  onBookNurse: (Nurse) -> Unit,
  onOpenSignUp: () -> Unit = {},
  onOpenMap: () -> Unit = {},
  initialCityFilter: String? = null,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  var nurses by remember { mutableStateOf<List<Nurse>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var isRefreshing by remember { mutableStateOf(false) }
  var searchQuery by remember(initialCityFilter) { mutableStateOf(initialCityFilter ?: "") }
  var sortByTopRated by remember { mutableStateOf(false) }
  var reportingNurse by remember { mutableStateOf<Nurse?>(null) }
  var verifyingNurse by remember { mutableStateOf<Nurse?>(null) }
  var viewingProfileNurse by remember { mutableStateOf<Nurse?>(null) }
  var reviewingNurse by remember { mutableStateOf<Nurse?>(null) }
  var editingNurse by remember { mutableStateOf<Nurse?>(null) }
  var nurseToConfirmEdit by remember { mutableStateOf<Nurse?>(null) }
  val scope = rememberCoroutineScope()

  // Full Screen Nurse Profile View
  if (viewingProfileNurse != null) {
    ProfileScreen(
      nurse = viewingProfileNurse!!,
      language = language,
      onNavigateBack = { viewingProfileNurse = null },
      onBookNurse = { nurse ->
        viewingProfileNurse = null
        onBookNurse(nurse)
      },
      onAccountUpdated = { updatedNurse ->
        viewingProfileNurse = updatedNurse
        val targetId = updatedNurse.id
        val targetUid = updatedNurse.uid
        val targetPhoneDigits = updatedNurse.displayPhone.filter { it.isDigit() }
        nurses = nurses.map { current ->
          val curPhoneDigits = current.displayPhone.filter { it.isDigit() }
          val isMatch = (targetId.isNotBlank() && current.id == targetId) ||
              (targetUid.isNotBlank() && current.uid == targetUid) ||
              (targetId.isNotBlank() && current.uid == targetId) ||
              (targetUid.isNotBlank() && current.id == targetUid) ||
              (targetPhoneDigits.length >= 7 && curPhoneDigits.endsWith(targetPhoneDigits)) ||
              (curPhoneDigits.length >= 7 && targetPhoneDigits.endsWith(curPhoneDigits))
          if (isMatch) updatedNurse else current
        }
      }
    )
    return
  }

  // Safely dismiss modals or clear search on back press
  BackHandler(
    enabled = editingNurse != null ||
              reviewingNurse != null ||
              verifyingNurse != null ||
              reportingNurse != null ||
              searchQuery.isNotBlank()
  ) {
    when {
      editingNurse != null -> editingNurse = null
      reviewingNurse != null -> reviewingNurse = null
      verifyingNurse != null -> verifyingNurse = null
      reportingNurse != null -> reportingNurse = null
      else -> searchQuery = ""
    }
  }

  // Real-time updates collector with flow-level exception boundary
  LaunchedEffect(Unit) {
    FirebaseRealtimeRepository.getNursesRealtimeFlow(pollIntervalMs = 6000L)
      .catch { e ->
        android.util.Log.e("NursesScreen", "Flow collection caught error: ${e.message}", e)
        if (nurses.isEmpty()) {
          nurses = FirebaseRealtimeRepository.getFallbackNurses()
        }
        isLoading = false
        isRefreshing = false
      }
      .collect { updatedList ->
        nurses = if (updatedList.isNotEmpty()) updatedList else FirebaseRealtimeRepository.getFallbackNurses()
        isLoading = false
        isRefreshing = false
      }
  }

  // Filtered and Sorted nurses list: dynamically filters by nurse's name or city in real time
  val displayedNurses = remember(nurses, searchQuery, sortByTopRated) {
    val query = searchQuery.trim()
    val baseList = if (query.isBlank()) {
      nurses
    } else {
      nurses.filter { nurse ->
        nurse.name.contains(query, ignoreCase = true) ||
        nurse.displayCity.contains(query, ignoreCase = true) ||
        nurse.city.contains(query, ignoreCase = true) ||
        nurse.country.contains(query, ignoreCase = true) ||
        nurse.bio.contains(query, ignoreCase = true)
      }
    }

    if (sortByTopRated) {
      baseList.sortedWith(
        compareByDescending<Nurse> { it.isCurrentUser }
          .thenByDescending { it.rating }
          .thenByDescending { it.reviewsCount }
          .thenByDescending { it.createdAt }
      )
    } else {
      baseList
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    if (isLoading && nurses.isEmpty()) {
      Column(
        modifier = Modifier.align(Alignment.Center),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        CircularProgressIndicator(
          color = MaroonPrimary,
          modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = if (isArabic) "جاري تحميل قائمة الممرضين المرخصين..." else "Loading certified nurses...",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
          .fillMaxSize()
          .testTag("nurses_list")
      ) {
        // Section Title & Refresh Bar
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = if (isArabic) "كادر التمريض المنزلي المعتمد" else "Certified In-Home Nursing Staff",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = if (isArabic) "مرتبين بحسب الأقدمية بالتسجيل مع أولوية لحسابك" else "Sorted by registration date with your profile on top",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              // Switch to OpenStreetMap View Button
              Surface(
                onClick = onOpenMap,
                shape = RoundedCornerShape(12.dp),
                color = MaroonPrimary.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary.copy(alpha = 0.3f)),
                modifier = Modifier.testTag("nurses_header_open_map_button")
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    Icons.Default.Map,
                    contentDescription = "Map View",
                    tint = MaroonPrimary,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (isArabic) "الخريطة" else "Map",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = MaroonPrimary,
                      fontSize = 11.sp
                    )
                  )
                }
              }

              IconButton(
                onClick = {
                  if (isRefreshing) return@IconButton
                  isRefreshing = true
                  scope.launch {
                    try {
                      val fetched = FirebaseRealtimeRepository.fetchMergedNurses()
                      nurses = if (fetched.isNotEmpty()) fetched else FirebaseRealtimeRepository.getFallbackNurses()
                    } catch (e: Exception) {
                      android.util.Log.e("NursesScreen", "Manual refresh error: ${e.message}", e)
                    } finally {
                      isRefreshing = false
                    }
                  }
                },
                modifier = Modifier.testTag("refresh_nurses_button")
              ) {
                if (isRefreshing) {
                  CircularProgressIndicator(
                    color = MaroonPrimary,
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp
                  )
                } else {
                  Icon(
                    Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = MaroonPrimary
                  )
                }
              }
            }
          }
        }

        // 1. Dashboard & Statistics Summary Header Card (Nurses, Countries, Cities)
        item {
          NursesStatsDashboardCard(
            nurses = nurses,
            language = language
          )
        }

        // 2. Modern Smart Search Bar (Search by Nurse Name or City dynamically in real time)
        item {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            OutlinedTextField(
              value = searchQuery,
              onValueChange = { searchQuery = it },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("nurses_search_bar"),
              placeholder = {
                Text(
                  text = if (isArabic) "ابحث باسم الممرض أو المدينة (مثل: دمشق، أحمد)..." else "Search by nurse name or city (e.g. Damascus)...",
                  style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                  color = Color(0xFF94A3B8)
                )
              },
              leadingIcon = {
                Icon(
                  Icons.Default.Search,
                  contentDescription = if (isArabic) "بحث" else "Search",
                  tint = MaroonPrimary,
                  modifier = Modifier.size(20.dp)
                )
              },
              trailingIcon = {
                if (searchQuery.isNotBlank()) {
                  IconButton(
                    onClick = { searchQuery = "" },
                    modifier = Modifier
                      .size(28.dp)
                      .testTag("clear_nurses_search_button")
                  ) {
                    Icon(
                      Icons.Default.Close,
                      contentDescription = if (isArabic) "مسح البحث" else "Clear search",
                      tint = Color(0xFF64748B),
                      modifier = Modifier.size(17.dp)
                    )
                  }
                }
              },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaroonPrimary,
                unfocusedBorderColor = Color(0xFFCBD5E1),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                cursorColor = MaroonPrimary
              )
            )

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              if (searchQuery.isNotBlank()) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  Text(
                    text = if (isArabic) "نتائج البحث: ${displayedNurses.size}" else "Matching results: ${displayedNurses.size}",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      color = MaroonPrimary,
                      fontSize = 11.5.sp
                    )
                  )
                  TextButton(
                    onClick = { searchQuery = "" },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    modifier = Modifier.height(26.dp)
                  ) {
                    Text(
                      text = if (isArabic) "إلغاء التصفية" else "Clear",
                      style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF64748B),
                        fontSize = 10.5.sp
                      )
                    )
                  }
                }
              } else {
                Text(
                  text = if (isArabic) "تصفية فورية بحسب الاسم أو المدينة" else "Instant filtering by name or city",
                  style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFF64748B),
                    fontSize = 11.sp
                  )
                )
              }

              // "Top Rated ⭐" Sort Chip
              FilterChip(
                selected = sortByTopRated,
                onClick = { sortByTopRated = !sortByTopRated },
                leadingIcon = {
                  Icon(
                    Icons.Default.Star,
                    contentDescription = null,
                    tint = if (sortByTopRated) Color(0xFFD97706) else Color(0xFF9CA3AF),
                    modifier = Modifier.size(13.dp)
                  )
                },
                label = {
                  Text(
                    if (isArabic) "الأعلى تقييماً ⭐" else "Top Rated ⭐",
                    fontSize = 11.sp,
                    fontWeight = if (sortByTopRated) FontWeight.Bold else FontWeight.Normal
                  )
                },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFFFEF3C7),
                  selectedLabelColor = Color(0xFF92400E)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                  .height(30.dp)
                  .testTag("sort_top_rated_chip")
              )
            }
          }
        }

        // 3. Join as Nurse Banner / Quick Sign Up Card
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onOpenSignUp() }
              .testTag("nurses_join_banner")
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(MaroonPrimary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Person,
                  contentDescription = null,
                  tint = MaroonPrimary,
                  modifier = Modifier.size(22.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = if (isArabic) "هل أنت ممرض مرخص؟ سجل حسابك الآن" else "Are you a licensed nurse? Sign Up Now",
                  style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                  ),
                  color = MaroonPrimary
                )
                Text(
                  text = if (isArabic) "انضم إلى شبكة GoNurse واستقبل طلبات المرضى في مدينتك" else "Join GoNurse to receive home visit requests in your city",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaroonPrimary,
                modifier = Modifier.padding(2.dp)
              ) {
                Text(
                  text = if (isArabic) "إنشاء حساب ممرض" else "Sign Up",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = Color.White
                  ),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
              }
            }
          }
        }

        // Empty State: When no nurses in selected city
        if (displayedNurses.isEmpty()) {
          item {
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("empty_nurses_in_city_card")
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Box(
                  modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(MaroonPrimary.copy(alpha = 0.08f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = if (searchQuery.isNotBlank()) Icons.Default.SearchOff else Icons.Default.People,
                    contentDescription = null,
                    tint = MaroonPrimary,
                    modifier = Modifier.size(30.dp)
                  )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                  text = if (isArabic) {
                    if (searchQuery.isNotBlank()) "لا توجد نتائج مطابقة لبحثك"
                    else "عذراً، لا يوجد ممرضون متاحون حالياً"
                  } else {
                    if (searchQuery.isNotBlank()) "No results matching your search"
                    else "Sorry, no nurses currently available"
                  },
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                  ),
                  color = MaterialTheme.colorScheme.onSurface,
                  textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = if (isArabic) {
                    if (searchQuery.isNotBlank()) "لم نجد أي ممرض يطابق \"$searchQuery\". جرب البحث باسم أو مدينة أخرى، أو اضغط أدناه لعرض جميع الممرضين."
                    else "تم نشر طلبك، وسيتواصل معك أول ممرض متاح قريباً."
                  } else {
                    if (searchQuery.isNotBlank()) "No nurses found matching \"$searchQuery\". Try searching by another name or city, or tap below to show all."
                    else "Your request has been published, and the first available nurse will contact you soon."
                  },
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                  ),
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                  onClick = { searchQuery = "" },
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = MaroonPrimary,
                    contentColor = MaroonOnPrimary
                  ),
                  contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                  Icon(
                    Icons.Default.People,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) "عرض كافة الكوادر التمريضية" else "Show All Nursing Staff",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                  )
                }
              }
            }
          }
        } else {
          // Nurse Items (Registered nurses list, sorted oldest first with current user on top)
          items(displayedNurses, key = { it.id }) { nurse ->
            NurseCard(
              nurse = nurse,
              language = language,
              onEditAccountClick = { nurseToConfirmEdit = nurse },
              onBookClick = { nurseToConfirmEdit = nurse },
              onReportClick = { reportingNurse = nurse },
              onVerifyClick = { verifyingNurse = nurse },
              onProfileClick = { viewingProfileNurse = nurse },
              onRateClick = { reviewingNurse = nurse }
            )
          }
        }
      }
    }

    // Rating & Review Dialog Integration
    reviewingNurse?.let { nurseToReview ->
      val reviewRequest = NursingRequest(
        id = "req_rate_${System.currentTimeMillis()}",
        patientName = if (isArabic) "مريض" else "Patient",
        patientPhone = "",
        whatsappNumber = "",
        serviceName = nurseToReview.displaySpecialization.ifBlank { if (isArabic) "خدمة تمريضية منزلية" else "Home Nursing Care" },
        city = nurseToReview.displayCity,
        notes = "",
        status = "منجز",
        isCompleted = true,
        selectedNurseName = nurseToReview.displayName,
        selectedNursePhone = nurseToReview.displayPhone,
        timestamp = System.currentTimeMillis()
      )
      SubmitReviewDialog(
        request = reviewRequest,
        language = language,
        initialNurse = nurseToReview,
        onDismiss = { reviewingNurse = null },
        onReviewSubmitted = { review ->
          reviewingNurse = null
          // Immediately update in-memory state for instant user feedback
          val targetId = nurseToReview.id
          val targetUid = nurseToReview.uid
          nurses = nurses.map { current ->
            if (current.id == targetId || (targetUid.isNotBlank() && current.uid == targetUid)) {
              val newCount = current.reviewsCount + 1
              val newRating = ((current.rating * current.reviewsCount + review.rating) / newCount)
              val roundedRating = (Math.round(newRating * 10.0) / 10.0).coerceIn(1.0, 5.0)
              current.copy(rating = roundedRating, reviewsCount = newCount)
            } else {
              current
            }
          }
          // Asynchronously sync latest merged data from Firebase Realtime Database
          scope.launch {
            try {
              val refreshed = FirebaseRealtimeRepository.fetchMergedNurses()
              if (refreshed.isNotEmpty()) {
                nurses = refreshed
              }
            } catch (_: Exception) {}
          }
        }
      )
    }

    // Reporting Dialog Integration
    reportingNurse?.let { nurseToReport ->
      ReportDialog(
        target = ReportTarget.NurseProfile(
          nurseId = nurseToReport.id,
          nurseName = nurseToReport.displayName,
          nurseCity = nurseToReport.displayCity
        ),
        language = language,
        onDismiss = { reportingNurse = null }
      )
    }

    // Account Verification Dialog Integration
    verifyingNurse?.let { nurseToVerify ->
      VerifyAccountDialog(
        nurse = nurseToVerify,
        language = language,
        onDismiss = { verifyingNurse = null }
      )
    }

    // Alert dialog warning about WhatsApp phone match requirement before opening edit profile
    val targetNurse = nurseToConfirmEdit
    if (targetNurse != null) {
      AlertDialog(
        onDismissRequest = { nurseToConfirmEdit = null },
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Warning,
              contentDescription = null,
              tint = Color(0xFFD97706),
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) "تنبيه تعديل الملف الشخصي" else "Edit Profile Notice",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }
        },
        text = {
          Text(
            text = if (isArabic)
              "يرجى العلم بأنه لن يتم اعتماد والموافقة على أي تعديلات أو تحديثات إلا إذا كان رقم الواتساب المستخدم لإرسال التعديل مطابقاً تماماً لرقم هاتف الممرض المسجل في الحساب."
            else
              "Please note that modifications will only be approved if the WhatsApp number used for submission strictly matches the nurse's registered phone number.",
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            color = MaterialTheme.colorScheme.onSurface
          )
        },
        confirmButton = {
          Button(
            onClick = {
              val nurse = targetNurse
              nurseToConfirmEdit = null
              editingNurse = nurse
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary)
          ) {
            Text(text = if (isArabic) "أوافق" else "Agree")
          }
        },
        dismissButton = {
          TextButton(onClick = { nurseToConfirmEdit = null }) {
            Text(
              text = if (isArabic) "إلغاء" else "Cancel",
              color = Color(0xFF6B7280)
            )
          }
        }
      )
    }

    // Dedicated Edit Account Dialog Integration
    editingNurse?.let { nurseToEdit ->
      EditAccountDialog(
        nurse = nurseToEdit,
        language = language,
        onDismiss = { editingNurse = null },
        onAccountUpdated = { updatedNurse ->
          editingNurse = null
          val targetId = updatedNurse.id
          val targetUid = updatedNurse.uid
          val targetPhoneDigits = updatedNurse.displayPhone.filter { it.isDigit() }
          nurses = nurses.map { current ->
            val curPhoneDigits = current.displayPhone.filter { it.isDigit() }
            val isMatch = (targetId.isNotBlank() && current.id == targetId) ||
                (targetUid.isNotBlank() && current.uid == targetUid) ||
                (targetId.isNotBlank() && current.uid == targetId) ||
                (targetUid.isNotBlank() && current.id == targetUid) ||
                (targetPhoneDigits.length >= 7 && curPhoneDigits.endsWith(targetPhoneDigits)) ||
                (curPhoneDigits.length >= 7 && targetPhoneDigits.endsWith(curPhoneDigits))
            if (isMatch) updatedNurse else current
          }
        }
      )
    }
  }
}

/**
 * Top Statistics Summary Card displaying Total Nurses, Countries, and Cities
 */
@Composable
fun NursesStatsDashboardCard(
  nurses: List<Nurse>,
  language: AppLanguage,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val totalNurses = nurses.size
  val countriesCount = remember(nurses) {
    val normalizedCountries = nurses.map { nurse ->
      CountryRepository.normalizeCountryName(
        countryRaw = nurse.country,
        phone = nurse.displayPhone,
        city = nurse.displayCity
      ).trim().lowercase()
    }.filter { it.isNotBlank() && it != "null" }.distinct()
    normalizedCountries.size.coerceAtLeast(1)
  }
  val citiesCount = remember(nurses) {
    nurses.map { it.displayCity.trim().lowercase() }
      .filter { it.isNotBlank() && it != "null" }
      .distinct()
      .size
      .coerceAtLeast(1)
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = Color.White
    ),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("nurses_stats_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(MaroonPrimary.copy(alpha = 0.1f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.People,
            contentDescription = null,
            tint = MaroonPrimary,
            modifier = Modifier.size(16.dp)
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isArabic) "إحصائيات كادر التمريض والتغطية الجغرافية" else "Nursing Staff & Coverage Statistics",
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Metric 1: Total Nurses
        StatMetricBox(
          number = totalNurses.toString(),
          title = if (isArabic) "إجمالي الممرضين" else "Total Nurses",
          subtitle = if (isArabic) "كادر مرخص" else "Certified",
          icon = Icons.Default.People,
          iconTint = MaroonPrimary,
          modifier = Modifier.weight(1f)
        )

        // Metric 2: Countries
        StatMetricBox(
          number = countriesCount.toString(),
          title = if (isArabic) "الدول المتاحة" else "Countries",
          subtitle = if (isArabic) "تغطية دولية" else "Available",
          icon = Icons.Default.Public,
          iconTint = Color(0xFF0284C7),
          modifier = Modifier.weight(1f)
        )

        // Metric 3: Cities
        StatMetricBox(
          number = citiesCount.toString(),
          title = if (isArabic) "المدن والمحافظات" else "Covered Cities",
          subtitle = if (isArabic) "زيارة منزلية" else "Home Visits",
          icon = Icons.Default.LocationCity,
          iconTint = Color(0xFF0D9488),
          modifier = Modifier.weight(1f)
        )
      }
    }
  }
}

@Composable
private fun StatMetricBox(
  number: String,
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = Color(0xFFF9FAFB),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 6.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Icon(
          icon,
          contentDescription = null,
          tint = iconTint,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = number,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Black,
            fontSize = 15.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
          fontWeight = FontWeight.SemiBold,
          fontSize = 10.sp
        ),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall.copy(
          fontSize = 8.5.sp
        ),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        maxLines = 1
      )
    }
  }
}

@Composable
fun NurseCard(
  nurse: Nurse,
  language: AppLanguage,
  onEditAccountClick: () -> Unit = {},
  onBookClick: () -> Unit = {},
  onReportClick: () -> Unit = {},
  onVerifyClick: () -> Unit = {},
  onProfileClick: () -> Unit = {},
  onRateClick: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current

  val isCurrent = nurse.isCurrentUser

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isCurrent) Color(0xFFFFF7F8) else Color.White
    ),
    border = if (isCurrent) {
      androidx.compose.foundation.BorderStroke(1.5.dp, MaroonPrimary)
    } else {
      androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    },
    elevation = CardDefaults.cardElevation(defaultElevation = if (isCurrent) 2.5.dp else 1.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("nurse_card_${nurse.id}")
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      // Top row: Avatar + Name + Current User Badge (Clickable to view full profile)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onProfileClick() },
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Avatar with Base64/Network memory rendering / icon fallback
        GoNurseImage(
          imageSource = nurse.profileImageUri.ifBlank { nurse.certificateImageUri },
          contentDescription = nurse.displayName,
          isCurrentUser = isCurrent,
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = nurse.displayName,
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              ),
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )

            if (nurse.isVerified) {
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                Icons.Default.Verified,
                contentDescription = if (isArabic) "موثق بشارة زرقاء" else "Verified Nurse",
                tint = Color(0xFF2563EB),
                modifier = Modifier
                  .size(16.dp)
                  .testTag("verified_blue_badge_${nurse.id}")
              )
            }

            if (isCurrent) {
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaroonPrimary,
                modifier = Modifier.padding(1.dp)
              ) {
                Text(
                  text = if (isArabic) "حسابك الشخصي" else "Your Account",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  ),
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }
            }
          }

          Text(
            text = nurse.displaySpecialization,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
            color = MaroonPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        // Rating Badge (Clickable to rate nurse / view reviews)
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFFFFF8E1),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.6f)),
          modifier = Modifier
            .clickable { onRateClick() }
            .testTag("nurse_card_rating_badge_${nurse.id}")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.Star,
              contentDescription = "Rating",
              tint = Color(0xFFFFA000),
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = if (nurse.reviewsCount > 0) {
                String.format(Locale.US, "%.1f (%d)", nurse.rating, nurse.reviewsCount)
              } else {
                String.format(Locale.US, "%.1f", nurse.rating)
              },
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color(0xFF795548)
              )
            )
          }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Distinct, Explicit Report Nurse Button
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFFFEF2F2),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
          modifier = Modifier
            .clickable { onReportClick() }
            .testTag("report_nurse_button_${nurse.id}")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.Flag,
              contentDescription = if (isArabic) "إبلاغ عن الممرض" else "Report Nurse",
              tint = Color(0xFFDC2626),
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = if (isArabic) "إبلاغ عن الممرض" else "Report Nurse",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                color = Color(0xFFB91C1C)
              )
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Tags FlowRow: Country + City + Experience + Verification (responsive wrapping on all screen widths)
      @OptIn(ExperimentalLayoutApi::class)
      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        InfoTag(
          icon = Icons.Default.LocationOn,
          text = "${nurse.displayCity} (${nurse.displayCountry})"
        )

        InfoTag(
          icon = Icons.Default.WorkHistory,
          text = if (isArabic) "${nurse.experienceYears} سنوات خبرة" else "${nurse.experienceYears} yrs exp"
        )

        InfoTag(
          icon = if (nurse.isVerified) Icons.Default.Verified else Icons.Default.Security,
          text = if (nurse.isVerified) {
            if (isArabic) "موثق رسمي" else "Verified"
          } else {
            if (isArabic) "غير موثق" else "Unverified"
          }
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // FORCED PERMANENT VERIFICATION TILE / BUTTON FOR ALL ACCOUNTS
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (nurse.isVerified) Color(0xFFF0FDF4) else Color(0xFFFFFBEB),
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (nurse.isVerified) Color(0xFF86EFAC) else Color(0xFFFDE68A)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onVerifyClick() }
          .testTag("verify_account_tile_${nurse.id}")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 7.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            if (nurse.isVerified) Icons.Default.VerifiedUser else Icons.Default.PendingActions,
            contentDescription = null,
            tint = if (nurse.isVerified) Color(0xFF16A34A) else Color(0xFFD97706),
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (nurse.isVerified) {
                if (isArabic) "حساب موثق رسمياً ✓" else "Officially Verified Account ✓"
              } else {
                if (isArabic) "توثيق الحساب / Verify Account" else "Verify Account (Upload Docs)"
              },
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp
              ),
              color = if (nurse.isVerified) Color(0xFF15803D) else Color(0xFFB45309)
            )
            Text(
              text = if (nurse.isVerified) {
                if (isArabic) "تم اعتماد رخصة المزاولة" else "Practice license verified"
              } else {
                if (isArabic) "انقر لرفع الترخيص والهوية ومراسلة الإدارة" else "Tap to upload license & ID for verification"
              },
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.5.sp,
                color = if (nurse.isVerified) Color(0xFF166534) else Color(0xFF92400E)
              )
            )
          }
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (nurse.isVerified) Color(0xFFDCFCE7) else MaroonPrimary,
            modifier = Modifier.padding(2.dp)
          ) {
            Text(
              text = if (nurse.isVerified) {
                if (isArabic) "معتمد" else "Approved"
              } else {
                if (isArabic) "توثيق الآن" else "Verify Now"
              },
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (nurse.isVerified) Color(0xFF15803D) else Color.White
              ),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
            )
          }
        }
      }

      if (nurse.bio.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = nurse.bio,
          style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 11.sp,
            lineHeight = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          ),
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Action Buttons Row: Rate Nurse / WhatsApp / Book Nurse
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Dedicated Rating & Review Button (Replaces Phone Call)
        OutlinedButton(
          onClick = onRateClick,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(
            contentColor = Color(0xFFD97706)
          ),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier
            .height(34.dp)
            .testTag("nurse_rate_button_${nurse.id}")
        ) {
          Icon(
            Icons.Default.Star,
            contentDescription = "Rate Nurse",
            modifier = Modifier.size(14.dp),
            tint = Color(0xFFD97706)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "تقييم ⭐" else "Rate ⭐",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFB45309)
          )
        }

        // WhatsApp Button
        val waNumber = if (nurse.whatsapp.isNotBlank()) nurse.whatsapp else nurse.displayPhone
        if (waNumber.isNotBlank()) {
          OutlinedButton(
            onClick = {
              try {
                val clean = waNumber.replace(Regex("[^0-9]"), "")
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean"))
                context.startActivity(intent)
              } catch (_: Exception) {}
            },
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.height(34.dp)
          ) {
            Icon(
              Icons.Default.Chat,
              contentDescription = "WhatsApp",
              modifier = Modifier.size(14.dp),
              tint = Color(0xFF2E7D32)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "واتساب",
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium,
              color = Color(0xFF2E7D32)
            )
          }
        }

        // Edit Profile Button (Replaces Request Visit entirely)
        Button(
          onClick = onEditAccountClick,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaroonPrimary,
            contentColor = MaroonOnPrimary
          ),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier
            .weight(1f)
            .height(34.dp)
            .testTag("nurse_edit_profile_button_${nurse.id}")
        ) {
          Icon(
            Icons.Default.Edit,
            contentDescription = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 11.5.sp
            ),
            maxLines = 1
          )
        }
      }
    }
  }
}

@Composable
private fun InfoTag(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  text: String
) {
  Surface(
    shape = RoundedCornerShape(6.dp),
    color = Color(0xFFF3F4F6)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        icon,
        contentDescription = null,
        tint = MaroonPrimary,
        modifier = Modifier.size(11.dp)
      )
      Spacer(modifier = Modifier.width(3.dp))
      Text(
        text = text,
        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}


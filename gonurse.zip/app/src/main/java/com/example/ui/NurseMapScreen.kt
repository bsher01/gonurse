package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.ui.components.GoNurseImage
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import kotlinx.coroutines.launch
import java.net.URLEncoder
import kotlin.math.PI
import kotlin.math.asinh
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt
import kotlin.math.tan

// Standard City Center Coordinates across Syria and Regional Countries
data class CityLocation(
  val nameAr: String,
  val nameEn: String,
  val countryAr: String,
  val countryEn: String,
  val flagEmoji: String,
  val lat: Double,
  val lng: Double,
  val defaultZoom: Double = 13.0
)

val ALL_SUPPORTED_CITIES = listOf(
  // Syria 🇸🇾
  CityLocation("القامشلي", "Qamishli", "سوريا", "Syria", "🇸🇾", 37.0500, 41.2200, 13.5),
  CityLocation("الحسكة", "Hasakah", "سوريا", "Syria", "🇸🇾", 36.5024, 40.7483, 13.0),
  CityLocation("دمشق", "Damascus", "سوريا", "Syria", "🇸🇾", 33.5138, 36.2765, 12.8),
  CityLocation("حلب", "Aleppo", "سوريا", "Syria", "🇸🇾", 36.2021, 37.1343, 12.8),
  CityLocation("حمص", "Homs", "سوريا", "Syria", "🇸🇾", 34.7324, 36.7137, 13.0),
  CityLocation("اللاذقية", "Latakia", "سوريا", "Syria", "🇸🇾", 35.5317, 35.7900, 13.0),
  CityLocation("طرطوس", "Tartus", "سوريا", "Syria", "🇸🇾", 34.8890, 35.8866, 13.2),
  CityLocation("حماة", "Hama", "سوريا", "Syria", "🇸🇾", 35.1318, 36.7578, 13.0),
  CityLocation("الرقة", "Raqqa", "سوريا", "Syria", "🇸🇾", 35.9594, 39.0089, 13.0),
  CityLocation("دير الزور", "Deir ez-Zor", "سوريا", "Syria", "🇸🇾", 35.3359, 40.1408, 13.0),
  CityLocation("درعا", "Daraa", "سوريا", "Syria", "🇸🇾", 32.6184, 36.1022, 13.0),
  CityLocation("السويداء", "Sweida", "سوريا", "Syria", "🇸🇾", 32.7089, 36.5695, 13.0),
  CityLocation("إدلب", "Idlib", "سوريا", "Syria", "🇸🇾", 35.9306, 36.6339, 13.0),

  // Jordan 🇯🇴
  CityLocation("عمان", "Amman", "الأردن", "Jordan", "🇯🇴", 31.9539, 35.9106, 12.5),
  CityLocation("إربد", "Irbid", "الأردن", "Jordan", "🇯🇴", 32.5568, 35.8469, 13.0),
  CityLocation("الزرقاء", "Zarqa", "الأردن", "Jordan", "🇯🇴", 32.0728, 36.0880, 13.0),
  CityLocation("العقبة", "Aqaba", "الأردن", "Jordan", "🇯🇴", 29.5320, 35.0063, 13.0),

  // Palestine 🇵🇸
  CityLocation("القدس", "Jerusalem", "فلسطين", "Palestine", "🇵🇸", 31.7683, 35.2137, 13.0),
  CityLocation("غزة", "Gaza", "فلسطين", "Palestine", "🇵🇸", 31.5017, 34.4668, 13.0),
  CityLocation("رام الله", "Ramallah", "فلسطين", "Palestine", "🇵🇸", 31.9038, 35.2034, 13.5),
  CityLocation("نابلس", "Nablus", "فلسطين", "Palestine", "🇵🇸", 32.2227, 35.2621, 13.5),
  CityLocation("الخليل", "Hebron", "فلسطين", "Palestine", "🇵🇸", 31.5293, 35.0938, 13.5),
  CityLocation("حيفا", "Haifa", "فلسطين", "Palestine", "🇵🇸", 32.7940, 34.9896, 13.0),
  CityLocation("يافا", "Jaffa", "فلسطين", "Palestine", "🇵🇸", 32.0535, 34.7544, 13.0),

  // Egypt 🇪🇬
  CityLocation("القاهرة", "Cairo", "مصر", "Egypt", "🇪🇬", 30.0444, 31.2357, 12.0),
  CityLocation("الإسكندرية", "Alexandria", "مصر", "Egypt", "🇪🇬", 31.2001, 29.9187, 12.5),
  CityLocation("الجيزة", "Giza", "مصر", "Egypt", "🇪🇬", 30.0131, 31.2089, 12.5),
  CityLocation("المنصورة", "Mansoura", "مصر", "Egypt", "🇪🇬", 31.0409, 31.3785, 13.0),
  CityLocation("بورسعيد", "Port Said", "مصر", "Egypt", "🇪🇬", 31.2653, 32.3019, 13.0),
  CityLocation("أسيوط", "Asyut", "مصر", "Egypt", "🇪🇬", 27.1801, 31.1837, 13.0),
  CityLocation("أسوان", "Aswan", "مصر", "Egypt", "🇪🇬", 24.0889, 32.8998, 13.0),

  // Sudan 🇸🇩
  CityLocation("الخرطوم", "Khartoum", "السودان", "Sudan", "🇸🇩", 15.5007, 32.5599, 12.0),
  CityLocation("أم درمان", "Omdurman", "السودان", "Sudan", "🇸🇩", 15.6506, 32.4815, 12.5),
  CityLocation("بورتسودان", "Port Sudan", "السودان", "Sudan", "🇸🇩", 19.6158, 37.2164, 13.0),
  CityLocation("كسلا", "Kassala", "السودان", "Sudan", "🇸🇩", 15.4510, 36.4000, 13.0),

  // Lebanon 🇱🇧
  CityLocation("بيروت", "Beirut", "لبنان", "Lebanon", "🇱🇧", 33.8938, 35.5018, 13.0),
  CityLocation("طرابلس", "Tripoli", "لبنان", "Lebanon", "🇱🇧", 34.4367, 35.8497, 13.0),
  CityLocation("صيدا", "Sidon", "لبنان", "Lebanon", "🇱🇧", 33.5631, 35.3689, 13.0),

  // Saudi Arabia 🇸🇦
  CityLocation("الرياض", "Riyadh", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦", 24.7136, 46.6753, 12.0),
  CityLocation("جدة", "Jeddah", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦", 21.4858, 39.1925, 12.0),
  CityLocation("مكة المكرمة", "Mecca", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦", 21.3891, 39.8579, 12.5),
  CityLocation("المدينة المنورة", "Medina", "المملكة العربية السعودية", "Saudi Arabia", "🇸🇦", 24.5247, 39.5692, 12.5),

  // Iraq 🇮🇶
  CityLocation("بغداد", "Baghdad", "العراق", "Iraq", "🇮🇶", 33.3152, 44.3661, 12.0),
  CityLocation("أربيل", "Erbil", "العراق", "Iraq", "🇮🇶", 36.1911, 44.0091, 12.5),
  CityLocation("الموصل", "Mosul", "العراق", "Iraq", "🇮🇶", 36.3400, 43.1300, 12.5),
  CityLocation("البصرة", "Basra", "العراق", "Iraq", "🇮🇶", 30.5081, 47.7835, 12.5),

  // Germany 🇩🇪
  CityLocation("برلين", "Berlin", "ألمانيا", "Germany", "🇩🇪", 52.5200, 13.4050, 12.0)
)

// Backwards compatibility alias for any existing reference
val SYRIAN_CITIES = ALL_SUPPORTED_CITIES.filter { it.countryAr == "سوريا" }

const val DEFAULT_CITY_NAME = "القامشلي"
const val MIN_MAP_ZOOM = 4.0
const val MAX_MAP_ZOOM = 18.0
const val OSM_TILE_SIZE = 256

/**
 * Screen displaying interactive OpenStreetMap with smooth gestures,
 * city-based filtering (strictly defaulting to Qamishli), and collision-free
 * radial marker spacing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NurseMapScreen(
  language: AppLanguage,
  onNurseClick: (Nurse) -> Unit = {},
  onBookNurse: (Nurse) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  // Selected City Filter (Strictly defaulting to Qamishli)
  var selectedCityName by remember { mutableStateOf(DEFAULT_CITY_NAME) }

  // Map viewport state
  var centerLat by remember { mutableDoubleStateOf(37.0500) }
  var centerLng by remember { mutableDoubleStateOf(41.2200) }
  var zoom by remember { mutableDoubleStateOf(13.5) }

  var allNurses by remember { mutableStateOf<List<Nurse>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var selectedNurse by remember { mutableStateOf<Nurse?>(null) }
  var viewingProfileNurse by remember { mutableStateOf<Nurse?>(null) }

  // Fetch nurses from Firebase Realtime Database
  val loadNurses = {
    isLoading = true
    coroutineScope.launch {
      try {
        val list = FirebaseRealtimeRepository.fetchMergedNurses()
        allNurses = list.filter { it.isAvailable }
      } catch (_: Exception) {
        allNurses = emptyList()
      } finally {
        isLoading = false
      }
    }
  }

  LaunchedEffect(Unit) {
    loadNurses()
  }

  var searchQuery by remember { mutableStateOf("") }
  var isSearchDropdownOpen by remember { mutableStateOf(false) }
  val focusManager = LocalFocusManager.current

  // Filtered cities based on search query
  val filteredCities = remember(searchQuery) {
    val q = searchQuery.trim().lowercase()
    if (q.isEmpty()) {
      ALL_SUPPORTED_CITIES
    } else {
      ALL_SUPPORTED_CITIES.filter { city ->
        city.nameAr.lowercase().contains(q) ||
        city.nameEn.lowercase().contains(q) ||
        city.countryAr.lowercase().contains(q) ||
        city.countryEn.lowercase().contains(q)
      }
    }
  }

  // Filtered nurses based on the selected city
  val displayedNurses = remember(allNurses, selectedCityName) {
    if (selectedCityName == "الكل" || selectedCityName.equals("All", ignoreCase = true)) {
      allNurses
    } else {
      allNurses.filter { nurse ->
        val city = nurse.displayCity.trim().lowercase()
        val target = selectedCityName.trim().lowercase()

        val matchingCityObj = ALL_SUPPORTED_CITIES.firstOrNull {
          it.nameAr.lowercase() == target || it.nameEn.lowercase() == target
        }

        city.contains(target) ||
        (matchingCityObj != null && (
          city.contains(matchingCityObj.nameAr.lowercase()) ||
          city.contains(matchingCityObj.nameEn.lowercase())
        ))
      }
    }
  }

  var flyAnimationJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

  // Smooth camera navigation to a specific city with animated pan and zoom
  val navigateToCity = { city: CityLocation ->
    selectedCityName = city.nameAr
    selectedNurse = null
    searchQuery = ""
    isSearchDropdownOpen = false
    focusManager.clearFocus()
    flyAnimationJob?.cancel()
    flyAnimationJob = coroutineScope.launch {
      val startLat = centerLat
      val startLng = centerLng
      val startZoom = zoom
      val targetLat = city.lat
      val targetLng = city.lng
      val targetZoom = city.defaultZoom

      androidx.compose.animation.core.animate(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.tween(
          durationMillis = 800,
          easing = androidx.compose.animation.core.FastOutSlowInEasing
        )
      ) { fraction, _ ->
        centerLat = startLat + (targetLat - startLat) * fraction
        centerLng = startLng + (targetLng - startLng) * fraction
        zoom = startZoom + (targetZoom - startZoom) * fraction
      }
    }
  }

  // Smooth camera navigation to regional view encompassing all cities
  val navigateToRegionalView = {
    selectedCityName = if (isArabic) "الكل" else "All"
    selectedNurse = null
    searchQuery = ""
    isSearchDropdownOpen = false
    focusManager.clearFocus()
    flyAnimationJob?.cancel()
    flyAnimationJob = coroutineScope.launch {
      val startLat = centerLat
      val startLng = centerLng
      val startZoom = zoom
      val targetLat = 30.0
      val targetLng = 36.5
      val targetZoom = 5.8

      androidx.compose.animation.core.animate(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.tween(
          durationMillis = 800,
          easing = androidx.compose.animation.core.FastOutSlowInEasing
        )
      ) { fraction, _ ->
        centerLat = startLat + (targetLat - startLat) * fraction
        centerLng = startLng + (targetLng - startLng) * fraction
        zoom = startZoom + (targetZoom - startZoom) * fraction
      }
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .testTag("nurse_map_screen")
  ) {
    // Interactive OpenStreetMap Layer with Smooth Dragging, Pinch-to-Zoom, and Double-Tap
    OpenStreetMapCanvas(
      centerLat = centerLat,
      centerLng = centerLng,
      zoom = zoom,
      nurses = allNurses, // Global nurse display: markers remain permanently visible across all cities
      selectedNurse = selectedNurse,
      language = language,
      onCenterChange = { lat, lng ->
        flyAnimationJob?.cancel()
        centerLat = lat
        centerLng = lng
      },
      onZoomChange = { newZoom ->
        flyAnimationJob?.cancel()
        zoom = newZoom.coerceIn(MIN_MAP_ZOOM, MAX_MAP_ZOOM)
      },
      onMarkerClick = { nurse ->
        selectedNurse = if (selectedNurse?.id == nurse.id) null else nurse
      }
    )

    // Top Controls Area: Header Banner + Horizontal City Filter Chips
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.TopCenter)
    ) {
      // Main Crimson App Bar
      Surface(
        color = MaroonPrimary.copy(alpha = 0.96f),
        contentColor = MaroonOnPrimary,
        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
        shadowElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.Map,
                contentDescription = null,
                tint = Color(0xFFFFD54F),
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = if (isArabic) "خريطة الكوادر التمريضية" else "Nurse Map",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                  )
                )
                Text(
                  text = if (isArabic)
                    "$selectedCityName • ${displayedNurses.size} كادر متاح"
                  else
                    "$selectedCityName • ${displayedNurses.size} active nurses",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.5.sp,
                    color = MaroonOnPrimary.copy(alpha = 0.9f)
                  )
                )
              }
            }

            IconButton(
              onClick = { loadNurses() },
              modifier = Modifier.size(34.dp)
            ) {
              if (isLoading) {
                CircularProgressIndicator(
                  modifier = Modifier.size(16.dp),
                  color = MaroonOnPrimary,
                  strokeWidth = 2.dp
                )
              } else {
                Icon(
                  Icons.Default.Refresh,
                  contentDescription = "Refresh",
                  tint = MaroonOnPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Clean, Responsive Search Input & Searchable Dropdown for Cities
      val isAllSelected = selectedCityName == "الكل" || selectedCityName.equals("All", ignoreCase = true)
      Surface(
        color = Color.White,
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 6.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier
          .padding(horizontal = 12.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          // Search Bar Row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Default.Search,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(
              modifier = Modifier
                .weight(1f)
                .height(36.dp),
              contentAlignment = Alignment.CenterStart
            ) {
              if (searchQuery.isEmpty()) {
                Text(
                  text = if (isArabic) "ابحث عن مدينة... (دمشق، عمان، القاهرة، القدس...)" else "Search city... (Damascus, Amman, Cairo...)",
                  style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF94A3B8),
                    fontSize = 13.sp
                  ),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }

              BasicTextField(
                value = searchQuery,
                onValueChange = {
                  searchQuery = it
                  isSearchDropdownOpen = true
                },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                  color = Color(0xFF1E293B),
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.Medium
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                  onSearch = {
                    focusManager.clearFocus()
                    val first = filteredCities.firstOrNull()
                    if (first != null) {
                      navigateToCity(first)
                      searchQuery = ""
                      isSearchDropdownOpen = false
                    }
                  }
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("city_search_text_field")
                  .clickable { isSearchDropdownOpen = true }
              )
            }

            // Active Filter Badge / Pill
            Surface(
              onClick = {
                isSearchDropdownOpen = !isSearchDropdownOpen
              },
              shape = RoundedCornerShape(8.dp),
              color = if (isAllSelected) Color(0xFFEFF6FF) else MaroonPrimary.copy(alpha = 0.12f),
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isAllSelected) Color(0xFFBFDBFE) else MaroonPrimary.copy(alpha = 0.3f)
              ),
              modifier = Modifier.padding(start = 4.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = if (isAllSelected) (if (isArabic) "🌐 كل المدن" else "🌐 All") else "📍 $selectedCityName",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (isAllSelected) Color(0xFF1D4ED8) else MaroonPrimary
                  )
                )
                Spacer(modifier = Modifier.width(2.dp))
                Icon(
                  if (isSearchDropdownOpen) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                  contentDescription = null,
                  tint = if (isAllSelected) Color(0xFF1D4ED8) else MaroonPrimary,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            // Clear Search Button
            if (searchQuery.isNotEmpty()) {
              IconButton(
                onClick = {
                  searchQuery = ""
                  isSearchDropdownOpen = false
                  focusManager.clearFocus()
                },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(
                  Icons.Default.Close,
                  contentDescription = "Clear search",
                  tint = Color(0xFF64748B),
                  modifier = Modifier.size(16.dp)
                )
              }
            }
          }

          // Responsive Searchable Dropdown List
          AnimatedVisibility(
            visible = isSearchDropdownOpen,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 2.dp)
            ) {
              HorizontalDivider(
                color = Color(0xFFF1F5F9),
                thickness = 1.dp
              )

              LazyColumn(
                modifier = Modifier
                  .fillMaxWidth()
                  .heightIn(max = 240.dp)
                  .testTag("city_search_dropdown_list")
              ) {
                // "All Cities / Regional View" Item
                item {
                  Surface(
                    onClick = {
                      navigateToRegionalView()
                    },
                    color = if (isAllSelected) Color(0xFFF0FDF4) else Color.Transparent,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          Icons.Default.Public,
                          contentDescription = null,
                          tint = Color(0xFF16A34A),
                          modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                          Text(
                            text = if (isArabic) "جميع المدن والكوادر (عرض إقليمي شامل)" else "All Cities & Nurses (Regional View)",
                            style = MaterialTheme.typography.bodySmall.copy(
                              fontWeight = FontWeight.Bold,
                              color = Color(0xFF16A34A)
                            )
                          )
                          Text(
                            text = if (isArabic) "سوريا، الأردن، فلسطين، مصر، السودان وكافة المناطق" else "Syria, Jordan, Palestine, Egypt, Sudan & all regions",
                            style = MaterialTheme.typography.labelSmall.copy(
                              fontSize = 10.sp,
                              color = Color(0xFF64748B)
                            )
                          )
                        }
                      }

                      Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFDCFCE7),
                        modifier = Modifier.padding(start = 4.dp)
                      ) {
                        Text(
                          text = "${allNurses.size} " + if (isArabic) "ممرض" else "nurses",
                          style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                          ),
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  }
                }

                // Filtered Cities
                if (filteredCities.isEmpty()) {
                  item {
                    Box(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = if (isArabic) "لم يتم العثور على مدينة مطابقة" else "No matching city found",
                        style = MaterialTheme.typography.bodySmall.copy(
                          color = Color(0xFF94A3B8)
                        )
                      )
                    }
                  }
                } else {
                  items(filteredCities) { city ->
                    val isThisSelected = selectedCityName == city.nameAr || selectedCityName.equals(city.nameEn, ignoreCase = true)
                    val nurseCount = remember(allNurses, city) {
                      allNurses.count { nurse ->
                        val nc = nurse.displayCity.trim().lowercase()
                        nc.contains(city.nameAr.lowercase()) ||
                        nc.contains(city.nameEn.lowercase())
                      }
                    }

                    Surface(
                      onClick = {
                        navigateToCity(city)
                        searchQuery = ""
                        isSearchDropdownOpen = false
                        focusManager.clearFocus()
                      },
                      color = if (isThisSelected) MaroonPrimary.copy(alpha = 0.08f) else Color.Transparent,
                      modifier = Modifier
                        .fillMaxWidth()
                        .testTag("city_item_${city.nameEn.lowercase()}")
                    ) {
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                          Text(
                            text = city.flagEmoji,
                            fontSize = 16.sp
                          )
                          Spacer(modifier = Modifier.width(8.dp))
                          Column {
                            Text(
                              text = if (isArabic) city.nameAr else city.nameEn,
                              style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = if (isThisSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isThisSelected) MaroonPrimary else Color(0xFF1E293B)
                              )
                            )
                            Text(
                              text = "${if (isArabic) city.countryAr else city.countryEn} • ${if (isArabic) city.nameEn else city.nameAr}",
                              style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                              )
                            )
                          }
                        }

                        if (nurseCount > 0) {
                          Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaroonPrimary.copy(alpha = 0.1f),
                            modifier = Modifier.padding(start = 4.dp)
                          ) {
                            Text(
                              text = "$nurseCount " + if (isArabic) "متاح" else "active",
                              style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaroonPrimary
                              ),
                              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Floating Map Navigation Controls (Recenter, Zoom In, Zoom Out)
    Column(
      modifier = Modifier
        .align(Alignment.CenterEnd)
        .padding(end = 12.dp, bottom = 120.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Recenter on Selected City or Region with smooth animated glide
      FloatingActionButton(
        onClick = {
          val matchingCity = ALL_SUPPORTED_CITIES.firstOrNull {
            it.nameAr == selectedCityName || it.nameEn.equals(selectedCityName, ignoreCase = true)
          }
          if (matchingCity != null) {
            navigateToCity(matchingCity)
          } else if (selectedCityName == "الكل" || selectedCityName.equals("All", ignoreCase = true)) {
            navigateToRegionalView()
          } else {
            val defaultCity = ALL_SUPPORTED_CITIES.firstOrNull { it.nameAr == DEFAULT_CITY_NAME }
            if (defaultCity != null) {
              navigateToCity(defaultCity)
            } else {
              centerLat = 37.0500
              centerLng = 41.2200
              zoom = 13.5
            }
          }
        },
        containerColor = Color.White,
        contentColor = MaroonPrimary,
        shape = CircleShape,
        modifier = Modifier
          .size(42.dp)
          .shadow(5.dp, CircleShape)
          .testTag("map_recenter_button")
      ) {
        Icon(
          Icons.Default.MyLocation,
          contentDescription = "Recenter",
          modifier = Modifier.size(20.dp)
        )
      }

      // Zoom In (+)
      FloatingActionButton(
        onClick = {
          if (zoom < MAX_MAP_ZOOM) zoom = min(zoom + 0.8, MAX_MAP_ZOOM)
        },
        containerColor = Color.White,
        contentColor = MaroonPrimary,
        shape = CircleShape,
        modifier = Modifier
          .size(42.dp)
          .shadow(5.dp, CircleShape)
          .testTag("map_zoom_in_button")
      ) {
        Icon(
          Icons.Default.Add,
          contentDescription = "Zoom In",
          modifier = Modifier.size(20.dp)
        )
      }

      // Zoom Out (-)
      FloatingActionButton(
        onClick = {
          if (zoom > MIN_MAP_ZOOM) zoom = max(zoom - 0.8, MIN_MAP_ZOOM)
        },
        containerColor = Color.White,
        contentColor = MaroonPrimary,
        shape = CircleShape,
        modifier = Modifier
          .size(42.dp)
          .shadow(5.dp, CircleShape)
          .testTag("map_zoom_out_button")
      ) {
        Icon(
          Icons.Default.Remove,
          contentDescription = "Zoom Out",
          modifier = Modifier.size(20.dp)
        )
      }
    }

    // Bottom Selected Nurse Info Card Popup
    AnimatedVisibility(
      visible = selectedNurse != null,
      enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
      exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(12.dp)
    ) {
      selectedNurse?.let { nurse ->
        NurseMapInfoCard(
          nurse = nurse,
          language = language,
          onClose = { selectedNurse = null },
          onViewProfile = {
            viewingProfileNurse = nurse
          },
          onWhatsAppClick = {
            val cleanPhone = (if (nurse.whatsapp.isNotBlank()) nurse.whatsapp else nurse.displayPhone)
              .replace("+", "")
              .replace(" ", "")
              .replace("-", "")
            if (cleanPhone.isNotBlank()) {
              try {
                val prefilled = if (isArabic) {
                  "مرحباً ${nurse.displayName}، أود الاستفسار عن خدماتك التمريضية المنزلية عبر تطبيق GoNurse."
                } else {
                  "Hello ${nurse.displayName}, I would like to inquire about your home nursing services via GoNurse."
                }
                val encoded = URLEncoder.encode(prefilled, "UTF-8")
                val uri = Uri.parse("https://wa.me/$cleanPhone?text=$encoded")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                context.startActivity(intent)
              } catch (_: Exception) {}
            }
          }
        )
      }
    }

    // Profile Screen Modal
    viewingProfileNurse?.let { nurse ->
      ProfileScreen(
        nurse = nurse,
        language = language,
        onNavigateBack = { viewingProfileNurse = null },
        onBookNurse = { bookedNurse ->
          viewingProfileNurse = null
          onBookNurse(bookedNurse)
        }
      )
    }
  }
}

/**
 * Interactive OpenStreetMap Tile Renderer and Dynamic Marker Layer
 * Fixes aspect ratio, distortion, and coordinate boundaries across Mediterranean,
 * Syria, Jordan, Palestine, Egypt, and Sudan. Includes a rich vector cartographic base layer
 * and smooth touch gestures (pinch-zoom, multi-touch panning, and double-tap zoom).
 */
@Composable
fun OpenStreetMapCanvas(
  centerLat: Double,
  centerLng: Double,
  zoom: Double,
  nurses: List<Nurse>,
  selectedNurse: Nurse?,
  language: AppLanguage = AppLanguage.ARABIC,
  onCenterChange: (Double, Double) -> Unit,
  onZoomChange: (Double) -> Unit,
  onMarkerClick: (Nurse) -> Unit
) {
  val density = LocalDensity.current

  val currentCenterLat by rememberUpdatedState(centerLat)
  val currentCenterLng by rememberUpdatedState(centerLng)
  val currentZoom by rememberUpdatedState(zoom)
  val currentOnCenterChange by rememberUpdatedState(onCenterChange)
  val currentOnZoomChange by rememberUpdatedState(onZoomChange)

  // Ensure the entire map viewport is strictly LTR so gestures and marker/tile offsets
  // are never mirrored by RTL in Arabic layouts, which was causing the inverted touch movement.
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    BoxWithConstraints(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF5B9BD5)) // Distinct, recognizable Google Maps blue sea base
        .pointerInput(Unit) {
          // Double-tap to zoom in
          detectTapGestures(
            onDoubleTap = {
              currentOnZoomChange(min(currentZoom + 1.0, MAX_MAP_ZOOM))
            }
          )
        }
        .pointerInput(Unit) {
          // Direct 1:1 Natural Pan & Pinch-to-Zoom Gestures
          detectTransformGestures(panZoomLock = false) { _, pan, gestureZoom, _ ->
            val newZoom = if (gestureZoom != 1.0f) {
              val zoomDelta = (ln(gestureZoom.toDouble()) / ln(2.0))
              (currentZoom + zoomDelta).coerceIn(MIN_MAP_ZOOM, MAX_MAP_ZOOM)
            } else {
              currentZoom
            }

            val worldSize = OSM_TILE_SIZE * 2.0.pow(newZoom)
            val (currentCenterX, currentCenterY) = latLngToWorld(currentCenterLat, currentCenterLng, worldSize)

            // Direct Natural Pan:
            // When user drags finger right (+pan.x), camera moves West (-pan.x) so map moves right with finger
            // When user drags finger down (+pan.y), camera moves North (-pan.y) so map moves down with finger
            val newCenterX = currentCenterX - pan.x
            val newCenterY = currentCenterY - pan.y

            val (newLat, newLng) = worldToLatLng(newCenterX, newCenterY, worldSize)

            if (gestureZoom != 1.0f) {
              currentOnZoomChange(newZoom)
            }
            currentOnCenterChange(newLat.coerceIn(-85.0, 85.0), newLng)
          }
        }
    ) {
      val widthPx = constraints.maxWidth.toFloat()
      val heightPx = constraints.maxHeight.toFloat()

      val tileZoom = floor(zoom).toInt().coerceIn(0, 19)
      val scale = 2.0.pow(zoom - tileZoom)
      val scaledTileSizePx = OSM_TILE_SIZE * scale
      val worldSize = OSM_TILE_SIZE * 2.0.pow(zoom)

      // Center Coordinate in World Coordinates at continuous zoom
      val (centerWorldX, centerWorldY) = latLngToWorld(centerLat, centerLng, worldSize)

      // Visible Tile Bounding Box in Screen Pixels
      val minPxX = centerWorldX - widthPx / 2f
      val maxPxX = centerWorldX + widthPx / 2f
      val minPxY = centerWorldY - heightPx / 2f
      val maxPxY = centerWorldY + heightPx / 2f

      // 1. Clean Background Base Layer (Distinct, recognizable blue water matching Google Maps)
      Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(color = Color(0xFF5B9BD5))
      }

      // 2. High-Quality Map Tile Layer (Google Maps Roadmap Tiles with signature blue sea & zero watermark)
      val numTilesAtLevel = 2.0.pow(tileZoom.toDouble()).toInt()
      val startCol = floor(minPxX / scaledTileSizePx).toInt()
      val endCol = floor(maxPxX / scaledTileSizePx).toInt()
      val startRow = floor(minPxY / scaledTileSizePx).toInt().coerceIn(0, numTilesAtLevel - 1)
      val endRow = floor(maxPxY / scaledTileSizePx).toInt().coerceIn(0, numTilesAtLevel - 1)

      val langCode = if (language == AppLanguage.ARABIC) "ar" else "en"

      for (col in startCol..endCol) {
        val tileX = ((col % numTilesAtLevel) + numTilesAtLevel) % numTilesAtLevel
        for (row in startRow..endRow) {
          val tileY = row
          val tileLeftPx = (col * scaledTileSizePx) - minPxX
          val tileTopPx = (row * scaledTileSizePx) - minPxY

          // Load Google Maps official roadmap tiles with load balancing (mt0, mt1, mt2, mt3)
          // Features:
          // - NO "API KEY REQUIRED" watermark
          // - Water bodies (seas, lakes, rivers) clearly colored in vibrant recognizable blue
          // - High contrast land, crisp boundaries, and localized text
          val server = ((col * 31 + row).let { (it % 4 + 4) % 4 })
          val tileUrl = "https://mt$server.google.com/vt/lyrs=m&x=$tileX&y=$tileY&z=$tileZoom&hl=$langCode"

          val leftDp = with(density) { tileLeftPx.toFloat().toDp() }
          val topDp = with(density) { tileTopPx.toFloat().toDp() }
          val sizeDp = with(density) { (scaledTileSizePx + 0.6f).toFloat().toDp() } // 0.6px bleed prevents seams

          key("${tileZoom}_${tileX}_${tileY}_${col}") {
            AsyncImage(
              model = ImageRequest.Builder(LocalContext.current)
                .data(tileUrl)
                .setHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14) GoNurseApp/1.0")
                .memoryCacheKey(tileUrl)
                .diskCacheKey(tileUrl)
                .crossfade(false)
                .build(),
              contentDescription = null,
              contentScale = ContentScale.FillBounds,
              modifier = Modifier
                .offset(x = leftDp, y = topDp)
                .size(sizeDp)
            )
          }
        }
      }

      // 3. Collision-Free Distributed Nurse Markers
      val dispersedMarkers = remember(nurses) {
        calculateDispersedNurseCoordinates(nurses)
      }

      dispersedMarkers.forEach { (nurse, coords) ->
        val (nurseLat, nurseLng) = coords

        // Convert nurse lat/lng to screen pixel coordinates via Web Mercator
        val (nurseWorldX, nurseWorldY) = latLngToWorld(nurseLat, nurseLng, worldSize)

        val screenX = nurseWorldX - minPxX
        val screenY = nurseWorldY - minPxY

        val isSelected = selectedNurse?.id == nurse.id

        // Only draw markers visible within screen viewport (with 100px margin)
        if (screenX >= -100 && screenX <= widthPx + 100 && screenY >= -100 && screenY <= heightPx + 100) {
          val markerXDp = with(density) { (screenX.toFloat() - 24f).toDp() }
          val markerYDp = with(density) { (screenY.toFloat() - 48f).toDp() }

          NurseMapMarker(
            nurse = nurse,
            isSelected = isSelected,
            onClick = { onMarkerClick(nurse) },
            modifier = Modifier
              .offset(x = markerXDp, y = markerYDp)
              .zIndex(if (isSelected) 10f else 1f)
          )
        }
      }
    }
  }
}

/**
 * Converts geographic lat/lng to Web Mercator world coordinates in pixels
 */
fun latLngToWorld(lat: Double, lng: Double, worldSize: Double): Pair<Double, Double> {
  val clampedLat = lat.coerceIn(-85.05112878, 85.05112878)
  val clampedLng = ((lng + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
  val x = (clampedLng + 180.0) / 360.0 * worldSize
  val latRad = Math.toRadians(clampedLat)
  val y = (1.0 - ln(tan(PI / 4.0 + latRad / 2.0)) / PI) / 2.0 * worldSize
  return Pair(x, y)
}

/**
 * Converts Web Mercator world coordinates in pixels to geographic lat/lng
 */
fun worldToLatLng(x: Double, y: Double, worldSize: Double): Pair<Double, Double> {
  val lng = ((x / worldSize) * 360.0 - 180.0).coerceIn(-180.0, 180.0)
  val yNorm = (1.0 - 2.0 * (y / worldSize)).coerceIn(-1.0, 1.0)
  val latRad = 2.0 * atan(kotlin.math.exp(yNorm * PI)) - PI / 2.0
  val lat = Math.toDegrees(latRad).coerceIn(-85.05112878, 85.05112878)
  return Pair(lat, lng)
}

/**
 * Nurse Map Marker Pin with Crimson Styling and Star Rating Badge
 */
@Composable
fun NurseMapMarker(
  nurse: Nurse,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scale by animateFloatAsState(
    targetValue = if (isSelected) 1.28f else 1.0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
    label = "marker_scale"
  )

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier
      .clickable(onClick = onClick)
      .testTag("nurse_marker_${nurse.id}")
  ) {
    // Rating / Name Mini Badge
    Surface(
      shape = RoundedCornerShape(6.dp),
      color = if (isSelected) MaroonPrimary else Color.White,
      shadowElevation = if (isSelected) 8.dp else 3.dp,
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        if (isSelected) Color(0xFFFFD54F) else MaroonPrimary.copy(alpha = 0.4f)
      )
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.Star,
          contentDescription = null,
          tint = if (isSelected) Color(0xFFFFD54F) else Color(0xFFD97706),
          modifier = Modifier.size(11.dp)
        )
        Spacer(modifier = Modifier.width(2.dp))
        Text(
          text = String.format(java.util.Locale.US, "%.1f", nurse.rating),
          fontWeight = FontWeight.Bold,
          fontSize = 10.sp,
          color = if (isSelected) Color.White else MaroonPrimary
        )
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    // Main Crimson Pin Avatar with Halo Ring
    Box(
      modifier = Modifier
        .size(44.dp)
        .shadow(if (isSelected) 8.dp else 4.dp, CircleShape)
        .background(
          color = if (isSelected) Color(0xFFFFD54F) else MaroonPrimary,
          shape = CircleShape
        )
        .border(
          width = if (isSelected) 3.dp else 2.dp,
          color = Color.White,
          shape = CircleShape
        )
        .padding(3.dp),
      contentAlignment = Alignment.Center
    ) {
      if (nurse.profileImageUri.isNotBlank()) {
        GoNurseImage(
          imageSource = nurse.profileImageUri,
          contentDescription = nurse.displayName,
          modifier = Modifier
            .fillMaxSize()
            .clip(CircleShape),
          contentScale = ContentScale.Crop
        )
      } else {
        Icon(
          Icons.Default.Person,
          contentDescription = nurse.displayName,
          tint = if (isSelected) MaroonPrimary else MaroonOnPrimary,
          modifier = Modifier.size(24.dp)
        )
      }
    }
  }
}

/**
 * Nurse Map Info Bottom Card showing nurse details and direct WhatsApp / Profile actions
 */
@Composable
fun NurseMapInfoCard(
  nurse: Nurse,
  language: AppLanguage,
  onClose: () -> Unit,
  onViewProfile: () -> Unit,
  onWhatsAppClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val isArabic = language == AppLanguage.ARABIC

  Card(
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("nurse_map_info_card")
  ) {
    Column(
      modifier = Modifier.padding(14.dp)
    ) {
      // Top Row: Avatar, Name, Badge, Close
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Nurse Avatar
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(MaroonPrimary.copy(alpha = 0.1f))
            .border(2.dp, MaroonPrimary, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          if (nurse.profileImageUri.isNotBlank()) {
            GoNurseImage(
              imageSource = nurse.profileImageUri,
              contentDescription = nurse.displayName,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          } else {
            Icon(
              Icons.Default.Person,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(30.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Name, Specialization & Location
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = nurse.displayName,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
              ),
              color = Color(0xFF1F2937),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
            if (nurse.isVerified) {
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                Icons.Default.Verified,
                contentDescription = "Verified",
                tint = Color(0xFF1565C0),
                modifier = Modifier.size(15.dp)
              )
            }
          }

          Text(
            text = nurse.displaySpecialization,
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 11.5.sp,
              color = MaroonPrimary,
              fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )

          Spacer(modifier = Modifier.height(2.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Star,
              contentDescription = null,
              tint = Color(0xFFD97706),
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = String.format(java.util.Locale.US, "%.1f (%d)", nurse.rating, nurse.reviewsCount),
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = Color(0xFF374151)
              )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              Icons.Default.LocationCity,
              contentDescription = null,
              tint = Color(0xFF6B7280),
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = nurse.displayCity,
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                color = Color(0xFF6B7280)
              )
            )
          }
        }

        // Close Card Button
        IconButton(
          onClick = onClose,
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            Icons.Default.Close,
            contentDescription = "Close",
            tint = Color(0xFF9CA3AF),
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action Buttons: View Profile, WhatsApp, and Google Maps Navigation
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // View Profile Button
        Button(
          onClick = onViewProfile,
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaroonPrimary,
            contentColor = MaroonOnPrimary
          ),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1.1f)
            .height(38.dp)
            .testTag("map_card_view_profile_button")
        ) {
          Icon(
            Icons.Default.Person,
            contentDescription = null,
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "الملف الشخصي" else "Profile",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
          )
        }

        // WhatsApp Contact Button
        OutlinedButton(
          onClick = onWhatsAppClick,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2E7D32)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1f)
            .height(38.dp)
            .testTag("map_card_whatsapp_button")
        ) {
          Icon(
            Icons.Default.Chat,
            contentDescription = "WhatsApp",
            tint = Color(0xFF2E7D32),
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "واتساب" else "WhatsApp",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = Color(0xFF2E7D32)
          )
        }

        // Google Maps Navigation Button
        OutlinedButton(
          onClick = {
            val coords = getBaseCityCoordinates(resolveCityKey(nurse.displayCity))
            val lat = coords.first
            val lng = coords.second
            val gmmIntentUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(nurse.displayName)})")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
              setPackage("com.google.android.apps.maps")
            }
            try {
              context.startActivity(mapIntent)
            } catch (_: Exception) {
              val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")
              try {
                context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
              } catch (_: Exception) {}
            }
          },
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF1976D2)),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1.1f)
            .height(38.dp)
            .testTag("map_card_google_maps_button")
        ) {
          Icon(
            Icons.Default.Place,
            contentDescription = "Google Maps",
            tint = Color(0xFF1976D2),
            modifier = Modifier.size(15.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "خرائط Google" else "Google Maps",
            fontWeight = FontWeight.Bold,
            fontSize = 10.5.sp,
            color = Color(0xFF1976D2)
          )
        }
      }
    }
  }
}

/**
 * Calculates collision-free dispersed coordinates for nurses in the same city.
 * Uses a sunflower/golden spiral radial algorithm to space out multiple nurses
 * evenly without marker overlapping.
 */
fun calculateDispersedNurseCoordinates(nurses: List<Nurse>): List<Pair<Nurse, Pair<Double, Double>>> {
  // Group nurses by base city
  val groupedByCity = nurses.groupBy { nurse ->
    resolveCityKey(nurse.displayCity)
  }

  val result = mutableListOf<Pair<Nurse, Pair<Double, Double>>>()

  groupedByCity.forEach { (cityKey, cityNurses) ->
    val baseCoords = getBaseCityCoordinates(cityKey)
    val count = cityNurses.size

    cityNurses.forEachIndexed { index, nurse ->
      val (lat, lng) = if (count == 1) {
        baseCoords
      } else {
        // Golden Angle Spiral Dispersion (Spiderfying)
        val goldenAngle = 137.5 * (PI / 180.0)
        val angle = index * goldenAngle
        val radiusKm = 0.0075 * sqrt((index + 1).toDouble()) // ~500m to 1.5km spread
        val latOffset = radiusKm * cos(angle)
        val lngOffset = (radiusKm * sin(angle)) / cos(Math.toRadians(baseCoords.first))

        Pair(baseCoords.first + latOffset, baseCoords.second + lngOffset)
      }
      result.add(Pair(nurse, Pair(lat, lng)))
    }
  }

  return result
}

/**
 * Maps a city string to a canonical city key
 */
fun resolveCityKey(cityRaw: String): String {
  val clean = cityRaw.trim().lowercase()
  return when {
    clean.contains("قامشلي") || clean.contains("qamishli") -> "Qamishli"
    clean.contains("حسكة") || clean.contains("hasakah") -> "Hasakah"
    clean.contains("دمشق") || clean.contains("damascus") -> "Damascus"
    clean.contains("حلب") || clean.contains("aleppo") -> "Aleppo"
    clean.contains("حمص") || clean.contains("homs") -> "Homs"
    clean.contains("لاذقية") || clean.contains("latakia") -> "Latakia"
    clean.contains("طرطوس") || clean.contains("tartus") -> "Tartus"
    clean.contains("حماة") || clean.contains("حماه") || clean.contains("hama") -> "Hama"
    clean.contains("رقة") || clean.contains("raqqa") -> "Raqqa"
    clean.contains("دير الزور") || clean.contains("deir") -> "Deir ez-Zor"
    clean.contains("درعا") || clean.contains("daraa") -> "Daraa"
    clean.contains("سويداء") || clean.contains("sweida") -> "Sweida"
    clean.contains("إدلب") || clean.contains("ادلب") || clean.contains("idlib") -> "Idlib"

    // Jordan
    clean.contains("عمان") || clean.contains("amman") -> "Amman"
    clean.contains("إربد") || clean.contains("اربد") || clean.contains("irbid") -> "Irbid"
    clean.contains("زرقاء") || clean.contains("zarqa") -> "Zarqa"
    clean.contains("عقبة") || clean.contains("aqaba") -> "Aqaba"

    // Palestine
    clean.contains("قدس") || clean.contains("jerusalem") -> "Jerusalem"
    clean.contains("غزة") || clean.contains("غزه") || clean.contains("gaza") -> "Gaza"
    clean.contains("رام الله") || clean.contains("ramallah") -> "Ramallah"
    clean.contains("نابلس") || clean.contains("nablus") -> "Nablus"
    clean.contains("خليل") || clean.contains("hebron") -> "Hebron"
    clean.contains("حيفا") || clean.contains("haifa") -> "Haifa"
    clean.contains("يافا") || clean.contains("jaffa") -> "Jaffa"

    // Egypt
    clean.contains("قاهرة") || clean.contains("قاهره") || clean.contains("cairo") -> "Cairo"
    clean.contains("إسكندرية") || clean.contains("اسكندرية") || clean.contains("اسكندريه") || clean.contains("alexandria") -> "Alexandria"
    clean.contains("جيزة") || clean.contains("جيزه") || clean.contains("giza") -> "Giza"
    clean.contains("منصورة") || clean.contains("منصوره") || clean.contains("mansoura") -> "Mansoura"
    clean.contains("بورسعيد") || clean.contains("port said") -> "Port Said"
    clean.contains("أسيوط") || clean.contains("اسيوط") || clean.contains("asyut") -> "Asyut"
    clean.contains("أسوان") || clean.contains("اسوان") || clean.contains("aswan") -> "Aswan"

    // Sudan
    clean.contains("خرطوم") || clean.contains("khartoum") -> "Khartoum"
    clean.contains("أم درمان") || clean.contains("ام درمان") || clean.contains("omdurman") -> "Omdurman"
    clean.contains("بورتسودان") || clean.contains("port sudan") -> "Port Sudan"
    clean.contains("كسلا") || clean.contains("kassala") -> "Kassala"

    // Lebanon
    clean.contains("بيروت") || clean.contains("beirut") -> "Beirut"
    clean.contains("طرابلس") || clean.contains("tripoli") -> "Tripoli"
    clean.contains("صيدا") || clean.contains("sidon") -> "Sidon"

    // Saudi Arabia
    clean.contains("رياض") || clean.contains("riyadh") -> "Riyadh"
    clean.contains("جدة") || clean.contains("جده") || clean.contains("jeddah") -> "Jeddah"
    clean.contains("مكة") || clean.contains("مكه") || clean.contains("mecca") -> "Mecca"
    clean.contains("مدينة") || clean.contains("medina") -> "Medina"

    // Iraq
    clean.contains("بغداد") || clean.contains("baghdad") -> "Baghdad"
    clean.contains("أربيل") || clean.contains("اربيل") || clean.contains("erbil") -> "Erbil"
    clean.contains("موصل") || clean.contains("mosul") -> "Mosul"
    clean.contains("بصرة") || clean.contains("بصره") || clean.contains("basra") -> "Basra"

    // Germany
    clean.contains("برلين") || clean.contains("berlin") -> "Berlin"

    else -> {
      val found = ALL_SUPPORTED_CITIES.firstOrNull {
        clean.contains(it.nameAr.lowercase()) || clean.contains(it.nameEn.lowercase())
      }
      found?.nameEn ?: "Qamishli"
    }
  }
}

/**
 * Returns base geographic latitude/longitude for a canonical city
 */
fun getBaseCityCoordinates(cityKey: String): Pair<Double, Double> {
  val found = ALL_SUPPORTED_CITIES.firstOrNull {
    it.nameEn.equals(cityKey, ignoreCase = true) || it.nameAr.equals(cityKey, ignoreCase = true)
  }
  return if (found != null) {
    Pair(found.lat, found.lng)
  } else {
    Pair(37.0500, 41.2200)
  }
}

package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor

/**
 * High-definition visual inspection dialog for Administrators.
 * Displays stored Base64 profile pictures and clinical license documents with full pan,
 * multi-touch pinch-to-zoom (up to 5x), and rotation reset for verifying license text,
 * seals, graduation credentials, and facial identity.
 */
@Composable
fun AdminImageInspectionDialog(
  title: String,
  subtitle: String,
  imageBase64: String,
  onDismiss: () -> Unit,
  isArabic: Boolean = true
) {
  var scale by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }

  val decodedBitmap = remember(imageBase64) {
    ImageCompressor.getCachedOrDecodeBase64(imageBase64)
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(
      usePlatformDefaultWidth = false,
      dismissOnBackPress = true,
      dismissOnClickOutside = true
    )
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF0B0F19)),
      color = Color(0xFF0B0F19)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 14.dp, vertical = 10.dp)
      ) {
        // TOP APP BAR
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("admin_inspection_close_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
          ) {
            Text(
              text = title,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              maxLines = 1
            )
            if (subtitle.isNotBlank()) {
              Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = Color(0xFF94A3B8),
                maxLines = 1
              )
            }
          }

          IconButton(
            onClick = {
              scale = 1f
              offsetX = 0f
              offsetY = 0f
            },
            modifier = Modifier.testTag("admin_inspection_reset_zoom")
          ) {
            Icon(Icons.Default.RestartAlt, contentDescription = "Reset Zoom", tint = Color.White)
          }
        }

        // IMAGE VIEWPORT WITH PAN & ZOOM
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF020617))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
            .clipToBounds()
            .pointerInput(Unit) {
              detectTransformGestures { _, pan, zoom, _ ->
                scale = (scale * zoom).coerceIn(1f, 5f)
                val maxOffset = 1800f * scale
                offsetX = (offsetX + pan.x).coerceIn(-maxOffset, maxOffset)
                offsetY = (offsetY + pan.y).coerceIn(-maxOffset, maxOffset)
              }
            },
          contentAlignment = Alignment.Center
        ) {
          if (decodedBitmap != null) {
            Image(
              bitmap = decodedBitmap.asImageBitmap(),
              contentDescription = title,
              contentScale = ContentScale.Fit,
              modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                  scaleX = scale
                  scaleY = scale
                  translationX = offsetX
                  translationY = offsetY
                }
            )
          } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = MaroonPrimary)
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = if (isArabic) "تعذر فك تشفير الصورة أو أنها غير متوفرة" else "Image unavailable or corrupted",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
              )
            }
          }

          // Zoom Level Indicator Chip
          if (scale > 1.05f) {
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xCC000000),
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
            ) {
              Text(
                text = "${(scale * 100).toInt()}%",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // BOTTOM CONTROLS
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = {
                scale = (scale - 0.5f).coerceAtLeast(1f)
                if (scale <= 1f) {
                  offsetX = 0f
                  offsetY = 0f
                }
              }
            ) {
              Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White)
            }

            IconButton(
              onClick = {
                scale = (scale + 0.5f).coerceAtMost(5f)
              }
            ) {
              Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White)
            }

            Text(
              text = if (isArabic) "يمكنك التقريب بإصبعين للتكبير وفحص التفاصيل" else "Pinch to zoom & inspect text",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Color(0xFF94A3B8),
              modifier = Modifier.padding(start = 4.dp)
            )
          }

          Button(
            onClick = onDismiss,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
            modifier = Modifier.testTag("admin_inspection_done_button")
          ) {
            Text(if (isArabic) "إغلاق المعاينة" else "Done")
          }
        }
      }
    }
  }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppLanguage
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary

@Composable
fun LegalDisclaimerDialog(
  language: AppLanguage,
  onAgreeAndContinue: () -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC

  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  Dialog(
    onDismissRequest = { /* Mandatory: User must explicitly agree */ },
    properties = DialogProperties(
      dismissOnBackPress = false,
      dismissOnClickOutside = false,
      usePlatformDefaultWidth = false
    )
  ) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier
          .fillMaxWidth(0.92f)
          .heightIn(max = 680.dp)
          .testTag("legal_disclaimer_dialog")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
        // Top Icon & Title Header
        Box(
          modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(MaroonPrimary.copy(alpha = 0.1f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.Gavel,
            contentDescription = "Legal Terms",
            tint = MaroonPrimary,
            modifier = Modifier.size(30.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = if (isArabic) "إخلاء المسؤولية والشروط القانونية" else "Legal Disclaimer & Terms of Service",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 17.5.sp
          ),
          color = MaterialTheme.colorScheme.onSurface,
          textAlign = TextAlign.Center
        )

        Text(
          text = if (isArabic) "يرجى قراءة الشروط والموافقة للمتابعة واستخدام التطبيق" else "Please review terms and agree to continue using the app",
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Scrollable Terms Content
        Column(
          modifier = Modifier
            .weight(1f, fill = false)
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Point 1: Platform Role
          LegalPointCard(
            icon = Icons.Default.HealthAndSafety,
            title = if (isArabic) "1. منصة تقنية وسيطة" else "1. Intermediary Technology Platform",
            description = if (isArabic) {
              "تطبيق GoNurse هو منصة تقنية وسيطة تهدف إلى تسهيل الربط المباشر بين المرضى وطالبي الرعاية المنزلية وبين الكوادر التمريضية المستقلة المرخصة في مدينتهم."
            } else {
              "GoNurse is an intermediary platform that facilitates direct connections between patients and licensed independent nursing professionals in their city."
            }
          )

          // Point 2: Medical & Legal Liability Disclaimer
          LegalPointCard(
            icon = Icons.Default.VerifiedUser,
            title = if (isArabic) "2. إخلاء المسؤولية الطبية والقانونية" else "2. Medical & Legal Liability Disclaimer",
            description = if (isArabic) {
              "التطبيق لا يقدم تشخيصات طبية ولا يتحمل أي مسؤولية طبية، علاجية، أو قانونية مباشرة عن الخدمات أو الإجراءات المقدمة من الكوادر المستقلة. التطبيق غير مخصص لحالات الطوارئ الحرجة."
            } else {
              "GoNurse does not provide medical diagnoses and assumes no direct medical, therapeutic, or legal liability for services provided by independent nurses. Not for emergency services."
            }
          )

          // Point 3: Identity & Professional License Verification
          LegalPointCard(
            icon = Icons.Default.Gavel,
            title = if (isArabic) "3. التحقق المهني والهوية" else "3. Professional Verification",
            description = if (isArabic) {
              "يلتزم الكادر التمريضي بتقديم وثائق مزاولة المهنة المعتمدة، ويتعين على المريض أو ذويه التأكد من هوية وترخيص الكادر الطبي عند حضوره لتقديم الزيارة."
            } else {
              "Nursing professionals must provide valid practice licenses. Patients are advised to verify the healthcare worker's identity upon their home visit."
            }
          )

          // Point 4: Privacy & Protection
          LegalPointCard(
            icon = Icons.Default.Lock,
            title = if (isArabic) "4. حماية الخصوصية والأرقام" else "4. Privacy & Data Protection",
            description = if (isArabic) {
              "يلتزم التطبيق بحماية خصوصية الهواتف وعدم نشرها علناً، مع توفير آليات إبلاغ فورية للإدارة في حال وجود أي تجاوز أو مخالفة."
            } else {
              "The platform protects personal phone numbers from public exposure and provides a direct reporting mechanism to administrators."
            }
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mandatory Agree Button
        Button(
          onClick = onAgreeAndContinue,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaroonPrimary,
            contentColor = MaroonOnPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("agree_disclaimer_button")
        ) {
          Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "أوافق ومتابعة" else "Agree & Continue",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Copyright & Ownership Attribution Footer
        Text(
          text = if (isArabic) "GoNurse © 2026 - حقوق التطبيق والملكية محفوظة للممرض بشير الابراهيم" else "GoNurse © 2026 - Developed & Owned by Nurse Basher Al Ibrahim",
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            lineHeight = 14.sp
          ),
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
          textAlign = TextAlign.Center,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("legal_disclaimer_copyright_footer")
        )
      }
    }
    }
  }
}

@Composable
private fun LegalPointCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  description: String
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.Top
    ) {
      Box(
        modifier = Modifier
          .size(30.dp)
          .clip(CircleShape)
          .background(MaroonPrimary.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          icon,
          contentDescription = null,
          tint = MaroonPrimary,
          modifier = Modifier.size(16.dp)
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 11.sp,
            lineHeight = 16.sp
          ),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

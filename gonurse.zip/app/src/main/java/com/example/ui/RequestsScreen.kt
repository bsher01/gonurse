package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseRealtimeRepository
import com.example.data.RequestOwnershipStore
import com.example.model.AppLanguage
import com.example.model.NurseReview
import com.example.model.NursingRequest
import com.example.ui.components.ReportDialog
import com.example.ui.components.ReportTarget
import com.example.ui.components.SubmitReviewDialog
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.ui.theme.MedicalSuccessGreen
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RequestsScreen(
  language: AppLanguage,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  var requests by remember { mutableStateOf<List<NursingRequest>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var isRefreshing by remember { mutableStateOf(false) }
  var requestToComplete by remember { mutableStateOf<NursingRequest?>(null) }
  var reportingRequest by remember { mutableStateOf<NursingRequest?>(null) }
  var reviewingRequest by remember { mutableStateOf<NursingRequest?>(null) }
  var reviewedRequestIds by remember { mutableStateOf<Set<String>>(emptySet()) }
  var isCompleting by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  // Safely dismiss completion confirmation, review, or report dialog on back press
  BackHandler(enabled = requestToComplete != null || reportingRequest != null || reviewingRequest != null) {
    when {
      reviewingRequest != null -> reviewingRequest = null
      requestToComplete != null -> requestToComplete = null
      else -> reportingRequest = null
    }
  }

  // Real-time updates collector with flow-level exception safety
  LaunchedEffect(Unit) {
    FirebaseRealtimeRepository.getRequestsRealtimeFlow(pollIntervalMs = 5000L)
      .catch { e ->
        android.util.Log.e("RequestsScreen", "Requests flow error: ${e.message}", e)
        if (requests.isEmpty()) {
          requests = FirebaseRealtimeRepository.getFallbackRequests()
        }
        isLoading = false
        isRefreshing = false
      }
      .collect { updatedList ->
        requests = if (updatedList.isNotEmpty()) updatedList else FirebaseRealtimeRepository.getFallbackRequests()
        isLoading = false
        isRefreshing = false
      }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    if (isLoading && requests.isEmpty()) {
      Column(
        modifier = Modifier.align(Alignment.Center),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        CircularProgressIndicator(
          color = MaroonPrimary,
          modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = if (isArabic) "جاري مزامنة الطلبات من قاعدة البيانات..." else "Syncing requests from Firebase...",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    } else if (requests.isEmpty()) {
      Column(
        modifier = Modifier
          .align(Alignment.Center)
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(
          Icons.Default.HourglassBottom,
          contentDescription = null,
          tint = MaroonPrimary.copy(alpha = 0.5f),
          modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = if (isArabic) "لا توجد طلبات تمريضية حالياً" else "No nursing requests currently",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = if (isArabic) "يمكنك حجز أي خدمة من تبويب الخدمات لتظهر هنا مباشرة" else "Book any service from Services tab to appear here in real-time",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    } else {
      LazyColumn(
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
          .fillMaxSize()
          .testTag("requests_list")
      ) {
        // Top Header bar
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = if (isArabic) "سجل طلبات الزيارات التمريضية" else "Home Nursing Requests Log",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = if (isArabic) "محدث لحظياً من خادم Firebase المباشر" else "Real-time updates from Firebase database",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            IconButton(
              onClick = {
                if (isRefreshing) return@IconButton
                isRefreshing = true
                scope.launch {
                  try {
                    val fetched = FirebaseRealtimeRepository.fetchRequests()
                    requests = if (fetched.isNotEmpty()) fetched else FirebaseRealtimeRepository.getFallbackRequests()
                  } catch (e: Exception) {
                    android.util.Log.e("RequestsScreen", "Manual refresh error: ${e.message}", e)
                  } finally {
                    isRefreshing = false
                  }
                }
              },
              modifier = Modifier.testTag("refresh_requests_button")
            ) {
              if (isRefreshing) {
                CircularProgressIndicator(
                  color = MaroonPrimary,
                  modifier = Modifier.size(18.dp),
                  strokeWidth = 2.dp
                )
              } else {
                Icon(
                  Icons.Default.Refresh,
                  contentDescription = "Refresh",
                  tint = MaroonPrimary
                )
              }
            }
          }
        }

        // 1. Dashboard & Statistics Summary Header Card for Requests
        item {
          RequestsStatsDashboardCard(
            requests = requests,
            language = language
          )
        }

        // Requests items
        items(requests, key = { it.id }) { request ->
          val isOwner = RequestOwnershipStore.isRequestOwner(context, request.id, request.creatorId)
          val isReviewed = reviewedRequestIds.contains(request.id)
          RequestCard(
            request = request,
            isOwner = isOwner,
            isReviewed = isReviewed,
            language = language,
            onMarkCompletedClick = {
              requestToComplete = request
            },
            onRateNurseClick = {
              reviewingRequest = request
            },
            onReportClick = {
              reportingRequest = request
            }
          )
        }
      }
    }
  }

  // Confirm Completion Dialog (Exclusive to Creator)
  requestToComplete?.let { req ->
    AlertDialog(
      onDismissRequest = { if (!isCompleting) requestToComplete = null },
      icon = {
        Icon(
          Icons.Default.TaskAlt,
          contentDescription = null,
          tint = MedicalSuccessGreen,
          modifier = Modifier.size(36.dp)
        )
      },
      title = {
        Text(
          text = if (isArabic) "تأكيد إتمام الخدمة التمريضية؟" else "Confirm Service Completion?",
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center
        )
      },
      text = {
        Text(
          text = if (isArabic) {
            "بصفتك صاحب هذا الطلب (${req.serviceName})، سيؤدي تحديد الطلب كـ 'منجز' إلى إغلاق المحادثة وقفل إمكانية المراسلة، وسيتاح لك تقييم الكادر التمريضي مباشرة."
          } else {
            "As the creator of this request (${req.serviceName}), marking it as 'Completed' will lock the chat and open the review dialog to rate your nurse."
          },
          style = MaterialTheme.typography.bodyMedium,
          lineHeight = 20.sp
        )
      },
      confirmButton = {
        Button(
          onClick = {
            scope.launch {
              isCompleting = true
              val success = FirebaseRealtimeRepository.markRequestAsCompleted(req.id)
              if (success) {
                // Update local item immediately for instant snappy feedback
                val completedReq = req.copy(status = "منجز", isCompleted = true)
                requests = requests.map { if (it.id == req.id) completedReq else it }
                // Immediately trigger Review Modal Dialog upon completion
                reviewingRequest = completedReq
              }
              isCompleting = false
              requestToComplete = null
            }
          },
          enabled = !isCompleting,
          colors = ButtonDefaults.buttonColors(containerColor = MedicalSuccessGreen),
          shape = RoundedCornerShape(10.dp)
        ) {
          if (isCompleting) {
            CircularProgressIndicator(
              color = Color.White,
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
          }
          Text(
            text = if (isArabic) "نعم، إتمام وتقييم الكادر ⭐" else "Yes, Complete & Rate ⭐",
            color = Color.White,
            fontWeight = FontWeight.Bold
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = { requestToComplete = null },
          enabled = !isCompleting
        ) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      },
      shape = RoundedCornerShape(18.dp),
      containerColor = Color.White
    )
  }

  // Modal Rating & Review Dialog (Triggered only after isCompleted: true)
  reviewingRequest?.let { reqToReview ->
    SubmitReviewDialog(
      request = reqToReview,
      language = language,
      onDismiss = { reviewingRequest = null },
      onReviewSubmitted = { review ->
        reviewedRequestIds = reviewedRequestIds + reqToReview.id
        reviewingRequest = null
      }
    )
  }

  // Reporting Dialog Integration for Requests
  reportingRequest?.let { reqToReport ->
    ReportDialog(
      target = ReportTarget.NursingRequestItem(
        requestId = reqToReport.id,
        serviceName = reqToReport.serviceName,
        patientName = reqToReport.patientName,
        city = reqToReport.city
      ),
      language = language,
      onDismiss = { reportingRequest = null }
    )
  }
}

/**
 * Top Statistics Summary Card displaying Total Requests Count, Pending and Completed
 */
@Composable
fun RequestsStatsDashboardCard(
  requests: List<NursingRequest>,
  language: AppLanguage,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val totalCount = requests.size
  val completedCount = remember(requests) {
    requests.count { it.isOrderCompleted }
  }
  val pendingCount = remember(requests, completedCount) {
    (totalCount - completedCount).coerceAtLeast(0)
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("requests_stats_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(MaroonPrimary.copy(alpha = 0.1f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.Assignment,
            contentDescription = null,
            tint = MaroonPrimary,
            modifier = Modifier.size(16.dp)
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isArabic) "إحصائيات وحالة طلبات الرعاية المنزلية" else "Home Nursing Requests Statistics",
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Metric 1: Total Count of Requests
        RequestStatMetricBox(
          number = totalCount.toString(),
          title = if (isArabic) "إجمالي الطلبات" else "Total Requests",
          subtitle = if (isArabic) "طلب مسجل" else "All Requests",
          icon = Icons.Default.Assignment,
          iconTint = MaroonPrimary,
          modifier = Modifier.weight(1f)
        )

        // Metric 2: Pending Requests (Open for nurses)
        RequestStatMetricBox(
          number = pendingCount.toString(),
          title = if (isArabic) "قيد الانتظار" else "Open / Pending",
          subtitle = if (isArabic) "متاح للمراسلة" else "Open for Chat",
          icon = Icons.Default.HourglassBottom,
          iconTint = Color(0xFFEA580C),
          modifier = Modifier.weight(1f)
        )

        // Metric 3: Completed Requests
        RequestStatMetricBox(
          number = completedCount.toString(),
          title = if (isArabic) "الطلبات المنجزة" else "Completed",
          subtitle = if (isArabic) "تمت بنجاح" else "Closed & Done",
          icon = Icons.Default.CheckCircle,
          iconTint = MedicalSuccessGreen,
          modifier = Modifier.weight(1f)
        )
      }
    }
  }
}

@Composable
private fun RequestStatMetricBox(
  number: String,
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = Color(0xFFF9FAFB),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 6.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Icon(
          icon,
          contentDescription = null,
          tint = iconTint,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = number,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Black,
            fontSize = 15.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
          fontWeight = FontWeight.SemiBold,
          fontSize = 10.sp
        ),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall.copy(
          fontSize = 8.5.sp
        ),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        maxLines = 1
      )
    }
  }
}

@Composable
fun RequestCard(
  request: NursingRequest,
  isOwner: Boolean,
  isReviewed: Boolean = false,
  language: AppLanguage,
  onMarkCompletedClick: () -> Unit,
  onRateNurseClick: () -> Unit = {},
  onReportClick: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val isCompleted = request.isOrderCompleted

  val timeFormatted = remember(request.timestamp) {
    try {
      val date = Date(request.timestamp)
      val format = SimpleDateFormat("yyyy/MM/dd - hh:mm a", if (isArabic) Locale("ar") else Locale.ENGLISH)
      format.format(date)
    } catch (_: Exception) {
      "الآن"
    }
  }

  val targetPhone = request.displayPhone
  val cleanWaNumber = remember(targetPhone) {
    targetPhone.replace(Regex("[^0-9]"), "")
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isOwner) Color(0xFFFCFDFD) else Color.White
    ),
    border = androidx.compose.foundation.BorderStroke(
      if (isOwner) 1.5.dp else 1.dp,
      when {
        isCompleted -> Color(0xFF81C784)
        isOwner -> MaroonPrimary
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
      }
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isOwner) 2.dp else 1.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("request_card_${request.id}")
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      // Top Row: Service Name & Owner Badge + Status Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(
                if (isCompleted) MedicalSuccessGreen.copy(alpha = 0.12f) else MaroonPrimary.copy(alpha = 0.1f)
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              if (isCompleted) Icons.Default.TaskAlt else Icons.Default.MedicalServices,
              contentDescription = null,
              tint = if (isCompleted) MedicalSuccessGreen else MaroonPrimary,
              modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = request.serviceName,
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.5.sp
                ),
                color = if (isCompleted) MedicalSuccessGreen else MaroonPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
              if (isOwner) {
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = MaroonPrimary,
                  modifier = Modifier.padding(1.dp)
                ) {
                  Text(
                    text = if (isArabic) "طلبك الخاص" else "Your Request",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontSize = 8.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaroonOnPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                  )
                }
              }
            }
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          // Status Badge (Completed vs Open)
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isCompleted) Color(0xFFE8F5E9) else Color(0xFFFFF3E0),
            border = androidx.compose.foundation.BorderStroke(
              1.dp,
              if (isCompleted) Color(0xFF81C784) else Color(0xFFFFB74D)
            )
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                if (isCompleted) Icons.Default.CheckCircle else Icons.Default.HourglassBottom,
                contentDescription = null,
                tint = if (isCompleted) MedicalSuccessGreen else Color(0xFFE65100),
                modifier = Modifier.size(11.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isCompleted) (if (isArabic) "منجز (مكتمل)" else "Completed") else (if (isArabic) "قيد الانتظار" else "Pending"),
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  color = if (isCompleted) MedicalSuccessGreen else Color(0xFFE65100)
                )
              )
            }
          }

          Spacer(modifier = Modifier.width(4.dp))

          // Distinct Report Button for Request
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFEF2F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
            modifier = Modifier
              .clickable { onReportClick() }
              .testTag("report_request_button_${request.id}")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.Flag,
                contentDescription = if (isArabic) "إبلاغ عن الطلب" else "Report Request",
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = if (isArabic) "إبلاغ عن الطلب" else "Report",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  color = Color(0xFFB91C1C)
                )
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Patient Name & Country/City Location
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Icon(
            Icons.Default.Person,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = request.patientName,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.LocationOn,
            contentDescription = null,
            tint = MaroonPrimary,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = request.displayLocation,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      // Medical Notes if provided
      if (request.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color(0xFFF9FAFB),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(6.dp),
            verticalAlignment = Alignment.Top
          ) {
            Icon(
              Icons.Default.Notes,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(13.dp).padding(top = 1.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = request.notes,
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.5.sp,
                lineHeight = 14.sp
              ),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Timestamp Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.AccessTime,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.outline,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
          text = timeFormatted,
          style = MaterialTheme.typography.labelSmall.copy(
            fontSize = 9.5.sp,
            color = MaterialTheme.colorScheme.outline
          )
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Action Buttons Section:
      // 1. WhatsApp Button (Active for all states)
      // 2. Dynamic Rate Nurse Button (Visible & Active when isCompleted == true)
      // 3. Creator "Mark Completed" Button (Exclusive authority to request creator)
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // WhatsApp Action Button (Active across all request states)
          Button(
            onClick = {
              if (cleanWaNumber.isNotBlank()) {
                try {
                  val prefilled = if (isArabic) {
                    "مرحباً ${request.patientName}، بخصوص طلب خدمة (${request.serviceName}) في تطبيق GoNurse."
                  } else {
                    "Hello ${request.patientName}, regarding your request for (${request.serviceName}) on GoNurse."
                  }
                  val encoded = URLEncoder.encode(prefilled, "UTF-8")
                  val uri = Uri.parse("https://wa.me/$cleanWaNumber?text=$encoded")
                  val intent = Intent(Intent.ACTION_VIEW, uri)
                  context.startActivity(intent)
                } catch (_: Exception) {}
              }
            },
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = Color(0xFF2E7D32),
              contentColor = Color.White
            ),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier
              .weight(1f)
              .height(36.dp)
              .testTag("whatsapp_patient_button_${request.id}")
          ) {
            Icon(
              Icons.Default.Chat,
              contentDescription = "WhatsApp",
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = if (isArabic) "تواصل عبر واتساب" else "WhatsApp",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              )
            )
          }

          // Dynamic Rate Nurse Button (Active & Visible when request is marked as completed)
          if (isCompleted) {
            Button(
              onClick = onRateNurseClick,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isReviewed) Color(0xFFFEF3C7) else MaroonPrimary,
                contentColor = if (isReviewed) Color(0xFF92400E) else MaroonOnPrimary
              ),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
              modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .testTag("rate_nurse_button_${request.id}")
            ) {
              Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = if (isReviewed) Color(0xFFD97706) else Color(0xFFFFD54F),
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isReviewed) {
                  if (isArabic) "تم التقييم ⭐" else "Rated ⭐"
                } else {
                  if (isArabic) "تقييم الكادر ⭐" else "Rate Nurse ⭐"
                },
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp
                )
              )
            }
          }
        }

        // Exclusive Creator Control Row: "Mark as Completed" button
        if (isOwner) {
          if (!isCompleted) {
            Button(
              onClick = onMarkCompletedClick,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MedicalSuccessGreen,
                contentColor = Color.White
              ),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .testTag("mark_completed_button_${request.id}")
            ) {
              Icon(
                Icons.Default.TaskAlt,
                contentDescription = null,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) "تحديد كمنجز (إتمام الطلب)" else "Mark as Completed",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.5.sp
                )
              )
            }
          } else {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFE8F5E9),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF81C784).copy(alpha = 0.6f)),
              modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
              ) {
                Icon(
                  Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = MedicalSuccessGreen,
                  modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                  text = if (isArabic) "طلبك منجز بنجاح ✓" else "Request completed successfully ✓",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = MedicalSuccessGreen
                  )
                )
              }
            }
          }
        }
      }
    }
  }
}

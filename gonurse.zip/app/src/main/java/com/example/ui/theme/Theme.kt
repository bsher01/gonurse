package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CleanWhiteColorScheme =
  lightColorScheme(
    primary = MaroonPrimary,
    onPrimary = MaroonOnPrimary,
    primaryContainer = MaroonPrimaryContainer,
    onPrimaryContainer = MaroonOnPrimaryContainer,
    secondary = MaroonSecondary,
    onSecondary = MaroonOnSecondary,
    secondaryContainer = MaroonSecondaryContainer,
    onSecondaryContainer = MaroonOnSecondaryContainer,
    tertiary = MaroonTertiary,
    onTertiary = MaroonOnTertiary,
    tertiaryContainer = MaroonTertiaryContainer,
    onTertiaryContainer = MaroonOnTertiaryContainer,
    background = BackgroundLight,
    surface = SurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    outline = OutlineLight,
    outlineVariant = OutlineVariantLight,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    onSurfaceVariant = TextSecondaryLight,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = CleanWhiteColorScheme,
    typography = Typography,
    content = content
  )
}



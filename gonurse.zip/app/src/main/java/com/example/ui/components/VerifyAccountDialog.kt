package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.launch

/**
 * Account Verification Dialog (توثيق الحساب)
 * Allows nurses to upload their professional license,
 * saves it directly to Firebase RTDB under pending review,
 * and triggers a WhatsApp message directly to the admin (+994407958647).
 */
@Composable
fun VerifyAccountDialog(
  nurse: Nurse,
  language: AppLanguage,
  onDismiss: () -> Unit,
  onVerificationSubmitted: () -> Unit = {}
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var licenseUri by remember { mutableStateOf<Uri?>(null) }
  var isSubmitting by remember { mutableStateOf(false) }
  var statusMessage by remember { mutableStateOf("") }

  val licensePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    if (uri != null) {
      licenseUri = uri
    }
  }

  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  Dialog(
    onDismissRequest = { if (!isSubmitting) onDismiss() },
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
          .fillMaxWidth(0.94f)
          .imePadding()
          .padding(vertical = 12.dp)
          .testTag("verify_account_dialog")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
        ) {
          // Header
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(MaroonPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.VerifiedUser,
                  contentDescription = null,
                  tint = MaroonPrimary,
                  modifier = Modifier.size(24.dp)
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = if (isArabic) "توثيق حساب الكادر التمريضي" else "Verify Nursing Profile",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp
                  ),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = if (isArabic) "احصل على شارة التوثيق الرسمية" else "Obtain official verification badge",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(onClick = onDismiss, enabled = !isSubmitting) {
              Icon(Icons.Default.Close, contentDescription = "Close")
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Information box
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.Security,
                contentDescription = null,
                tint = Color(0xFF2563EB),
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isArabic)
                  "يتم إرسال صورة الترخيص مباشرة إلى قاعدة البيانات وفتح رسالة واتساب مع المشرف لاعتماد الشارة الزرقاء."
                else
                  "License is securely saved to Firebase RTDB and a WhatsApp review request sent to admin.",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontSize = 11.sp,
                  color = Color(0xFF1E40AF),
                  lineHeight = 16.sp
                )
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // License document upload box
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .border(
                width = if (licenseUri != null) 2.dp else 1.dp,
                color = if (licenseUri != null) Color(0xFF16A34A) else Color(0xFFCBD5E1),
                shape = RoundedCornerShape(14.dp)
              )
              .clickable { licensePickerLauncher.launch("image/*") }
              .testTag("verify_license_picker"),
            colors = CardDefaults.cardColors(
              containerColor = if (licenseUri != null) Color(0xFFF0FDF4) else Color(0xFFF8FAFC)
            )
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              if (licenseUri != null) {
                AsyncImage(
                  model = licenseUri,
                  contentDescription = "Selected License",
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) "تم اختيار وثيقة الترخيص (انقر للتغيير)" else "License Selected (Tap to change)",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFF16A34A)
                  )
                }
              } else {
                Icon(Icons.Default.UploadFile, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = if (isArabic) "رفع ترخيص مزاولة المهنة" else "Upload Professional License",
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  color = MaroonPrimary
                )
                Text(
                  text = if (isArabic) "اضغط هنا لاختيار صورة الترخيص من المعرض" else "Tap to choose license image from gallery",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = Color.Gray
                )
              }
            }
          }

          if (statusMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = statusMessage,
              style = MaterialTheme.typography.bodySmall.copy(color = MaroonPrimary),
              modifier = Modifier.fillMaxWidth()
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Action Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = onDismiss,
              enabled = !isSubmitting,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f).height(44.dp)
            ) {
              Text(if (isArabic) "إلغاء" else "Cancel")
            }

            Button(
              onClick = {
                if (licenseUri == null) {
                  Toast.makeText(context, if (isArabic) "يرجى اختيار صورة الترخيص أولاً" else "Please select license image first", Toast.LENGTH_SHORT).show()
                  return@Button
                }

                scope.launch {
                  isSubmitting = true
                  statusMessage = if (isArabic) "جاري ضغط الوثيقة وحفظها في Firebase..." else "Compressing & saving to Firebase..."

                  try {
                    val base64 = ImageCompressor.compressUriToBase64(context, licenseUri!!)
                    val nurseId = if (nurse.id.isNotBlank()) nurse.id else "nurse_${System.currentTimeMillis()}"

                    val updatedNurse = nurse.copy(
                      id = nurseId,
                      licenseImageBase64 = base64,
                      isVerified = false,
                      status = "PENDING"
                    )

                    FirebaseRealtimeRepository.saveNurseRegistration(updatedNurse)
                    FirebaseRealtimeRepository.refreshPendingAdminCount()

                    Toast.makeText(
                      context,
                      if (isArabic) "تم رفع الترخيص بنجاح، وطلب التوثيق معلق في شاشة المشرف للمراجعة" else "License uploaded successfully and pending admin review",
                      Toast.LENGTH_LONG
                    ).show()

                    onVerificationSubmitted()
                    onDismiss()
                  } catch (e: Exception) {
                    statusMessage = "حدث خطأ: ${e.message}"
                  } finally {
                    isSubmitting = false
                  }
                }
              },
              enabled = !isSubmitting && licenseUri != null,
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary, contentColor = MaroonOnPrimary),
              modifier = Modifier.weight(1.5f).height(44.dp).testTag("submit_verification_button")
            ) {
              if (isSubmitting) {
                CircularProgressIndicator(color = MaroonOnPrimary, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
              } else {
                Text(
                  text = if (isArabic) "إرسال عبر واتساب" else "Send via WhatsApp",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
              }
            }
          }
        }
      }
    }
  }
}

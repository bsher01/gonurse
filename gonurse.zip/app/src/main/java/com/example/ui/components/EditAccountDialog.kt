package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.FirebaseRealtimeRepository
import com.example.data.UserAuthStore
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.ui.theme.MaroonPrimary
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.launch

/**
 * Interface for editing nurse account details (Phone, Country, City, Bio)
 * and requesting account deletion, integrated seamlessly with Firebase RTDB and WhatsApp.
 */
@Composable
fun EditAccountDialog(
  nurse: Nurse,
  language: AppLanguage,
  onDismiss: () -> Unit,
  onAccountUpdated: (Nurse) -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  // Form State
  var phone by rememberSaveable { mutableStateOf(nurse.phone.ifBlank { UserAuthStore.getSavedPhone(context) }) }
  var country by rememberSaveable { mutableStateOf(nurse.country.ifBlank { UserAuthStore.getSavedCountry(context).ifBlank { "سوريا" } }) }
  var city by rememberSaveable { mutableStateOf(nurse.city.ifBlank { UserAuthStore.getSavedCity(context) }) }
  var bio by rememberSaveable { mutableStateOf(nurse.bio.ifBlank { UserAuthStore.getSavedBio(context) }) }

  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  // Profile Picture State
  var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
  var currentProfileImageUri by rememberSaveable {
    mutableStateOf(
      nurse.profileImageUri.ifBlank { UserAuthStore.getSavedProfileImageUri(context) }
    )
  }
  var uploadProgressMessage by remember { mutableStateOf<String?>(null) }

  // Photo Picker Launcher (Android Photo Picker - Zero permissions required)
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      selectedImageUri = uri
      errorMessage = null
    }
  }

  // Account Deletion State
  var showDeleteConfirmDialog by remember { mutableStateOf(false) }
  var deletionReason by remember { mutableStateOf("") }

  CompositionLocalProvider(
    LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
  ) {
    Dialog(
      onDismissRequest = { if (!isLoading) onDismiss() },
      properties = DialogProperties(
        usePlatformDefaultWidth = false,
        dismissOnBackPress = !isLoading,
        dismissOnClickOutside = !isLoading
      )
    ) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
          .fillMaxWidth(0.95f)
          .fillMaxHeight(0.90f)
          .testTag("edit_account_dialog")
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
        ) {
          // Header Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(MaroonPrimary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(22.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaroonPrimary
                )
                Text(
                  text = if (isArabic) "تحديث بيانات الحساب أو تقديم طلب حذف الحساب نهائياً" else "Update profile details or request account deletion",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(onClick = onDismiss, enabled = !isLoading) {
              Icon(Icons.Default.Close, contentDescription = "Close")
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

          // WhatsApp Phone Number Match Requirement Notice
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFFEF3C7),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 10.dp)
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.Info,
                contentDescription = null,
                tint = Color(0xFFB45309),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isArabic)
                  "تنبيه: لن يتم اعتماد أي تعديل أو حذف إلا إذا كان رقم الواتساب المستخدم للإرسال مطابقاً تماماً لرقم هاتف الممرض المسجل في الحساب."
                else
                  "Notice: Modifications or deletion will only be approved if the WhatsApp number used matches the registered phone number.",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, lineHeight = 16.sp),
                color = Color(0xFF92400E)
              )
            }
          }

          // Error banner
          if (errorMessage != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.errorContainer,
              modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
              Text(
                text = errorMessage ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          // Form fields
          Column(
            modifier = Modifier
              .weight(1f)
              .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            // Profile Picture Section
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFFF9FAFB),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = if (isArabic) "الصورة الشخصية للكادر التمريضي" else "Nurse Profile Picture",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                  contentAlignment = Alignment.BottomEnd,
                  modifier = Modifier.size(86.dp)
                ) {
                  val selected = selectedImageUri
                  if (selected != null) {
                    AsyncImage(
                      model = ImageRequest.Builder(context)
                        .data(selected)
                        .crossfade(true)
                        .build(),
                      contentDescription = "Selected profile picture",
                      modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, MaroonPrimary, CircleShape),
                      contentScale = ContentScale.Crop
                    )
                  } else {
                    GoNurseImage(
                      imageSource = currentProfileImageUri.ifBlank { nurse.certificateImageUri },
                      contentDescription = nurse.displayName,
                      isCurrentUser = true,
                      modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, MaroonPrimary.copy(alpha = 0.4f), CircleShape)
                    )
                  }

                  // Small camera badge button
                  Surface(
                    shape = CircleShape,
                    color = MaroonPrimary,
                    shadowElevation = 2.dp,
                    modifier = Modifier.size(28.dp)
                  ) {
                    IconButton(
                      onClick = {
                        photoPickerLauncher.launch(
                          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                      },
                      modifier = Modifier.fillMaxSize()
                    ) {
                      Icon(
                        Icons.Default.PhotoCamera,
                        contentDescription = "Change photo",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                  onClick = {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  },
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.testTag("change_profile_photo_button")
                ) {
                  Icon(
                    Icons.Default.AddAPhoto,
                    contentDescription = null,
                    tint = MaroonPrimary,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (selectedImageUri != null) {
                      if (isArabic) "اختيار صورة أخرى" else "Choose another photo"
                    } else {
                      if (isArabic) "تغيير الصورة الشخصية" else "Change Profile Photo"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaroonPrimary
                  )
                }

                if (selectedImageUri != null) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFECFDF5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                  ) {
                    Text(
                      text = if (isArabic)
                        "✓ صورة جديدة محددة (سيتم ضغطها وتحديثها فوراً للجميع)"
                      else
                        "✓ New photo selected (will be compressed & uploaded universally)",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = Color(0xFF047857)),
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }
              }
            }

            // Phone Field
            OutlinedTextField(
              value = phone,
              onValueChange = { phone = it; errorMessage = null },
              label = { Text(if (isArabic) "رقم الهاتف المحمول" else "Phone Number") },
              leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().testTag("edit_phone_field")
            )

            // Country Field
            OutlinedTextField(
              value = country,
              onValueChange = { country = it; errorMessage = null },
              label = { Text(if (isArabic) "الدولة" else "Country") },
              leadingIcon = { Icon(Icons.Default.Public, contentDescription = null, tint = MaroonPrimary) },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().testTag("edit_country_field")
            )

            // City Field
            OutlinedTextField(
              value = city,
              onValueChange = { city = it; errorMessage = null },
              label = { Text(if (isArabic) "المدينة" else "City") },
              leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null, tint = MaroonPrimary) },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().testTag("edit_city_field")
            )

            // Bio Field
            OutlinedTextField(
              value = bio,
              onValueChange = { bio = it; errorMessage = null },
              label = { Text(if (isArabic) "نبذة عن الممرض والخبرات" else "Bio & Experience") },
              leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = MaroonPrimary) },
              minLines = 3,
              maxLines = 5,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().testTag("edit_bio_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Submit Changes Button
            Button(
              onClick = {
                if (phone.isBlank()) {
                  errorMessage = if (isArabic) "يرجى إدخال رقم الهاتف" else "Please enter phone number"
                  return@Button
                }
                scope.launch {
                  isLoading = true
                  errorMessage = null
                  uploadProgressMessage = null
                  try {
                    val nurseId = if (nurse.id.isNotBlank()) nurse.id else UserAuthStore.getSavedUserId(context)
                    val registeredPhone = UserAuthStore.getSavedPhone(context).ifBlank { nurse.phone }

                    var finalProfileImage = currentProfileImageUri

                    // 1. Strict image compression & upload to Firebase Storage if a new photo was selected
                    val newUri = selectedImageUri
                    if (newUri != null) {
                      uploadProgressMessage = if (isArabic) "جاري ضغط ورفع الصورة..." else "Compressing & uploading photo..."
                      val uploadedUrl = FirebaseRealtimeRepository.uploadAndSaveNurseProfileImage(
                        context = context,
                        nurseId = nurseId,
                        imageUri = newUri
                      )
                      if (uploadedUrl.isNotBlank()) {
                        finalProfileImage = uploadedUrl
                        currentProfileImageUri = uploadedUrl
                      }
                    }

                    // 2. Persist account details in Firebase Realtime Database
                    FirebaseRealtimeRepository.updateNurseAccountDetails(
                      nurseId = nurseId,
                      displayName = nurse.displayName,
                      email = nurse.email,
                      phone = phone.trim(),
                      whatsapp = phone.trim(),
                      city = city.trim(),
                      specialization = nurse.displaySpecialization,
                      bio = bio.trim(),
                      experienceYears = nurse.experienceYears
                    )

                    // 3. Record update request in Firebase RTDB node pending_updates
                    FirebaseRealtimeRepository.requestProfileUpdate(
                      nurseId = nurseId,
                      registeredPhone = registeredPhone,
                      requestedPhone = phone.trim(),
                      requestedCountry = country.trim(),
                      requestedCity = city.trim(),
                      requestedBio = bio.trim()
                    )

                    // 4. Update local user session in UserAuthStore
                    UserAuthStore.updateUserProfile(
                      context = context,
                      phone = phone.trim(),
                      bio = bio.trim(),
                      city = city.trim(),
                      country = country.trim()
                    )
                    if (finalProfileImage.isNotBlank()) {
                      UserAuthStore.setSavedProfileImageUri(context, finalProfileImage)
                    }

                    // 5. Open direct WhatsApp to Admin with requested changes
                    WhatsAppHelper.openWhatsAppAdminForProfileUpdate(
                      context = context,
                      registeredPhone = registeredPhone,
                      requestedPhone = phone.trim(),
                      requestedCountry = country.trim(),
                      requestedCity = city.trim(),
                      requestedBio = bio.trim()
                    )

                    Toast.makeText(
                      context,
                      if (isArabic) "تم حفظ التعديلات وتحديث الصورة بنجاح"
                      else "Profile details & picture updated successfully",
                      Toast.LENGTH_LONG
                    ).show()

                    val updatedNurse = nurse.copy(
                      phone = phone.trim(),
                      country = country.trim(),
                      city = city.trim(),
                      bio = bio.trim(),
                      profileImageUri = finalProfileImage
                    )
                    onAccountUpdated(updatedNurse)
                    onDismiss()
                  } catch (e: Exception) {
                    errorMessage = "فشل تحديث الملف الشخصي: ${e.message}"
                  } finally {
                    isLoading = false
                    uploadProgressMessage = null
                  }
                }
              },
              enabled = !isLoading,
              colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("submit_profile_update_button")
            ) {
              if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(uploadProgressMessage ?: if (isArabic) "جاري الحفظ والتحديث..." else "Saving & updating...")
              } else {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isArabic) "حفظ التعديلات وإرسالها عبر واتساب" else "Save & Submit via WhatsApp")
              }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(6.dp))

            // Account Deletion Section
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isArabic) "طلب حذف الحساب نهائياً" else "Delete Account",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFDC2626)
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = if (isArabic)
                    "يمكنك تقديم طلب لحذف بياناتك وحسابك بالكامل من GoNurse بعد مراجعة الإدارة وتأكيد رقم الهاتف."
                  else
                    "Submit an account deletion request for admin verification and removal.",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF7F1D1D)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                  onClick = { showDeleteConfirmDialog = true },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth().testTag("open_delete_account_dialog_button")
                ) {
                  Text(if (isArabic) "تقديم طلب حذف الحساب" else "Request Account Deletion")
                }
              }
            }
          }
        }
      }
    }
  }

  // Confirm Account Deletion Dialog
  if (showDeleteConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirmDialog = false },
      title = {
        Text(if (isArabic) "تأكيد طلب حذف الحساب" else "Confirm Deletion Request")
      },
      text = {
        Column {
          Text(
            if (isArabic)
              "سيتم تسجيل طلب الحذف بقاعدة البيانات وإرسال إشعار عبر واتساب للمشرف ليقوم بمسح الحساب نهائياً بعد مطابقة رقمك. يرجى كتابة سبب الحذف (اختياري):"
            else
              "A deletion request will be registered and dispatched to admin via WhatsApp. Please specify a reason:"
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = deletionReason,
            onValueChange = { deletionReason = it },
            placeholder = { Text(if (isArabic) "سبب الحذف..." else "Reason for deletion...") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showDeleteConfirmDialog = false
            scope.launch {
              isLoading = true
              val nurseId = if (nurse.id.isNotBlank()) nurse.id else UserAuthStore.getSavedUserId(context)
              val registeredPhone = UserAuthStore.getSavedPhone(context).ifBlank { nurse.phone }

              // Save to pending_deletions in Firebase
              FirebaseRealtimeRepository.requestAccountDeletion(
                nurseId = nurseId,
                registeredPhone = registeredPhone,
                reason = deletionReason.ifBlank { "طلب المستخدم حذف حسابه" }
              )

              // Open WhatsApp notice to Admin
              WhatsAppHelper.openWhatsAppAdminForDeletion(
                context = context,
                registeredPhone = registeredPhone,
                reason = deletionReason.ifBlank { "طلب المستخدم حذف حسابه" }
              )

              Toast.makeText(
                context,
                if (isArabic) "تم إرسال طلب الحذف بنجاح وفتح واتساب للمتابعة مع المشرف"
                else "Deletion request submitted and WhatsApp opened",
                Toast.LENGTH_LONG
              ).show()

              onDismiss()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
          Text(if (isArabic) "تأكيد وإرسال عبر واتساب" else "Confirm & Send WhatsApp")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirmDialog = false }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }
}

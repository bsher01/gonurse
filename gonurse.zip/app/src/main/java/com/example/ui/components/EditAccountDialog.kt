package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.FirebaseRealtimeRepository
import com.example.data.UserAuthStore
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.ui.theme.MaroonPrimary
import com.example.util.WhatsAppHelper
import com.example.util.bringIntoViewOnFocus
import com.example.util.keyboardNestedScroll
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import kotlinx.coroutines.launch

/**
 * Interface for editing nurse account details (Phone, Country, City, Bio)
 * and requesting account deletion, integrated seamlessly with Firebase RTDB and WhatsApp.
 */
@Composable
fun EditAccountDialog(
  nurse: Nurse,
  language: AppLanguage,
  onDismiss: () -> Unit,
  onAccountUpdated: (Nurse) -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val focusManager = LocalFocusManager.current
  val scope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  // Form State
  val initialName = when {
    Nurse.isRealPersonName(nurse.name) -> nurse.name.trim()
    Nurse.isRealPersonName(nurse.fullName) -> nurse.fullName.trim()
    Nurse.isRealPersonName(UserAuthStore.getSavedUserName(context)) -> UserAuthStore.getSavedUserName(context).trim()
    Nurse.isRealPersonName(nurse.displayName) -> nurse.displayName.trim()
    else -> ""
  }

  var name by rememberSaveable { mutableStateOf(initialName) }
  var phone by rememberSaveable { mutableStateOf(nurse.phone.ifBlank { UserAuthStore.getSavedPhone(context) }) }
  var country by rememberSaveable { mutableStateOf(nurse.country.ifBlank { UserAuthStore.getSavedCountry(context).ifBlank { "سوريا" } }) }
  var city by rememberSaveable { mutableStateOf(nurse.city.ifBlank { UserAuthStore.getSavedCity(context) }) }
  var bio by rememberSaveable { mutableStateOf(nurse.bio.ifBlank { UserAuthStore.getSavedBio(context) }) }

  val nameFocusRequester = remember { FocusRequester() }
  val phoneFocusRequester = remember { FocusRequester() }
  val countryFocusRequester = remember { FocusRequester() }
  val cityFocusRequester = remember { FocusRequester() }
  val bioFocusRequester = remember { FocusRequester() }

  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  // Profile Picture State & Cropping
  var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
  var pendingCropUri by remember { mutableStateOf<Uri?>(null) }
  var showCropDialog by remember { mutableStateOf(false) }
  var croppedBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var croppedBase64 by remember { mutableStateOf("") }

  var currentProfileImageUri by rememberSaveable {
    mutableStateOf(
      nurse.profileImageUri.ifBlank { UserAuthStore.getSavedProfileImageUri(context) }
    )
  }
  var uploadProgressMessage by remember { mutableStateOf<String?>(null) }

  // Photo Picker Launcher (Android Photo Picker - Zero permissions required)
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      pendingCropUri = uri
      showCropDialog = true
      errorMessage = null
    }
  }

  // Account Deletion State
  var showDeleteConfirmDialog by remember { mutableStateOf(false) }
  var deletionReason by remember { mutableStateOf("") }
  var deletePhoneInput by rememberSaveable { mutableStateOf(phone) }
  var deleteCountryInput by rememberSaveable { mutableStateOf(country.ifBlank { "سوريا" }) }
  var deleteValidationError by remember { mutableStateOf<String?>(null) }

  // Interactive Cropping Dialog
  if (showCropDialog && pendingCropUri != null) {
    ImageCropDialog(
      imageUri = pendingCropUri!!,
      onDismiss = {
        showCropDialog = false
        pendingCropUri = null
      },
      onCropConfirmed = { bitmap, base64 ->
        croppedBitmap = bitmap
        croppedBase64 = base64
        selectedImageUri = pendingCropUri
        showCropDialog = false
        pendingCropUri = null
      },
      isArabic = isArabic
    )
  }

  CompositionLocalProvider(
    LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
  ) {
    Dialog(
      onDismissRequest = { if (!isLoading) onDismiss() },
      properties = DialogProperties(
        usePlatformDefaultWidth = false,
        dismissOnBackPress = !isLoading,
        dismissOnClickOutside = !isLoading
      )
    ) {
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
          .fillMaxWidth(0.95f)
          .fillMaxHeight(0.92f)
          .imePadding()
          .padding(vertical = 12.dp)
          .testTag("edit_account_dialog")
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
        ) {
          // Header Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(MaroonPrimary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(22.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "تعديل الملف الشخصي" else "Edit Profile",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaroonPrimary
                )
                Text(
                  text = if (isArabic) "تحديث بيانات الحساب أو تقديم طلب حذف الحساب نهائياً" else "Update profile details or request account deletion",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            IconButton(onClick = onDismiss, enabled = !isLoading) {
              Icon(Icons.Default.Close, contentDescription = "Close")
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

          // Form fields with full vertical scroll accessibility and keyboard adjustment
          Column(
            modifier = Modifier
              .weight(1f)
              .keyboardNestedScroll()
              .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
          ) {
            // WhatsApp Phone Number Match Requirement Notice
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFFEF3C7),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Info,
                  contentDescription = null,
                  tint = Color(0xFFB45309),
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (isArabic)
                    "تنبيه: لن يتم اعتماد أي تعديل أو حذف إلا إذا كان رقم الواتساب المستخدم للإرسال مطابقاً تماماً لرقم هاتف الممرض المسجل في الحساب."
                  else
                    "Notice: Modifications or deletion will only be approved if the WhatsApp number used matches the registered phone number.",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, lineHeight = 16.sp),
                  color = Color(0xFF92400E)
                )
              }
            }

            // Error banner
            if (errorMessage != null) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = errorMessage ?: "",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                  modifier = Modifier.padding(10.dp)
                )
              }
            }
            // Profile Picture Section
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFFF9FAFB),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = if (isArabic) "الصورة الشخصية للكادر التمريضي" else "Nurse Profile Picture",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                  contentAlignment = Alignment.BottomEnd,
                  modifier = Modifier.size(86.dp)
                ) {
                  if (croppedBitmap != null) {
                    Image(
                      bitmap = croppedBitmap!!.asImageBitmap(),
                      contentDescription = "Cropped profile picture",
                      modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, MaroonPrimary, CircleShape),
                      contentScale = ContentScale.Crop
                    )
                  } else if (selectedImageUri != null) {
                    AsyncImage(
                      model = ImageRequest.Builder(context)
                        .data(selectedImageUri)
                        .crossfade(true)
                        .build(),
                      contentDescription = "Selected profile picture",
                      modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, MaroonPrimary, CircleShape),
                      contentScale = ContentScale.Crop
                    )
                  } else {
                    GoNurseImage(
                      imageSource = currentProfileImageUri.ifBlank { nurse.certificateImageUri },
                      contentDescription = nurse.displayName,
                      isCurrentUser = true,
                      modifier = Modifier
                        .size(86.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, MaroonPrimary.copy(alpha = 0.4f), CircleShape)
                    )
                  }

                  // Small camera badge button
                  Surface(
                    shape = CircleShape,
                    color = MaroonPrimary,
                    shadowElevation = 2.dp,
                    modifier = Modifier.size(28.dp)
                  ) {
                    IconButton(
                      onClick = {
                        photoPickerLauncher.launch(
                          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                      },
                      modifier = Modifier.fillMaxSize()
                    ) {
                      Icon(
                        Icons.Default.PhotoCamera,
                        contentDescription = "Change photo",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                  onClick = {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  },
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.testTag("change_profile_photo_button")
                ) {
                  Icon(
                    Icons.Default.Crop,
                    contentDescription = null,
                    tint = MaroonPrimary,
                    modifier = Modifier.size(16.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (croppedBitmap != null) {
                      if (isArabic) "إعادة قص وضبط الصورة" else "Re-crop profile photo"
                    } else if (selectedImageUri != null) {
                      if (isArabic) "اختيار صورة أخرى" else "Choose another photo"
                    } else {
                      if (isArabic) "تغيير وقص الصورة الشخصية" else "Change & Crop Photo"
                    },
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaroonPrimary
                  )
                }

                if (croppedBitmap != null) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFECFDF5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                  ) {
                    Text(
                      text = if (isArabic)
                        "✓ تم قص وضبط الصورة وضغطها بنجاح (< 50KB جاهزة للحفظ)"
                      else
                        "✓ Photo cropped & compressed into Base64 (< 50KB)",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = Color(0xFF047857)),
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                } else if (selectedImageUri != null) {
                  Spacer(modifier = Modifier.height(6.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFECFDF5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                  ) {
                    Text(
                      text = if (isArabic)
                        "✓ صورة جديدة محددة"
                      else
                        "✓ New photo selected",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = Color(0xFF047857)),
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }
              }
            }

            // Full Name Field (الاسم الكامل للممرض)
            OutlinedTextField(
              value = name,
              onValueChange = { name = it; errorMessage = null },
              label = { Text(if (isArabic) "الاسم الكامل (الاسم والكنية) *" else "Full Name (First & Last) *") },
              placeholder = { Text(if (isArabic) "مثال: مروان أحمد السعيد" else "e.g. Marwan Al-Saeed") },
              leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
              keyboardActions = KeyboardActions(onNext = { phoneFocusRequester.requestFocus() }),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .focusRequester(nameFocusRequester)
                .bringIntoViewOnFocus()
                .testTag("edit_name_field")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Phone Field
            OutlinedTextField(
              value = phone,
              onValueChange = { phone = it; errorMessage = null },
              label = { Text(if (isArabic) "رقم الهاتف المحمول (الواتساب) *" else "WhatsApp Phone Number *") },
              leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
              keyboardActions = KeyboardActions(onNext = { countryFocusRequester.requestFocus() }),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .focusRequester(phoneFocusRequester)
                .bringIntoViewOnFocus()
                .testTag("edit_phone_field")
            )

            // Country Field
            OutlinedTextField(
              value = country,
              onValueChange = { country = it; errorMessage = null },
              label = { Text(if (isArabic) "الدولة" else "Country") },
              leadingIcon = { Icon(Icons.Default.Public, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
              keyboardActions = KeyboardActions(onNext = { cityFocusRequester.requestFocus() }),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .focusRequester(countryFocusRequester)
                .bringIntoViewOnFocus()
                .testTag("edit_country_field")
            )

            // City Field
            OutlinedTextField(
              value = city,
              onValueChange = { city = it; errorMessage = null },
              label = { Text(if (isArabic) "المدينة" else "City") },
              leadingIcon = { Icon(Icons.Default.LocationCity, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
              keyboardActions = KeyboardActions(onNext = { bioFocusRequester.requestFocus() }),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .focusRequester(cityFocusRequester)
                .bringIntoViewOnFocus()
                .testTag("edit_city_field")
            )

            // Bio Field
            OutlinedTextField(
              value = bio,
              onValueChange = { bio = it; errorMessage = null },
              label = { Text(if (isArabic) "نبذة عن الممرض والخبرات" else "Bio & Experience") },
              leadingIcon = { Icon(Icons.Default.Description, contentDescription = null, tint = MaroonPrimary) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Done),
              keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
              minLines = 3,
              maxLines = 5,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .focusRequester(bioFocusRequester)
                .bringIntoViewOnFocus()
                .testTag("edit_bio_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Submit Changes Button
            Button(
              onClick = {
                val cleanName = name.trim()
                if (cleanName.isBlank() || cleanName.length < 3 || Nurse.isPhoneOrId(cleanName)) {
                  errorMessage = if (isArabic)
                    "يرجى إدخال اسم حقيقي كامل للممرض (3 أحرف على الأقل)"
                  else
                    "Please enter a valid full name (at least 3 characters)"
                  nameFocusRequester.requestFocus()
                  return@Button
                }

                val cleanDigits = phone.filter { it.isDigit() }
                if (cleanDigits.length < 6) {
                  errorMessage = if (isArabic) "يرجى إدخال رقم هاتف واتساب صالح (6 أرقام على الأقل) - حقل إلزامي" else "Please enter a valid WhatsApp phone number (required)"
                  phoneFocusRequester.requestFocus()
                  return@Button
                }
                if (country.isBlank()) {
                  errorMessage = if (isArabic) "يرجى تحديد أو إدخال الدولة (حقل إلزامي)" else "Please enter country (required)"
                  countryFocusRequester.requestFocus()
                  return@Button
                }
                scope.launch {
                  isLoading = true
                  errorMessage = null
                  uploadProgressMessage = if (isArabic) "جاري حفظ وتحديث البيانات..." else "Saving profile changes..."
                  try {
                    val nurseId = if (nurse.id.isNotBlank()) nurse.id else UserAuthStore.getSavedUserId(context)
                    val registeredPhone = UserAuthStore.getSavedPhone(context).ifBlank { nurse.phone }
                    val finalProfileImage = if (croppedBase64.isNotBlank()) croppedBase64 else if (selectedImageUri != null) selectedImageUri.toString() else nurse.profileImageUri

                    // 1. Immediately update nurse account in Firebase Realtime Database
                    FirebaseRealtimeRepository.updateNurseAccountDetails(
                      nurseId = nurseId,
                      displayName = cleanName,
                      email = nurse.email,
                      phone = phone.trim(),
                      whatsapp = phone.trim(),
                      country = country.trim(),
                      city = city.trim(),
                      specialization = nurse.specialization,
                      bio = bio.trim(),
                      experienceYears = nurse.experienceYears,
                      profileImageUri = finalProfileImage
                    )

                    // 2. Also record update request inside permitted node /nurses/{nurseId}/pendingUpdate for admin audit
                    try {
                      FirebaseRealtimeRepository.requestProfileUpdate(
                        nurseId = nurseId,
                        nurseName = nurse.displayName,
                        requestedName = cleanName,
                        registeredPhone = registeredPhone,
                        oldPhone = nurse.displayPhone,
                        oldCountry = nurse.country,
                        oldCity = nurse.displayCity,
                        oldBio = nurse.bio,
                        oldProfileImageUri = nurse.profileImageUri,
                        requestedPhone = phone.trim(),
                        requestedCountry = country.trim(),
                        requestedCity = city.trim(),
                        requestedBio = bio.trim(),
                        requestedProfileImageBase64 = croppedBase64
                      )
                    } catch (_: Exception) {}

                    // 3. Update local user auth session store
                    UserAuthStore.updateUserProfile(
                      context = context,
                      phone = phone.trim(),
                      bio = bio.trim(),
                      city = city.trim(),
                      country = country.trim(),
                      name = cleanName,
                      profileImageUri = finalProfileImage
                    )

                    // 4. Construct updated Nurse model
                    val updatedNurse = nurse.copy(
                      name = cleanName,
                      fullName = cleanName,
                      phone = phone.trim(),
                      mobile = phone.trim(),
                      whatsapp = phone.trim(),
                      country = country.trim(),
                      city = city.trim(),
                      bio = bio.trim(),
                      profileImageUri = finalProfileImage
                    )

                    // 5. Notify parent UI immediately so all lists and profile cards update in real-time
                    onAccountUpdated(updatedNurse)

                    Toast.makeText(
                      context,
                      if (isArabic) "تم حفظ وتحديث بيانات الملف الشخصي بنجاح" else "Profile updated successfully",
                      Toast.LENGTH_SHORT
                    ).show()

                    onDismiss()
                  } catch (e: Exception) {
                    errorMessage = "فشل حفظ التعديلات: ${e.message}"
                  } finally {
                    isLoading = false
                    uploadProgressMessage = null
                  }
                }
              },
              enabled = !isLoading,
              colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("submit_profile_update_button")
            ) {
              if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(uploadProgressMessage ?: if (isArabic) "جاري حفظ التعديلات..." else "Saving changes...")
              } else {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isArabic) "حفظ وتحديث الملف الشخصي" else "Save & Update Profile")
              }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(6.dp))

            // Account Deletion Section
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isArabic) "طلب حذف الحساب نهائياً" else "Delete Account",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFDC2626)
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = if (isArabic)
                    "يمكنك تقديم طلب لحذف بياناتك وحسابك بالكامل من GoNurse بعد مراجعة الإدارة وتأكيد رقم الهاتف."
                  else
                    "Submit an account deletion request for admin verification and removal.",
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF7F1D1D)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                  onClick = { showDeleteConfirmDialog = true },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth().testTag("open_delete_account_dialog_button")
                ) {
                  Text(if (isArabic) "تقديم طلب حذف الحساب" else "Request Account Deletion")
                }
              }
            }
          }
        }
      }
    }
  }

  // Confirm Account Deletion Dialog
  if (showDeleteConfirmDialog) {
    AlertDialog(
      onDismissRequest = {
        if (!isLoading) {
          showDeleteConfirmDialog = false
          deleteValidationError = null
        }
      },
      title = {
        Text(if (isArabic) "تأكيد طلب حذف الحساب" else "Confirm Deletion Request")
      },
      text = {
        Column(
          modifier = Modifier
            .imePadding()
            .verticalScroll(rememberScrollState())
        ) {
          Text(
            if (isArabic)
              "سيتم تسجيل طلب الحذف كبند معلق في شاشة المشرف حتى يقوم المشرف بمراجعته واعتماده لمسح الحساب نهائياً:"
            else
              "The deletion request will be queued in the Admin Screen for manual review and permanent removal:"
          )
          Spacer(modifier = Modifier.height(10.dp))

          // Mandatory WhatsApp phone
          Text(
            text = if (isArabic) "رقم هاتف الواتساب المرتبط بالحساب *" else "Associated WhatsApp Phone *",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = deletePhoneInput,
            onValueChange = {
              deletePhoneInput = it
              deleteValidationError = null
            },
            placeholder = { Text(if (isArabic) "مثال: +9639xxxxxxxx" else "+9639xxxxxxxx") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("delete_phone_field")
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Mandatory Country
          Text(
            text = if (isArabic) "الدولة *" else "Country *",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = deleteCountryInput,
            onValueChange = {
              deleteCountryInput = it
              deleteValidationError = null
            },
            placeholder = { Text(if (isArabic) "اسم الدولة..." else "Country...") },
            leadingIcon = { Icon(Icons.Default.Public, contentDescription = null, tint = MaroonPrimary) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("delete_country_field")
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Optional reason
          Text(
            text = if (isArabic) "سبب الحذف (اختياري)" else "Reason (Optional)",
            style = MaterialTheme.typography.labelMedium
          )
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = deletionReason,
            onValueChange = { deletionReason = it },
            placeholder = { Text(if (isArabic) "سبب الحذف..." else "Reason for deletion...") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          )

          if (deleteValidationError != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = deleteValidationError!!,
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val cleanDigits = deletePhoneInput.filter { it.isDigit() }
            if (cleanDigits.length < 6) {
              deleteValidationError = if (isArabic) "يرجى إدخال رقم هاتف واتساب صالح (6 أرقام على الأقل)" else "Please enter a valid WhatsApp phone number"
              return@Button
            }
            if (deleteCountryInput.isBlank()) {
              deleteValidationError = if (isArabic) "يرجى إدخال الدولة (حقل إلزامي)" else "Please enter country"
              return@Button
            }

            scope.launch {
              isLoading = true
              showDeleteConfirmDialog = false
              try {
                val nurseId = if (nurse.id.isNotBlank()) nurse.id else UserAuthStore.getSavedUserId(context)
                val registeredPhone = deletePhoneInput.trim().ifBlank { UserAuthStore.getSavedPhone(context).ifBlank { nurse.phone } }

                // Save deletion request directly inside permitted node /nurses/{nurseId}/pendingDeletion
                FirebaseRealtimeRepository.requestAccountDeletion(
                  nurseId = nurseId,
                  nurseName = nurse.displayName,
                  registeredPhone = registeredPhone,
                  country = deleteCountryInput.trim(),
                  city = nurse.displayCity,
                  reason = deletionReason.ifBlank { "طلب المستخدم حذف حسابه" }
                )

                Toast.makeText(
                  context,
                  if (isArabic) "تم تسجيل طلب حذف الحساب بنجاح، وسيقوم المشرف بمراجعته واعتماده"
                  else "Account deletion request submitted and pending admin review",
                  Toast.LENGTH_LONG
                ).show()

                onDismiss()
              } catch (e: Exception) {
                Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
              } finally {
                isLoading = false
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
          Text(if (isArabic) "تأكيد وإرسال طلب الحذف" else "Confirm & Submit Request")
        }
      },
      dismissButton = {
        TextButton(onClick = {
          showDeleteConfirmDialog = false
          deleteValidationError = null
        }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }
}

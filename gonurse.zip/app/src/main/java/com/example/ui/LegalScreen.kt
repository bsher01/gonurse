package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.MaroonPrimary

/**
 * Dedicated primary screen for "Terms of Use and Legal Disclaimer" (الشروط والأحكام وإخلاء المسؤولية)
 * accessible as a primary tab in the GoNurse bottom navigation bar.
 */
@Composable
fun LegalScreen(
  language: AppLanguage,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
    Column(
      modifier = modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .testTag("legal_screen_container"),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Header Banner
      Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        tonalElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 12.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(MaroonPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.Gavel,
              contentDescription = "Legal Terms",
              tint = MaroonPrimary,
              modifier = Modifier.size(28.dp)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = if (isArabic) "الشروط والأحكام وإخلاء المسؤولية" else "Terms of Use & Legal Disclaimer",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 17.sp
            ),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = if (isArabic)
              "المعايير التنظيمية والضوابط القانونية لاستخدام منصة GoNurse للرعاية التمريضية المنزلية"
            else
              "Regulatory standards and legal terms governing the use of GoNurse home healthcare platform",
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 11.5.sp,
              lineHeight = 16.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
          )
        }
      }

      // Legal Points Section (Points 1 to 4)
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Point 1: Platform Role (منصة تقنية وسيطة)
        LegalSectionCard(
          icon = Icons.Default.HealthAndSafety,
          title = if (isArabic) "1. منصة تقنية وسيطة" else "1. Intermediary Technology Platform",
          description = if (isArabic) {
            "تطبيق GoNurse هو منصة تقنية وسيطة تهدف إلى تسهيل الربط المباشر بين المرضى وطالبي الرعاية المنزلية وبين الكوادر التمريضية المستقلة المرخصة في مدينتهم."
          } else {
            "GoNurse is an intermediary platform that facilitates direct connections between patients and licensed independent nursing professionals in their city."
          },
          testTag = "legal_card_point_1"
        )

        // Point 2: Medical & Legal Liability Disclaimer (إخلاء المسؤولية الطبية والقانونية)
        LegalSectionCard(
          icon = Icons.Default.VerifiedUser,
          title = if (isArabic) "2. إخلاء المسؤولية الطبية والقانونية" else "2. Medical & Legal Liability Disclaimer",
          description = if (isArabic) {
            "التطبيق لا يقدم تشخيصات طبية ولا يتحمل أي مسؤولية طبية، علاجية، أو قانونية مباشرة عن الخدمات أو الإجراءات المقدمة من الكوادر المستقلة. التطبيق غير مخصص لحالات الطوارئ الحرجة."
          } else {
            "GoNurse does not provide medical diagnoses and assumes no direct medical, therapeutic, or legal liability for services provided by independent nurses. Not for emergency services."
          },
          testTag = "legal_card_point_2"
        )

        // Point 3: Identity & Professional License Verification (التحقق المهني والهوية)
        LegalSectionCard(
          icon = Icons.Default.Gavel,
          title = if (isArabic) "3. التحقق المهني والهوية" else "3. Professional Verification",
          description = if (isArabic) {
            "يلتزم الكادر التمريضي بتقديم وثائق مزاولة المهنة المعتمدة، ويتعين على المريض أو ذويه التأكد من هوية وترخيص الكادر الطبي عند حضوره لتقديم الزيارة."
          } else {
            "Nursing professionals must provide valid practice licenses. Patients are advised to verify the healthcare worker's identity upon their home visit."
          },
          testTag = "legal_card_point_3"
        )

        // Point 4: Privacy & Protection (حماية الخصوصية والأرقام)
        LegalSectionCard(
          icon = Icons.Default.Lock,
          title = if (isArabic) "4. حماية الخصوصية والأرقام" else "4. Privacy & Data Protection",
          description = if (isArabic) {
            "يلتزم التطبيق بحماية خصوصية الهواتف وعدم نشرها علناً، مع توفير آليات إبلاغ فورية للإدارة في حال وجود أي تجاوز أو مخالفة."
          } else {
            "The platform protects personal phone numbers from public exposure and provides a direct reporting mechanism to administrators."
          },
          testTag = "legal_card_point_4"
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Official Ownership & Copyright Attribution Card
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("legal_screen_ownership_card")
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              Icons.Default.Security,
              contentDescription = "Ownership",
              tint = MaroonPrimary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic)
                "GoNurse © 2026 - حقوق التطبيق والملكية محفوظة للمهندس بشير الابراهيم"
              else
                "GoNurse © 2026 - Developed & Owned by Eng. Basher Al Ibrahim",
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = if (isArabic)
              "تطبيق الرعاية التمريضية المنزلية المعتمد • جميع الحقوق محفوظة"
            else
              "GoNurse Home Healthcare Platform • All Rights Reserved",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun LegalSectionCard(
  icon: ImageVector,
  title: String,
  description: String,
  testTag: String
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.Top
    ) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(MaroonPrimary.copy(alpha = 0.1f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          icon,
          contentDescription = null,
          tint = MaroonPrimary,
          modifier = Modifier.size(18.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 13.5.sp
          ),
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 11.5.sp,
            lineHeight = 18.sp
          ),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AppConfig
import com.example.model.AppLanguage
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary

/**
 * Non-dismissible, blocking Forced Update Dialog & Screen.
 * Prevents any further interaction with the app when the current installed version
 * is older than the required minimum version specified in Firebase Realtime Database.
 */
@Composable
fun ForcedUpdateDialog(
  appConfig: AppConfig,
  currentVersionName: String,
  currentVersionCode: Long,
  language: AppLanguage,
  onOpenStore: () -> Unit = {}
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  // Consume and block system back button completely
  BackHandler(enabled = true) {
    // Blocking: do not allow exiting or navigating away
  }

  val title = if (isArabic) appConfig.updateTitleAr else appConfig.updateTitleEn
  val message = if (isArabic) appConfig.updateMessageAr else appConfig.updateMessageEn
  val targetVersion = appConfig.latestVersionName.ifBlank { appConfig.minVersionName }

  Dialog(
    onDismissRequest = {
      // Intentionally empty: Non-dismissible dialog
    },
    properties = DialogProperties(
      dismissOnBackPress = false,
      dismissOnClickOutside = false,
      usePlatformDefaultWidth = false
    )
  ) {
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color.Black.copy(alpha = 0.75f))
          .padding(16.dp)
          .testTag("forced_update_dialog_scaffold"),
        contentAlignment = Alignment.Center
      ) {
        Card(
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
          modifier = Modifier
            .fillMaxWidth(0.95f)
            .testTag("forced_update_card")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp)
              .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // Header Icon with Modern Badge Effect
            Box(
              modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(
                  Brush.linearGradient(
                    listOf(
                      MaroonPrimary.copy(alpha = 0.15f),
                      MaroonPrimary.copy(alpha = 0.05f)
                    )
                  )
                )
                .border(2.dp, MaroonPrimary.copy(alpha = 0.3f), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.SystemUpdate,
                contentDescription = "Update Required",
                tint = MaroonPrimary,
                modifier = Modifier.size(38.dp)
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Urgent Attention Badge
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = Color(0xFFFEF2F2),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA))
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.Warning,
                  contentDescription = null,
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "إصدار التطبيق منتهي الصلاحية" else "App Version Deprecated",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color(0xFFB91C1C)
                  )
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Update Title
            Text(
              text = title,
              style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                textAlign = TextAlign.Center
              ),
              color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Detailed Update Notice
            Text(
              text = message,
              style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                lineHeight = 19.sp,
                textAlign = TextAlign.Center
              ),
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Version Comparison Card
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color(0xFFF9FAFB),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                // Current Installed Version
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = if (isArabic) "الإصدار الحالي لديك:" else "Current Installed Version:",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF3F4F6)
                  ) {
                    Text(
                      text = "v$currentVersionName ($currentVersionCode)",
                      style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                      ),
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                      color = Color(0xFF4B5563)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Required Minimum Version
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = if (isArabic) "الحد الأدنى المطلوب:" else "Minimum Required Version:",
                    style = MaterialTheme.typography.bodySmall.copy(
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.SemiBold
                    ),
                    color = Color(0xFFDC2626)
                  )
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFEE2E2)
                  ) {
                    Text(
                      text = "v${appConfig.minVersionName} (${appConfig.minVersionCode})",
                      style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                      ),
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                      color = Color(0xFF991B1B)
                    )
                  }
                }

                if (targetVersion.isNotBlank()) {
                  Spacer(modifier = Modifier.height(8.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = if (isArabic) "أحدث إصدار متاح:" else "Latest Version Available:",
                      style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                      color = Color(0xFF15803D)
                    )
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = Color(0xFFDCFCE7)
                    ) {
                      Text(
                        text = "v$targetVersion",
                        style = MaterialTheme.typography.labelSmall.copy(
                          fontFamily = FontFamily.Monospace,
                          fontWeight = FontWeight.Bold,
                          fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        color = Color(0xFF166534)
                      )
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Security & Medical Integrity Guarantee Notice
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFEFF6FF),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.Security,
                  contentDescription = null,
                  tint = Color(0xFF2563EB),
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (isArabic)
                    "لحماية بيانات المرضى والممرضين وسلامة طلبات الرعاية الصحية، تم إيقاف الإصدارات القديمة."
                  else
                    "To ensure patient safety, nurse data protection, and medical request integrity, legacy versions are strictly blocked.",
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 10.5.sp,
                    lineHeight = 14.sp
                  ),
                  color = Color(0xFF1E40AF)
                )
              }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Blocking Action: Download Latest APK / Update from dynamic update_url
            val buttonLabel = when {
              appConfig.updateUrl.contains("t.me", ignoreCase = true) ->
                if (isArabic) "تحديث التطبيق الآن (قناة التلغرام)" else "Update via Telegram Channel (APK)"
              appConfig.updateUrl.contains("play.google.com", ignoreCase = true) ->
                if (isArabic) "تحديث التطبيق من Google Play" else "Update on Google Play"
              else ->
                if (isArabic) "تحديث التطبيق الآن" else "Update Application Now"
            }

            Button(
              onClick = {
                onOpenStore()
                launchUpdateUrl(context, appConfig.updateUrl)
              },
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MaroonPrimary,
                contentColor = MaroonOnPrimary
              ),
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("forced_update_action_button")
            ) {
              Icon(
                imageVector = Icons.Default.Upgrade,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = buttonLabel,
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                )
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.OpenInBrowser,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }
  }
}

private const val OFFICIAL_TELEGRAM_UPDATE_URL = "https://t.me/GoNurse"

/**
 * Safely dispatches the user to the dynamic update URL configured in Firebase Remote Config
 * (e.g. APK download, Telegram channel, Google Play Store, or website).
 */
private fun launchUpdateUrl(context: Context, rawUrl: String) {
  val targetUrl = rawUrl.trim().ifBlank { OFFICIAL_TELEGRAM_UPDATE_URL }
  val formattedUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://") && !targetUrl.startsWith("market://")) {
    "https://$targetUrl"
  } else {
    targetUrl
  }

  try {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(formattedUrl)).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
  } catch (e: Exception) {
    try {
      // Fallback intent pointing to Telegram update channel
      val fallbackIntent = Intent(
        Intent.ACTION_VIEW,
        Uri.parse(OFFICIAL_TELEGRAM_UPDATE_URL)
      ).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(fallbackIntent)
    } catch (_: Exception) {
      // Ignore if no browser/app installed
    }
  }
}

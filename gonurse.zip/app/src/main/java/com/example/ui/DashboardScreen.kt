package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.FirebaseRealtimeRepository
import com.example.data.UserAuthStore
import com.example.model.AppLanguage
import com.example.model.MedicalService
import com.example.model.MedicalServiceRepository
import com.example.model.Nurse
import com.example.ui.theme.CardBorderColor
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.NetworkMonitor

enum class DashboardTab {
  SERVICES,
  NURSES,
  MAP,
  REQUESTS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
  language: AppLanguage,
  onToggleLanguage: () -> Unit,
  onOpenSignUp: () -> Unit = {},
  onOpenAdmin: () -> Unit = {},
  onOpenVerification: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val isConnected by NetworkMonitor.observeConnectivity(context).collectAsState(initial = true)
  val isLoggedIn by remember { mutableStateOf(UserAuthStore.isLoggedIn(context)) }
  val pendingAdminCount by FirebaseRealtimeRepository.pendingAdminCountFlow.collectAsState()

  LaunchedEffect(Unit) {
    FirebaseRealtimeRepository.refreshPendingAdminCount()
  }

  var currentTab by remember { mutableStateOf(DashboardTab.SERVICES) }
  var selectedServiceForBooking by remember { mutableStateOf<MedicalService?>(null) }
  var selectedNurseForBooking by remember { mutableStateOf<Nurse?>(null) }
  var confirmedBookingInfo by remember { mutableStateOf<Triple<String, String, String>?>(null) }
  var filterCityForNurses by remember { mutableStateOf<String?>(null) }

  // Admin Passcode Dialog State
  var showAdminDialog by remember { mutableStateOf(false) }
  var adminPasscodeInput by remember { mutableStateOf("") }
  var adminPasscodeError by remember { mutableStateOf(false) }

  val allServices = MedicalServiceRepository.services

  // Handle hardware & gesture back presses to pop state step-by-step
  BackHandler(
    enabled = confirmedBookingInfo != null ||
              selectedServiceForBooking != null ||
              selectedNurseForBooking != null ||
              filterCityForNurses != null ||
              currentTab != DashboardTab.SERVICES
  ) {
    when {
      confirmedBookingInfo != null -> confirmedBookingInfo = null
      selectedServiceForBooking != null -> selectedServiceForBooking = null
      selectedNurseForBooking != null -> selectedNurseForBooking = null
      filterCityForNurses != null -> filterCityForNurses = null
      currentTab != DashboardTab.SERVICES -> currentTab = DashboardTab.SERVICES
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Mini Brand Icon
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaroonPrimary)
                .padding(2.dp),
              contentAlignment = Alignment.Center
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_app_icon),
                contentDescription = "GoNurse Logo",
                modifier = Modifier
                  .fillMaxSize()
                  .clip(RoundedCornerShape(6.dp)),
                contentScale = ContentScale.Crop
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "GoNurse",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 0.5.sp
                ),
                color = MaroonPrimary
              )
              Text(
                text = if (isArabic) "رعاية تمريضية منزلية" else "Home Healthcare",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        },
        actions = {
          // Sign Up / Join as Nurse Action Button
          Surface(
            onClick = onOpenSignUp,
            shape = RoundedCornerShape(16.dp),
            color = MaroonPrimary,
            modifier = Modifier
              .padding(end = 6.dp)
              .testTag("appbar_signup_button")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.People,
                contentDescription = "Sign Up",
                tint = MaroonOnPrimary,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isArabic) "إنشاء حساب ممرض" else "Sign Up",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = MaroonOnPrimary,
                  fontSize = 10.5.sp
                )
              )
            }
          }

          // Language Switcher Toggle Button in Header (AppBar)
          Surface(
            onClick = onToggleLanguage,
            shape = RoundedCornerShape(16.dp),
            color = MaroonPrimary.copy(alpha = 0.1f),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary.copy(alpha = 0.25f)),
            modifier = Modifier
              .padding(end = 6.dp)
              .testTag("language_toggle_button")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.Language,
                contentDescription = "Translate Language",
                tint = MaroonPrimary,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = if (isArabic) "EN" else "عربي",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = MaroonPrimary,
                  fontSize = 10.5.sp
                )
              )
            }
          }

          // Protected Admin Screen Entry Button with Dynamic Pending Badge
          BadgedBox(
            badge = {
              if (pendingAdminCount > 0) {
                Badge(
                  containerColor = Color(0xFFDC2626),
                  contentColor = Color.White,
                  modifier = Modifier.testTag("admin_shield_badge")
                ) {
                  Text(
                    text = if (pendingAdminCount > 99) "99+" else pendingAdminCount.toString(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            },
            modifier = Modifier.padding(end = 10.dp)
          ) {
            Surface(
              onClick = {
                adminPasscodeInput = ""
                adminPasscodeError = false
                showAdminDialog = true
              },
              shape = RoundedCornerShape(16.dp),
              color = MaroonPrimary.copy(alpha = 0.1f),
              border = androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary.copy(alpha = 0.25f)),
              modifier = Modifier.testTag("appbar_admin_button")
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Shield,
                  contentDescription = "Admin Portal",
                  tint = MaroonPrimary,
                  modifier = Modifier.size(15.dp)
                )
              }
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        )
      )
    },
    bottomBar = {
      // Bottom Navigation Bar with 3 tabs: Services, Nurses, Requests
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_navigation_bar")
      ) {
        // Tab 1: Services (الخدمات)
        NavigationBarItem(
          selected = currentTab == DashboardTab.SERVICES,
          onClick = { currentTab = DashboardTab.SERVICES },
          icon = {
            Icon(
              Icons.Default.MedicalServices,
              contentDescription = if (isArabic) "الخدمات" else "Services"
            )
          },
          label = {
            Text(
              text = if (isArabic) "الخدمات" else "Services",
              fontWeight = if (currentTab == DashboardTab.SERVICES) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.5.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaroonPrimary,
            selectedTextColor = MaroonPrimary,
            indicatorColor = MaroonPrimary.copy(alpha = 0.15f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
          ),
          modifier = Modifier.testTag("tab_services")
        )

        // Tab 2: Nurses (الممرضين)
        NavigationBarItem(
          selected = currentTab == DashboardTab.NURSES,
          onClick = { currentTab = DashboardTab.NURSES },
          icon = {
            Icon(
              Icons.Default.People,
              contentDescription = if (isArabic) "الممرضين" else "Nurses"
            )
          },
          label = {
            Text(
              text = if (isArabic) "الممرضين" else "Nurses",
              fontWeight = if (currentTab == DashboardTab.NURSES) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.5.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaroonPrimary,
            selectedTextColor = MaroonPrimary,
            indicatorColor = MaroonPrimary.copy(alpha = 0.15f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
          ),
          modifier = Modifier.testTag("tab_nurses")
        )

        // Tab 3: Map (الخريطة)
        NavigationBarItem(
          selected = currentTab == DashboardTab.MAP,
          onClick = { currentTab = DashboardTab.MAP },
          icon = {
            Icon(
              Icons.Default.Map,
              contentDescription = if (isArabic) "الخريطة" else "Map"
            )
          },
          label = {
            Text(
              text = if (isArabic) "الخريطة" else "Map",
              fontWeight = if (currentTab == DashboardTab.MAP) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.5.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaroonPrimary,
            selectedTextColor = MaroonPrimary,
            indicatorColor = MaroonPrimary.copy(alpha = 0.15f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
          ),
          modifier = Modifier.testTag("tab_map")
        )

        // Tab 4: Requests (الطلبات)
        NavigationBarItem(
          selected = currentTab == DashboardTab.REQUESTS,
          onClick = { currentTab = DashboardTab.REQUESTS },
          icon = {
            Icon(
              Icons.Default.Assignment,
              contentDescription = if (isArabic) "الطلبات" else "Requests"
            )
          },
          label = {
            Text(
              text = if (isArabic) "الطلبات" else "Requests",
              fontWeight = if (currentTab == DashboardTab.REQUESTS) FontWeight.Bold else FontWeight.Normal,
              fontSize = 11.5.sp
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaroonPrimary,
            selectedTextColor = MaroonPrimary,
            indicatorColor = MaroonPrimary.copy(alpha = 0.15f),
            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
          ),
          modifier = Modifier.testTag("tab_requests")
        )
      }
    },
    modifier = modifier.fillMaxSize()
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      // Subtle "Offline Mode" Status Indicator Bar
      if (!isConnected) {
        Surface(
          color = Color(0xFFFEF3C7), // Warm amber background
          contentColor = Color(0xFF92400E),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("offline_mode_indicator")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              Icons.Default.WifiOff,
              contentDescription = "Offline",
              tint = Color(0xFFD97706),
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic)
                "⚡ وضع عدم الاتصال: يتم عرض البيانات المخزنة محلياً بسلاسة وسيعاد المزامنة تلقائياً عند عودة الإنترنت"
              else
                "⚡ Offline Mode: Displaying cached local data. Changes will sync once reconnected.",
              style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
              ),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }

      Box(
        modifier = Modifier
          .fillMaxSize()
          .weight(1f)
      ) {
      Crossfade(
        targetState = currentTab,
        animationSpec = tween(durationMillis = 300),
        label = "tab_crossfade"
      ) { tab ->
        when (tab) {
          DashboardTab.SERVICES -> {
            // Compact 2-column grid layout showing 4 services together on screen (2 top, 2 bottom) with smooth scrolling
            LazyVerticalGrid(
              columns = GridCells.Fixed(2),
              contentPadding = PaddingValues(
                start = 10.dp,
                end = 10.dp,
                top = 6.dp,
                bottom = 16.dp
              ),
              verticalArrangement = Arrangement.spacedBy(10.dp),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              modifier = Modifier
                .fillMaxSize()
                .testTag("services_grid")
            ) {
              // 6 Medical Services in Compact 2x2 Screen Fitting Cards
              items(allServices, key = { it.id }) { service ->
                CompactMedicalServiceCard(
                  service = service,
                  language = language,
                  onBookClicked = {
                    selectedServiceForBooking = service
                  }
                )
              }

              // Reassurance Guarantee Footer
              item(span = { GridItemSpan(maxLineSpan) }) {
                CompactReassuranceFooter(language = language)
              }
            }
          }

          DashboardTab.NURSES -> {
            NursesScreen(
              language = language,
              onBookNurse = { nurse ->
                selectedNurseForBooking = nurse
              },
              onOpenSignUp = onOpenSignUp,
              onOpenMap = {
                currentTab = DashboardTab.MAP
              },
              initialCityFilter = filterCityForNurses
            )
          }

          DashboardTab.MAP -> {
            NurseMapScreen(
              language = language,
              onBookNurse = { nurse ->
                selectedNurseForBooking = nurse
              }
            )
          }

          DashboardTab.REQUESTS -> {
            RequestsScreen(
              language = language
            )
          }
        }
      }
    }
  }
}

  // Booking Modal Bottom Sheet for Medical Service
  selectedServiceForBooking?.let { service ->
    BookingBottomSheet(
      service = service,
      nurse = null,
      language = language,
      onDismiss = { selectedServiceForBooking = null },
      onBookingConfirmed = { serviceTitle, patientName, selectedCity ->
        selectedServiceForBooking = null
        filterCityForNurses = selectedCity
        currentTab = DashboardTab.NURSES
        confirmedBookingInfo = Triple(serviceTitle, patientName, selectedCity)
      }
    )
  }

  // Booking Modal Bottom Sheet for Nurse Direct Visit
  selectedNurseForBooking?.let { nurse ->
    BookingBottomSheet(
      service = null,
      nurse = nurse,
      language = language,
      onDismiss = { selectedNurseForBooking = null },
      onBookingConfirmed = { serviceTitle, patientName, selectedCity ->
        selectedNurseForBooking = null
        filterCityForNurses = selectedCity
        currentTab = DashboardTab.NURSES
        confirmedBookingInfo = Triple(serviceTitle, patientName, selectedCity)
      }
    )
  }

  // Booking Success Dialog
  confirmedBookingInfo?.let { (serviceTitle, patientName, selectedCity) ->
    BookingSuccessDialog(
      serviceTitle = serviceTitle,
      patientName = patientName,
      selectedCity = selectedCity,
      language = language,
      onDismiss = {
        confirmedBookingInfo = null
      }
    )
  }

  // Admin Passcode Dialog (Passcode: 0932189336BSHERbsher)
  if (showAdminDialog) {
    androidx.compose.material3.AlertDialog(
      onDismissRequest = { showAdminDialog = false },
      title = {
        Text(
          text = if (isArabic) "لوحة تحكم المشرف (Admin Portal)" else "Admin Portal",
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Column {
          Text(
            text = if (isArabic) "أدخل رمز المرور السري للمشرف للمتابعة:" else "Enter the admin passcode to access:",
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.height(10.dp))
          androidx.compose.material3.OutlinedTextField(
            value = adminPasscodeInput,
            onValueChange = {
              adminPasscodeInput = it
              adminPasscodeError = false
            },
            label = { Text("رمز المرور (Passcode)") },
            singleLine = true,
            isError = adminPasscodeError,
            modifier = Modifier.fillMaxWidth().testTag("admin_passcode_input")
          )
          if (adminPasscodeError) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isArabic) "رمز المرور غير صحيح" else "Incorrect passcode",
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (adminPasscodeInput.trim() == "0932189336BSHERbsher") {
              showAdminDialog = false
              onOpenAdmin()
            } else {
              adminPasscodeError = true
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
          modifier = Modifier.testTag("admin_passcode_confirm_button")
        ) {
          Text(if (isArabic) "دخول" else "Enter")
        }
      },
      dismissButton = {
        androidx.compose.material3.TextButton(onClick = { showAdminDialog = false }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }
}

@Composable
fun CompactMedicalServiceCard(
  service: MedicalService,
  language: AppLanguage,
  onBookClicked: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp, pressedElevation = 3.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("card_service_${service.id}")
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Realistic High-Quality Photo Header
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(1.25f)
      ) {
        Image(
          painter = painterResource(id = service.imageRes),
          contentDescription = if (isArabic) service.titleAr else service.titleEn,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Subtle gradient overlay for clear contrast
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color(0x33000000),
                  Color.Transparent,
                  Color(0x66000000)
                )
              )
            )
        )

        // Category Tag
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaroonPrimary.copy(alpha = 0.92f),
          modifier = Modifier
            .padding(6.dp)
            .align(Alignment.TopStart)
        ) {
          Text(
            text = if (isArabic) service.categoryAr else service.categoryEn,
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 9.5.sp,
              fontWeight = FontWeight.Bold
            ),
            color = Color.White,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      // Compact Card Content
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp)
      ) {
        // Service Title
        Text(
          text = if (isArabic) service.titleAr else service.titleEn,
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp,
            lineHeight = 16.sp
          ),
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 2,
          minLines = 2,
          overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Action Button: "Book Service Only" (حجز الخدمة فقط)
        Button(
          onClick = onBookClicked,
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaroonPrimary,
            contentColor = MaroonOnPrimary
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .testTag("book_service_${service.id}")
        ) {
          Icon(
            Icons.Default.EventNote,
            contentDescription = null,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "حجز الخدمة فقط" else "Book Service Only",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            ),
            maxLines = 1
          )
        }
      }
    }
  }
}

@Composable
fun CompactReassuranceFooter(language: AppLanguage) {
  val isArabic = language == AppLanguage.ARABIC

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(top = 4.dp, bottom = 8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.Shield,
          contentDescription = null,
          tint = MaroonPrimary,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isArabic) {
            "جميع الممرضين معتمدون ومرخصون من هيئة التخصصات الصحية مع أعلى معايير التعقيم الطبي."
          } else {
            "All nurses are officially certified by health authorities adhering to sterile clinical protocols."
          },
          style = MaterialTheme.typography.labelSmall.copy(
            fontSize = 10.5.sp,
            lineHeight = 14.sp
          ),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "حقوق التطبيق والمنصة محفوظة © بشير الابراهيم (GoNurse Owner)",
      style = MaterialTheme.typography.labelSmall.copy(
        fontWeight = FontWeight.SemiBold,
        fontSize = 10.sp
      ),
      color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
  }
}


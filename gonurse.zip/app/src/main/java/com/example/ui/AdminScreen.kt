package com.example.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.content.Intent
import android.net.Uri
import com.example.model.NursingRequest
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.PendingAccountDeletion
import com.example.model.PendingProfileUpdate
import com.example.model.PendingRegistration
import com.example.model.SubmittedReport
import com.example.ui.components.AdminImageInspectionDialog
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AdminTab(val titleAr: String, val titleEn: String) {
  REGISTRATIONS("طلبات إنشاء حساب ممرض", "Nurse Account Applications"),
  PATIENT_REQUESTS("طلبات المرضى والزيارات", "Patient Requests"),
  UPDATES("تعديل البيانات", "Profile Updates"),
  DELETIONS("طلبات حذف الحسابات", "Account Deletions"),
  REPORTS("البلاغات", "Reports")
}

/**
 * Protected Admin Screen secured with passcode 0932189336BSHERbsher.
 * Provides management workflows for Registration, Profile Updates, Account Deletion, and Reports
 * completely integrated with Firebase RTDB for full administrative actions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
  language: AppLanguage,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  var selectedTab by remember { mutableStateOf(AdminTab.REGISTRATIONS) }

  // Initial bundle from cache provides instantaneous 0ms display on screen opening
  val initialBundle = FirebaseRealtimeRepository.adminDataFlow.value
  var isLoading by remember { mutableStateOf(initialBundle == null) }

  // Dismissed item tracking to prevent ghost items from lingering or reappearing upon background syncs
  var dismissedRegistrationIds by remember { mutableStateOf(setOf<String>()) }
  var dismissedUpdateIds by remember { mutableStateOf(setOf<String>()) }
  var dismissedDeletionIds by remember { mutableStateOf(setOf<String>()) }
  var dismissedReportIds by remember { mutableStateOf(setOf<String>()) }
  var completedRequestIds by remember { mutableStateOf(setOf<String>()) }

  var pendingRegistrations by remember {
    mutableStateOf(initialBundle?.registrations ?: emptyList())
  }
  var patientRequests by remember {
    mutableStateOf(initialBundle?.patientRequests ?: emptyList())
  }
  var pendingUpdates by remember {
    mutableStateOf(initialBundle?.updates ?: emptyList())
  }
  var pendingDeletions by remember {
    mutableStateOf(initialBundle?.deletions ?: emptyList())
  }
  var submittedReports by remember {
    mutableStateOf(initialBundle?.reports ?: emptyList())
  }

  // Rejection Dialog State
  var rejectingRegistrationId by remember { mutableStateOf<PendingRegistration?>(null) }
  var rejectionReasonText by remember { mutableStateOf("") }

  // Deletion Confirmation Dialog State (Process / Wipe vs Cancel / Keep)
  var confirmingDeletionItem by remember { mutableStateOf<PendingAccountDeletion?>(null) }
  var cancelingDeletionItem by remember { mutableStateOf<PendingAccountDeletion?>(null) }

  // Visual Image Inspection Dialog State
  var inspectingImageTitle by remember { mutableStateOf("") }
  var inspectingImageSubtitle by remember { mutableStateOf("") }
  var inspectingImageBase64 by remember { mutableStateOf<String?>(null) }

  BackHandler {
    onNavigateBack()
  }

  var isRefreshing by remember { mutableStateOf(false) }

  fun reloadAll(isManual: Boolean = false) {
    coroutineScope.launch {
      if (isManual) isRefreshing = true
      try {
        val bundle = FirebaseRealtimeRepository.triggerAdminDataSync(forceRefresh = isManual)
        pendingRegistrations = bundle.registrations.filter { it.id !in dismissedRegistrationIds }
        patientRequests = bundle.patientRequests.map { if (it.id in completedRequestIds) it.copy(isCompleted = true) else it }
        pendingUpdates = bundle.updates.filter { it.id !in dismissedUpdateIds }
        pendingDeletions = bundle.deletions.filter { it.id !in dismissedDeletionIds }
        submittedReports = bundle.reports.filter { it.id !in dismissedReportIds }
      } catch (e: Exception) {
        if (isManual) {
          Toast.makeText(context, "فشل جلب الطلبات: ${e.message}", Toast.LENGTH_SHORT).show()
        }
      } finally {
        isLoading = false
        isRefreshing = false
      }
    }
  }

  // Real-time reactive flow collector: immediately updates admin state and filters out processed items
  LaunchedEffect(Unit) {
    FirebaseRealtimeRepository.adminDataFlow.collect { bundle ->
      if (bundle != null) {
        pendingRegistrations = bundle.registrations.filter { it.id !in dismissedRegistrationIds }
        patientRequests = bundle.patientRequests.map { if (it.id in completedRequestIds) it.copy(isCompleted = true) else it }
        pendingUpdates = bundle.updates.filter { it.id !in dismissedUpdateIds }
        pendingDeletions = bundle.deletions.filter { it.id !in dismissedDeletionIds }
        submittedReports = bundle.reports.filter { it.id !in dismissedReportIds }
        isLoading = false
      }
    }
  }

  // Single-event fetch on screen launch only if no cache exists
  LaunchedEffect(Unit) {
    if (FirebaseRealtimeRepository.adminDataFlow.value == null) {
      reloadAll(isManual = false)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Security,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isArabic) "شاشة المشرف المعتمد" else "Admin Portal",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaroonPrimary
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = CircleShape,
                  color = Color(0xFF16A34A),
                  modifier = Modifier.size(6.dp)
                ) {}
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isArabic) "مزامنة لحظية نشطة مع قاعدة البيانات" else "Real-time sync active",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("admin_back_button")
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = MaroonPrimary
            )
          }
        },
        actions = {
          if (isRefreshing) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              color = MaroonPrimary,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
          }
          IconButton(
            onClick = { reloadAll(isManual = true) },
            modifier = Modifier.testTag("admin_refresh_button")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = MaroonPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      // Tab Row with live pending counts
      ScrollableTabRow(
        selectedTabIndex = selectedTab.ordinal,
        edgePadding = 12.dp,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaroonPrimary
      ) {
        AdminTab.values().forEach { tab ->
          val count = when (tab) {
            AdminTab.REGISTRATIONS -> pendingRegistrations.size
            AdminTab.PATIENT_REQUESTS -> patientRequests.count { !it.isCompleted }
            AdminTab.UPDATES -> pendingUpdates.size
            AdminTab.DELETIONS -> pendingDeletions.size
            AdminTab.REPORTS -> submittedReports.size
          }
          Tab(
            selected = selectedTab == tab,
            onClick = { selectedTab = tab },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = if (isArabic) tab.titleAr else tab.titleEn,
                  fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                )
                if (count > 0) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = CircleShape,
                    color = if (selectedTab == tab) MaroonPrimary else Color(0xFF64748B)
                  ) {
                    Text(
                      text = count.toString(),
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }
              }
            }
          )
        }
      }

      if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = MaroonPrimary)
        }
      } else {
        when (selectedTab) {
          AdminTab.REGISTRATIONS -> {
            RegistrationsTabContent(
              items = pendingRegistrations,
              isArabic = isArabic,
              onInspectImage = { title, subtitle, base64 ->
                inspectingImageTitle = title
                inspectingImageSubtitle = subtitle
                inspectingImageBase64 = base64
              },
              onApprove = { reg ->
                val targetId = reg.id
                dismissedRegistrationIds = dismissedRegistrationIds + targetId
                pendingRegistrations = pendingRegistrations.filter { it.id != targetId }
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.approveRegistration(targetId)
                  if (success) {
                    Toast.makeText(context, if (isArabic) "تم اعتماد وتوثيق الحساب بنجاح في قاعدة البيانات" else "Nurse account approved and verified", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "فشل اعتماد الحساب في الخادم", Toast.LENGTH_SHORT).show()
                    dismissedRegistrationIds = dismissedRegistrationIds - targetId
                    reloadAll(isManual = true)
                  }
                }
              },
              onRejectPrompt = { reg ->
                rejectingRegistrationId = reg
                rejectionReasonText = ""
              }
            )
          }

          AdminTab.PATIENT_REQUESTS -> {
            PatientRequestsAdminTabContent(
              items = patientRequests,
              isArabic = isArabic,
              onRefresh = { reloadAll(isManual = true) },
              onMarkCompleted = { reqId ->
                completedRequestIds = completedRequestIds + reqId
                patientRequests = patientRequests.map { if (it.id == reqId) it.copy(isCompleted = true) else it }
              }
            )
          }

          AdminTab.UPDATES -> {
            UpdatesTabContent(
              items = pendingUpdates,
              isArabic = isArabic,
              onInspectImage = { title, subtitle, base64 ->
                inspectingImageTitle = title
                inspectingImageSubtitle = subtitle
                inspectingImageBase64 = base64
              },
              onApprove = { upd ->
                val targetId = upd.id
                dismissedUpdateIds = dismissedUpdateIds + targetId
                pendingUpdates = pendingUpdates.filter { it.id != targetId }
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.approveProfileUpdate(upd)
                  if (success) {
                    Toast.makeText(context, if (isArabic) "تمت الموافقة على تعديل البيانات وتحديث الملف العام بنجاح" else "Profile update approved and applied", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "فشل حفظ التحديث في الخادم", Toast.LENGTH_SHORT).show()
                    dismissedUpdateIds = dismissedUpdateIds - targetId
                    reloadAll(isManual = true)
                  }
                }
              },
              onReject = { upd ->
                val targetId = upd.id
                dismissedUpdateIds = dismissedUpdateIds + targetId
                pendingUpdates = pendingUpdates.filter { it.id != targetId }
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.rejectProfileUpdate(targetId, nurseId = upd.nurseId, reason = "رفض المشرف")
                  if (success) {
                    Toast.makeText(context, if (isArabic) "تم رفض طلب تعديل البيانات" else "Profile update request rejected", Toast.LENGTH_SHORT).show()
                  } else {
                    dismissedUpdateIds = dismissedUpdateIds - targetId
                    reloadAll(isManual = true)
                  }
                }
              }
            )
          }

          AdminTab.DELETIONS -> {
            DeletionsTabContent(
              items = pendingDeletions,
              isArabic = isArabic,
              onApprovePrompt = { del ->
                confirmingDeletionItem = del
              },
              onCancelPrompt = { del ->
                cancelingDeletionItem = del
              }
            )
          }

          AdminTab.REPORTS -> {
            ReportsTabContent(
              items = submittedReports,
              isArabic = isArabic,
              onDismissReport = { report ->
                val targetId = report.id
                dismissedReportIds = dismissedReportIds + targetId
                submittedReports = submittedReports.filter { it.id != targetId }
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.deleteReport(targetId)
                  if (success) {
                    Toast.makeText(context, if (isArabic) "تم إغلاق البلاغ بنجاح" else "Report closed successfully", Toast.LENGTH_SHORT).show()
                  } else {
                    dismissedReportIds = dismissedReportIds - targetId
                    reloadAll(isManual = true)
                  }
                }
              },
              onFollowUpViaWhatsApp = { report ->
                val targetPhone = report.reporterPhone.trim()
                if (targetPhone.filter { it.isDigit() }.length >= 7) {
                  val msg = """
                    🚨 متابعة بلاغ وارد في تطبيق GoNurse:
                    • معرف البلاغ: ${report.id}
                    • المُبَلِّغ: ${report.reporterPhone.ifBlank { "غير مسجل" }} ${if (report.reporterCountry.isNotBlank()) "(${report.reporterCountry})" else ""}
                    • المُبَلَّغ عنه: ${report.targetName} (${report.targetType} - ${report.targetCity})
                    • سبب البلاغ: ${report.reason}
                    • الملاحظات: ${report.additionalNotes.ifBlank { "لا توجد ملاحظات إضافية" }}
                  """.trimIndent()
                  WhatsAppHelper.openWhatsApp(context, targetPhone, msg, report.reporterCountry)
                } else {
                  android.widget.Toast.makeText(
                    context,
                    if (isArabic) "رقم هاتف المُبلِّغ غير متوفر للمتابعة" else "Reporter phone is not available",
                    android.widget.Toast.LENGTH_SHORT
                  ).show()
                }
              }
            )
          }
        }
      }
    }
  }

  // Registration Rejection Dialog
  if (rejectingRegistrationId != null) {
    val reg = rejectingRegistrationId!!
    AlertDialog(
      onDismissRequest = { rejectingRegistrationId = null },
      title = {
        Text(if (isArabic) "رفض طلب إنشاء الحساب" else "Reject Nurse Application")
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            if (isArabic) "يرجى تحديد سبب الرفض لحفظه في السجل:"
            else "Specify rejection reason:"
          )
          OutlinedTextField(
            value = rejectionReasonText,
            onValueChange = { rejectionReasonText = it },
            placeholder = { Text(if (isArabic) "مثال: صورة الترخيص غير واضحة..." else "e.g., Unclear license image") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val target = reg
            val reason = rejectionReasonText
            val targetId = target.id
            rejectingRegistrationId = null
            dismissedRegistrationIds = dismissedRegistrationIds + targetId
            pendingRegistrations = pendingRegistrations.filter { it.id != targetId }
            coroutineScope.launch {
              val success = FirebaseRealtimeRepository.rejectRegistration(targetId, reason)
              if (success) {
                Toast.makeText(context, if (isArabic) "تم رفض الطلب بنجاح" else "Application rejected", Toast.LENGTH_SHORT).show()
              } else {
                Toast.makeText(context, "فشل رفض الطلب في الخادم", Toast.LENGTH_SHORT).show()
                dismissedRegistrationIds = dismissedRegistrationIds - targetId
                reloadAll(isManual = true)
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
          Text(if (isArabic) "تأكيد الرفض" else "Confirm Reject")
        }
      },
      dismissButton = {
        TextButton(onClick = { rejectingRegistrationId = null }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }

  // Account Deletion Approval Confirmation Dialog
  if (confirmingDeletionItem != null) {
    val del = confirmingDeletionItem!!
    AlertDialog(
      onDismissRequest = { confirmingDeletionItem = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            if (isArabic) "تأكيد حذف الحساب نهائياً" else "Confirm Permanent Deletion",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFFDC2626)
          )
        }
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = if (isArabic)
              "تحذير شديد: أنت على وشك مسح حساب الممرض بشكل نهائي لا رجعة فيه:"
            else
              "Warning: You are about to permanently erase this nurse account:",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
          )
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFFEF2F2),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              if (del.nurseName.isNotBlank()) {
                Text(text = "• اسم الممرض: ${del.nurseName}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
              }
              Text(text = "• رقم الهاتف المسجل: ${del.registeredPhone}", style = MaterialTheme.typography.bodySmall)
              if (del.nurseId.isNotBlank()) {
                Text(text = "• معرّف الحساب: ${del.nurseId}", style = MaterialTheme.typography.bodySmall)
              }
              Text(text = "• الدولة والمدينة: ${del.country}${if (del.city.isNotBlank()) " - " + del.city else ""}", style = MaterialTheme.typography.bodySmall)
              if (del.reason.isNotBlank()) {
                Text(text = "• سبب الحذف: ${del.reason}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFB91C1C))
              }
            }
          }
          Text(
            text = if (isArabic)
              "سيتم حذف كافة البيانات والتقييمات والسجلات من خوادم وقاعدة بيانات Firebase والتخزين المحلي نهائياً. هل ترغب في إتمام المسح الآن؟"
            else
              "All nurse data, reviews, and records will be permanently removed from Firebase RTDB and local cache. Proceed?",
            style = MaterialTheme.typography.bodySmall
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val target = del
            val targetId = del.id
            confirmingDeletionItem = null
            dismissedDeletionIds = dismissedDeletionIds + targetId
            pendingDeletions = pendingDeletions.filter { it.id != targetId }
            coroutineScope.launch {
              val success = FirebaseRealtimeRepository.approveAccountDeletion(target)
              if (success) {
                Toast.makeText(context, if (isArabic) "تم حذف الحساب بالكامل وبشكل نهائي من خوادم Firebase" else "Account permanently deleted from Firebase", Toast.LENGTH_LONG).show()
              } else {
                Toast.makeText(context, "فشل حذف الحساب من خادم Firebase", Toast.LENGTH_SHORT).show()
                dismissedDeletionIds = dismissedDeletionIds - targetId
                reloadAll(isManual = true)
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
          shape = RoundedCornerShape(8.dp)
        ) {
          Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isArabic) "نعم، مسح وحذف نهائي" else "Wipe Account")
        }
      },
      dismissButton = {
        OutlinedButton(
          onClick = { confirmingDeletionItem = null },
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(if (isArabic) "تراجع" else "Cancel")
        }
      }
    )
  }

  // Account Deletion Cancellation Confirmation Dialog
  if (cancelingDeletionItem != null) {
    val del = cancelingDeletionItem!!
    AlertDialog(
      onDismissRequest = { cancelingDeletionItem = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Close, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(22.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            if (isArabic) "تأكيد إلغاء طلب حذف الحساب" else "Confirm Cancel Deletion Request",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaroonPrimary
          )
        }
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = if (isArabic)
              "هل أنت متأكد من رغبتك في إلغاء طلب حذف الحساب والإبقاء على الحساب نشطاً في تطبيق GoNurse؟"
            else
              "Are you sure you want to cancel this deletion request and keep the account active?",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
          )
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              if (del.nurseName.isNotBlank()) {
                Text(
                  text = "• ${if (isArabic) "الممرض" else "Nurse"}: ${del.nurseName}",
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )
              }
              Text(
                text = "• ${if (isArabic) "رقم الهاتف" else "Phone"}: ${del.registeredPhone}",
                style = MaterialTheme.typography.bodySmall
              )
              if (del.country.isNotBlank() || del.city.isNotBlank()) {
                Text(
                  text = "• ${if (isArabic) "الموقع" else "Location"}: ${del.country}${if (del.city.isNotBlank()) " - " + del.city else ""}",
                  style = MaterialTheme.typography.bodySmall
                )
              }
              if (del.reason.isNotBlank()) {
                Text(
                  text = "• ${if (isArabic) "السبب المذكور" else "Reason"}: ${del.reason}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
          Text(
            text = if (isArabic)
              "سيتم حذف هذا الطلب فقط من قائمة طلبات الحذف المعلقة، ولن تتأثر بيانات الممرض أو تقييماته وسيبقى حسابه متاحاً للعملاء."
            else
              "Only the pending request will be dismissed. The nurse profile and all evaluations will remain fully operational.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val target = del
            val targetId = del.id
            cancelingDeletionItem = null
            dismissedDeletionIds = dismissedDeletionIds + targetId
            pendingDeletions = pendingDeletions.filter { it.id != targetId }
            coroutineScope.launch {
              val success = FirebaseRealtimeRepository.rejectAccountDeletion(targetId, nurseId = target.nurseId, reason = "إلغاء الطلب من قبل المشرف")
              if (success) {
                Toast.makeText(
                  context,
                  if (isArabic) "تم إلغاء طلب حذف الحساب والاحتفاظ بالحساب نشطاً بنجاح" else "Deletion request cancelled, account preserved",
                  Toast.LENGTH_SHORT
                ).show()
              } else {
                Toast.makeText(context, "فشل إلغاء الطلب في الخادم", Toast.LENGTH_SHORT).show()
                dismissedDeletionIds = dismissedDeletionIds - targetId
                reloadAll(isManual = true)
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
          shape = RoundedCornerShape(8.dp)
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isArabic) "نعم، إلغاء الطلب والاحتفاظ بالحساب" else "Confirm Cancel & Keep Account")
        }
      },
      dismissButton = {
        OutlinedButton(
          onClick = { cancelingDeletionItem = null },
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(if (isArabic) "تراجع" else "Dismiss")
        }
      }
    )
  }

  // Visual Image Inspection Dialog (Pinch-to-zoom 500% & pan for stamps, certifications, licenses)
  if (!inspectingImageBase64.isNullOrBlank()) {
    AdminImageInspectionDialog(
      title = inspectingImageTitle,
      subtitle = inspectingImageSubtitle,
      imageBase64 = inspectingImageBase64!!,
      onDismiss = { inspectingImageBase64 = null },
      isArabic = isArabic
    )
  }
}

@Composable
private fun RegistrationsTabContent(
  items: List<PendingRegistration>,
  isArabic: Boolean,
  onInspectImage: (title: String, subtitle: String, base64: String) -> Unit,
  onApprove: (PendingRegistration) -> Unit,
  onRejectPrompt: (PendingRegistration) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات إنشاء حسابات معلقة حالياً" else "No pending account applications",
      subtitle = if (isArabic) "تظهر طلبات إنشاء حسابات الممرضين الجديدة هنا فور تقديمها" else "New nurse applications will appear here"
    )
    return
  }

  var searchQuery by remember { mutableStateOf("") }
  var filterStatus by remember { mutableStateOf("ALL") } // ALL, WITH_LICENSE, NO_LICENSE
  var visibleLimit by remember { mutableIntStateOf(25) }

  val filteredItems = remember(items, searchQuery, filterStatus) {
    val q = searchQuery.trim().lowercase()
    items.filter { reg ->
      val matchesSearch = q.isBlank() ||
          reg.name.lowercase().contains(q) ||
          reg.phone.contains(q) ||
          reg.city.lowercase().contains(q) ||
          reg.country.lowercase().contains(q) ||
          reg.id.lowercase().contains(q)
      val matchesFilter = when (filterStatus) {
        "WITH_LICENSE" -> reg.licenseImageBase64.isNotBlank()
        "NO_LICENSE" -> reg.licenseImageBase64.isBlank()
        else -> true
      }
      matchesSearch && matchesFilter
    }
  }

  val displayedItems = remember(filteredItems, visibleLimit) {
    filteredItems.take(visibleLimit)
  }

  Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp)) {
    // Quick Search & Filter Header
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier.fillMaxWidth().testTag("admin_registrations_search"),
      placeholder = { Text(if (isArabic) "بحث بالاسم، الهاتف، المدينة..." else "Search by name, phone, city...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaroonPrimary) },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(12.dp)
    )

    Spacer(modifier = Modifier.height(6.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      FilterChip(
        selected = filterStatus == "ALL",
        onClick = { filterStatus = "ALL" },
        label = { Text(if (isArabic) "الكل (${items.size})" else "All (${items.size})") }
      )
      val withLicenseCount = remember(items) { items.count { it.licenseImageBase64.isNotBlank() } }
      FilterChip(
        selected = filterStatus == "WITH_LICENSE",
        onClick = { filterStatus = "WITH_LICENSE" },
        label = { Text(if (isArabic) "مع ترخيص ($withLicenseCount)" else "With License ($withLicenseCount)") }
      )
      val withoutLicenseCount = items.size - withLicenseCount
      FilterChip(
        selected = filterStatus == "NO_LICENSE",
        onClick = { filterStatus = "NO_LICENSE" },
        label = { Text(if (isArabic) "بدون ترخيص ($withoutLicenseCount)" else "No License ($withoutLicenseCount)") }
      )
    }

    Spacer(modifier = Modifier.height(8.dp))

    if (displayedItems.isEmpty()) {
      Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
          text = if (isArabic) "لا توجد طلبات تطابق البحث" else "No applications match your search",
          style = MaterialTheme.typography.bodyMedium,
          color = Color(0xFF64748B)
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(displayedItems, key = { it.id }) { reg ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_reg_card_${reg.id}"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  val profileBmp by produceState<Bitmap?>(initialValue = null, reg.profileImageBase64) {
                    value = if (reg.profileImageBase64.isNotBlank()) {
                      withContext(Dispatchers.Default) {
                        ImageCompressor.getCachedOrDecodeBase64(reg.profileImageBase64)
                      }
                    } else null
                  }

                  if (profileBmp != null) {
                    Box(
                      modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, MaroonPrimary, CircleShape)
                        .clickable {
                          onInspectImage(
                            if (isArabic) "الصورة الشخصية للممرض" else "Nurse Profile Picture",
                            "${reg.country} • ${reg.city} (${reg.phone})",
                            reg.profileImageBase64
                          )
                        },
                      contentAlignment = Alignment.Center
                    ) {
                      Image(
                        bitmap = profileBmp!!.asImageBitmap(),
                        contentDescription = "Profile Picture",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                      )
                    }
                  } else {
                    Box(
                      modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaroonPrimary.copy(alpha = 0.1f)),
                      contentAlignment = Alignment.Center
                    ) {
                      Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(22.dp))
                    }
                  }
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = reg.name.ifBlank { reg.phone },
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = "${reg.phone} • ${reg.country} • ${reg.city}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = Color(0xFFF59E0B).copy(alpha = 0.15f)
                ) {
                  Text(
                    text = if (isArabic) "قيد المراجعة" else "Pending",
                    color = Color(0xFFB45309),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }

              if (reg.bio.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(
                    text = "النبذة: ${reg.bio}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                  )
                }
              }

              // VISUAL INSPECTION SECTION (Profile Photo & License Document)
              if (reg.profileImageBase64.isNotBlank() || reg.licenseImageBase64.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                  verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Text(
                    text = if (isArabic) "المستندات والصور المرفقة للفحص والتدقيق:" else "Attached Media for Visual Inspection:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaroonPrimary
                  )

                  // Profile Picture inspection row
                  if (reg.profileImageBase64.isNotBlank()) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(
                          Icons.Default.Person,
                          contentDescription = null,
                          tint = Color(0xFF2563EB),
                          modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = if (isArabic) "الصورة الشخصية (مؤطرة ومضغوطة)" else "Profile Photo (Framed)",
                          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                          maxLines = 1,
                          overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                      }

                      OutlinedButton(
                        onClick = {
                          onInspectImage(
                            if (isArabic) "الصورة الشخصية للممرض" else "Nurse Profile Picture",
                            "${reg.country} - ${reg.city} • ${reg.phone}",
                            reg.profileImageBase64
                          )
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("admin_inspect_profile_${reg.id}")
                      ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaroonPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isArabic) "معاينة الوجه" else "Inspect Face", style = MaterialTheme.typography.labelSmall, color = MaroonPrimary)
                      }
                    }
                  }

                  // License Document inspection row
                  if (reg.licenseImageBase64.isNotBlank()) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                    ) {
                      Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Icon(
                          Icons.Default.VerifiedUser,
                          contentDescription = null,
                          tint = Color(0xFF16A34A),
                          modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f, fill = false)) {
                          Text(
                            text = if (isArabic) "وثيقة ترخيص مزاولة المهنة" else "Practice License Document",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                          )
                          Text(
                            text = if (isArabic) "فحص الأختام والشهادة بدقة عالية" else "Inspect stamps & credentials",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                          )
                        }
                      }

                      Button(
                        onClick = {
                          onInspectImage(
                            if (isArabic) "وثيقة ترخيص مزاولة المهنة" else "Practice License Document",
                            "${reg.country} - ${reg.city} • ${reg.phone}",
                            reg.licenseImageBase64
                          )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("admin_inspect_license_${reg.id}")
                      ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isArabic) "فحص وتكبير (Zoom)" else "Inspect License", style = MaterialTheme.typography.labelSmall, color = Color.White)
                      }
                    }
                  }
                }
              } else {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = Color(0xFFFEF3C7),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = if (isArabic) "تنبيه للمشرف: لم يرفع الممرض وثيقة ترخيص. اعتماد الحساب لن يمنحه الشارة الزرقاء حتى يرفع رخصة معتمدة."
                      else "Admin Notice: No license uploaded. Approving will activate the profile without the verified badge.",
                      style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF92400E))
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              // WhatsApp Communication Button for Manual Verification
              val context = LocalContext.current
              Button(
                onClick = {
                  WhatsAppHelper.openWhatsApp(
                    context,
                    reg.phone,
                    if (isArabic) "مرحباً، معك مشرف تطبيق GoNurse بخصوص طلب إنشاء حساب ممرض والتوثيق."
                    else "Hello, GoNurse Admin here regarding your registration."
                  )
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("admin_whatsapp_reg_${reg.id}"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                shape = RoundedCornerShape(10.dp)
              ) {
                Icon(Icons.Default.Phone, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isArabic) "تواصل وتحقق عبر واتساب" else "Verify via WhatsApp", color = Color.White)
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Approve / Reject Actions
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Button(
                  onClick = { onApprove(reg) },
                  modifier = Modifier
                    .weight(1f)
                    .testTag("admin_approve_reg_${reg.id}"),
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    if (isArabic) {
                      if (reg.licenseImageBase64.isNotBlank()) "اعتماد وتوثيق الترخيص" else "تفعيل الحساب (بدون توثيق)"
                    } else {
                      if (reg.licenseImageBase64.isNotBlank()) "Approve & Verify" else "Activate (Unverified)"
                    }
                  )
                }

                OutlinedButton(
                  onClick = { onRejectPrompt(reg) },
                  modifier = Modifier
                    .weight(1f)
                    .testTag("admin_reject_reg_${reg.id}"),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(if (isArabic) "رفض الطلب" else "Reject")
                }
              }
            }
          }
        }

        if (filteredItems.size > visibleLimit) {
          item {
            Box(
              modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
              contentAlignment = Alignment.Center
            ) {
              OutlinedButton(
                onClick = { visibleLimit += 25 },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("admin_load_more_registrations")
              ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaroonPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "عرض المزيد من الطلبات (المتبقي: ${filteredItems.size - visibleLimit})"
                  else "Load more (${filteredItems.size - visibleLimit} remaining)",
                  fontWeight = FontWeight.SemiBold,
                  color = MaroonPrimary
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PatientRequestsAdminTabContent(
  items: List<NursingRequest>,
  isArabic: Boolean,
  onRefresh: () -> Unit,
  onMarkCompleted: (String) -> Unit = {}
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  var searchQuery by remember { mutableStateOf("") }
  var filterStatus by remember { mutableStateOf("ALL") }

  val filteredItems = remember(items, searchQuery, filterStatus) {
    val query = searchQuery.trim().lowercase()
    items.filter { req ->
      val matchesSearch = query.isBlank() ||
          req.patientName.lowercase().contains(query) ||
          req.patientPhone.contains(query) ||
          req.whatsappNumber.contains(query) ||
          req.serviceName.lowercase().contains(query) ||
          req.city.lowercase().contains(query) ||
          req.notes.lowercase().contains(query)

      val matchesStatus = when (filterStatus) {
        "PENDING" -> !req.isCompleted
        "COMPLETED" -> req.isCompleted
        else -> true
      }
      matchesSearch && matchesStatus
    }.sortedByDescending { it.timestamp }
  }

  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات تمريضية مسجلة حالياً" else "No nursing requests recorded",
      subtitle = if (isArabic) "تظهر جميع طلبات المرضى والزيارات المحجوزة هنا فور إرسالها" else "Patient home visit requests will appear here"
    )
    return
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 14.dp, vertical = 8.dp)
  ) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 8.dp)
        .testTag("admin_requests_search_input"),
      placeholder = {
        Text(
          text = if (isArabic) "بحث باسم المريض أو الهاتف أو الخدمة أو المدينة..." else "Search patient, phone, service, city...",
          style = MaterialTheme.typography.bodySmall,
          color = Color(0xFF94A3B8)
        )
      },
      leadingIcon = {
        Icon(Icons.Default.Search, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(20.dp))
      },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { searchQuery = "" }) {
            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
          }
        }
      },
      singleLine = true,
      shape = RoundedCornerShape(10.dp)
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 10.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      FilterChip(
        selected = filterStatus == "ALL",
        onClick = { filterStatus = "ALL" },
        label = { Text(if (isArabic) "الكل (${items.size})" else "All (${items.size})") }
      )
      FilterChip(
        selected = filterStatus == "PENDING",
        onClick = { filterStatus = "PENDING" },
        label = { Text(if (isArabic) "قيد الانتظار (${items.count { !it.isCompleted }})" else "Pending (${items.count { !it.isCompleted }})") }
      )
      FilterChip(
        selected = filterStatus == "COMPLETED",
        onClick = { filterStatus = "COMPLETED" },
        label = { Text(if (isArabic) "منجزة (${items.count { it.isCompleted }})" else "Completed (${items.count { it.isCompleted }})") }
      )
    }

    if (filteredItems.isEmpty()) {
      Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
          text = if (isArabic) "لا توجد طلبات تطابق معايير البحث الحالية" else "No requests matching current filter",
          style = MaterialTheme.typography.bodyMedium,
          color = Color(0xFF64748B)
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredItems, key = { it.id }) { req ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_request_card_${req.id}"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = CircleShape,
                    color = MaroonPrimary.copy(alpha = 0.12f),
                    modifier = Modifier.size(36.dp)
                  ) {
                    Box(contentAlignment = Alignment.Center) {
                      Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(20.dp))
                    }
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = req.patientName.ifBlank { if (isArabic) "مريض (بدون اسم)" else "Patient (Unnamed)" },
                      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                      color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                      text = "${req.city} • ${req.country}",
                      style = MaterialTheme.typography.labelSmall,
                      color = Color(0xFF64748B)
                    )
                  }
                }

                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = if (req.isCompleted) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                ) {
                  Text(
                    text = if (req.isCompleted) (if (isArabic) "منجز" else "Completed") else (if (isArabic) "قيد الانتظار" else "Pending"),
                    color = if (req.isCompleted) Color(0xFF166534) else Color(0xFF92400E),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MedicalServices, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = req.serviceName,
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaroonPrimary
                )
              }

              if (req.address.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(text = req.address, style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                }
              }

              if (req.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.Top) {
                  Icon(Icons.Default.Notes, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = req.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                val contactPhone = req.getPhone().ifBlank { req.displayPhone }
                val contactDigits = contactPhone.filter { it.isDigit() }
                if (contactDigits.length >= 7 && !contactDigits.contains("932189336")) {
                  Button(
                    onClick = {
                      val patientTitle = req.patientName.ifBlank { if (isArabic) "المريض" else "Patient" }
                      val msg = if (isArabic) {
                        "مرحباً $patientTitle، نتواصل معك من إدارة تطبيق GoNurse بخصوص طلب خدمة (${req.serviceName})."
                      } else {
                        "Hello $patientTitle, contacting you from GoNurse regarding your request for (${req.serviceName})."
                      }
                      WhatsAppHelper.openWhatsAppWithPatient(context, contactPhone, msg, req.country)
                    },
                    modifier = Modifier.weight(1f).height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "واتساب المريض" else "WhatsApp", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  }
                }

                if (!req.isCompleted) {
                  OutlinedButton(
                    onClick = {
                      val targetId = req.id
                      onMarkCompleted(targetId)
                      coroutineScope.launch {
                        val ok = FirebaseRealtimeRepository.markRequestAsCompleted(targetId)
                        if (ok) {
                          Toast.makeText(context, if (isArabic) "تم تحديد الطلب كـ منجز" else "Marked as completed", Toast.LENGTH_SHORT).show()
                        }
                      }
                    },
                    modifier = Modifier.weight(1f).height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaroonPrimary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "تحديد كـ منجز" else "Complete", fontSize = 11.5.sp, color = MaroonPrimary)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun UpdatesTabContent(
  items: List<PendingProfileUpdate>,
  isArabic: Boolean,
  onInspectImage: (title: String, subtitle: String, base64: String) -> Unit,
  onApprove: (PendingProfileUpdate) -> Unit,
  onReject: (PendingProfileUpdate) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات تعديل بيانات معلقة" else "No pending profile updates",
      subtitle = if (isArabic) "تظهر طلبات تعديل بيانات الممرضين هنا مع مقارنة البيانات القديمة والجديدة" else "Profile modification requests will appear here"
    )
    return
  }

  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }
  val context = LocalContext.current

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { upd ->
      val contactPhone = upd.requestedPhone.ifBlank { upd.registeredPhone }
      val formattedDate = remember(upd.timestamp) {
        try {
          dateFormat.format(Date(upd.timestamp))
        } catch (_: Exception) {
          ""
        }
      }

      val isPhoneChanged = upd.requestedPhone.isNotBlank() && upd.requestedPhone != (upd.oldPhone.ifBlank { upd.registeredPhone })
      val oldPhoneDisplay = upd.oldPhone.ifBlank { upd.registeredPhone }
      val newPhoneDisplay = if (upd.requestedPhone.isNotBlank()) upd.requestedPhone else oldPhoneDisplay

      val oldLocationDisplay = listOf(upd.oldCountry, upd.oldCity).filter { it.isNotBlank() }.joinToString(" - ").ifBlank { if (isArabic) "غير محدد" else "Not specified" }
      val newCountry = upd.requestedCountry.ifBlank { upd.oldCountry }
      val newCity = upd.requestedCity.ifBlank { upd.oldCity }
      val newLocationDisplay = listOf(newCountry, newCity).filter { it.isNotBlank() }.joinToString(" - ").ifBlank { if (isArabic) "غير محدد" else "Not specified" }
      val isLocationChanged = (upd.requestedCountry.isNotBlank() && upd.requestedCountry != upd.oldCountry) ||
                              (upd.requestedCity.isNotBlank() && upd.requestedCity != upd.oldCity)

      val oldBioDisplay = upd.oldBio.ifBlank { if (isArabic) "لا توجد نبذة سابقة" else "No previous bio" }
      val newBioDisplay = if (upd.requestedBio.isNotBlank()) upd.requestedBio else oldBioDisplay
      val isBioChanged = upd.requestedBio.isNotBlank() && upd.requestedBio != upd.oldBio

      val hasNewPhoto = upd.requestedProfileImageBase64.isNotBlank()

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_update_card_${upd.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Card Header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color(0xFFEFF6FF),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "طلب تعديل الملف الشخصي" else "Profile Update Request",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFF1E3A8A)
                )
                if (formattedDate.isNotBlank()) {
                  Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFDBEAFE)
            ) {
              Text(
                text = if (isArabic) "قيد المراجعة" else "Pending Review",
                color = Color(0xFF1D4ED8),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Nurse Identity Header
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = upd.nurseName.ifBlank { if (isArabic) "ممرض مسجل" else "Registered Nurse" },
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "${if (isArabic) "رقم الحساب:" else "Phone:"} ${upd.registeredPhone}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              if (upd.nurseId.isNotBlank()) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.surface
                ) {
                  Text(
                    text = "ID: ${upd.nurseId.takeLast(8)}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Section Title: Old vs. New Data Comparison
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isArabic) "مقارنة البيانات (القديمة ⬅️ الجديدة):" else "Data Comparison (Current ⬅️ Requested):",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = MaroonPrimary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Old vs New Rows
          val isNameChanged = upd.requestedName.isNotBlank() && upd.requestedName != upd.nurseName
          val oldNameDisplay = upd.nurseName.ifBlank { if (isArabic) "غير محدد" else "Not specified" }
          val newNameDisplay = if (upd.requestedName.isNotBlank()) upd.requestedName else oldNameDisplay

          OldVsNewRow(
            label = if (isArabic) "الاسم الكامل" else "Full Name",
            oldValue = oldNameDisplay,
            newValue = newNameDisplay,
            isChanged = isNameChanged,
            isArabic = isArabic
          )

          OldVsNewRow(
            label = if (isArabic) "رقم الهاتف" else "Phone Number",
            oldValue = oldPhoneDisplay,
            newValue = newPhoneDisplay,
            isChanged = isPhoneChanged,
            isArabic = isArabic
          )

          OldVsNewRow(
            label = if (isArabic) "الدولة والمدينة" else "Location",
            oldValue = oldLocationDisplay,
            newValue = newLocationDisplay,
            isChanged = isLocationChanged,
            isArabic = isArabic
          )

          OldVsNewRow(
            label = if (isArabic) "النبذة التعريفية" else "Bio / Summary",
            oldValue = oldBioDisplay,
            newValue = newBioDisplay,
            isChanged = isBioChanged,
            isArabic = isArabic
          )

          // Profile Image Comparison
          if (hasNewPhoto) {
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFF0FDF4),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = if (isArabic) "الصورة الشخصية" else "Profile Picture",
                      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = Color(0xFFDCFCE7)
                    ) {
                      Text(
                        text = if (isArabic) "صورة جديدة" else "New Photo",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                        color = Color(0xFF15803D),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                      )
                    }
                  }

                  OutlinedButton(
                    onClick = {
                      onInspectImage(
                        if (isArabic) "الصورة الشخصية الجديدة للممرض" else "New Nurse Profile Picture",
                        "${upd.nurseName} • ${upd.registeredPhone}",
                        upd.requestedProfileImageBase64
                      )
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                  ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaroonPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isArabic) "معاينة وتكبير" else "Inspect", style = MaterialTheme.typography.labelSmall, color = MaroonPrimary)
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = if (isArabic) "الصورة الحالية" else "Current",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val oldBmp by produceState<Bitmap?>(initialValue = null, upd.oldProfileImageUri) {
                      value = if (upd.oldProfileImageUri.isNotBlank()) {
                        withContext(Dispatchers.Default) {
                          ImageCompressor.getCachedOrDecodeBase64(upd.oldProfileImageUri)
                        }
                      } else null
                    }
                    if (oldBmp != null) {
                      Image(
                        bitmap = oldBmp!!.asImageBitmap(),
                        contentDescription = "Old Profile Photo",
                        modifier = Modifier
                          .size(48.dp)
                          .clip(CircleShape)
                          .border(1.5.dp, Color(0xFF94A3B8), CircleShape),
                        contentScale = ContentScale.Crop
                      )
                    } else {
                      Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(48.dp)
                      ) {
                        Box(contentAlignment = Alignment.Center) {
                          Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(24.dp))
                        }
                      }
                    }
                  }

                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "to",
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(20.dp)
                  )

                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = if (isArabic) "الصورة الجديدة" else "Requested New",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                      color = Color(0xFF15803D)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val newBmp by produceState<Bitmap?>(initialValue = null, upd.requestedProfileImageBase64) {
                      value = if (upd.requestedProfileImageBase64.isNotBlank()) {
                        withContext(Dispatchers.Default) {
                          ImageCompressor.getCachedOrDecodeBase64(upd.requestedProfileImageBase64)
                        }
                      } else null
                    }
                    if (newBmp != null) {
                      Image(
                        bitmap = newBmp!!.asImageBitmap(),
                        contentDescription = "New Profile Photo",
                        modifier = Modifier
                          .size(48.dp)
                          .clip(CircleShape)
                          .border(2.dp, Color(0xFF16A34A), CircleShape),
                        contentScale = ContentScale.Crop
                      )
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // WhatsApp Communication Button
          Button(
            onClick = {
              WhatsAppHelper.openWhatsApp(
                context,
                contactPhone,
                if (isArabic) "مرحباً، معك مشرف تطبيق GoNurse بخصوص طلب تعديل بيانات حسابكم."
                else "Hello, GoNurse Admin here regarding your profile update request."
              )
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_whatsapp_update_${upd.id}"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Phone, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isArabic) "تواصل وتحقق عبر واتساب" else "Verify via WhatsApp", color = Color.White)
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Approve & Reject Action Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onApprove(upd) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_approve_update_${upd.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "موافقة" else "Approve", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = { onReject(upd) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_reject_update_${upd.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "رفض" else "Reject", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DeletionsTabContent(
  items: List<PendingAccountDeletion>,
  isArabic: Boolean,
  onApprovePrompt: (PendingAccountDeletion) -> Unit,
  onCancelPrompt: (PendingAccountDeletion) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات حذف حسابات معلقة" else "No pending account deletions",
      subtitle = if (isArabic) "تظهر طلبات حذف الحسابات هنا للمراجعة والتحقق ومسح الحساب نهائياً" else "Account deletion requests will appear here"
    )
    return
  }

  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }
  val context = LocalContext.current

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Management Section Header Banner
    item {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFFEF2F2),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = CircleShape,
            color = Color(0xFFFEE2E2),
            modifier = Modifier.size(40.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(22.dp))
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = if (isArabic) "إدارة طلبات حذف الحسابات" else "Account Deletions Management",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF991B1B)
              )
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFDC2626)
              ) {
                Text(
                  text = "${items.size} ${if (isArabic) "طلب معلق" else "pending"}",
                  color = Color.White,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isArabic)
                "راجع بيانات الممرض وتواصل معه عبر واتساب للتحقق من هويته، ثم يمكنك إما مسح الحساب نهائياً من خوادم Firebase أو إلغاء الطلب والإبقاء على الحساب نشطاً."
              else
                "Review nurse details and verify their identity via WhatsApp, then proceed with permanent deletion or cancel the request to keep the account active.",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Color(0xFF7F1D1D),
              lineHeight = 16.sp
            )
          }
        }
      }
    }

    items(items, key = { it.id }) { del ->
      val formattedDate = remember(del.timestamp) {
        try {
          dateFormat.format(Date(del.timestamp))
        } catch (_: Exception) {
          ""
        }
      }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_del_card_${del.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Top Card Header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = CircleShape,
                color = Color(0xFFFEE2E2),
                modifier = Modifier.size(36.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                }
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "طلب حذف حساب ممرض" else "Nurse Deletion Request",
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFDC2626)
                )
                if (formattedDate.isNotBlank()) {
                  Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFFEE2E2)
            ) {
              Text(
                text = if (isArabic) "قيد المراجعة" else "Pending Review",
                color = Color(0xFFB91C1C),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Requesting Nurse Details Card
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  shape = CircleShape,
                  color = MaroonPrimary.copy(alpha = 0.12f),
                  modifier = Modifier.size(34.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(20.dp))
                  }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = del.nurseName.ifBlank { if (isArabic) "ممرض مسجل" else "Registered Nurse" },
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                  )
                  if (del.nurseId.isNotBlank()) {
                    Text(
                      text = "ID: ${del.nurseId}",
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))
              HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
              Spacer(modifier = Modifier.height(8.dp))

              // Phone
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "${if (isArabic) "رقم الهاتف:" else "Phone:"} ${del.registeredPhone}",
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                )
              }

              // Location
              if (del.country.isNotBlank() || del.city.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "${if (isArabic) "الموقع:" else "Location:"} ${del.country}${if (del.city.isNotBlank()) " - " + del.city else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }

          // Reason Box
          if (del.reason.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFFFFF1F2),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) "سبب طلب الحذف المذكور:" else "Stated Deletion Reason:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFFBE123C))
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = del.reason,
                  style = MaterialTheme.typography.bodySmall,
                  color = Color(0xFF881337)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // WhatsApp Communication Button
          Button(
            onClick = {
              WhatsAppHelper.openWhatsApp(
                context,
                del.registeredPhone,
                if (isArabic) "مرحباً ${del.nurseName}، معك مشرف تطبيق GoNurse للتحقق من هويتكم بخصوص طلب حذف حسابكم."
                else "Hello ${del.nurseName}, GoNurse Admin here regarding your account deletion request."
              )
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("admin_whatsapp_del_${del.id}"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Phone, contentDescription = "WhatsApp", tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isArabic) "تواصل وتحقق من الهوية عبر واتساب" else "Verify Identity via WhatsApp",
              color = Color.White,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Approve Deletion (Process) / Cancel Deletion (Keep) Actions
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onApprovePrompt(del) },
              modifier = Modifier
                .weight(1.2f)
                .testTag("admin_approve_del_${del.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "معالجة ومسح الحساب" else "Process Deletion", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = { onCancelPrompt(del) },
              modifier = Modifier
                .weight(1.1f)
                .testTag("admin_reject_del_${del.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = MaroonPrimary),
              border = androidx.compose.foundation.BorderStroke(1.dp, MaroonPrimary),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "إلغاء الطلب (إبقاء الحساب)" else "Cancel Request", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun OldVsNewRow(
  label: String,
  oldValue: String,
  newValue: String,
  isChanged: Boolean,
  isArabic: Boolean
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
      )
      if (isChanged) {
        Spacer(modifier = Modifier.width(6.dp))
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = Color(0xFFDCFCE7)
        ) {
          Text(
            text = if (isArabic) "مُعَدَّل" else "Modified",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
            color = Color(0xFF15803D),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Old value box
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(6.dp)) {
          Text(
            text = if (isArabic) "الحالي (القديم):" else "Current (Old):",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          )
          Text(
            text = oldValue.ifBlank { "—" },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = "to",
        tint = if (isChanged) Color(0xFF16A34A) else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(16.dp)
      )

      // New value box
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isChanged) Color(0xFFF0FDF4) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = if (isChanged) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC)) else null,
        modifier = Modifier.weight(1f)
      ) {
        Column(modifier = Modifier.padding(6.dp)) {
          Text(
            text = if (isArabic) "المطلوب (الجديد):" else "Requested (New):",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = if (isChanged) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurfaceVariant)
          )
          Text(
            text = newValue.ifBlank { "—" },
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = if (isChanged) FontWeight.Bold else FontWeight.Normal),
            color = if (isChanged) Color(0xFF166534) else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
          )
        }
      }
    }
  }
}

@Composable
private fun EmptyPendingView(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.CheckCircle
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Box(
        modifier = Modifier
          .size(64.dp)
          .clip(CircleShape)
          .background(MaroonPrimary.copy(alpha = 0.08f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(32.dp))
      }
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 17.sp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )
    }
  }
}

@Composable
private fun ReportsTabContent(
  items: List<SubmittedReport>,
  isArabic: Boolean,
  onDismissReport: (SubmittedReport) -> Unit,
  onFollowUpViaWhatsApp: (SubmittedReport) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد بلاغات حالياً" else "No reports submitted",
      subtitle = if (isArabic) "أي شكوى أو بلاغ يقدمه المستخدمون سيظهر هنا مباشرة للمتابعة" else "User complaints will appear here"
    )
    return
  }

  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { report ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_report_card_${report.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Top Header: Date and Report Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFDC2626).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Flag,
                  contentDescription = null,
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "بلاغ عن مخالفة" else "Incident Report",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFDC2626)
                )
                Text(
                  text = dateFormat.format(Date(report.timestamp)),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFFEF4444).copy(alpha = 0.12f)
            ) {
              Text(
                text = if (isArabic) "مراجعة عاجلة" else "Review",
                color = Color(0xFFB91C1C),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          HorizontalDivider(color = Color(0xFFF1F5F9))
          Spacer(modifier = Modifier.height(12.dp))

          // 1. المُبَلِّغ (Who submitted the report)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "المُبَلِّغ (مقدم الشكوى):" else "Reporter:",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaroonPrimary
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = if (report.reporterPhone.isNotBlank()) "رقم الهاتف: ${report.reporterPhone}" else "غير مسجل برقم هاتف",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 2. المُبَلَّغ عنه (Who was reported)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFFEF2F2),
            border = BorderStroke(1.dp, Color(0xFFFECACA)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ReportProblem, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "المُبَلَّغ عنه:" else "Reported Target:",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFDC2626)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = report.targetName.ifBlank { "غير محدد" },
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              if (report.targetCity.isNotBlank() || report.targetType.isNotBlank()) {
                Text(
                  text = "النوع: ${report.targetType} • المدينة: ${report.targetCity} • المعرف: ${report.targetId}",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3. مضمون البلاغ (Exact content and details of the report)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFFFFBEB),
            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = if (isArabic) "مضمون البلاغ والسبب:" else "Report Reason & Details:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFFB45309)
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "• السبب: ${report.reason.ifBlank { "مخالفة عامة" }}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
              )
              if (report.additionalNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "• التفاصيل: ${report.additionalNotes}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Action Buttons: Follow up via WhatsApp & Dismiss/Delete
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onFollowUpViaWhatsApp(report) },
              modifier = Modifier
                .weight(1.2f)
                .testTag("admin_followup_report_${report.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "متابعة عبر واتساب" else "WhatsApp")
            }

            OutlinedButton(
              onClick = { onDismissReport(report) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_dismiss_report_${report.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
              border = BorderStroke(1.dp, Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "إغلاق البلاغ" else "Dismiss")
            }
          }
        }
      }
    }
  }
}

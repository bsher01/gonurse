package com.example.ui

import android.graphics.BitmapFactory
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.PendingAccountDeletion
import com.example.model.PendingProfileUpdate
import com.example.model.PendingRegistration
import com.example.model.SubmittedReport
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AdminTab(val titleAr: String, val titleEn: String) {
  REGISTRATIONS("طلبات التسجيل", "Registrations"),
  UPDATES("تعديل البيانات", "Profile Updates"),
  DELETIONS("حذف الحسابات", "Deletions"),
  REPORTS("البلاغات", "Reports")
}

/**
 * Protected Admin Screen secured with passcode 0932189336BSHERbsher.
 * Provides management workflows for Registration, Profile Updates, Account Deletion, and Reports
 * completely integrated with Firebase RTDB and WhatsApp messaging to +994407958647.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
  language: AppLanguage,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isArabic = language == AppLanguage.ARABIC
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  var selectedTab by remember { mutableStateOf(AdminTab.REGISTRATIONS) }
  var isLoading by remember { mutableStateOf(true) }

  var pendingRegistrations by remember { mutableStateOf<List<PendingRegistration>>(emptyList()) }
  var pendingUpdates by remember { mutableStateOf<List<PendingProfileUpdate>>(emptyList()) }
  var pendingDeletions by remember { mutableStateOf<List<PendingAccountDeletion>>(emptyList()) }
  var submittedReports by remember { mutableStateOf<List<SubmittedReport>>(emptyList()) }

  // Rejection Dialog State
  var rejectingRegistrationId by remember { mutableStateOf<PendingRegistration?>(null) }
  var rejectionReasonText by remember { mutableStateOf("") }

  // Deletion Confirmation Dialog State
  var confirmingDeletionItem by remember { mutableStateOf<PendingAccountDeletion?>(null) }

  BackHandler {
    onNavigateBack()
  }

  fun reloadAll() {
    coroutineScope.launch {
      isLoading = true
      try {
        pendingRegistrations = FirebaseRealtimeRepository.fetchPendingRegistrations()
        pendingUpdates = FirebaseRealtimeRepository.fetchPendingUpdates()
        pendingDeletions = FirebaseRealtimeRepository.fetchPendingDeletions()
        submittedReports = FirebaseRealtimeRepository.fetchReports()
      } catch (e: Exception) {
        Toast.makeText(context, "فشل جلب الطلبات: ${e.message}", Toast.LENGTH_SHORT).show()
      } finally {
        isLoading = false
      }
    }
  }

  LaunchedEffect(Unit) {
    reloadAll()
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.Security,
              contentDescription = null,
              tint = MaroonPrimary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isArabic) "شاشة المشرف المعتمد" else "Admin Portal",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaroonPrimary
              )
              Text(
                text = if (isArabic) "إدارة الطلبات عبر واتساب وقاعدة البيانات" else "WhatsApp & DB Management",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.testTag("admin_back_button")
          ) {
            Icon(
              Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = MaroonPrimary
            )
          }
        },
        actions = {
          IconButton(
            onClick = { reloadAll() },
            modifier = Modifier.testTag("admin_refresh_button")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = MaroonPrimary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { paddingValues ->
    Column(
      modifier = modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(MaterialTheme.colorScheme.background)
    ) {
      // Tab Row with live pending counts
      ScrollableTabRow(
        selectedTabIndex = selectedTab.ordinal,
        edgePadding = 12.dp,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaroonPrimary
      ) {
        AdminTab.values().forEach { tab ->
          val count = when (tab) {
            AdminTab.REGISTRATIONS -> pendingRegistrations.size
            AdminTab.UPDATES -> pendingUpdates.size
            AdminTab.DELETIONS -> pendingDeletions.size
            AdminTab.REPORTS -> submittedReports.size
          }
          Tab(
            selected = selectedTab == tab,
            onClick = { selectedTab = tab },
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = if (isArabic) tab.titleAr else tab.titleEn,
                  fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                )
                if (count > 0) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = CircleShape,
                    color = if (selectedTab == tab) MaroonPrimary else Color(0xFF64748B)
                  ) {
                    Text(
                      text = count.toString(),
                      color = Color.White,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }
              }
            }
          )
        }
      }

      if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = MaroonPrimary)
        }
      } else {
        when (selectedTab) {
          AdminTab.REGISTRATIONS -> {
            RegistrationsTabContent(
              items = pendingRegistrations,
              isArabic = isArabic,
              onApprove = { reg ->
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.approveRegistration(reg.id)
                  if (success) {
                    pendingRegistrations = pendingRegistrations.filter { it.id != reg.id }
                    val adminMsg = WhatsAppHelper.buildRegistrationDecisionAdminNotification(
                      nursePhone = reg.phone,
                      nurseCity = reg.city,
                      nurseCountry = reg.country,
                      isApproved = true
                    )
                    WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                    Toast.makeText(context, "تم اعتماد وتوثيق الحساب وتأكيد الإجراء عبر واتساب", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "فشل اعتماد الحساب في الخادم", Toast.LENGTH_SHORT).show()
                  }
                }
              },
              onRejectPrompt = { reg ->
                rejectingRegistrationId = reg
                rejectionReasonText = ""
              }
            )
          }

          AdminTab.UPDATES -> {
            UpdatesTabContent(
              items = pendingUpdates,
              isArabic = isArabic,
              onApprove = { upd ->
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.approveProfileUpdate(upd)
                  if (success) {
                    pendingUpdates = pendingUpdates.filter { it.id != upd.id }
                    val adminMsg = WhatsAppHelper.buildProfileUpdateAdminNotification(
                      registeredPhone = upd.registeredPhone,
                      requestedPhone = upd.requestedPhone,
                      requestedCity = upd.requestedCity,
                      isApproved = true
                    )
                    WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                    Toast.makeText(context, "تم اعتماد التعديل وتأكيد الإجراء عبر واتساب", Toast.LENGTH_SHORT).show()
                  } else {
                    Toast.makeText(context, "فشل حفظ التحديث في الخادم", Toast.LENGTH_SHORT).show()
                  }
                }
              },
              onReject = { upd ->
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.rejectProfileUpdate(upd.id, "عدم تطابق رقم الهاتف مع السجل")
                  if (success) {
                    pendingUpdates = pendingUpdates.filter { it.id != upd.id }
                    val adminMsg = WhatsAppHelper.buildProfileUpdateAdminNotification(
                      registeredPhone = upd.registeredPhone,
                      requestedPhone = upd.requestedPhone,
                      requestedCity = upd.requestedCity,
                      isApproved = false,
                      reason = "عدم تطابق رقم الهاتف مع السجل"
                    )
                    WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                    Toast.makeText(context, "تم رفض التعديل وتأكيد الإجراء عبر واتساب", Toast.LENGTH_SHORT).show()
                  }
                }
              }
            )
          }

          AdminTab.DELETIONS -> {
            DeletionsTabContent(
              items = pendingDeletions,
              isArabic = isArabic,
              onApprovePrompt = { del ->
                confirmingDeletionItem = del
              },
              onReject = { del ->
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.rejectAccountDeletion(del.id, "عدم مطابقة الهاتف")
                  if (success) {
                    pendingDeletions = pendingDeletions.filter { it.id != del.id }
                    val adminMsg = WhatsAppHelper.buildAccountDeletionAdminNotification(
                      nursePhone = del.registeredPhone,
                      isApproved = false,
                      reason = "عدم مطابقة الهاتف"
                    )
                    WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                    Toast.makeText(context, "تم رفض طلب الحذف وتأكيد الإجراء عبر واتساب", Toast.LENGTH_SHORT).show()
                  }
                }
              }
            )
          }

          AdminTab.REPORTS -> {
            ReportsTabContent(
              items = submittedReports,
              isArabic = isArabic,
              onDismissReport = { report ->
                coroutineScope.launch {
                  val success = FirebaseRealtimeRepository.deleteReport(report.id)
                  if (success) {
                    submittedReports = submittedReports.filter { it.id != report.id }
                    Toast.makeText(context, if (isArabic) "تم إغلاق البلاغ بنجاح" else "Report closed successfully", Toast.LENGTH_SHORT).show()
                  }
                }
              },
              onFollowUpViaWhatsApp = { report ->
                val msg = """
                  🚨 متابعة بلاغ وارد في تطبيق GoNurse:
                  • معرف البلاغ: ${report.id}
                  • المُبَلِّغ: ${report.reporterPhone.ifBlank { "غير مسجل" }}
                  • المُبَلَّغ عنه: ${report.targetName} (${report.targetType} - ${report.targetCity})
                  • سبب البلاغ: ${report.reason}
                  • الملاحظات: ${report.additionalNotes.ifBlank { "لا توجد ملاحظات إضافية" }}
                """.trimIndent()
                WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, msg)
              }
            )
          }
        }
      }
    }
  }

  // Registration Rejection Dialog
  if (rejectingRegistrationId != null) {
    val reg = rejectingRegistrationId!!
    AlertDialog(
      onDismissRequest = { rejectingRegistrationId = null },
      title = {
        Text(if (isArabic) "رفض طلب التسجيل" else "Reject Registration")
      },
      text = {
        Column {
          Text(
            if (isArabic) "يرجى تحديد سبب الرفض ليتم تسجيله وإرسال التأكيد عبر واتساب المشرف (+994407958647):"
            else "Specify rejection reason to be sent via WhatsApp (+994407958647):"
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = rejectionReasonText,
            onValueChange = { rejectionReasonText = it },
            placeholder = { Text(if (isArabic) "مثال: صورة الترخيص غير واضحة..." else "e.g., Unclear license image") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val target = reg
            val reason = rejectionReasonText
            rejectingRegistrationId = null
            coroutineScope.launch {
              val success = FirebaseRealtimeRepository.rejectRegistration(target.id, reason)
              if (success) {
                pendingRegistrations = pendingRegistrations.filter { it.id != target.id }
                val adminMsg = WhatsAppHelper.buildRegistrationDecisionAdminNotification(
                  nursePhone = target.phone,
                  nurseCity = target.city,
                  nurseCountry = target.country,
                  isApproved = false,
                  reason = reason
                )
                WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                Toast.makeText(context, "تم رفض الطلب في Firebase وإرسال التأكيد للواتساب", Toast.LENGTH_SHORT).show()
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
          Text(if (isArabic) "تأكيد الرفض وإرسال واتساب" else "Confirm Reject & WhatsApp")
        }
      },
      dismissButton = {
        TextButton(onClick = { rejectingRegistrationId = null }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }

  // Account Deletion Approval Confirmation Dialog
  if (confirmingDeletionItem != null) {
    val del = confirmingDeletionItem!!
    AlertDialog(
      onDismissRequest = { confirmingDeletionItem = null },
      title = {
        Text(if (isArabic) "تأكيد حذف الحساب نهائياً" else "Confirm Account Wipe")
      },
      text = {
        Text(
          if (isArabic)
            "تحذير: سيتم مسح سجل الممرض (${del.registeredPhone}) بالكامل من خوادم وقاعدة بيانات Firebase، ثم إرسال رسالة تأكيد الحذف عبر واتساب المشرف (+994407958647). هل ترغب في المتابعة؟"
          else
            "Warning: Nurse record (${del.registeredPhone}) will be permanently erased from Firebase RTDB and a WhatsApp confirmation dispatched to Admin. Continue?"
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val target = del
            confirmingDeletionItem = null
            coroutineScope.launch {
              val success = FirebaseRealtimeRepository.approveAccountDeletion(target)
              if (success) {
                pendingDeletions = pendingDeletions.filter { it.id != target.id }
                val adminMsg = WhatsAppHelper.buildAccountDeletionAdminNotification(
                  nursePhone = target.registeredPhone,
                  isApproved = true
                )
                WhatsAppHelper.openWhatsApp(context, WhatsAppHelper.ADMIN_WHATSAPP_NUMBER, adminMsg)
                Toast.makeText(context, "تم حذف الحساب بالكامل من Firebase وتأكيد الإجراء بالواتساب", Toast.LENGTH_LONG).show()
              } else {
                Toast.makeText(context, "فشل حذف الحساب من خادم Firebase", Toast.LENGTH_SHORT).show()
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
        ) {
          Text(if (isArabic) "مسح وحذف نهائي" else "Wipe Account")
        }
      },
      dismissButton = {
        TextButton(onClick = { confirmingDeletionItem = null }) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    )
  }
}

@Composable
private fun RegistrationsTabContent(
  items: List<PendingRegistration>,
  isArabic: Boolean,
  onApprove: (PendingRegistration) -> Unit,
  onRejectPrompt: (PendingRegistration) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات تسجيل معلقة حالياً" else "No pending registrations",
      subtitle = if (isArabic) "تظهر طلبات إنشاء حسابات الممرضين الجديدة هنا فور تقديمها" else "New nurse applications will appear here"
    )
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { reg ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_reg_card_${reg.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(MaroonPrimary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = reg.phone,
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = "${reg.country} • ${reg.city}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFFF59E0B).copy(alpha = 0.15f)
            ) {
              Text(
                text = if (isArabic) "قيد المراجعة" else "Pending",
                color = Color(0xFFB45309),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          if (reg.bio.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "النبذة: ${reg.bio}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(8.dp)
              )
            }
          }

          // Lightweight License Indicator (Verification media reviewed directly via WhatsApp)
          if (reg.licenseImageBase64.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFF1F5F9))
                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                Icons.Default.VerifiedUser,
                contentDescription = null,
                tint = MaroonPrimary,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "وثيقة ترخيص مزاولة المهنة مرفقة" else "License Document Attached",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = if (isArabic) "تتم مراجعة ومعاينة الوثيقة بالكامل عبر واتساب المشرف (+994407958647)" else "Reviewed via Admin WhatsApp (+994407958647)",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Approve / Reject Actions
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onApprove(reg) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_approve_reg_${reg.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "اعتماد وتوثيق" else "Approve")
            }

            OutlinedButton(
              onClick = { onRejectPrompt(reg) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_reject_reg_${reg.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "رفض الطلب" else "Reject")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun UpdatesTabContent(
  items: List<PendingProfileUpdate>,
  isArabic: Boolean,
  onApprove: (PendingProfileUpdate) -> Unit,
  onReject: (PendingProfileUpdate) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات تعديل بيانات معلقة" else "No pending profile updates",
      subtitle = if (isArabic) "تظهر طلبات تعديل بيانات الممرضين هنا بعد إرسالها للتحقق من رقم الهاتف" else "Profile modification requests will appear here"
    )
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { upd ->
      // Interactive state to simulate admin cross-verifying sender WhatsApp phone
      var senderPhoneInput by remember { mutableStateOf(upd.registeredPhone) }
      val isPhoneMatched = remember(senderPhoneInput, upd.registeredPhone) {
        val clean1 = senderPhoneInput.filter { it.isDigit() }
        val clean2 = upd.registeredPhone.filter { it.isDigit() }
        clean1.isNotEmpty() && clean2.isNotEmpty() && (clean1.endsWith(clean2) || clean2.endsWith(clean1))
      }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_update_card_${upd.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isArabic) "طلب تعديل بيانات" else "Update Request",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isPhoneMatched) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
            ) {
              Text(
                text = if (isPhoneMatched) (if (isArabic) "مطابق لرقم الهاتف ✅" else "Phone Matched ✅")
                else (if (isArabic) "رقم غير مطابق ❌" else "Phone Mismatched ❌"),
                color = if (isPhoneMatched) Color(0xFF15803D) else Color(0xFFB91C1C),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "رقم الهاتف المسجل بقاعدة البيانات: ${upd.registeredPhone}",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
          )

          // Verification field
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = senderPhoneInput,
            onValueChange = { senderPhoneInput = it },
            label = { Text(if (isArabic) "التحقق من رقم مرسل الرسالة" else "Verify Sender WhatsApp Phone") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          Spacer(modifier = Modifier.height(8.dp))
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = if (isArabic) "التعديلات المطلوبة:" else "Requested Changes:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
              )
              if (upd.requestedPhone.isNotBlank() && upd.requestedPhone != upd.registeredPhone) {
                Text(text = "• رقم الهاتف الجديد: ${upd.requestedPhone}", style = MaterialTheme.typography.bodySmall)
              }
              if (upd.requestedCountry.isNotBlank() || upd.requestedCity.isNotBlank()) {
                Text(text = "• المكان: ${upd.requestedCountry} - ${upd.requestedCity}", style = MaterialTheme.typography.bodySmall)
              }
              if (upd.requestedBio.isNotBlank()) {
                Text(text = "• النبذة: ${upd.requestedBio}", style = MaterialTheme.typography.bodySmall)
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onApprove(upd) },
              enabled = isPhoneMatched,
              modifier = Modifier
                .weight(1f)
                .testTag("admin_approve_update_${upd.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "اعتماد التعديل" else "Approve")
            }

            OutlinedButton(
              onClick = { onReject(upd) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_reject_update_${upd.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "رفض التعديل" else "Reject")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DeletionsTabContent(
  items: List<PendingAccountDeletion>,
  isArabic: Boolean,
  onApprovePrompt: (PendingAccountDeletion) -> Unit,
  onReject: (PendingAccountDeletion) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد طلبات حذف حسابات معلقة" else "No pending account deletions",
      subtitle = if (isArabic) "تظهر طلبات حذف الحسابات هنا للتحقق من رقم الهاتف ومسح الحساب نهائياً من Firebase" else "Account deletion requests will appear here"
    )
    return
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { del ->
      var senderPhoneInput by remember { mutableStateOf(del.registeredPhone) }
      val isPhoneMatched = remember(senderPhoneInput, del.registeredPhone) {
        val clean1 = senderPhoneInput.filter { it.isDigit() }
        val clean2 = del.registeredPhone.filter { it.isDigit() }
        clean1.isNotEmpty() && clean2.isNotEmpty() && (clean1.endsWith(clean2) || clean2.endsWith(clean1))
      }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_del_card_${del.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isArabic) "طلب حذف حساب نهائي" else "Account Deletion Request",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFFDC2626)
              )
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isPhoneMatched) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
            ) {
              Text(
                text = if (isPhoneMatched) (if (isArabic) "الهاتف مطابق ✅" else "Matched ✅")
                else (if (isArabic) "الهاتف غير مطابق ❌" else "Mismatched ❌"),
                color = if (isPhoneMatched) Color(0xFF15803D) else Color(0xFFB91C1C),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = "رقم هاتف الحساب المسجل: ${del.registeredPhone}",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
          )

          Spacer(modifier = Modifier.height(6.dp))
          OutlinedTextField(
            value = senderPhoneInput,
            onValueChange = { senderPhoneInput = it },
            label = { Text(if (isArabic) "التحقق من رقم مرسل طلب الحذف" else "Verify Requester Phone") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          if (del.reason.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "السبب المذكور: ${del.reason}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(8.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onApprovePrompt(del) },
              enabled = isPhoneMatched,
              modifier = Modifier
                .weight(1.3f)
                .testTag("admin_approve_del_${del.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "تأكيد ومسح الحساب" else "Wipe Account")
            }

            OutlinedButton(
              onClick = { onReject(del) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_reject_del_${del.id}"),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "رفض الحذف" else "Reject")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun EmptyPendingView(title: String, subtitle: String) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Box(
        modifier = Modifier
          .size(64.dp)
          .clip(CircleShape)
          .background(Color(0xFFE2E8F0)),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(32.dp))
      }
      Spacer(modifier = Modifier.height(14.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )
    }
  }
}

@Composable
private fun ReportsTabContent(
  items: List<SubmittedReport>,
  isArabic: Boolean,
  onDismissReport: (SubmittedReport) -> Unit,
  onFollowUpViaWhatsApp: (SubmittedReport) -> Unit
) {
  if (items.isEmpty()) {
    EmptyPendingView(
      title = if (isArabic) "لا توجد بلاغات حالياً" else "No reports submitted",
      subtitle = if (isArabic) "أي شكوى أو بلاغ يقدمه المستخدمون سيظهر هنا مباشرة للمتابعة" else "User complaints will appear here"
    )
    return
  }

  val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale("ar")) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    items(items, key = { it.id }) { report ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("admin_report_card_${report.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Top Header: Date and Report Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFDC2626).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  Icons.Default.Flag,
                  contentDescription = null,
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = if (isArabic) "بلاغ عن مخالفة" else "Incident Report",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFDC2626)
                )
                Text(
                  text = dateFormat.format(Date(report.timestamp)),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xFFEF4444).copy(alpha = 0.12f)
            ) {
              Text(
                text = if (isArabic) "مراجعة عاجلة" else "Review",
                color = Color(0xFFB91C1C),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          HorizontalDivider(color = Color(0xFFF1F5F9))
          Spacer(modifier = Modifier.height(12.dp))

          // 1. المُبَلِّغ (Who submitted the report)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = MaroonPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "المُبَلِّغ (مقدم الشكوى):" else "Reporter:",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaroonPrimary
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = if (report.reporterPhone.isNotBlank()) "رقم الهاتف: ${report.reporterPhone}" else "غير مسجل برقم هاتف",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 2. المُبَلَّغ عنه (Who was reported)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFFEF2F2),
            border = BorderStroke(1.dp, Color(0xFFFECACA)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ReportProblem, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) "المُبَلَّغ عنه:" else "Reported Target:",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = Color(0xFFDC2626)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = report.targetName.ifBlank { "غير محدد" },
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              if (report.targetCity.isNotBlank() || report.targetType.isNotBlank()) {
                Text(
                  text = "النوع: ${report.targetType} • المدينة: ${report.targetCity} • المعرف: ${report.targetId}",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // 3. مضمون البلاغ (Exact content and details of the report)
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFFFFBEB),
            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = if (isArabic) "مضمون البلاغ والسبب:" else "Report Reason & Details:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFFB45309)
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "• السبب: ${report.reason.ifBlank { "مخالفة عامة" }}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
              )
              if (report.additionalNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "• التفاصيل: ${report.additionalNotes}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Action Buttons: Follow up via WhatsApp & Dismiss/Delete
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = { onFollowUpViaWhatsApp(report) },
              modifier = Modifier
                .weight(1.2f)
                .testTag("admin_followup_report_${report.id}"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "متابعة عبر واتساب" else "WhatsApp")
            }

            OutlinedButton(
              onClick = { onDismissReport(report) },
              modifier = Modifier
                .weight(1f)
                .testTag("admin_dismiss_report_${report.id}"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
              border = BorderStroke(1.dp, Color(0xFFDC2626)),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isArabic) "إغلاق البلاغ" else "Dismiss")
            }
          }
        }
      }
    }
  }
}

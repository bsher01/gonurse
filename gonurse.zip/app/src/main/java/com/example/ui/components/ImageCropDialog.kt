package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import kotlinx.coroutines.launch

/**
 * An intuitive, professional profile picture cropper dialog tailored for healthcare staff.
 * Allows framing head and upper body with pan, zoom (gesture + slider), 90-degree rotation,
 * rule-of-thirds composition grid, and a live circular profile avatar preview badge.
 *
 * Guarantees that the confirm/done button ("زر الموافق") is prominently visible, accessible,
 * and functional both in the top header action bar and in the bottom controls panel.
 */
@Composable
fun ImageCropDialog(
  imageUri: Uri,
  onCropConfirmed: (croppedBitmap: Bitmap, base64Compressed: String) -> Unit,
  onDismiss: () -> Unit,
  isArabic: Boolean = true
) {
  val context = LocalContext.current
  val density = LocalDensity.current
  val coroutineScope = rememberCoroutineScope()

  var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var isLoadingBitmap by remember { mutableStateOf(true) }
  var isProcessingCrop by remember { mutableStateOf(false) }

  // Transform states
  var scale by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }
  var rotationDegrees by remember { mutableFloatStateOf(0f) }

  // Measured viewport & crop geometry states
  var viewportWidthPx by remember { mutableFloatStateOf(0f) }
  var viewportHeightPx by remember { mutableFloatStateOf(0f) }
  var cropBoxRect by remember { mutableStateOf(Rect.Zero) }
  var baseScale by remember { mutableFloatStateOf(1f) }

  // Load downsampled bitmap safely without OOM
  LaunchedEffect(imageUri) {
    isLoadingBitmap = true
    val bmp = ImageCompressor.decodeSampledBitmap(context, imageUri, maxDimension = 1200)
    sourceBitmap = bmp
    isLoadingBitmap = false
  }

  // Crop execution handler accessible by both top and bottom confirm buttons
  val executeCrop: () -> Unit = {
    val bmp = sourceBitmap
    if (bmp != null && !isProcessingCrop) {
      coroutineScope.launch {
        isProcessingCrop = true
        try {
          // Compute geometry fallback if not measured yet
          val effectiveCropRect = if (cropBoxRect.width > 0f) cropBoxRect else Rect(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat())
          val effectiveVpWidth = if (viewportWidthPx > 0f) viewportWidthPx else bmp.width.toFloat()
          val effectiveVpHeight = if (viewportHeightPx > 0f) viewportHeightPx else bmp.height.toFloat()
          val effectiveBaseScale = if (baseScale > 0f) baseScale else 1f

          // Compute visible bounds relative to the source bitmap
          val totalScale = effectiveBaseScale * scale
          val displayedWidth = bmp.width * totalScale
          val displayedHeight = bmp.height * totalScale

          // Center coordinates
          val displayedCenterX = (effectiveVpWidth / 2f) + offsetX
          val displayedCenterY = (effectiveVpHeight / 2f) + offsetY

          val displayedLeft = displayedCenterX - (displayedWidth / 2f)
          val displayedTop = displayedCenterY - (displayedHeight / 2f)

          // Relative to source bitmap
          val cropLeftInBmp = ((effectiveCropRect.left - displayedLeft) / totalScale).toInt()
          val cropTopInBmp = ((effectiveCropRect.top - displayedTop) / totalScale).toInt()
          val cropWidthInBmp = (effectiveCropRect.width / totalScale).toInt()
          val cropHeightInBmp = (effectiveCropRect.height / totalScale).toInt()

          val result = ImageCompressor.cropAndCompress(
            sourceBitmap = bmp,
            cropX = cropLeftInBmp,
            cropY = cropTopInBmp,
            cropWidth = cropWidthInBmp,
            cropHeight = cropHeightInBmp,
            rotationDegrees = rotationDegrees,
            maxDimension = 340,
            maxQuality = 72,
            targetMaxBytes = 45 * 1024,
            context = context
          )

          if (result.base64.isNotBlank()) {
            val croppedBitmap = ImageCompressor.getCachedOrDecodeBase64(result.base64) ?: bmp
            onCropConfirmed(croppedBitmap, result.base64)
          } else {
            val fallback = ImageCompressor.compressProfileImage(context, imageUri)
            val fallbackBmp = ImageCompressor.getCachedOrDecodeBase64(fallback.base64) ?: bmp
            onCropConfirmed(fallbackBmp, fallback.base64)
          }
        } catch (e: Exception) {
          android.util.Log.e("ImageCropDialog", "Crop execution error: ${e.message}", e)
          val fallback = ImageCompressor.compressProfileImage(context, imageUri)
          val fallbackBmp = ImageCompressor.getCachedOrDecodeBase64(fallback.base64) ?: bmp
          onCropConfirmed(fallbackBmp, fallback.base64)
        } finally {
          isProcessingCrop = false
        }
      }
    }
  }

  Dialog(
    onDismissRequest = {
      if (!isProcessingCrop) onDismiss()
    },
    properties = DialogProperties(
      usePlatformDefaultWidth = false,
      dismissOnBackPress = !isProcessingCrop,
      dismissOnClickOutside = false
    )
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF0B1120)),
      color = Color(0xFF0B1120)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // TOP HEADER BAR with Top Confirm Button
        Surface(
          color = Color(0xFF1E293B),
          tonalElevation = 4.dp,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            IconButton(
              onClick = onDismiss,
              enabled = !isProcessingCrop,
              modifier = Modifier.testTag("crop_dialog_cancel_button")
            ) {
              Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
            }

            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
            ) {
              Text(
                text = if (isArabic) "قص وضبط الصورة الشخصية" else "Frame & Crop Profile Photo",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                maxLines = 1
              )
              Text(
                text = if (isArabic) "اضبط إطار الوجه وأعلى الكتفين" else "Frame face and upper shoulders",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = Color(0xFF94A3B8),
                maxLines = 1
              )
            }

            // TOP CONFIRM / DONE BUTTON (زر موافق العلوي)
            Button(
              onClick = { executeCrop() },
              enabled = !isProcessingCrop && sourceBitmap != null,
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MaroonPrimary,
                contentColor = Color.White
              ),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier = Modifier.testTag("crop_dialog_top_confirm_button")
            ) {
              if (isProcessingCrop) {
                CircularProgressIndicator(
                  color = Color.White,
                  modifier = Modifier.size(16.dp),
                  strokeWidth = 2.dp
                )
              } else {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isArabic) "موافق" else "Done",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
              }
            }
          }
        }

        // LOADING STATE OR CROPPING VIEWPORT
        if (isLoadingBitmap || sourceBitmap == null) {
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = MaroonPrimary)
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (isArabic) "جاري تحميل وتجهيز الصورة..." else "Loading photo...",
                color = Color.White,
                fontSize = 13.sp
              )
            }
          }
        } else {
          val bmp = sourceBitmap!!

          // CROPPING VIEWPORT (Occupies exact remaining vertical space)
          BoxWithConstraints(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
              .clipToBounds(),
            contentAlignment = Alignment.Center
          ) {
            val vpWidth = constraints.maxWidth.toFloat()
            val vpHeight = constraints.maxHeight.toFloat()

            // Update geometry states
            val cropBoxSizePx = (Math.min(vpWidth, vpHeight) * 0.84f).coerceAtLeast(100f)
            val cropBoxLeft = (vpWidth - cropBoxSizePx) / 2f
            val cropBoxTop = (vpHeight - cropBoxSizePx) / 2f
            val calculatedRect = Rect(cropBoxLeft, cropBoxTop, cropBoxLeft + cropBoxSizePx, cropBoxTop + cropBoxSizePx)
            val calculatedBaseScale = Math.max(cropBoxSizePx / bmp.width, cropBoxSizePx / bmp.height)

            LaunchedEffect(vpWidth, vpHeight) {
              viewportWidthPx = vpWidth
              viewportHeightPx = vpHeight
              cropBoxRect = calculatedRect
              baseScale = calculatedBaseScale
            }

            // Touch gesture detector: pan & pinch-to-zoom
            Box(
              modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                  detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    val maxOffset = cropBoxSizePx * 1.5f * scale
                    offsetX = (offsetX + pan.x).coerceIn(-maxOffset, maxOffset)
                    offsetY = (offsetY + pan.y).coerceIn(-maxOffset, maxOffset)
                  }
                }
            ) {
              // The Image being transformed
              androidx.compose.foundation.Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Cropping target",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                  .align(Alignment.Center)
                  .size(
                    with(density) { (bmp.width * calculatedBaseScale).toDp() },
                    with(density) { (bmp.height * calculatedBaseScale).toDp() }
                  )
                  .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                    rotationZ = rotationDegrees
                  }
              )

              // MASK OVERLAY & GUIDES
              Canvas(modifier = Modifier.fillMaxSize()) {
                val path = Path().apply {
                  addRect(Rect(0f, 0f, size.width, size.height))
                }
                val cropPath = Path().apply {
                  addRect(calculatedRect)
                }

                // Darken outside the crop box
                clipPath(cropPath, clipOp = ClipOp.Difference) {
                  drawRect(Color(0xD9050B14))
                }

                // Border of crop box
                drawRect(
                  color = Color.White,
                  topLeft = Offset(calculatedRect.left, calculatedRect.top),
                  size = Size(calculatedRect.width, calculatedRect.height),
                  style = Stroke(width = 2.dp.toPx())
                )

                // Rule of thirds lines inside crop box
                val thirdW = calculatedRect.width / 3f
                val thirdH = calculatedRect.height / 3f

                // Vertical grid lines
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(calculatedRect.left + thirdW, calculatedRect.top),
                  end = Offset(calculatedRect.left + thirdW, calculatedRect.bottom),
                  strokeWidth = 1.dp.toPx()
                )
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(calculatedRect.left + thirdW * 2f, calculatedRect.top),
                  end = Offset(calculatedRect.left + thirdW * 2f, calculatedRect.bottom),
                  strokeWidth = 1.dp.toPx()
                )

                // Horizontal grid lines
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(calculatedRect.left, calculatedRect.top + thirdH),
                  end = Offset(calculatedRect.right, calculatedRect.top + thirdH),
                  strokeWidth = 1.dp.toPx()
                )
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(calculatedRect.left, calculatedRect.top + thirdH * 2f),
                  end = Offset(calculatedRect.right, calculatedRect.top + thirdH * 2f),
                  strokeWidth = 1.dp.toPx()
                )

                // Circular avatar outline showing how it frames inside a circle
                drawCircle(
                  color = MaroonPrimary.copy(alpha = 0.85f),
                  radius = calculatedRect.width / 2f,
                  center = calculatedRect.center,
                  style = Stroke(width = 2.dp.toPx())
                )
              }
            }

            // MINIATURE CIRCULAR PREVIEW BADGE (Anchored at top-end inside viewport)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xDD1E293B),
              border = BorderStroke(1.dp, Color(0xFF475569)),
              modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, MaroonPrimary, CircleShape)
                    .clipToBounds(),
                  contentAlignment = Alignment.Center
                ) {
                  androidx.compose.foundation.Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                      .fillMaxSize()
                      .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX * (36f / cropBoxSizePx)
                        translationY = offsetY * (36f / cropBoxSizePx)
                        rotationZ = rotationDegrees
                      }
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                  Text(
                    text = if (isArabic) "معاينة الملف" else "Live Preview",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = if (isArabic) "الصورة الرمزية" else "Avatar Circle",
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8)
                  )
                }
              }
            }
          }
        }

        // DEDICATED BOTTOM CONTROLS & ACTION BAR (Outside viewport, guaranteed visible)
        Surface(
          color = Color(0xFF1E293B),
          tonalElevation = 6.dp,
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            // ZOOM & ROTATE TOOLBAR
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              // Rotate Button
              IconButton(
                onClick = {
                  rotationDegrees = (rotationDegrees + 90f) % 360f
                },
                enabled = !isProcessingCrop,
                modifier = Modifier.testTag("crop_rotate_button")
              ) {
                Icon(
                  Icons.Default.RotateRight,
                  contentDescription = "Rotate 90 degrees",
                  tint = Color.White
                )
              }

              // Reset Button
              IconButton(
                onClick = {
                  scale = 1f
                  offsetX = 0f
                  offsetY = 0f
                  rotationDegrees = 0f
                },
                enabled = !isProcessingCrop,
                modifier = Modifier.testTag("crop_dialog_reset_button")
              ) {
                Icon(
                  Icons.Default.RestartAlt,
                  contentDescription = "Reset",
                  tint = Color(0xFF94A3B8)
                )
              }

              // Zoom Slider
              Row(
                modifier = Modifier
                  .weight(1f)
                  .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.ZoomOut,
                  contentDescription = "Zoom out",
                  tint = Color(0xFF94A3B8),
                  modifier = Modifier.size(18.dp)
                )
                Slider(
                  value = scale,
                  onValueChange = { scale = it },
                  valueRange = 1f..3.5f,
                  colors = SliderDefaults.colors(
                    thumbColor = MaroonPrimary,
                    activeTrackColor = MaroonPrimary,
                    inactiveTrackColor = Color(0xFF334155)
                  ),
                  modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp)
                    .testTag("crop_zoom_slider")
                )
                Icon(
                  Icons.Default.ZoomIn,
                  contentDescription = "Zoom in",
                  tint = Color(0xFF94A3B8),
                  modifier = Modifier.size(18.dp)
                )
              }

              // Center Face Button
              IconButton(
                onClick = {
                  offsetX = 0f
                  offsetY = 0f
                },
                enabled = !isProcessingCrop,
                modifier = Modifier.testTag("crop_center_button")
              ) {
                Icon(
                  Icons.Default.Face,
                  contentDescription = "Center Face",
                  tint = Color.White
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ACTION BUTTONS: CANCEL & PRIMARY CONFIRM ("زر الموافق")
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedButton(
                onClick = onDismiss,
                enabled = !isProcessingCrop,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCBD5E1)),
                border = BorderStroke(1.dp, Color(0xFF475569)),
                modifier = Modifier
                  .weight(1f)
                  .height(50.dp)
                  .testTag("crop_dialog_cancel_action")
              ) {
                Text(
                  text = if (isArabic) "إلغاء" else "Cancel",
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
              }

              Button(
                onClick = { executeCrop() },
                enabled = !isProcessingCrop && sourceBitmap != null,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = MaroonPrimary,
                  contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                modifier = Modifier
                  .weight(1.5f)
                  .height(50.dp)
                  .testTag("crop_dialog_confirm_button")
              ) {
                if (isProcessingCrop) {
                  CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isArabic) "جاري القص والضغط..." else "Processing...",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                  )
                } else {
                  Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) "موافق (قص وحفظ)" else "Confirm & Crop",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

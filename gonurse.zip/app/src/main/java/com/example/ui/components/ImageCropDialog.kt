package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MaroonPrimary
import com.example.util.ImageCompressor
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * An intuitive, professional profile picture cropper dialog tailored for healthcare staff.
 * Allows framing head and upper body with pan, zoom (gesture + slider), 90-degree rotation,
 * rule-of-thirds composition grid, and a live circular profile avatar preview badge.
 */
@Composable
fun ImageCropDialog(
  imageUri: Uri,
  onCropConfirmed: (croppedBitmap: Bitmap, base64Compressed: String) -> Unit,
  onDismiss: () -> Unit,
  isArabic: Boolean = true
) {
  val context = LocalContext.current
  val density = LocalDensity.current
  val coroutineScope = rememberCoroutineScope()

  var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var isLoadingBitmap by remember { mutableStateOf(true) }
  var isProcessingCrop by remember { mutableStateOf(false) }

  // Transform states
  var scale by remember { mutableFloatStateOf(1f) }
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }
  var rotationDegrees by remember { mutableFloatStateOf(0f) }

  // Load downsampled bitmap safely without OOM
  LaunchedEffect(imageUri) {
    isLoadingBitmap = true
    val bmp = ImageCompressor.decodeSampledBitmap(context, imageUri, maxDimension = 1200)
    sourceBitmap = bmp
    isLoadingBitmap = false
  }

  Dialog(
    onDismissRequest = {
      if (!isProcessingCrop) onDismiss()
    },
    properties = DialogProperties(
      usePlatformDefaultWidth = false,
      dismissOnBackPress = !isProcessingCrop,
      dismissOnClickOutside = false
    )
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF0F172A)),
      color = Color(0xFF0F172A)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // TOP HEADER BAR
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          IconButton(
            onClick = onDismiss,
            enabled = !isProcessingCrop,
            modifier = Modifier.testTag("crop_dialog_cancel_button")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = if (isArabic) "قص وضبط الصورة الشخصية" else "Frame & Crop Profile Photo",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = Color.White
            )
            Text(
              text = if (isArabic) "اضبط إطار الوجه وأعلى الكتفين للمظهر المهني" else "Frame face and upper shoulders clearly",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Color(0xFF94A3B8)
            )
          }

          IconButton(
            onClick = {
              scale = 1f
              offsetX = 0f
              offsetY = 0f
              rotationDegrees = 0f
            },
            enabled = !isProcessingCrop,
            modifier = Modifier.testTag("crop_dialog_reset_button")
          ) {
            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = Color.White)
          }
        }

        if (isLoadingBitmap || sourceBitmap == null) {
          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth(),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = MaroonPrimary)
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (isArabic) "جاري تحميل وتجهيز الصورة..." else "Loading photo...",
                color = Color.White,
                fontSize = 13.sp
              )
            }
          }
        } else {
          val bmp = sourceBitmap!!

          // CROPPING VIEWPORT
          BoxWithConstraints(
            modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
              .clipToBounds(),
            contentAlignment = Alignment.Center
          ) {
            val viewportWidthPx = constraints.maxWidth.toFloat()
            val viewportHeightPx = constraints.maxHeight.toFloat()

            // The crop box: square centered within viewport
            val cropBoxSizePx = (Math.min(viewportWidthPx, viewportHeightPx) * 0.82f).coerceAtLeast(100f)
            val cropBoxLeft = (viewportWidthPx - cropBoxSizePx) / 2f
            val cropBoxTop = (viewportHeightPx - cropBoxSizePx) / 2f
            val cropBoxRect = Rect(cropBoxLeft, cropBoxTop, cropBoxLeft + cropBoxSizePx, cropBoxTop + cropBoxSizePx)

            // Base fitting scale: how much source bitmap is scaled to fill the crop box initially
            val baseScale = Math.max(cropBoxSizePx / bmp.width, cropBoxSizePx / bmp.height)

            // Touch gesture detector: pan & pinch-to-zoom
            Box(
              modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                  detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    // Allow panning with sensible limits
                    val maxOffset = cropBoxSizePx * 1.5f * scale
                    offsetX = (offsetX + pan.x).coerceIn(-maxOffset, maxOffset)
                    offsetY = (offsetY + pan.y).coerceIn(-maxOffset, maxOffset)
                  }
                }
            ) {
              // The Image being transformed
              androidx.compose.foundation.Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "Cropping target",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                  .align(Alignment.Center)
                  .size(
                    with(density) { (bmp.width * baseScale).toDp() },
                    with(density) { (bmp.height * baseScale).toDp() }
                  )
                  .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                    rotationZ = rotationDegrees
                  }
              )

              // MASK OVERLAY & GUIDES
              Canvas(modifier = Modifier.fillMaxSize()) {
                val path = Path().apply {
                  addRect(Rect(0f, 0f, size.width, size.height))
                }
                val cropPath = Path().apply {
                  addRect(cropBoxRect)
                }

                // Darken outside the crop box
                clipPath(cropPath, clipOp = ClipOp.Difference) {
                  drawRect(Color(0xBB0A0F1D))
                }

                // Border of crop box
                drawRect(
                  color = Color.White,
                  topLeft = Offset(cropBoxRect.left, cropBoxRect.top),
                  size = Size(cropBoxRect.width, cropBoxRect.height),
                  style = Stroke(width = 2.dp.toPx())
                )

                // Rule of thirds lines inside crop box
                val thirdW = cropBoxRect.width / 3f
                val thirdH = cropBoxRect.height / 3f

                // Vertical grid lines
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(cropBoxRect.left + thirdW, cropBoxRect.top),
                  end = Offset(cropBoxRect.left + thirdW, cropBoxRect.bottom),
                  strokeWidth = 1.dp.toPx()
                )
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(cropBoxRect.left + thirdW * 2f, cropBoxRect.top),
                  end = Offset(cropBoxRect.left + thirdW * 2f, cropBoxRect.bottom),
                  strokeWidth = 1.dp.toPx()
                )

                // Horizontal grid lines
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(cropBoxRect.left, cropBoxRect.top + thirdH),
                  end = Offset(cropBoxRect.right, cropBoxRect.top + thirdH),
                  strokeWidth = 1.dp.toPx()
                )
                drawLine(
                  color = Color(0x66FFFFFF),
                  start = Offset(cropBoxRect.left, cropBoxRect.top + thirdH * 2f),
                  end = Offset(cropBoxRect.right, cropBoxRect.top + thirdH * 2f),
                  strokeWidth = 1.dp.toPx()
                )

                // Subtle circular avatar outline to show how it looks as a circle avatar
                drawCircle(
                  color = MaroonPrimary.copy(alpha = 0.8f),
                  radius = cropBoxRect.width / 2f,
                  center = cropBoxRect.center,
                  style = Stroke(width = 2.dp.toPx())
                )
              }
            }

            // MINIATURE CIRCULAR PREVIEW BADGE (Picture-in-picture avatar preview)
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = Color(0xCC1E293B),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, MaroonPrimary, CircleShape)
                    .clipToBounds(),
                  contentAlignment = Alignment.Center
                ) {
                  androidx.compose.foundation.Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                      .fillMaxSize()
                      .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX * (38f / cropBoxSizePx)
                        translationY = offsetY * (38f / cropBoxSizePx)
                        rotationZ = rotationDegrees
                      }
                  )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                  Text(
                    text = if (isArabic) "معاينة الملف" else "Live Preview",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                  )
                  Text(
                    text = if (isArabic) "الملف الشخصي" else "Nurse Avatar",
                    fontSize = 9.sp,
                    color = Color(0xFF94A3B8)
                  )
                }
              }
            }

            // CROP CALCULATION LAMBDA
            val executeCrop = {
              coroutineScope.launch {
                isProcessingCrop = true
                try {
                  // Compute visible bounds relative to the source bitmap
                  val totalScale = baseScale * scale
                  val displayedWidth = bmp.width * totalScale
                  val displayedHeight = bmp.height * totalScale

                  // Center coordinates
                  val displayedCenterX = (viewportWidthPx / 2f) + offsetX
                  val displayedCenterY = (viewportHeightPx / 2f) + offsetY

                  val displayedLeft = displayedCenterX - (displayedWidth / 2f)
                  val displayedTop = displayedCenterY - (displayedHeight / 2f)

                  // Relative to source bitmap
                  val cropLeftInBmp = ((cropBoxRect.left - displayedLeft) / totalScale).toInt()
                  val cropTopInBmp = ((cropBoxRect.top - displayedTop) / totalScale).toInt()
                  val cropWidthInBmp = (cropBoxRect.width / totalScale).toInt()
                  val cropHeightInBmp = (cropBoxRect.height / totalScale).toInt()

                  val result = ImageCompressor.cropAndCompress(
                    sourceBitmap = bmp,
                    cropX = cropLeftInBmp,
                    cropY = cropTopInBmp,
                    cropWidth = cropWidthInBmp,
                    cropHeight = cropHeightInBmp,
                    rotationDegrees = rotationDegrees,
                    maxDimension = 340,
                    maxQuality = 72,
                    targetMaxBytes = 45 * 1024
                  )

                  if (result.base64.isNotBlank()) {
                    val croppedBitmap = ImageCompressor.getCachedOrDecodeBase64(result.base64) ?: bmp
                    onCropConfirmed(croppedBitmap, result.base64)
                  } else {
                    // Fallback to source
                    val fallback = ImageCompressor.compressProfileImage(context, imageUri)
                    val fallbackBmp = ImageCompressor.getCachedOrDecodeBase64(fallback.base64) ?: bmp
                    onCropConfirmed(fallbackBmp, fallback.base64)
                  }
                } catch (e: Exception) {
                  android.util.Log.e("ImageCropDialog", "Crop execution error: ${e.message}", e)
                  val fallback = ImageCompressor.compressProfileImage(context, imageUri)
                  onCropConfirmed(bmp, fallback.base64)
                } finally {
                  isProcessingCrop = false
                }
              }
            }

            // CONTROLS AT THE BOTTOM OF THE DIALOG
            Column(
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xE60F172A))
                .padding(horizontal = 14.dp, vertical = 10.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              // ZOOM & ROTATE TOOLBAR
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                // Rotate Button
                IconButton(
                  onClick = {
                    rotationDegrees = (rotationDegrees + 90f) % 360f
                  },
                  enabled = !isProcessingCrop,
                  modifier = Modifier.testTag("crop_rotate_button")
                ) {
                  Icon(
                    Icons.Default.RotateRight,
                    contentDescription = "Rotate 90 degrees",
                    tint = Color.White
                  )
                }

                // Zoom Slider
                Row(
                  modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(
                    Icons.Default.ZoomOut,
                    contentDescription = "Zoom out",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                  )
                  Slider(
                    value = scale,
                    onValueChange = { scale = it },
                    valueRange = 1f..3.5f,
                    colors = SliderDefaults.colors(
                      thumbColor = MaroonPrimary,
                      activeTrackColor = MaroonPrimary,
                      inactiveTrackColor = Color(0xFF334155)
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp).testTag("crop_zoom_slider")
                  )
                  Icon(
                    Icons.Default.ZoomIn,
                    contentDescription = "Zoom in",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                  )
                }

                // Quick Center Button
                IconButton(
                  onClick = {
                    offsetX = 0f
                    offsetY = 0f
                  },
                  enabled = !isProcessingCrop,
                  modifier = Modifier.testTag("crop_center_button")
                ) {
                  Icon(
                    Icons.Default.Face,
                    contentDescription = "Center Face",
                    tint = Color.White
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              // CONFIRM / CANCEL BUTTONS
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                OutlinedButton(
                  onClick = onDismiss,
                  enabled = !isProcessingCrop,
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCBD5E1)),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
                  modifier = Modifier.weight(1f).testTag("crop_dialog_cancel_action")
                ) {
                  Text(if (isArabic) "إلغاء" else "Cancel")
                }

                Button(
                  onClick = { executeCrop() },
                  enabled = !isProcessingCrop,
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = MaroonPrimary),
                  modifier = Modifier.weight(1.3f).testTag("crop_dialog_confirm_button")
                ) {
                  if (isProcessingCrop) {
                    CircularProgressIndicator(
                      color = Color.White,
                      modifier = Modifier.size(18.dp),
                      strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isArabic) "جاري الضغط والقص..." else "Processing...")
                  } else {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isArabic) "تأكيد وقص الصورة" else "Confirm & Crop")
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

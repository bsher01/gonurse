package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseRealtimeRepository
import com.example.model.AppLanguage
import com.example.model.Nurse
import com.example.model.NurseReview
import com.example.model.NursingRequest
import com.example.ui.theme.MaroonOnPrimary
import com.example.ui.theme.MaroonPrimary
import com.example.ui.theme.MedicalSuccessGreen
import kotlinx.coroutines.launch

/**
 * Modal dialog for rating and reviewing a nurse upon request completion.
 * Patients can submit a 1-5 star rating and text review stored at `reviews/{nurseId}/{reviewId}`.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubmitReviewDialog(
  request: NursingRequest,
  language: AppLanguage,
  initialNurse: Nurse? = null,
  onDismiss: () -> Unit,
  onReviewSubmitted: (NurseReview) -> Unit
) {
  val isArabic = language == AppLanguage.ARABIC
  val focusManager = LocalFocusManager.current
  val scope = rememberCoroutineScope()

  var selectedRating by remember { mutableIntStateOf(5) }
  var reviewText by remember { mutableStateOf("") }
  var patientName by remember { mutableStateOf(request.patientName) }
  var isSubmitting by remember { mutableStateOf(false) }
  var isSuccess by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  // Available nurses to select if request has none specified
  var availableNurses by remember { mutableStateOf<List<Nurse>>(emptyList()) }
  var selectedNurse by remember { mutableStateOf<Nurse?>(initialNurse) }
  var dropdownExpanded by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    val list = FirebaseRealtimeRepository.fetchMergedNurses()
    availableNurses = list
    if (selectedNurse == null) {
      val matched = list.firstOrNull { nurse ->
        (request.selectedNurseName.isNotBlank() && (nurse.displayName.contains(request.selectedNurseName, ignoreCase = true) || request.selectedNurseName.contains(nurse.displayName, ignoreCase = true))) ||
        (request.selectedNursePhone.isNotBlank() && (nurse.displayPhone.contains(request.selectedNursePhone) || request.selectedNursePhone.contains(nurse.displayPhone)))
      } ?: list.firstOrNull()
      selectedNurse = matched
    }
  }

  val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

  CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
    AlertDialog(
      onDismissRequest = { if (!isSubmitting) onDismiss() },
      properties = DialogProperties(usePlatformDefaultWidth = false),
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .padding(vertical = 12.dp),
      shape = RoundedCornerShape(20.dp),
      containerColor = Color.White,
      title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xFFFEF3C7)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.Star,
            contentDescription = null,
            tint = Color(0xFFD97706),
            modifier = Modifier.size(20.dp)
          )
        }
        Text(
          text = if (isArabic) "تقييم الكادر الطبي والخدمة" else "Rate Nurse & Service",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
      }
    },
    text = {
      if (isSuccess) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MedicalSuccessGreen,
            modifier = Modifier.size(54.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = if (isArabic) "شكراً لك! تم إرسال تقييمك بنجاح" else "Thank you! Review submitted successfully",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MedicalSuccessGreen,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = if (isArabic) "تقييمك يساعد في رفع جودة الخدمات التمريضية وتوجيه المرضى الآخرين." else "Your review helps maintain quality nursing care for all patients.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
          )
        }
      } else {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // Request Info Snippet
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF9FAFB),
            border = BorderStroke(1.dp, Color(0xFFE5E7EB)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "${if (isArabic) "الخدمة المنجزة:" else "Completed Service:"} ${request.serviceName}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaroonPrimary
              )
              if (request.city.isNotBlank()) {
                Text(
                  text = "${if (isArabic) "المدينة:" else "City:"} ${request.city}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }

          // Nurse Selection if multiple or display assigned
          if (availableNurses.isNotEmpty()) {
            Column {
              Text(
                text = if (isArabic) "الممرض المسؤول عن الزيارة:" else "Attending Nurse:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(4.dp))

              ExposedDropdownMenuBox(
                expanded = dropdownExpanded,
                onExpandedChange = { dropdownExpanded = it }
              ) {
                OutlinedTextField(
                  value = selectedNurse?.displayName ?: (if (isArabic) "اختر الكادر الطبي" else "Select Nurse"),
                  onValueChange = {},
                  readOnly = true,
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                  colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaroonPrimary,
                    unfocusedBorderColor = Color(0xFFE5E7EB)
                  ),
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
                    .testTag("review_nurse_selector")
                )

                ExposedDropdownMenu(
                  expanded = dropdownExpanded,
                  onDismissRequest = { dropdownExpanded = false }
                ) {
                  availableNurses.forEach { nurse ->
                    DropdownMenuItem(
                      text = {
                        Column {
                          Text(nurse.displayName, fontWeight = FontWeight.Bold)
                          Text(
                            "${nurse.displaySpecialization} • ${nurse.displayCity}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                          )
                        }
                      },
                      onClick = {
                        selectedNurse = nurse
                        dropdownExpanded = false
                      }
                    )
                  }
                }
              }
            }
          }

          // Interactive 5-Star Rating Selector
          Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (isArabic) "اختر التقييم بالنجوم:" else "Select Star Rating:",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.fillMaxWidth()
            ) {
              for (star in 1..5) {
                val isFilled = star <= selectedRating
                Icon(
                  imageVector = if (isFilled) Icons.Default.Star else Icons.Outlined.StarOutline,
                  contentDescription = "$star stars",
                  tint = if (isFilled) Color(0xFFFFB300) else Color(0xFFD1D5DB),
                  modifier = Modifier
                    .size(38.dp)
                    .clickable { selectedRating = star }
                    .padding(2.dp)
                    .testTag("star_rating_$star")
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            val ratingLabel = when (selectedRating) {
              5 -> if (isArabic) "⭐⭐⭐⭐⭐ ممتاز جداً (أنصح به بشدة)" else "⭐⭐⭐⭐⭐ Excellent (Highly Recommended)"
              4 -> if (isArabic) "⭐⭐⭐⭐ جيد جداً (خدمة ممتازة)" else "⭐⭐⭐⭐ Very Good"
              3 -> if (isArabic) "⭐⭐⭐ جيد (تجربة مقبولة)" else "⭐⭐⭐ Good"
              2 -> if (isArabic) "⭐⭐ دون المتوقع" else "⭐⭐ Fair"
              else -> if (isArabic) "⭐ ضعيف (بحاجة لتحسين)" else "⭐ Poor"
            }
            Text(
              text = ratingLabel,
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp
              ),
              color = Color(0xFFB45309),
              textAlign = TextAlign.Center
            )
          }

          // Patient Name
          OutlinedTextField(
            value = patientName,
            onValueChange = { patientName = it },
            label = { Text(if (isArabic) "اسم المريض أو المرافق" else "Patient Name") },
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaroonPrimary,
              unfocusedBorderColor = Color(0xFFE5E7EB)
            ),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("review_patient_name_input")
          )

          // Review Text Input
          OutlinedTextField(
            value = reviewText,
            onValueChange = { reviewText = it },
            label = { Text(if (isArabic) "رأيك وملاحظاتك عن الزيارة (اختياري)" else "Review / Feedback (Optional)") },
            placeholder = {
              Text(
                if (isArabic) "اكتب رأيك حول دقة الموعد، النظافة والتعقيم، والتعامل الطبي..."
                else "Write your thoughts on punctuality, hygiene, and care..."
              )
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaroonPrimary,
              unfocusedBorderColor = Color(0xFFE5E7EB)
            ),
            minLines = 3,
            maxLines = 5,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("review_text_input")
          )

          if (errorMessage != null) {
            Text(
              text = errorMessage!!,
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.labelSmall
            )
          }
        }
      }
    },
    confirmButton = {
      if (isSuccess) {
        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MedicalSuccessGreen)
        ) {
          Text(if (isArabic) "إغلاق" else "Close", color = Color.White, fontWeight = FontWeight.Bold)
        }
      } else {
        Button(
          onClick = {
            val nurse = selectedNurse
            val targetNurseId = (nurse?.id?.ifBlank { nurse.uid } ?: "").ifBlank { "nurse_default" }
            val newReview = NurseReview(
              id = "rev_${System.currentTimeMillis()}",
              nurseId = targetNurseId,
              rating = selectedRating,
              reviewText = reviewText.trim(),
              patientName = patientName.trim().ifBlank { "مريض" },
              createdAt = System.currentTimeMillis(),
              requestId = request.id,
              serviceName = request.serviceName
            )

            scope.launch {
              isSubmitting = true
              errorMessage = null
              val ok = FirebaseRealtimeRepository.submitReview(targetNurseId, newReview)
              if (ok) {
                isSuccess = true
                onReviewSubmitted(newReview)
              } else {
                errorMessage = if (isArabic) "تعذر حفظ التقييم، يرجى المحاولة مرة أخرى" else "Failed to submit review, please retry"
              }
              isSubmitting = false
            }
          },
          enabled = !isSubmitting,
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaroonPrimary,
            contentColor = MaroonOnPrimary
          ),
          modifier = Modifier.testTag("submit_review_action_button")
        ) {
          if (isSubmitting) {
            CircularProgressIndicator(
              color = MaroonOnPrimary,
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
          }
          Text(
            text = if (isArabic) "إرسال التقييم الآن ⭐" else "Submit Review ⭐",
            fontWeight = FontWeight.Bold
          )
        }
      }
    },
    dismissButton = {
      if (!isSuccess) {
        TextButton(
          onClick = onDismiss,
          enabled = !isSubmitting
        ) {
          Text(if (isArabic) "إلغاء" else "Cancel")
        }
      }
    }
  )
  }
}

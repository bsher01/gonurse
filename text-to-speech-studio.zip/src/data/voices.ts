import { VoiceOption, StylePreset, CharacterPersona } from '../types';
import { HUNDRED_PERSONAS } from './extendedPersonas';

export const GEMINI_VOICES: VoiceOption[] = [
  {
    name: 'Kore',
    gender: 'Female',
    description: 'Clear, articulate, natural and versatile with balanced tone.',
    recommendedStyles: ['Professional', 'News', 'Educational', 'Storyteller'],
  },
  {
    name: 'Puck',
    gender: 'Male',
    description: 'Warm, energetic, upbeat and friendly conversational voice.',
    recommendedStyles: ['Cheerful', 'Podcast', 'Casual', 'Social Media'],
  },
  {
    name: 'Charon',
    gender: 'Male',
    description: 'Deep, resonant, calm and authoritative tone.',
    recommendedStyles: ['Documentary', 'Dramatic', 'Announcements', 'Corporate'],
  },
  {
    name: 'Fenrir',
    gender: 'Male',
    description: 'Strong, grounded, intense and cinematic voice.',
    recommendedStyles: ['Movie Trailer', 'Gaming', 'High Intensity', 'Narrative'],
  },
  {
    name: 'Zephyr',
    gender: 'Female',
    description: 'Soft, gentle, tranquil and soothing tone.',
    recommendedStyles: ['Meditative', 'Bedtime Story', 'Relaxing', 'ASMR'],
  },
];

export const CHARACTER_PERSONAS: CharacterPersona[] = [
  {
    id: 'p_layla',
    name: 'مريم / Layla',
    title: 'مذيعة الأخبار الرسمية',
    role: 'News Anchor',
    category: 'girls',
    voiceName: 'Kore',
    avatar: '🎙️',
    toneStyle: 'authoritative, crisp, and professional broadcast news anchor',
    samplePrompt: 'أهلاً بكم في النشرة الإخبارية. أعلنت اليوم أحدث التقنيات الذكية عن إطلاق نموذج صوتي متطور يعتمد على الذكاء الاصطناعي.',
  },
  {
    id: 'p_sami',
    name: 'سامي / Sami',
    title: 'مقدم البودكاست الحماسي',
    role: 'Podcast Host',
    category: 'youth',
    voiceName: 'Puck',
    avatar: '🎧',
    toneStyle: 'cheerful, bright, energetic podcast host with a friendly smile',
    samplePrompt: 'يا أهلاً وسهلاً بكم في حلقة جديدة من بودكاست المستقبل! اليوم معنا موضوع مميز جداً راح يعجبكم.',
  },
  {
    id: 'p_orion',
    name: 'الراوي / Orion',
    title: 'الراوي السينمائي الدرامي',
    role: 'Cinematic Narrator',
    category: 'special',
    voiceName: 'Fenrir',
    avatar: '🎬',
    toneStyle: 'dramatic, intense, epic cinematic movie trailer style',
    samplePrompt: 'في عالم مليء بالأسرار والغموض، تبدأ رحلة الأبطال نحو المجهول للبحث عن الحقيقة الغائبة.',
  },
  {
    id: 'p_maya',
    name: 'سارة / Maya',
    title: 'مرشدة التأمل والاسترخاء',
    role: 'Meditation Guide',
    category: 'girls',
    voiceName: 'Zephyr',
    avatar: '🌿',
    toneStyle: 'calm, slow, gentle, and relaxing meditation guide',
    samplePrompt: 'خذ نفساً عميقاً من الأنف... واحبس الهواء لثوانٍ... ثم أخرجه ببطء وراحة. أشعر بالهدوء يغمر المكان.',
  },
  {
    id: 'p_professor',
    name: 'الأستاذ طارق / Prof. Tareq',
    title: 'الأستاذ الجامعي المحاضر',
    role: 'Educator & Lecturer',
    category: 'youth',
    voiceName: 'Charon',
    avatar: '📚',
    toneStyle: 'articulate, wise, engaging, and educational professor',
    samplePrompt: 'مرحباً بكم يا طلابي الأعزاء في محاضرة اليوم حول أساسيات علم الذكاء الاصطناعي ومعالجة اللغات الطبيعية.',
  },
  {
    id: 'p_sports',
    name: 'كابتن زياد / Coach Ziad',
    title: 'المعلق الرياضي الحماسي',
    role: 'Sports Announcer',
    category: 'special',
    voiceName: 'Puck',
    avatar: '⚽',
    toneStyle: 'high intensity, fast paced, excited sports commentator',
    samplePrompt: 'كرة ممتازة في منتصف الميدان! يمررها ببراعة ويتجاوز المدافع الأول... وتسديدة قوية رائعة!',
  },
  {
    id: 'p_grandma',
    name: 'الجدة فاطمة / Grandma Fatima',
    title: 'حكواتية قصص الأطفال',
    role: 'Storyteller',
    category: 'elderly',
    voiceName: 'Zephyr',
    avatar: '📖',
    toneStyle: 'warm, expressive, gentle, storytelling grandmother',
    samplePrompt: 'كان يا ما كان في قديم الزمان، كان هناك عصفور صغير لطيف يحب الطيران بين الأشجار الخضراء العالية.',
  },
];

export const ALL_PERSONAS_LIST: CharacterPersona[] = [...CHARACTER_PERSONAS, ...HUNDRED_PERSONAS];

export const STYLE_PRESETS: StylePreset[] = [
  {
    id: 'cheerful',
    label: 'Cheerful & Upbeat',
    prefixPrompt: 'cheerful, bright, and smiling',
    iconName: 'Smile',
  },
  {
    id: 'calm',
    label: 'Calm & Soothing',
    prefixPrompt: 'calm, slow, gentle, and relaxing',
    iconName: 'Wind',
  },
  {
    id: 'news',
    label: 'News Anchor',
    prefixPrompt: 'authoritative, crisp, and professional broadcast news anchor',
    iconName: 'Newspaper',
  },
  {
    id: 'storyteller',
    label: 'Storyteller',
    prefixPrompt: 'expressive, captivating narrative storyteller with dramatic pauses',
    iconName: 'BookOpen',
  },
  {
    id: 'dramatic',
    label: 'Dramatic & Epic',
    prefixPrompt: 'dramatic, intense, epic cinematic trailer style',
    iconName: 'Sparkles',
  },
  {
    id: 'whisper',
    label: 'Soft Whisper',
    prefixPrompt: 'soft, intimate, whispering gently',
    iconName: 'Volume1',
  },
];

export const SAMPLE_TEXT_TEMPLATES = [
  {
    title: 'Welcome Speech',
    category: 'General',
    text: 'Welcome to our platform! We are delighted to have you join us today. Explore our interactive tools, design stunning projects, and unleash your creative potential.',
    recommendedVoice: 'Kore' as const,
    recommendedStyle: 'cheerful',
  },
  {
    title: 'Guided Meditation',
    category: 'Wellness',
    text: 'Take a deep breath in through your nose... hold for a moment... and gently exhale through your mouth. Notice the quiet stillness surrounding you right now.',
    recommendedVoice: 'Zephyr' as const,
    recommendedStyle: 'calm',
  },
  {
    title: 'Tech Product Launch',
    category: 'Business',
    text: 'Today, we are thrilled to announce our next-generation AI speech synthesis model. Faster, clearer, and remarkably lifelike across dozens of nuanced expressions.',
    recommendedVoice: 'Puck' as const,
    recommendedStyle: 'cheerful',
  },
  {
    title: 'Space Documentary',
    category: 'Educational',
    text: 'Billions of light-years away, vast nebulae give birth to thousands of newborn stars every galaxy cycle. Silent cosmic giants shaping the fabric of spacetime.',
    recommendedVoice: 'Charon' as const,
    recommendedStyle: 'dramatic',
  },
];

export const MULTI_SPEAKER_SAMPLES = [
  {
    title: 'Tech Podcast Dialogue',
    turns: [
      { id: '1', speakerName: 'Alex', voiceName: 'Puck' as const, text: "Hey Sam! Did you see the new Gemini 3.1 Flash TTS model release today?" },
      { id: '2', speakerName: 'Sam', voiceName: 'Kore' as const, text: "Yes! The multi-speaker voice synthesis sounds so natural and responsive." },
      { id: '3', speakerName: 'Alex', voiceName: 'Puck' as const, text: "Exactly! You can assign different voices to each character effortlessly." },
      { id: '4', speakerName: 'Sam', voiceName: 'Kore' as const, text: "It opens up incredible possibilities for podcasts, audiobooks, and interactive media." },
    ],
  },
  {
    title: 'Customer Support Consultation',
    turns: [
      { id: '1', speakerName: 'Customer', voiceName: 'Fenrir' as const, text: "Hello, I have a quick question about updating my account settings." },
      { id: '2', speakerName: 'Advisor', voiceName: 'Zephyr' as const, text: "I would be happy to guide you through that step by step!" },
      { id: '3', speakerName: 'Customer', voiceName: 'Fenrir' as const, text: "Great, thanks so much for your assistance." },
      { id: '4', speakerName: 'Advisor', voiceName: 'Zephyr' as const, text: "You are very welcome! Is there anything else I can help you with today?" },
    ],
  },
];

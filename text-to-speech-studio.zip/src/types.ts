export type VoiceName = 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';

export interface VoiceOption {
  name: VoiceName;
  gender: 'Male' | 'Female' | 'Neutral';
  description: string;
  recommendedStyles: string[];
}

export interface CharacterPersona {
  id: string;
  name: string;
  title: string;
  category?: 'all' | 'children' | 'girls' | 'youth' | 'elderly' | 'special';
  role: string;
  voiceName: VoiceName;
  avatar: string;
  toneStyle: string;
  samplePrompt: string;
}

export interface StylePreset {
  id: string;
  label: string;
  prefixPrompt: string;
  iconName: string;
}

export interface DialogueTurn {
  id: string;
  speakerName: string;
  voiceName: VoiceName;
  text: string;
}

export interface TTSRequest {
  mode: 'single' | 'multi';
  text?: string;
  voiceName?: VoiceName;
  stylePrompt?: string;
  turns?: { speaker: string; voiceName: VoiceName; text: string }[];
}

export interface TTSResponse {
  audioBase64: string;
  mimeType: string;
  durationEstimateSeconds?: number;
  sampleRate?: number;
}

export interface AudioHistoryItem {
  id: string;
  title: string;
  mode: 'single' | 'multi';
  textPreview: string;
  voicesUsed: VoiceName[];
  audioBase64: string;
  mimeType: string;
  createdAt: number;
}

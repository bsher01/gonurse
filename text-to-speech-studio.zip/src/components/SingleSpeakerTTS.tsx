import React, { useState } from 'react';
import { Play, Sparkles, Mic, Wand2, Volume2, HelpCircle, Check, Loader2, Users, Plus, Search } from 'lucide-react';
import { GEMINI_VOICES, STYLE_PRESETS, SAMPLE_TEXT_TEMPLATES, ALL_PERSONAS_LIST } from '../data/voices';
import { VoiceName, CharacterPersona } from '../types';

interface SingleSpeakerTTSProps {
  onGenerate: (text: string, voiceName: VoiceName, stylePrompt?: string) => Promise<void>;
  isLoading: boolean;
}

export const SingleSpeakerTTS: React.FC<SingleSpeakerTTSProps> = ({
  onGenerate,
  isLoading,
}) => {
  const [selectedVoice, setSelectedVoice] = useState<VoiceName>('Kore');
  const [selectedStyleId, setSelectedStyleId] = useState<string>('cheerful');
  const [customStyle, setCustomStyle] = useState<string>('');
  const [selectedPersonaId, setSelectedPersonaId] = useState<string | null>('p_layla');

  // Personas Filtering & Search
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Custom Personas created by the user
  const [customPersonas, setCustomPersonas] = useState<CharacterPersona[]>([]);
  const [showCreatePersona, setShowCreatePersona] = useState(false);
  const [newPersonaName, setNewPersonaName] = useState('');
  const [newPersonaRole, setNewPersonaRole] = useState('');
  const [newPersonaAvatar, setNewPersonaAvatar] = useState('🎭');

  const [text, setText] = useState<string>(SAMPLE_TEXT_TEMPLATES[0].text);

  const activeStyle = STYLE_PRESETS.find((s) => s.id === selectedStyleId);
  const allPersonas = [...customPersonas, ...ALL_PERSONAS_LIST];

  // Filter personas by Category and Search Query
  const filteredPersonas = allPersonas.filter((p) => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.role.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const activePersona = allPersonas.find((p) => p.id === selectedPersonaId);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!text.trim() || isLoading) return;

    const stylePrompt = customStyle.trim()
      ? customStyle.trim()
      : activeStyle
      ? activeStyle.prefixPrompt
      : undefined;

    onGenerate(text, selectedVoice, stylePrompt);
  };

  const handleSelectPersona = (persona: CharacterPersona) => {
    setSelectedPersonaId(persona.id);
    setSelectedVoice(persona.voiceName);
    setCustomStyle(persona.toneStyle);
    setText(persona.samplePrompt);
    setSelectedStyleId('');
  };

  const handleCreateCustomPersona = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersonaName.trim()) return;

    const createdPersona: CharacterPersona = {
      id: `custom_${Date.now()}`,
      name: newPersonaName.trim(),
      title: newPersonaRole.trim() || 'شخصية مخصصة',
      category: 'special',
      role: newPersonaRole.trim() || 'Custom Persona',
      voiceName: selectedVoice,
      avatar: newPersonaAvatar || '🎭',
      toneStyle: customStyle.trim() || 'clear, articulate, natural voice',
      samplePrompt: text.trim() || 'مرحباً بك! هذه نبرتي المخصصة الجديدة.',
    };

    setCustomPersonas([...customPersonas, createdPersona]);
    handleSelectPersona(createdPersona);
    setShowCreatePersona(false);
    setNewPersonaName('');
    setNewPersonaRole('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* 0. 100+ Personas Selection Box (شخصيات الأطفال، البنات، الشباب، كبار السن) */}
      <div className="space-y-4 bg-slate-900/95 border border-indigo-500/50 rounded-2xl p-4 sm:p-5 shadow-2xl shadow-indigo-950/40">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-purple-400" />
            <h3 className="text-sm font-bold text-slate-100">
              اختر من بين (112 شخصية) - أطفال، بنات، شباب، كبار السن
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowCreatePersona(!showCreatePersona)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-900/70 hover:bg-purple-800 text-purple-200 border border-purple-600/80 rounded-xl text-xs font-semibold transition-colors shadow-md"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>إضافة شخصيتك المخصصة</span>
            </button>

            <span className="text-xs text-indigo-200 font-bold bg-indigo-950/80 px-3 py-1 rounded-full border border-indigo-700/80 font-mono">
              {filteredPersonas.length} من {allPersonas.length} شخصية
            </span>
          </div>
        </div>

        {/* Categories Filter Tabs & Search Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2 border-t border-slate-800">
          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {[
              { id: 'all', label: 'الكل (112)', icon: '🌟' },
              { id: 'children', label: '👧 أطفال (20)', icon: '👧' },
              { id: 'girls', label: '👩 بنات وشابات (27)', icon: '👩' },
              { id: 'youth', label: '👦 شباب (28)', icon: '👦' },
              { id: 'elderly', label: '👴 كبار السن والعجزة (21)', icon: '👴' },
              { id: 'special', label: '✨ شخصيات خاصة (12)', icon: '✨' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1 ${
                  activeCategory === cat.id
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/40 font-bold border border-purple-400'
                    : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative shrink-0 sm:w-56">
            <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="ابحث عن اسم شخصية..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500 shadow-inner"
            />
          </div>
        </div>

        {/* Personas Cards Scrollable Grid */}
        {filteredPersonas.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-xs bg-slate-950/60 rounded-xl border border-slate-800/80">
            لا توجد شخصيات مطابقة للبحث. جرب البحث باسم آخر أو تغيير الفئة.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 max-h-[400px] overflow-y-auto pr-1">
            {filteredPersonas.map((persona) => {
              const isSelected = selectedPersonaId === persona.id;
              return (
                <button
                  key={persona.id}
                  type="button"
                  onClick={() => handleSelectPersona(persona)}
                  className={`p-3 rounded-xl border text-center transition-all flex flex-col items-center gap-1 relative group ${
                    isSelected
                      ? 'bg-purple-950/90 border-purple-400 text-white shadow-xl shadow-purple-950/80 ring-2 ring-purple-500/80'
                      : 'bg-slate-950/80 border-slate-800/90 text-slate-300 hover:bg-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <span className="text-2xl mb-0.5 group-hover:scale-110 transition-transform">
                    {persona.avatar}
                  </span>
                  <span className="text-xs font-bold leading-tight line-clamp-1">
                    {persona.name}
                  </span>
                  <span className="text-[10px] text-slate-400 line-clamp-1">{persona.title}</span>
                  {isSelected && (
                    <span className="absolute top-1.5 right-1.5 h-2.5 w-2.5 rounded-full bg-purple-400 animate-pulse shadow-sm shadow-purple-300" />
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* Selected Active Persona Info Banner */}
        {activePersona && (
          <div className="p-3 bg-slate-950 border border-purple-500/40 rounded-xl flex items-center justify-between gap-3 text-xs shadow-inner">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{activePersona.avatar}</span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-100 text-sm">{activePersona.name}</span>
                  <span className="text-[10px] bg-purple-950 text-purple-200 border border-purple-800 px-2 py-0.5 rounded-full font-medium">
                    {activePersona.title}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  الصوت الأساسي: <strong className="text-indigo-300">{activePersona.voiceName}</strong> • النبرة: {activePersona.toneStyle}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Create Custom Persona Form */}
        {showCreatePersona && (
          <div className="p-4 bg-slate-950 border border-purple-500/60 rounded-xl space-y-3 shadow-lg">
            <h4 className="text-xs font-bold text-purple-300 flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5" />
              إنشاء شخصية جديدة خاصة بك / Add New Persona
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">اسم الشخصية</label>
                <input
                  type="text"
                  placeholder="مثال: الطفل زياد"
                  value={newPersonaName}
                  onChange={(e) => setNewPersonaName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">الوصف أو الوظيفة</label>
                <input
                  type="text"
                  placeholder="مثال: طفل مرح يحب القصص"
                  value={newPersonaRole}
                  onChange={(e) => setNewPersonaRole(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">الرمز (Emoji)</label>
                <select
                  value={newPersonaAvatar}
                  onChange={(e) => setNewPersonaAvatar(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-100 focus:outline-none focus:border-purple-500"
                >
                  <option value="👧">👧 طفلة</option>
                  <option value="👦">👦 طفل</option>
                  <option value="👵">👵 جدة</option>
                  <option value="👴">👴 جد</option>
                  <option value="👩">👩 شابة</option>
                  <option value="👨">👨 شاب</option>
                  <option value="🎭">🎭 ممثل</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowCreatePersona(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg text-xs"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleCreateCustomPersona}
                className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold shadow-md"
              >
                حفظ الشخصية
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 1. Base Voices Selector (Kore, Puck, Charon, Fenrir, Zephyr) */}
      <div className="space-y-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Mic className="h-4 w-4 text-indigo-400" />
            <span>الأصوات الخمسة الأساسية للذكاء الاصطناعي (Gemini Base Voices)</span>
          </label>
          <span className="text-xs text-slate-400">5 الأصوات الأساسية المحركة للشخصيات</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {GEMINI_VOICES.map((voice) => {
            const isSelected = selectedVoice === voice.name;
            return (
              <button
                key={voice.name}
                type="button"
                onClick={() => setSelectedVoice(voice.name)}
                className={`relative text-left p-3.5 rounded-xl border transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-indigo-950/80 border-indigo-500 shadow-lg shadow-indigo-950/50 ring-1 ring-indigo-500/50'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-slate-100">{voice.name}</span>
                    <span
                      className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${
                        voice.gender === 'Female'
                          ? 'bg-pink-950/80 text-pink-300 border-pink-800/60'
                          : voice.gender === 'Male'
                          ? 'bg-blue-950/80 text-blue-300 border-blue-800/60'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {voice.gender}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-snug line-clamp-2 mt-1">
                    {voice.description}
                  </p>
                </div>

                {isSelected && (
                  <div className="absolute top-2 right-2 h-4 w-4 rounded-full bg-indigo-500 text-white flex items-center justify-center">
                    <Check className="h-2.5 w-2.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Style / Tone Modifiers */}
      <div className="space-y-3 bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Wand2 className="h-4 w-4 text-purple-400" />
            <span>Style & Expressive Tone</span>
          </label>
          <span className="text-xs text-slate-400">Guides emotional delivery</span>
        </div>

        {/* Preset Chips */}
        <div className="flex flex-wrap items-center gap-2">
          {STYLE_PRESETS.map((style) => {
            const isSelected = selectedStyleId === style.id && !customStyle;
            return (
              <button
                key={style.id}
                type="button"
                onClick={() => {
                  setSelectedStyleId(style.id);
                  setCustomStyle('');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                  isSelected
                    ? 'bg-purple-600 text-white border-purple-500 shadow-md shadow-purple-600/20'
                    : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                {style.label}
              </button>
            );
          })}
        </div>

        {/* Custom Style Input */}
        <div className="mt-2">
          <input
            type="text"
            placeholder="Or type custom tone (e.g. whispering excitedly, energetic sportscaster)..."
            value={customStyle}
            onChange={(e) => setCustomStyle(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
      </div>

      {/* 3. Text Prompt Input */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Volume2 className="h-4 w-4 text-indigo-400" />
            <span>Script Text</span>
          </label>

          {/* Preset Sample Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 hidden sm:inline">Samples:</span>
            <select
              onChange={(e) => {
                const sample = SAMPLE_TEXT_TEMPLATES.find((s) => s.title === e.target.value);
                if (sample) {
                  setText(sample.text);
                  setSelectedVoice(sample.recommendedVoice);
                  setSelectedStyleId(sample.recommendedStyle);
                  setCustomStyle('');
                }
              }}
              defaultValue=""
              className="bg-slate-900 border border-slate-800 text-xs text-slate-300 rounded-lg px-2.5 py-1 focus:outline-none focus:border-indigo-500"
            >
              <option value="" disabled>
                Load Sample Prompt...
              </option>
              {SAMPLE_TEXT_TEMPLATES.map((tmpl) => (
                <option key={tmpl.title} value={tmpl.title}>
                  {tmpl.title} ({tmpl.category})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative">
          <textarea
            rows={5}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type or paste the text you want Gemini to convert into natural speech..."
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500/80 focus:ring-1 focus:ring-indigo-500/80 transition-all resize-y min-h-[120px]"
          />

          <div className="flex items-center justify-between text-xs text-slate-500 px-2 mt-1">
            <span>Press Cmd/Ctrl + Enter to generate</span>
            <span>
              {text.length} chars • {text.trim() ? text.trim().split(/\s+/).length : 0} words
            </span>
          </div>
        </div>
      </div>

      {/* 4. Generate Action Button */}
      <button
        type="submit"
        disabled={isLoading || !text.trim()}
        className={`w-full py-3.5 px-6 rounded-xl font-medium text-sm flex items-center justify-center gap-2 shadow-xl transition-all ${
          isLoading || !text.trim()
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
            : 'bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-indigo-600/30 active:scale-[0.99]'
        }`}
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin text-white" />
            <span>Synthesizing Speech with Gemini...</span>
          </>
        ) : (
          <>
            <Sparkles className="h-4 w-4 text-indigo-200" />
            <span>Generate Speech Audio</span>
          </>
        )}
      </button>
    </form>
  );
};


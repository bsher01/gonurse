import React from 'react';
import { History, Play, Download, Trash2, X, Volume2 } from 'lucide-react';
import { AudioHistoryItem } from '../types';
import { downloadAudioBlob, processAudioData } from '../lib/audioUtils';

interface HistoryListProps {
  history: AudioHistoryItem[];
  onSelectHistoryItem: (item: AudioHistoryItem) => void;
  onClearHistory: () => void;
  onClose: () => void;
}

export const HistoryList: React.FC<HistoryListProps> = ({
  history,
  onSelectHistoryItem,
  onClearHistory,
  onClose,
}) => {
  const handleDownload = (e: React.MouseEvent, item: AudioHistoryItem) => {
    e.stopPropagation();
    const { blob } = processAudioData(item.audioBase64, item.mimeType);
    const filename = `${item.title.replace(/[^a-zA-Z0-9_\-]/g, '_').substring(0, 25)}.wav`;
    downloadAudioBlob(blob, filename);
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' • ' + d.toLocaleDateString();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <History className="h-4 w-4 text-indigo-400" />
          <h3 className="font-semibold text-sm text-slate-100">Generation History ({history.length})</h3>
        </div>

        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button
              onClick={onClearHistory}
              className="text-xs text-rose-400 hover:text-rose-300 px-2 py-1 hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1"
            >
              <Trash2 className="h-3 w-3" />
              <span>Clear</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {history.length === 0 ? (
        <div className="py-8 text-center text-slate-500 text-xs">
          No generated clips in history yet. Synthesize speech to save audio clips here.
        </div>
      ) : (
        <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
          {history.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectHistoryItem(item)}
              className="group p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900/60 transition-all cursor-pointer flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="h-8 w-8 rounded-full bg-indigo-950 border border-indigo-800/60 text-indigo-400 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  <Play className="h-3.5 w-3.5 fill-current ml-0.5" />
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-xs text-slate-200 truncate">{item.title}</span>
                    <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950 px-1.5 py-0.2 rounded border border-indigo-900">
                      {item.mode}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{item.textPreview}</p>
                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{formatDate(item.createdAt)}</p>
                </div>
              </div>

              <button
                onClick={(e) => handleDownload(e, item)}
                title="Download WAV"
                className="p-1.5 text-slate-400 hover:text-indigo-300 hover:bg-slate-800 rounded-lg shrink-0 transition-colors"
              >
                <Download className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

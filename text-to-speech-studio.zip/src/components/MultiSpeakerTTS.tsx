import React, { useState } from 'react';
import { MessageSquare, Plus, Trash2, Users, Sparkles, Loader2, ArrowUpDown } from 'lucide-react';
import { GEMINI_VOICES, MULTI_SPEAKER_SAMPLES } from '../data/voices';
import { DialogueTurn, VoiceName } from '../types';

interface MultiSpeakerTTSProps {
  onGenerateMulti: (turns: { speaker: string; voiceName: VoiceName; text: string }[]) => Promise<void>;
  isLoading: boolean;
}

export const MultiSpeakerTTS: React.FC<MultiSpeakerTTSProps> = ({
  onGenerateMulti,
  isLoading,
}) => {
  // Default Speaker Settings
  const [speaker1, setSpeaker1] = useState<{ name: string; voice: VoiceName }>({
    name: 'Alex',
    voice: 'Puck',
  });

  const [speaker2, setSpeaker2] = useState<{ name: string; voice: VoiceName }>({
    name: 'Sam',
    voice: 'Kore',
  });

  // Conversation turns
  const [turns, setTurns] = useState<DialogueTurn[]>([
    {
      id: '1',
      speakerName: 'Alex',
      voiceName: 'Puck',
      text: 'Hey Sam! Did you hear about the new Gemini 3.1 Flash TTS model release?',
    },
    {
      id: '2',
      speakerName: 'Sam',
      voiceName: 'Kore',
      text: 'Yes! The speech synthesis produces remarkably natural multi-speaker dialogues.',
    },
    {
      id: '3',
      speakerName: 'Alex',
      voiceName: 'Puck',
      text: 'We can effortlessly generate entire conversations with distinct voice personas!',
    },
    {
      id: '4',
      speakerName: 'Sam',
      voiceName: 'Kore',
      text: 'That is awesome. Let us synthesize this clip right now.',
    },
  ]);

  const handleAddTurn = (defaultSpeaker: '1' | '2') => {
    const spk = defaultSpeaker === '1' ? speaker1 : speaker2;
    const newTurn: DialogueTurn = {
      id: Date.now().toString(),
      speakerName: spk.name,
      voiceName: spk.voice,
      text: '',
    };
    setTurns([...turns, newTurn]);
  };

  const handleRemoveTurn = (id: string) => {
    if (turns.length <= 2) {
      alert('A multi-speaker dialogue requires at least 2 turns.');
      return;
    }
    setTurns(turns.filter((t) => t.id !== id));
  };

  const handleUpdateTurn = (id: string, field: keyof DialogueTurn, value: string) => {
    setTurns(
      turns.map((t) => {
        if (t.id === id) {
          if (field === 'speakerName') {
            // Automatically match voice name if speaker matches speaker1 or speaker2
            const matchedVoice =
              value.trim().toLowerCase() === speaker1.name.trim().toLowerCase()
                ? speaker1.voice
                : value.trim().toLowerCase() === speaker2.name.trim().toLowerCase()
                ? speaker2.voice
                : t.voiceName;
            return { ...t, speakerName: value, voiceName: matchedVoice };
          }
          return { ...t, [field]: value };
        }
        return t;
      })
    );
  };

  const handleLoadSample = (sampleTitle: string) => {
    const sample = MULTI_SPEAKER_SAMPLES.find((s) => s.title === sampleTitle);
    if (sample) {
      const spkNames = Array.from(new Set(sample.turns.map((t) => t.speakerName)));
      if (spkNames.length >= 2) {
        const firstTurnSpk1 = sample.turns.find((t) => t.speakerName === spkNames[0]);
        const firstTurnSpk2 = sample.turns.find((t) => t.speakerName === spkNames[1]);
        setSpeaker1({
          name: spkNames[0],
          voice: firstTurnSpk1?.voiceName || 'Puck',
        });
        setSpeaker2({
          name: spkNames[1],
          voice: firstTurnSpk2?.voiceName || 'Kore',
        });
      }

      setTurns(
        sample.turns.map((t, idx) => ({
          id: (idx + 1).toString(),
          speakerName: t.speakerName,
          voiceName: t.voiceName,
          text: t.text,
        }))
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    // Validate turn content
    const validTurns = turns.filter((t) => t.text.trim().length > 0);
    if (validTurns.length < 2) {
      alert('Please fill in text for at least 2 turns before generating.');
      return;
    }

    const payload = validTurns.map((t) => ({
      speaker: t.speakerName.trim() || 'Speaker',
      voiceName: t.voiceName,
      text: t.text.trim(),
    }));

    onGenerateMulti(payload);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Speaker Roles & Voices Config */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-200">Conversation Speakers Configuration</h3>
          </div>

          {/* Sample Dialogue Preset */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 hidden sm:inline">Preset Dialogues:</span>
            <select
              onChange={(e) => handleLoadSample(e.target.value)}
              defaultValue=""
              className="bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-lg px-2.5 py-1 focus:outline-none focus:border-indigo-500"
            >
              <option value="" disabled>
                Load Sample Dialogue...
              </option>
              {MULTI_SPEAKER_SAMPLES.map((s) => (
                <option key={s.title} value={s.title}>
                  {s.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Speaker 1 */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-medium text-indigo-400">
              <span>Speaker 1</span>
              <span className="bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded-md border border-indigo-800/50">Role A</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={speaker1.name}
                  onChange={(e) => {
                    const newName = e.target.value;
                    const oldName = speaker1.name;
                    setSpeaker1({ ...speaker1, name: newName });
                    // Update turn speaker names if they matched old name
                    setTurns(
                      turns.map((t) => (t.speakerName === oldName ? { ...t, speakerName: newName } : t))
                    );
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Voice Persona</label>
                <select
                  value={speaker1.voice}
                  onChange={(e) => {
                    const v = e.target.value as VoiceName;
                    setSpeaker1({ ...speaker1, voice: v });
                    setTurns(
                      turns.map((t) => (t.speakerName === speaker1.name ? { ...t, voiceName: v } : t))
                    );
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  {GEMINI_VOICES.map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.gender})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Speaker 2 */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between text-xs font-medium text-pink-400">
              <span>Speaker 2</span>
              <span className="bg-pink-950 text-pink-300 px-2 py-0.5 rounded-md border border-pink-800/50">Role B</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={speaker2.name}
                  onChange={(e) => {
                    const newName = e.target.value;
                    const oldName = speaker2.name;
                    setSpeaker2({ ...speaker2, name: newName });
                    setTurns(
                      turns.map((t) => (t.speakerName === oldName ? { ...t, speakerName: newName } : t))
                    );
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Voice Persona</label>
                <select
                  value={speaker2.voice}
                  onChange={(e) => {
                    const v = e.target.value as VoiceName;
                    setSpeaker2({ ...speaker2, voice: v });
                    setTurns(
                      turns.map((t) => (t.speakerName === speaker2.name ? { ...t, voiceName: v } : t))
                    );
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                >
                  {GEMINI_VOICES.map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.gender})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dialogue Script Turns */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-indigo-400" />
            <span>Dialogue Script Turns ({turns.length})</span>
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleAddTurn('1')}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
            >
              <Plus className="h-3 w-3" />
              <span>Add {speaker1.name} Turn</span>
            </button>
            <button
              type="button"
              onClick={() => handleAddTurn('2')}
              className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-pink-300 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
            >
              <Plus className="h-3 w-3" />
              <span>Add {speaker2.name} Turn</span>
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {turns.map((turn, index) => {
            const isSpk1 = turn.speakerName === speaker1.name;
            return (
              <div
                key={turn.id}
                className={`p-3.5 rounded-2xl border transition-all space-y-2 ${
                  isSpk1
                    ? 'bg-indigo-950/20 border-indigo-900/60'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-slate-500">#{index + 1}</span>
                    <select
                      value={turn.speakerName}
                      onChange={(e) => handleUpdateTurn(turn.id, 'speakerName', e.target.value)}
                      className="bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-200 rounded-lg px-2.5 py-1 focus:outline-none focus:border-indigo-500"
                    >
                      <option value={speaker1.name}>{speaker1.name}</option>
                      <option value={speaker2.name}>{speaker2.name}</option>
                    </select>

                    <span className="text-[10px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 font-mono">
                      Voice: {turn.voiceName}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveTurn(turn.id)}
                    title="Delete turn"
                    className="text-slate-500 hover:text-rose-400 p-1 rounded-lg hover:bg-slate-800 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>

                <textarea
                  rows={2}
                  value={turn.text}
                  onChange={(e) => handleUpdateTurn(turn.id, 'text', e.target.value)}
                  placeholder={`Type dialogue for ${turn.speakerName}...`}
                  className="w-full bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/80 transition-all resize-y"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Generate Multi-Speaker Speech Button */}
      <button
        type="submit"
        disabled={isLoading || turns.length < 2}
        className={`w-full py-3.5 px-6 rounded-xl font-medium text-sm flex items-center justify-center gap-2 shadow-xl transition-all ${
          isLoading || turns.length < 2
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
            : 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white shadow-indigo-600/30 active:scale-[0.99]'
        }`}
      >
        {isLoading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin text-white" />
            <span>Synthesizing Multi-Speaker Audio...</span>
          </>
        ) : (
          <>
            <Sparkles className="h-4 w-4 text-indigo-200" />
            <span>Synthesize Conversation Audio</span>
          </>
        )}
      </button>
    </form>
  );
};

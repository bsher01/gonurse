import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { SingleSpeakerTTS } from './components/SingleSpeakerTTS';
import { MultiSpeakerTTS } from './components/MultiSpeakerTTS';
import { AudioPlayer } from './components/AudioPlayer';
import { HistoryList } from './components/HistoryList';
import { AudioHistoryItem, VoiceName } from './types';
import { processAudioData } from './lib/audioUtils';
import { Sparkles, AlertCircle, Volume2, ShieldCheck, Zap } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'single' | 'multi'>('single');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active audio player state
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioTitle, setAudioTitle] = useState<string>('Welcome Speech');
  const [voicesUsed, setVoicesUsed] = useState<string[]>(['Kore']);

  // History & Drawer state
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<AudioHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('tts_studio_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tts_studio_history', JSON.stringify(history.slice(0, 20)));
    } catch (e) {
      console.warn('Could not save history to localStorage', e);
    }
  }, [history]);

  // Handle single speaker generation
  const handleGenerateSingle = async (
    text: string,
    voiceName: VoiceName,
    stylePrompt?: string
  ) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'single',
          text,
          voiceName,
          stylePrompt,
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to generate speech audio.');
      }

      const { blobUrl, blob } = processAudioData(data.audioBase64, data.mimeType);

      const titleSnippet = text.length > 32 ? `${text.substring(0, 32)}...` : text;
      setAudioBlobUrl(blobUrl);
      setAudioBlob(blob);
      setAudioTitle(titleSnippet);
      setVoicesUsed([voiceName]);

      // Add to history
      const newItem: AudioHistoryItem = {
        id: Date.now().toString(),
        title: titleSnippet,
        mode: 'single',
        textPreview: text,
        voicesUsed: [voiceName],
        audioBase64: data.audioBase64,
        mimeType: data.mimeType,
        createdAt: Date.now(),
      };

      setHistory((prev) => [newItem, ...prev]);
    } catch (err: any) {
      console.error('TTS Generation error:', err);
      setErrorMessage(err.message || 'An error occurred during audio synthesis.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle multi-speaker conversation generation
  const handleGenerateMulti = async (
    turns: { speaker: string; voiceName: VoiceName; text: string }[]
  ) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'multi',
          turns,
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to generate multi-speaker audio.');
      }

      const { blobUrl, blob } = processAudioData(data.audioBase64, data.mimeType);

      const uniqueVoices = Array.from(new Set(turns.map((t) => t.voiceName)));
      const titleSnippet = `Dialogue (${turns[0].speaker} & ${turns[1]?.speaker || 'Speaker'})`;

      setAudioBlobUrl(blobUrl);
      setAudioBlob(blob);
      setAudioTitle(titleSnippet);
      setVoicesUsed(uniqueVoices);

      // Add to history
      const newItem: AudioHistoryItem = {
        id: Date.now().toString(),
        title: titleSnippet,
        mode: 'multi',
        textPreview: turns.map((t) => `${t.speaker}: ${t.text}`).join(' | '),
        voicesUsed: uniqueVoices,
        audioBase64: data.audioBase64,
        mimeType: data.mimeType,
        createdAt: Date.now(),
      };

      setHistory((prev) => [newItem, ...prev]);
    } catch (err: any) {
      console.error('Multi-TTS error:', err);
      setErrorMessage(err.message || 'An error occurred during multi-speaker audio synthesis.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectHistoryItem = (item: AudioHistoryItem) => {
    const { blobUrl, blob } = processAudioData(item.audioBase64, item.mimeType);
    setAudioBlobUrl(blobUrl);
    setAudioBlob(blob);
    setAudioTitle(item.title);
    setVoicesUsed(item.voicesUsed);
    setShowHistory(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        historyCount={history.length}
        onToggleHistory={() => setShowHistory(!showHistory)}
        showHistory={showHistory}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-8 space-y-8">
        {/* Error Banner */}
        {errorMessage && (
          <div className="bg-rose-950/80 border border-rose-800 text-rose-200 px-4 py-3 rounded-xl text-xs flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-rose-400 hover:text-rose-100 text-xs font-semibold"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* History Slide-down panel */}
        {showHistory && (
          <HistoryList
            history={history}
            onSelectHistoryItem={handleSelectHistoryItem}
            onClearHistory={() => setHistory([])}
            onClose={() => setShowHistory(false)}
          />
        )}

        {/* Audio Player Card Section */}
        <section>
          <AudioPlayer
            audioBlobUrl={audioBlobUrl}
            audioBlob={audioBlob}
            title={audioTitle}
            voicesUsed={voicesUsed}
          />
        </section>

        {/* Workspace Form Section */}
        <section className="bg-slate-900/40 border border-slate-800/80 rounded-3xl p-6 sm:p-8 backdrop-blur-sm shadow-xl">
          <div className="mb-6 flex items-center justify-between border-b border-slate-800/80 pb-4">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                {activeTab === 'single' ? (
                  <>
                    <Volume2 className="h-5 w-5 text-indigo-400" />
                    <span>Single Voice Speech Synthesizer</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-5 w-5 text-pink-400" />
                    <span>Multi-Speaker Conversation Synthesizer</span>
                  </>
                )}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Powered by Gemini 3.1 Flash TTS model with high quality voice expression control
              </p>
            </div>

            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-full border border-slate-800">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
              <span>Server-side API Protection</span>
            </div>
          </div>

          {activeTab === 'single' ? (
            <SingleSpeakerTTS onGenerate={handleGenerateSingle} isLoading={isLoading} />
          ) : (
            <MultiSpeakerTTS onGenerateMulti={handleGenerateMulti} isLoading={isLoading} />
          )}
        </section>

        {/* Capability Feature Highlights */}
        <footer className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-900 text-xs text-slate-400">
          <div className="flex items-start gap-3 p-3 bg-slate-900/30 rounded-xl border border-slate-800/50">
            <Zap className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-300">Ultra Low Latency</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Fast audio generation with gemini-3.1-flash-tts-preview.</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 bg-slate-900/30 rounded-xl border border-slate-800/50">
            <Volume2 className="h-4 w-4 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-300">5 Distinct Personas</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Puck, Charon, Kore, Fenrir, and Zephyr built-in voices.</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 bg-slate-900/30 rounded-xl border border-slate-800/50">
            <Sparkles className="h-4 w-4 text-pink-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-300">Multi-Speaker Dialogues</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Synthesize multi-turn conversations between two distinct voices.</p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}

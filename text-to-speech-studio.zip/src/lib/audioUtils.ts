/**
 * Converts PCM base64 string to a playable WAV Blob URL.
 * Gemini TTS returns 24kHz 16-bit mono PCM audio data by default when response modality is AUDIO.
 */
export function processAudioData(base64Data: string, mimeType: string = 'audio/pcm;rate=24000'): { blobUrl: string; blob: Blob } {
  // If the MIME type is already audio/wav or audio/mp3 with valid container header
  if (mimeType.includes('audio/wav') || mimeType.includes('audio/mp3') || mimeType.includes('audio/mpeg')) {
    const binary = atob(base64Data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: mimeType });
    return {
      blobUrl: URL.createObjectURL(blob),
      blob,
    };
  }

  // Parse sample rate if specified in mimeType e.g., 'audio/pcm;rate=24000'
  let sampleRate = 24000;
  const match = mimeType.match(/rate=(\d+)/);
  if (match && match[1]) {
    sampleRate = parseInt(match[1], 10);
  }

  // Raw PCM data -> Wrap with 44-byte RIFF WAV header
  const binary = atob(base64Data);
  const pcmLength = binary.length;
  const pcmBytes = new Uint8Array(pcmLength);
  for (let i = 0; i < pcmLength; i++) {
    pcmBytes[i] = binary.charCodeAt(i);
  }

  const numChannels = 1; // Mono
  const bitDepth = 16;   // 16-bit signed integer PCM

  const header = new ArrayBuffer(44);
  const view = new DataView(header);

  // "RIFF"
  view.setUint32(0, 0x52494646, false);
  // Total file size minus 8
  view.setUint32(4, 36 + pcmLength, true);
  // "WAVE"
  view.setUint32(8, 0x57415645, false);
  // "fmt " chunk
  view.setUint32(12, 0x666d7420, false);
  // Subchunk1Size (16 for PCM)
  view.setUint32(16, 16, true);
  // AudioFormat (1 for PCM)
  view.setUint16(20, 1, true);
  // NumChannels
  view.setUint16(22, numChannels, true);
  // SampleRate
  view.setUint32(24, sampleRate, true);
  // ByteRate = SampleRate * NumChannels * BitsPerSample/8
  view.setUint32(28, sampleRate * numChannels * (bitDepth / 8), true);
  // BlockAlign = NumChannels * BitsPerSample/8
  view.setUint16(32, numChannels * (bitDepth / 8), true);
  // BitsPerSample
  view.setUint16(34, bitDepth, true);
  // "data" chunk
  view.setUint32(36, 0x64617461, false);
  // Subchunk2Size
  view.setUint32(40, pcmLength, true);

  const wavBytes = new Uint8Array(44 + pcmLength);
  wavBytes.set(new Uint8Array(header), 0);
  wavBytes.set(pcmBytes, 44);

  const blob = new Blob([wavBytes], { type: 'audio/wav' });
  return {
    blobUrl: URL.createObjectURL(blob),
    blob,
  };
}

export function downloadAudioBlob(blob: Blob, filename: string = 'tts-speech.wav') {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

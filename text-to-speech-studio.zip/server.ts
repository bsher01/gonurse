import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // Shared Gemini client instance
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Text-to-Speech API route using gemini-3.1-flash-tts-preview
  app.post("/api/tts", async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { mode, text, voiceName = "Kore", stylePrompt, turns } = req.body;

      if (mode === "single") {
        if (!text || typeof text !== "string" || text.trim().length === 0) {
          return res.status(400).json({ error: "Text prompt is required." });
        }

        const formattedText = stylePrompt && stylePrompt.trim() 
          ? `Say in a ${stylePrompt.trim()} tone: ${text.trim()}`
          : text.trim();

        const response = await ai.models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text: formattedText }] }],
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: voiceName || "Kore",
                },
              },
            },
          },
        });

        const part = response.candidates?.[0]?.content?.parts?.[0];
        const audioBase64 = part?.inlineData?.data;
        const mimeType = part?.inlineData?.mimeType || "audio/pcm;rate=24000";

        if (!audioBase64) {
          console.error("Gemini TTS response missing audio inlineData:", JSON.stringify(response, null, 2));
          return res.status(500).json({ error: "Failed to generate speech audio from Gemini TTS model." });
        }

        return res.json({
          audioBase64,
          mimeType,
        });
      } else if (mode === "multi") {
        if (!turns || !Array.isArray(turns) || turns.length < 2) {
          return res.status(400).json({ error: "Multi-speaker mode requires at least 2 dialogue turns." });
        }

        // Map speakers to voice configs (Exactly 2 unique speakers supported by Gemini multi-speaker config)
        const speakerVoiceMap = new Map<string, string>();
        for (const t of turns) {
          if (!speakerVoiceMap.has(t.speaker)) {
            speakerVoiceMap.set(t.speaker, t.voiceName || "Kore");
          }
        }

        const uniqueSpeakers = Array.from(speakerVoiceMap.keys());
        if (uniqueSpeakers.length < 2) {
          return res.status(400).json({ error: "Multi-speaker TTS requires at least 2 distinct speaker names (e.g. Alex and Sam)." });
        }

        // Format conversation prompt
        const conversationText = turns
          .map((turn) => `${turn.speaker}: ${turn.text}`)
          .join("\n");

        const prompt = `TTS the following conversation between ${uniqueSpeakers.join(" and ")}:\n${conversationText}`;

        const speakerVoiceConfigs = uniqueSpeakers.slice(0, 2).map((speaker) => ({
          speaker,
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: speakerVoiceMap.get(speaker) || "Kore",
            },
          },
        }));

        const response = await ai.models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text: prompt }] }],
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs,
              },
            },
          },
        });

        const part = response.candidates?.[0]?.content?.parts?.[0];
        const audioBase64 = part?.inlineData?.data;
        const mimeType = part?.inlineData?.mimeType || "audio/pcm;rate=24000";

        if (!audioBase64) {
          console.error("Gemini Multi-TTS response missing audio:", JSON.stringify(response, null, 2));
          return res.status(500).json({ error: "Failed to generate multi-speaker speech audio." });
        }

        return res.json({
          audioBase64,
          mimeType,
        });
      } else {
        return res.status(400).json({ error: "Invalid mode specified. Must be 'single' or 'multi'." });
      }
    } catch (err: any) {
      console.error("Error generating speech:", err);
      return res.status(500).json({
        error: err.message || "An error occurred while calling the Gemini TTS service.",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`TTS Studio server running on http://localhost:${PORT}`);
  });
}

startServer();
